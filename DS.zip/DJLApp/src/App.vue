<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'

export default {
  name: 'app',
  computed: {},
  mounted() {
    this.autoRem();
    this.h5Init();
    this.getCal2();
    this.getLoginState();
  },
  methods: {
    ...mapActions(["getCal2", "getLoginState"]),
    h5Init() {
      var oMeta = document.createElement('meta');
      oMeta.name = 'viewport'
      oMeta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'
      document.getElementsByTagName('head')[0].appendChild(oMeta)
      document.getElementsByTagName('body')[0].style.width = 'auto'
    },
    autoRem() {
      var designWidth = 650
      var curWidth = screen.width;
      var htmlEl = document.getElementsByTagName('html')[0];

      if (curWidth >= designWidth) {
        htmlEl.style.fontSize = '625%';
        htmlEl.style.width = designWidth + 'px';
        htmlEl.style.margin = 'auto';
      } else {
        htmlEl.style.fontSize = curWidth / designWidth * 625 + '%';
      }
    }
  }
}

</script>

<style>
html {
  font-size: 100px;
}

body,
ul,
p,
a,
div,
img {
  margin: 0;
  padding: 0;
}

li {
  list-style: none;
}

a {
  text-decoration: none;
  color: #5a5a5a;
  cursor: pointer;
}

.box {
  display: flex;
}

.clearfix:after {
  content: ".";
  display: block;
  height: 0;
  clear: both;
  visibility: hidden
}

.clearfix {
  *zoom: 1;
}



/*居中*/

.item-center {
  justify-content: center;
}



/*两端对齐*/

.space-between {
  justify-content: space-between
}



/*每个元素两侧的间隔相等。*/

.space-around {
  justify-content: space-around;
}



/*垂直居中*/

.vertical-center {
  align-items: center;
}



/*自动换行*/

.wrap {
  flex-wrap: wrap
}

.height10 {
  height: 0.1rem;
}

.bgf7 {
  background: #f7f7f7;
}



/*首页及需求模块输入框样式*/

.djl-input {
  height: 0.73rem;
  border: 1px solid #e4e4e4;
  margin-top: 0.25rem;
  min-height: initial;
}

.djl-input .mint-cell-text {
  font-size: 0.24rem;
  color: #5a5a5a;
}

.djl-input .mint-cell-wrapper {
  padding: 0;
  font-size: 0.2rem;
}

.djl-input .mint-cell-title {
  line-height: 0.71rem;
  border-right: 1px solid #e4e4e4;
  text-align: center;
  background: #f7f7f7;
}

.djl-input .mint-cell-value {
  padding-left: 0.23rem;
}



/*首页及需求模块输入框样式*/


/*首页及需求模块按钮样式*/

.demand-btn {
  height: .73rem !important;
  margin-top: .25rem;
  font-size: .3rem !important;
  border-radius: 0 !important;
  color: #fff4f5 !important;
  background: #f54102 !important;
}



/*需求模块内边距*/

.demand-inputItem {
  padding: 0rem 0.21rem
}



/*需求模块订单编号*/

.orderid {
  margin-top: 0.25rem;
  font-size: 0.22rem;
  color: #5a5a5a;
}



/* 浮动底部按钮样式：参考设计师简历页 */

.big-btn {
  display: block;
  width: 100%;
  height: 0.72rem;
  line-height: 0.72rem;
  font-size: 0.3rem;
  color: #fff;
  background-color: #f54203;
  text-align: center;
}



/*按钮样式*/

.large-btn {
  color: #fff;
  font-size: 0.3rem;
  margin-top: 0.3rem;
  border-radius: 0;
  height: 0.73rem;
  background: #f54102;
}



/*按钮定位到底部*/

.footerbtn {
  position: absolute;
  bottom: 0;
}
</style>
