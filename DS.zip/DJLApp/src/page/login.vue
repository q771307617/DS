<template>
	<div>
		<div v-if="isShow" class="h5-container">
			<!--头部  -->
			<djlheader title="登录">
				<a @click="routerBack" slot="headleft">
					<mt-button style="color: #fff;" icon="back"></mt-button>
				</a>
			</djlheader>

			<!--logo  -->
			<div class="h5-logo">
				<img :src="'h5/logo.png' | randomPath" alt="点将啦">
			</div>

			<!--表单  -->
			<div class="h5-form">
				<div class="h5-input">
					<div class="icon" :style="'background-image: url('+imgPath(1,'h5/username.png')+')'">
					</div>
					<input type="text" placeholder="用户名/手机号" class="input" v-model="username">
				</div>
				<p class="error">{{validateMsg.phone_msg}}</p>

				<div class="h5-input h5-input-pwd">
					<div class="icon" :style="'background-image: url('+imgPath(1,'h5/password.png')+')'">
					</div>
					<input type="password" placeholder="请输入密码" class="input" v-model="password" @keyup.enter="submit">
				</div>
				<p class="error">{{validateMsg.pwd_msg}}</p>

				<p class="forgetpwd">
					<router-link to="findpwd">忘记密码</router-link>
				</p>
				<button type="button" class="btn primary" @click="submit">登录</button>
			</div>

			<!--顶部  -->
			<div class="h5-footer">没有账号？
				<a href="javascript:" @click="reg">立即注册</a>
			</div>
		</div>
		<div v-else class="loding">
			<div class="lod-pic">
				<img :src="'icon2/login.gif' | randomPath" alt="认证">
			</div>
			<div>等待中。。。</div>
		</div>
	</div>
</template>
<script>
import api from '@/api';
import { Toast } from 'mint-ui';
import djlheader from '@/components/index/Header';
import { mapState, mapActions } from 'vuex';
export default {
  data() {
    return {
      username: '',
      password: '',
      isShow: true,
      validateMsg: {
        phone_msg: '',
        pwd_msg: ''
      }
    };
  },
  computed: {
    ...mapState({
      userInfo: state => state.User.userInfo
    })
  },
  mounted() {
    this.login();
  },
  methods: {
    async login() {
      var info = await api.getRoot('auth/login/status', {
        timestamp: Date.now()
      });

      if (info.status == 200) {
        //已登录
        location.href = '/';
        return;
      }

      //未登录
      if (api.isWX()) {
        this.isShow = false;
        var oauth = await api.getRoot('oauth/status');
        if (oauth.status != 200) {
          let redirect = this.$route.query.redirect;
          api.toWXAuth((redirect && decodeURIComponent(redirect)) || '/');
          return;
        }else{
          this.isShow = true;
        }
      }
    },
    ...mapActions(['getLoginState']),
    reg() {
      this.$router.replace({ name: 'register' });
    },
    imgPath(index, name) {
      const n = index % 5 + 1;
      return `http://${n}.img.dianjiangla.com/assets/${name}`;
    },
    submit() {
      const username = this.username;
      if (!username || !/^1[34578]\d{9}$/.test(username)) {
        this.validateMsg.phone_msg = '请输入11位数字的手机号';
        return;
      } else {
        this.validateMsg.phone_msg = '';
      }

      const password = this.password.trim();
      if (!password || password.length < 6 || password.length > 11) {
        this.validateMsg.pwd_msg = '请输入6-11位数字、字母组合的密码';
        return;
      } else {
        this.validateMsg.pwd_msg = '';
      }

      const r = new Date().getTime();
      api.postRoot('auth/login', { username, password, r }).then(e => {
        if (e.status !== 200) {
          Toast(e.msg);
          return;
        }
        Toast('登录成功');
        this.validateMsg.phone_msg = '';
        this.validateMsg.pwd_msg = '';
        this.getLoginState();
        this.routerBack();
      });
    },
    routerBack() {
      const redirect = this.$route.query.redirect;
      //      location.href = redirect && decodeURIComponent(redirect) || '/';
      this.$router.replace((redirect && decodeURIComponent(redirect)) || '/');
    }
  },
  components: { djlheader }
};
</script>

<style scoped>
/*登录、注册页*/

* {
  font-size: auto;
  font-family: 微软雅黑;
}

html {
  font-size: 625%;
}

em {
  font-style: normal;
}

.h5-container a {
  color: #f54203;
}

.h5-header {
  background-color: #fff;
  font-size: 0.28rem;
  text-align: center;
  border-bottom: 1px solid #dddee1;
  height: 0.82rem;
  line-height: 0.82rem;
  color: #282828;
}

.h5-header .btn {
  float: left;
  margin-left: 0.38rem;
  color: #282828;
}

.h5-header .btn img {
  height: 0.28rem;
}

.h5-logo {
  margin-top: 0.8rem;
  text-align: center;
}

.h5-logo img {
  width: 4.02rem;
  height: 1.01rem;
}

.h5-form {
  margin: 0 0.57rem;
  margin-top: 1.5rem;
}

.h5-form.reg {
  margin-top: 1.3rem;
}

.h5-form.reg .h5-input {
  margin-top: 0.35rem;
}

.h5-form .h5-input {
  width: 5.36rem;
  display: flex;
  border: 1px solid #dddee1;
  border-radius: 0.08rem;
}

.h5-form .h5-input input.code-tel {
  width: 2.5rem;
}

.h5-form .h5-input input.code-pic {
  width: 2.5rem;
}

.h5-form .h5-input .sendcode {
  white-space: nowrap;
  line-height: 0.7rem;
  margin-right: 0.25rem;
  color: #737373;
  font-size: 0.25rem;
  flex-grow: 1;
  text-align: right;
}

.h5-form .h5-input img.verifycode {
  flex-grow: 1;
  height: 0.7rem;
}

.h5-form .h5-input .disabled {
  white-space: nowrap;
  line-height: 0.7rem;
  margin-right: 0.25rem;
  cursor: not-allowed;
  color: #888888;
  font-size: 0.25rem;
}

.h5-form .h5-input .input {
  width: 100%;
  height: 0.7rem;
  font-size: 0.24rem;
  text-indent: 0.24rem;
  color: #888888;
  border: none;
  border-top-right-radius: 0.06rem;
  border-bottom-right-radius: 0.06rem;
}

.h5-form .h5-input .icon {
  width: 0.74rem;
  background-color: #dddee1;
  text-align: center;
  float: left;
  padding: 0.04rem 0;
  border-top-left-radius: 0.06rem;
  border-bottom-left-radius: 0.06rem;
  background-position: center center;
  background-repeat: no-repeat;
  background-size: 0.3rem 0.3rem;
}

.h5-form .h5-input-pwd {
  margin-top: 0.36rem;
}

.h5-form .forgetpwd {
  width: 5.36rem;
  font-size: 0.24rem;
  text-align: right;
  color: #f54203;
  margin-top: 0.2rem;
}

.h5-form .btn {
  color: #fff;
  border: none;
  border-radius: 0.05rem;
}

.h5-form .btn.err-msg,
.h5-form .btn.success {
  margin-top: 1rem;
}

.h5-form p.success {
  color: #19be6b;
}

.h5-form .btn.primary {
  margin-top: 0.6rem;
  width: 5.36rem;
  height: 0.7rem;
  background-color: #f54203;
  font-size: 0.28rem;
}

.h5-form.reg .btn.primary {
  margin-top: 0.5rem;
}

.h5-form p.err-msg {
  font-size: 0.22rem;
  color: #ff3030;
  margin: 0.02rem 0;
}

.h5-form .h5-form p.success {
  font-size: 0.18rem;
  color: #19be6b;
  margin: 0.02rem 0;
}

.h5-footer {
  margin-top: 0.52rem;
  text-align: center;
  font-size: 0.24rem;
  margin-bottom: 0.55rem;

  color: #282828;
}

.error {
  color: red;
  font-size: 0.18rem;
  display: block;
  margin-top: 0.1rem;
}

.loding {
  font-size: 0.18rem;
  color: #a6b8cc;
  display: flex;
  justify-content: center;
  align-content: center;
  margin-top: 4rem;
}
.lod-pic {
  width: 0.18rem;
  float: left;
  margin-right: 0.1rem;
}
.lod-pic img {
  width: 100%;
}
</style>
