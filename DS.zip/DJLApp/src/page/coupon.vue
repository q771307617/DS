<template>
  <div>
      <djlheader title="我的优惠券">
        <span @click="goback" slot="headleft">
            <mt-button icon="back"></mt-button>
        </span>
      </djlheader>
      <div class="list-item">
        <ul class="item">
          <li class="box space-between">
            <div class="box-left">
              <p>有效期：</p>
              <p>2017-08-14至2017-9-14</p>
              <p>限制雇佣包月类型使用</p>
            </div>
            <div class="box-right">
              <p>¥200</p>
              <p>【全额抵用券】</p>
            </div>
          </li>
        </ul>
      </div>
  </div>
</template>

<script>
import djlheader from '../components/index/Header.vue'
export default {
  components: {
    djlheader
  },
  methods: {
    goback(){
        this.$router.go(-1);
    },
  }
}
</script>

<style scoped>
.list-item{
  padding: 0.2rem 0.18rem;
  font-size:0.2rem;
  background: rgba(247, 247, 247, 1);
}
.item{
  background: #fff;
  padding-left:0.18rem;
}
.box-left{
  padding:0.2rem 0;
  color:#5a5a5a;
}
.box-left p:nth-child(2){
  font-size:0.28rem;
  margin: 0.15rem 0;
}
.box-right{
    width: 2rem;
    background: linear-gradient(to right,#fe8e01, #f54102);
    color:#fff;
    font-size: 0.24rem;
    text-align: center;
    padding:0.18rem 0;
}
.box-right p:first-child{
  font-size:0.6rem;
}
</style>
