<template>
  <div class="demand">
    <djlheader :title="'需求记录'">
            <span @click="goback" slot="headleft">
                <mt-button icon="back"></mt-button>
            </span>
      <mt-button @click="toAddDemand" class="add_demand" slot="headright">发布新需求</mt-button>
    </djlheader>
    <ul class="tab box item-center">
      <li v-bind:class="{active: active == 1}" @click="setActive(1)">待审核</li>
      <li v-bind:class="{active: active == 2}" @click="setActive(2)">待支付</li>
      <li v-bind:class="{active: active == 3}" @click="setActive(3)">工作中</li>
      <li v-bind:class="{active: active == 4}" @click="setActive(4)">待验收</li>
    </ul>
    <mt-tab-container v-model="active" class="list-item">
      <mt-tab-container-item :id="active">
        <ul>
          <li v-for="item in lists" :key="item.id" class="list">
            <p class="font-size" v-if="active!='1'">订单编号：{{item.order_id}}</p>
            <router-link v-if="active==1" :to="{name: 'audit', query: { id: item.id }}"
                         class="box space-between vertical-center list">
              <div class="box-left">
                <p>{{item.title}}</p>
                <p>预算：{{item.budget}}元</p>
              </div>
              <mt-button size="normal" class="demand-btn btn">待审核</mt-button>
            </router-link>
            <a v-if="active==2" :href="'/user/pay/?hireId='+item.id+'&orderType=demand'" class="box space-between vertical-center ">
              <div class="box-left">
                <p>{{item.title}}</p>
                <p>预算：{{item.budget}}元</p>
              </div>
              <mt-button size="normal" class="demand-btn btn">去支付</mt-button>
            </a>
            <router-link v-if="active==3" :to="{name: 'work', query: { id: item.id }}"
                         class="box space-between vertical-center ">
              <div class="box-left">
                <p>{{item.title}}</p>
                <p>预算：{{item.budget}}元</p>
              </div>
              <span class="list-value">工作中</span>
            </router-link>
            <router-link v-if="active==4" :to="{name: 'check', query: { id: item.id }}"
                         class="box space-between vertical-center ">
              <div class="box-left">
                <p>{{item.title}}</p>
                <p>预算：{{item.budget}}元</p>
              </div>
              <mt-button size="normal" class="demand-btn btn" >{{typelist[item.accept_status]}}</mt-button>
            </router-link>
          </li>
        </ul>
      </mt-tab-container-item>
    </mt-tab-container>
  </div>
</template>

<script>
  import djlheader from '@/components/index/Header'
  import {TabContainer, TabContainerItem} from 'mint-ui';
  import {mapState, mapMutations} from 'vuex'

  export default {
    data() {
      return {
        active: '1',
        lists: [],
        typelist:{'0':'待验收','1':'通过','-1':'未通过'},
      }
    },
    components: {djlheader},
    computed: {},
    mounted() {
      this.active = this.$route.params.active || 1;
      this.getList();
    },
    methods: {
      setActive(type){
        this.$router.replace({name: 'demand', params: {active: type}})
      },
      getList() {
        this.$ajax.get('demand/list', {status: this.active}).then((e) => {
          if (e.status != 200) {
            return;
          }
          this.lists = e.data.list;
        });

      },
      toAddDemand() {
        this.$router.push({name: 'addDemand'});
      },
      goback() {
        this.$router.push({name: 'personal'})
      },
    },
    watch: {
      '$route': function() {
        this.active = this.$route.params.active || 1;
        this.getList();
      }
    }
  }
</script>

<style scoped>
  .add_demand {
    font-size: 0.26rem;
    margin-right: 0.2rem;
  }

  .tab {
    font-size: 0.24rem;
  }

  .tab li {
    height: 0.88rem;
    line-height: 0.88rem;
    border-bottom: 1px solid #ccc;
    border-right: 1px solid #ccc;
    text-align: center;
    flex-grow: 1
  }

  .tab li:last-child {
    border-right: 0;
  }

  .tab li.active {
    background: #f54203;
    border: 1px solid #f1c3b1;
    border-left: 0;
    color: #fff;
  }

  .list-item {
    background: #f7f7f7;
  }

  .list {
    margin-bottom: 0.1rem;
    background: #fff;
    height: 1.4rem;
  }

  .font-size {
    font-size: 0.22rem;
    width: 100%;
    background: #fff;
    margin-left: 0.3rem;
    padding-top: .2rem;
  }

  .box-left {
    font-size: 0.22rem;
    color: #5a5a5a;
    margin-left: 0.3rem;
  }

  .box-left p {
    height: 0.35rem;
    width:3.5rem;
    line-height: 0.35rem;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
  }

  .list-value {
    font-size: 0.27rem;
    color: #5a5a5a;
    margin-right: 0.3rem;
  }

  .demand .btn {
    width: 1.66rem;
    height: 0.63rem;
    margin-top: 0;
    margin-right: 0.3rem;
  }
</style>


