<template>
  <div class="main" style="font-size: 0.12rem;">
  <div style="position: fixed;top: 0;width: 100%;max-width: 6.5rem;z-index: 9999;">
    <div class="bg-style">
      <mt-header class="title" style="background:none;" title="交易记录">
        <a @click="routerBack()"  slot="left">
          <mt-button icon="back"></mt-button>
        </a>
      </mt-header>

      <!--<router-link :to="{name:'account'}">-->
        <div style="margin-top: 0.5rem" class="money_info">
          <money-info></money-info>
        </div>
      <!--</router-link>-->
    </div>
  </div>
    <div style="height: 2.66rem"></div>
    <div class="tab-btn-jylist space-between box">
      <router-link :to="{name:'trading'}" replace>交易记录</router-link>
      <router-link :to="{naem:'trading',params:{status:1}}" replace>充退记录</router-link>
    </div>
    <mt-loadmore class="trading" :top-method="loadTop" :bottom-method="loadBottom" @top-status-change="handleTopChange"
                 :bottom-all-loaded="allLoaded" ref="loadmore">
      <ul>
        <li v-for="item in list">
          <p>订单编号：<span style="display: inline-block;">{{item.order_id}}</span></p>
          <div class="box space-between">
            <div>
              <p>交易渠道：{{typelist[item.channel]}}</p>
              <p>交易金额：{{item.amount}}元</p>
            </div>
            <div class="box item-center vertical-center" style="width: 2.66rem;font-size: 0.22rem;">
              <p>交易类型：{{statuslist[item.type]}}</p>
            </div>
          </div>
          <p>订单生成时间：{{item.create_time}}</p>
          <p>订单支付时间：{{item.pay_time}}</p>
        </li>
      </ul>
    </mt-loadmore>
  </div>
</template>

<script>
  import {Loadmore, Indicator, Toast} from 'mint-ui';
  import moneyInfo from '@/components/personal/moneyInfo'
  import djlheader from '@/components/index/Header'
  import menu from '@/components/prolist/menu'
  import moment from "moment";
  export default {
    data() {
      return {
        allLoaded: false,
        topStatus: '',
        list: [],
        typelist: ['余额支付', '支付宝','微信','支付宝','微信'],
        statuslist:{'DEPOSIT':'充值','WITHDRAW':'提现','DEMAND_DEPOSIT':'支付需求保证金','BUDGET_WITHDRAW':'退回保证金','HIRE_DEPOSIT':'支付雇佣保证金'},
        params: {
          status: 0,
          pageNum: 1,
          pageSize: 10
        },
        configData: {
          pageCount: 0,
        }
      }
    },
    components: {djlheader, 'money-info': moneyInfo},
    computed: {},
    mounted() {
      this.params.status = this.$route.params.status || 0;
      this.getList();
    },
    methods: {
      loadTop() {
        // 刷新数据
        this.list = [];
        this.params.pageNum = 1;
        this.allLoaded = false;
        this.getList();
        this.$refs.loadmore.onTopLoaded();
      },
      loadBottom() {
        // 加载更多数据
        if (this.params.pageNum > this.configData.pageCount) {
          Toast('没有更多了！');
          this.allLoaded = true; // 若数据已全部获取完毕
          this.$refs.loadmore.onBottomLoaded();
        }
        this.loadMore();
        this.$refs.loadmore.onBottomLoaded();
      },
      handleTopChange() {
        this.topStatus = status;
      },
      getList() {
        Indicator.open({
          text: '加载中...',
          spinnerType: 'fading-circle'
        });
        let params = {
          ...this.params
        }

        params.types = params.status == 1 ? 'DEPOSIT,WITHDRAW,BUDGET_WITHDRAW' : 'DEMAND_DEPOSIT,HIRE_DEPOSIT';
        this.$ajax.get('order/list', params).then(e => {
          if (e.status !== 200) {
            Indicator.close();
            return false;
          }

          let listarr = e.data.list.map((item) => {
            item.create_time = moment(item.create_time).format("YYYY-MM-DD HH:mm:ss")
            if(item.pay_time){
              item.pay_time = moment(item.pay_time).format("YYYY-MM-DD HH:mm:ss")
            }
            return item;
          });
          this.list = this.list.concat(listarr);
          let count = e.data.count == 'undefined' ? 0 : e.data.count;
          this.configData.pageCount = Math.ceil(count / params.pageSize);
          this.params.pageNum = this.params.pageNum + 1;
          Indicator.close();
          this.loading = false;
        }).catch(function (err) {
          Indicator.close();
        })
      },
      loadMore() {
        if (this.configData.pageCount < this.params.pageNum) {
          return false;
        }
        this.loading = true;
        this.getList();
      },
      routerBack() {
        this.$router.push({name: 'personal'});
      }
    },
    watch: {
      '$route': function () {
        this.params.status = this.$route.params.status || 0;
        this.loadTop();
      }
    }
  }
</script>

<style scoped>
  .bg-style {
    background: linear-gradient(to bottom, #f54102, #fe8e01);
    padding-bottom: 0.35rem;
  }

  .main {
    font-size: 0.24rem;
  }

  .tab-btn-jylist {
    height: 0.88rem;
    line-height: 0.88rem;
  }

  .tab-btn-jylist a {
    text-align: center;
    flex: 1;
    font-size: 0.26rem;
    border-bottom: 1px solid #c8c8c8;
  }


  .tab-btn-jylist a.router-link-exact-active {
    background-color: #fff;
    border: none;
    border-bottom: 2px solid #f54203;
    color: #f54203;
  }

  .trading {
    overflow: hidden;
  }

  .trading ul li {
    padding: 0.2rem 0.3rem;
    line-height: 0.4rem;
    border-bottom: 0.1rem solid #f7f7f7;
    font-size: 0.22rem;
    color: #5a5a5a;
  }

  .title {
    padding: 0 0.3rem;
    font-size: 0.36rem;
    color: #fff;
    height: 0.75rem;
  }
</style>
