<template>
	<div class="main">
		<djlheader :title="'雇佣记录'">
			<router-link :to="{name:'personal'}" slot="headleft">
				<mt-button icon="back" style="color: #fff;"></mt-button>
			</router-link>
		</djlheader>

		<div class="tab-btn space-between box">
			<router-link :to="{name:'paylist'}" replace>未支付</router-link>
			<router-link :to="{name:'paylist',params:{status:1}}" replace>已支付</router-link>
			<router-link :to="{name:'noaywageslist'}" replace>待发放工资</router-link>
			<router-link :to="{name:'wageslist'}" replace>已发放</router-link>
		</div>
		<router-view></router-view>
	</div>
</template>

<script scoped>
import djlheader from '@/components/index/Header'
export default {
	name: 'page-navbar',
	data() {
		return {
			selected: '1',
			hiredatas: [{
				"designer_id": 1,
				"designer_name": "huangyi",//设计师名字
				"end_time": 1497083846000,//雇佣结束时间
				"month": "1个月",
				"salary": 10000,//薪水
				"start_time": 1494405446000,//雇佣开始时间
				"status": 1,//	支付状态--雇佣状态；0：未支付，1：已支付，2：工作中，3：已完结,4:已取消
				"type": 0,//雇佣类型0为包月雇佣，1为定制雇佣
			},
			{
				"designer_id": 1,
				"designer_name": "那么快",//设计师名字
				"end_time": 1497083846485,//雇佣结束时间
				"month": "1个月",
				"salary": 8000,//薪水
				"start_time": 1494405875456,//雇佣开始时间
				"status": 1,//	支付状态--雇佣状态；0：未支付，1：已支付，2：工作中，3：已完结,4:已取消
				"type": 1,//雇佣类型0为包月雇佣，1为定制雇佣
			}]
		};
	},
	components: { djlheader },
};
</script>

<style>
.main {
	font-size: 0.24rem;
}

.tab-btn {
	height: 0.88rem;
	line-height: 0.88rem;
	border-bottom: 1px solid #c8c8c8;
}

.tab-btn a {
	text-align: center;
	flex: 1;
	border-left: 1px solid #c8c8c8;
}

.tab-btn a:first-child {
	border: none;
}

.router-link-exact-active {
	background-color: #f54203;
	color: #fff;
}
</style>
