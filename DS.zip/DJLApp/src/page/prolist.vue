<template>
    <div class="main">
      <!-- <netraffic></netraffic> -->
        <djlheader>
            <input type="text" slot="headleft" v-model="searchData.name" placeholder="请输入关键词进行搜索" class="headleft" />
            <img :src="ftpPath + '/icon_search.png'" slot="headright" @click="loadTop" class="headright" />
        </djlheader>

        <djl-menu :searchData="searchData" :callback="loadTop" />
        <div style="height: 0.68rem"></div>

        <div class="prolist">
            <mt-loadmore class="pro" :top-method="loadTop" :bottom-method="loadBottom" :auto-fill="false" @top-status-change="handleTopChange" :bottom-all-loaded="allLoaded" ref="loadmore">
                <ul class="box space-between wrap">
                    <li v-for="el in lists" :key="el.id">
                        <router-link :to="{path: '/proinfo/'+ el.id}">
                            <img v-lazy="el.image_url" class="proimg" />
                            <p class="proname">
                                {{el.name}}
                            </p>
                        </router-link>
                    </li>
                </ul>
            </mt-loadmore>
        </div>
    </div>
</template>

<script>
import djlheader from '@/components/index/Header'
import menu from '@/components/prolist/menu'
import { Loadmore, Indicator, Toast, Lazyload, InfiniteScroll } from 'mint-ui';
import { mapState } from 'vuex';

export default {
    components: { djlheader, 'djl-menu': menu },
    data() {
        return {
            lists: [],
            searchData: {
                name: '',
                typeid: '',
                type_text: '按区域',

                experienceid: 0,
                experience_text: '按级别',

                classIds: '',
                class_text: '按行业',

                rank:'',
//                expEnd: '',//经验结束
//                expStart: '',//经验开始
            },
            allLoaded: false,
            pageNum: 1,
            pageSize: 10,
            pageCount: 0,
        }
    },
    computed: {
        ...mapState({
            ftpPath: state => state.Public.ftpPath
        })
    },
    mounted() {
        this.getProList();
    },
    methods: {
        loadTop() {
            // 刷新数据
            this.lists = [];
            this.pageNum = 1;
            this.allLoaded = false;
            this.getProList();
            this.$refs.loadmore.onTopLoaded();
        },
        loadBottom() {
            // 加载更多数据
            if (this.pageNum > this.pageCount) {
                Toast('没有更多了！');
                this.allLoaded = true; // 若数据已全部获取完毕
                this.$refs.loadmore.onBottomLoaded();
            }
            this.loadMore();
            this.$refs.loadmore.onBottomLoaded();
        },
        handleTopChange() {
            this.topStatus = status;
        },
        getProList() {
            Indicator.open({
                text: '加载中...',
                spinnerType: 'fading-circle'
            });

            let params = {
                ...this.params
            }
            this.$ajax.get('product/list', {
                pageSize: this.pageSize,
                pageNum: this.pageNum,
                classIds: this.searchData.classIds,
                name: this.searchData.name,
                typeId: this.searchData.typeid,

                rank:this.searchData.rank,
//                expStart: this.searchData.expStart, //经验开始
//                expEnd: this.searchData.expEnd,     //经验结束

                // experienceid: this.searchData.experienceid,
            }).then(e => {
                if (e.status !== 200) {
                    Indicator.close();
                    return false;
                }
                this.lists = this.lists.concat(e.data.list);
                let count = e.data.count == 'undefined' ? 0 : e.data.count;
                this.pageCount = Math.ceil(count / this.pageSize);
                this.pageNum = this.pageNum + 1;
                Indicator.close();
            }).catch(function(err){
          Indicator.close();
      })
        },
        loadMore() {
            if (this.pageCount < this.pageNum) {
                return false;
            }
            this.getProList();
        }
    },
}
</script>

<style>
/*.prolist .mint-loadmore-bottom{
    margin-bottom: 0;
    height: 0.25rem;
    line-height: 0.25rem;
}*/
</style>

<style scoped>
.headleft {
    margin-left: 0.07rem;
    padding-left: 0.29rem;
    font-size: 0.22rem;
    color: #949494;
    width: 4.95rem;
    height: 0.34rem;
}

.headright {
    width: 0.4rem;
    height: 0.4rem;
    margin-right: 0.24rem;
}

.proimg {
    height: 3.1rem;
    width: 2.88rem;
}

.proname {
    text-align: center;
    font-size: 0.2rem;
    color: #090909;
    height: 0.4rem;
    line-height: 0.4rem;
}

.pro {
    font-size: 0.20rem;
}

.pro ul {
    padding: 0.17rem 0.17rem 0 0.17rem;
}

.pro ul li {
    width: 2.88rem;
    margin-bottom: 0.21rem;
}

.pro ul li a.img {
    display: block;
    width: 2.88rem;
    height: 3.1rem;
    overflow: hidden;
}

.pro ul li a img {
    width: 100%;
}

.pro ul li a.txt {
    display: block;
    height: 0.5rem;
    line-height: 0.5rem;
    text-align: center;
    color: #090909;
}
</style>
