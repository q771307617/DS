<template>
  <div class="main">
    <djlheader :title="nickname +' 的简历'">
      <a @click="routerBack" slot="headleft">
        <mt-button style="color: #fff;" icon="back"></mt-button>
      </a>
    </djlheader>
    <itemDesignerInfo :info="info"></itemDesignerInfo>
    <router-view ></router-view>
  </div>
</template>

<script>
  import djlheader from '@/components/index/Header'
  import itemDesignerInfo from '@/components/designer/item-designer-info'
  import {Button, Indicator} from 'mint-ui';
  export default {
    data() {
      return {
        params: {
          id: '',
        },
        nickname:'',
        info: [],
      }
    },
    components: {djlheader, itemDesignerInfo},
    computed: {},
    mounted() {
      this.params.id = this.$route.params.id;
      this.getInfoData();
    },
    methods: {
      getInfoData() {
        Indicator.open({
          text: '加载中...',
          spinnerType: 'fading-circle'
        });
        let params = {
          ...this.params
        }
        this.$ajax.get('designer/get', params).then(e => {
          if (e.status !== 200) {
            Indicator.close();
            return false;
          }
          this.nickname = e.data.nickname;
          this.info = e.data;
          Indicator.close();
          this.loading = false;
        }).catch(function(err){
          Indicator.close();
      });
      },
      routerBack() {
        if(window.history.length > 2){
          this.$router.go(-1);
          return;
        }else{
          this.$router.push({name: 'index'});
        }
      },
    }
  }
</script>

<style scoped>
</style>


