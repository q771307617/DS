<template>
  <div class="main">
    <div class="box space-between btn-group">
      <a @click="setType(0)" :class="params.type !=1 ? 'link-active':'' ">包月雇佣</a>
      <a @click="setType(1)" :class="params.type !=1 ? '':'link-active' ">定制雇佣</a>
    </div>

    <div v-if="params.type == '1'" class="from-style">
      <ul>
        <li class="box">
          <div>入职时间：</div>
          <a @click="openPicker()">{{params.startTime}}</a>
        </li>
        <li class="box">
          <div>结束时间：</div>
          <a @click="openPicker3()">{{params.endTime}}</a>
        </li>
        <li>
          <div><span style="color: red;">*</span>制作内容：</div>
          <div>
            <textarea v-model="params.invitation" style="width: 100%;" cols="30" rows="10"></textarea>
          </div>
          <div class="box">
            <div>应托管工资金额：</div>
            <div style="flex: 1;text-align: right;"><input v-model="params.price"
                                                           style="width: 1.6rem;text-align: center;" class="mony"
                                                           type="number"> 元
            </div>
          </div>
        </li>
      </ul>
    </div>
    <div v-else class="from-style">
      <ul>
        <li class="box">
          <div>入职时间：</div>
          <br>
          <a @click="openPicker2()">{{params.startTime}}</a>
        </li>
        <li class="box">
          <div>雇佣周期：</div>
          <div class="box">
            <div class="box month">
              <a @click="reduceMonth()" disabled class="reduce">-</a>
              <div class="num"><input v-model="variable.month" disabled type="number"></div>
              <a @click="addMonth()" class="add">+</a>
            </div>
            <div>月</div>
          </div>
        </li>
        <li>
          <div><span style="color: red;">*</span>入职邀请：</div>
          <div>
            <textarea v-model="params.invitation" style="width: 100%;" cols="30" rows="10"></textarea>
          </div>
          <div class="box">
            <div>应托管工资金额：</div>
            <div style="flex: 1;text-align: right;"><span class="mony">{{variable.countMony}}</span>元</div>
          </div>
        </li>
      </ul>
    </div>
    <div style="height: 0.8rem;"></div>
    <mt-tabbar fixed>
      <a @click="addHire()" class="big-btn">确认雇佣</a>
    </mt-tabbar>
    <mt-datetime-picker
      ref="picker"
      type="date"
      year-format="{value} 年"
      month-format="{value} 月"
      date-format="{value} 日"
      @confirm="setStartTime"
      v-model="variable.sdate">
    </mt-datetime-picker>

    <mt-datetime-picker
      ref="picker2"
      type="date"
      year-format="{value} 年"
      month-format="{value} 月"
      date-format="{value} 日"
      @confirm="setStartTime2"
      v-model="variable.sdate">
    </mt-datetime-picker>

    <mt-datetime-picker
      ref="picker3"
      type="date"
      year-format="{value} 年"
      month-format="{value} 月"
      date-format="{value} 日"
      @confirm="setEndTime"
      v-model="variable.edate">
    </mt-datetime-picker>
  </div>
</template>

<script>
  import djlheader from '@/components/index/Header'
  import itemDesignerInfo from '@/components/designer/item-designer-info'
  import {mapState, mapActions} from 'vuex'
  import {DatetimePicker, Tabbar, Toast} from 'mint-ui';
  import moment from "moment";
  export default {
    props: ['info'],
    data() {
      return {
        params: {
          designerId: '',
          startTime: '',
          endTime: '',
          invitation: '',
          price: 1,
          type: 0,
        },
        variable: {
          month: 1,
          salary: '',
          countMony: 0,
          sdate: '',
          edate: '',

        },
      }
    },
    components: {djlheader, itemDesignerInfo, moment},
    computed: {
      ...mapState({})
    },
    mounted() {
      this.params.designerId = this.$route.params.id || '';
      this.params.startTime = moment().format("YYYY-MM-DD");
      this.variable.sdate = moment().format("YYYY-MM-DD");
      this.variable.salary = this.$route.query.mony || 1;
      this.editEndTime();
    },
    methods: {
      addHire(){
        if(!this.isTime()) return;
        if (this.params.type == '1' && !this.params.invitation) {
          Toast('请填写制作内容！');
          return;
        }
        if (this.params.type == '0' && !this.params.invitation) {
          Toast('请填写入职邀请！');
          return;
        }
        if (this.params.invitation.length > 500) {
          Toast('入职邀请或制作内容字数请限制在500字符内！');
          return;
        }

        if (this.params.price <= 0 && this.params.type == '1'  ) {
          Toast('请输入正确的应托管工资金额！');
          return;
        }
        let addParams = {
          ...this.params
        }
        addParams.price = addParams.price || 0;

        addParams.startTime = moment(this.params.startTime).format('x')
        addParams.endTime = moment(this.params.endTime).format('x')
        addParams['hireInvitation.invitation'] = this.params.invitation;

        this.$ajax.postRoot('hire/add', addParams).then((e) => {
          if (e.status == 200) {
            Toast('雇佣订单已生成！');
            //支付操作
            location.href="/user/pay/?hireId="+e.data
//            this.$router.replace({
//              name: 'userpay',
//              query: {hireId: e.data}
//            });
          } else {
            Toast(e.msg);
          }
        })

      },
      setStartTime(){
        this.params.startTime = moment(this.variable.sdate).format("YYYY-MM-DD");
        if(!this.isTime()) return;
      },
      setStartTime2(){
        this.params.startTime = moment(this.variable.sdate).format("YYYY-MM-DD");
        this.editEndTime();
        if(!this.isTime()) return;
      },
      setEndTime(){
        this.params.endTime = moment(this.variable.edate).format("YYYY-MM-DD");
        if(!this.isTime()) return;
      },
      isTime(){
        let sdate = moment(this.params.startTime).format('x');
        let edate = moment(this.params.endTime).format('x');
        let ndate = moment( moment(new Date()).format('YYYY-MM-DD')).format('x');

        if (sdate < ndate) {
          Toast('入职时间不能小于'+moment().format('YYYY-MM-DD'))
          this.params.startTime = moment().format('YYYY-MM-DD');
          return false;
        }
        if (edate < ndate) {
          Toast('结束时间不能小于'+moment().format('YYYY-MM-DD'))
          this.params.endTime = moment().format('YYYY-MM-DD');
          return false;
        }

        if (sdate > edate) {
          Toast('结束时间不能小于入职时间，请重新选择')
          return false;
        }
        return true;
      },
      openPicker() {
        this.variable.sdate = this.params.startTime;
        this.$refs.picker.open();
      },
      openPicker2() {
        this.variable.sdate = this.params.startTime;
        this.$refs.picker2.open();
      },
      openPicker3() {
        this.variable.edate = this.params.endTime;
        this.$refs.picker3.open();
      },
      setType(type){
        this.variable.month = 1;
        this.params.startTime = moment().format("YYYY-MM-DD");
        this.params.type = type;
        this.editEndTime();
      },
      reduceMonth(){
        let month = Math.ceil(this.variable.month) - 1;
        if (month < 1) {
          month = 1;
        }
        this.variable.month = month;
        this.editEndTime();
      },
      addMonth(){
        let month = Math.ceil(this.variable.month) + 1;
        if (month > 12) {
          month = 12;
        }
        this.variable.month = month;
        this.editEndTime();
      },
      editEndTime(){
        let sDate = this.params.startTime;
        this.params.endTime = moment(sDate).add('months', Math.ceil(this.variable.month)).format("YYYY-MM-DD");
        this.variable.countMony = this.variable.month * this.variable.salary;
      }
    }
  }
</script>

<style scoped>
  .btn-group {
    border-bottom: 1px solid #c8c8c8;
  }

  .btn-group a {
    display: block;
    flex: 1;
    text-align: center;
    height: 0.54rem;
    line-height: 0.54rem;
    font-size: 0.24rem;
  }

  .btn-group a.link-active {
    color: #fff;
    background-color: #f54203;
  }

  .from-style {
    overflow: hidden;
    color: #5a5a5a;
  }

  .from-style ul li {
    border-bottom: 1px solid #c8c8c8;
    padding: 0.06rem 0.31rem;
    font-size: 0.22rem;
    line-height: 0.54rem;
  }

  .month {
    border: 1px solid #c8c8c8;
    height: 0.5rem;
    line-height: 0.5rem;
    margin: 0 0.33rem;
  }

  .month .reduce, .month .add {
    width: 0.6rem;
    height: 0.5rem;
    text-align: center;
    font-size: 0.3rem;
    display: block;
  }

  .month .reduce {
    border-right: 1px solid #c8c8c8;
  }

  .month .add {
    border-left: 1px solid #c8c8c8;
  }

  .month .num {
    height: 0.5rem;
    line-height: 0.5rem;
    overflow: hidden;
  }

  .month .num input {
    height: 0.5rem;
    border: none;
    width: 2.05rem;
    text-align: center;
    color: #f54203;
    font-size: 0.28rem;
  }

  .mony {
    font-size: 0.28rem;
    color: #f54203;
  }
</style>


