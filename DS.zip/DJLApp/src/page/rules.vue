<template>
    <div>
        <djlheader title="平台规则">
            <router-link :to="{name:'index'}" slot="headleft">
                <mt-button icon="back" style="color: #fff;"></mt-button>
            </router-link>
            <router-link :to="{name:'index'}" slot="headright" style="color: #fff;font-size: 14px;">X
            </router-link>
        </djlheader>
            <!-- 导航 -->
            <mt-navbar  v-model="selected" fixed class="nav-bar">
                <mt-tab-item id="1">平台介绍</mt-tab-item>
                <mt-tab-item id="2">雇佣模式</mt-tab-item>
                <mt-tab-item id="3">3天试用</mt-tab-item>
            </mt-navbar>
            <!-- 内容列表 -->
            <mt-tab-container v-model="selected" class="nav-container">
               <mt-tab-container-item :id="selected">
                    <img :src="'http://3.img.dianjiangla.com/assets/h5/ptgz/ptgz-'+selected+'.png' " alt="">
                </mt-tab-container-item>
            </mt-tab-container>
    </div>
</template>

<script>
import djlheader from '@/components/index/Header'
export default {
    components: { djlheader },
    data() {
        return {
            selected: '1'
        };
    }
};  
</script>


<style scoped>
.nav-bar{
    margin-top: 0.75rem;
}
.nav-container{
    margin-top: 0.75rem;
}
.mint-tab-item-label {
    color: inherit;
    font-size: 0.24rem;
    line-height: 1;
}

.mint-tab-item {
    border-right: 1px solid #ccc;
}

.mint-navbar .mint-tab-item.is-selected {
    border-right: 1px solid #ccc;
    color: #fdfdfd;
    background-color: #f54203;
    border: 1px solid #fc9e7c;
    margin-bottom: 0px; 
} 
img {
    width: 100%;
background-size: 100% 100%;
}
</style>


