<template>
    <div class="cash">
        <djlheader title="申请提现">
            <span @click="goback" slot="headleft">
                <mt-button icon="back"></mt-button>
            </span>
        </djlheader>
        <div class="con">
            <div class="desc">提现金额根据资金来源，遵循原路返回的原则，请分别查询支付宝、微信可提现金额</div>
            <div class="tab box vertical-center">
                <span class="box-item box vertical-center space-between box-left" @click="type = '1'">
                    <img :src="ftpPath + '/zfb.png'" class="icon2" />
                    <span style="flex-grow:2">支付宝</span>
                    <img :src="ftpPath + '/ok.png'" class="icon" v-if="type == '1'">
                    <img :src="ftpPath + '/ok2.png'" class="icon" v-else>
                </span>
                <span class="box-item box vertical-center space-between box-right" @click="type = '2'">
                    <img :src="ftpPath + '/wechart.png'" class="icon2" />
                    <span style="flex-grow:2">微信</span>
                    <img :src="ftpPath + '/ok.png'" class="icon" v-if="type == '2'">
                    <img :src="ftpPath + '/ok2.png'" class="icon" v-else>
                </span>
            </div>
            <div class="input-item">
                <mt-field label="姓名或企业名称" v-model="data.name" class="djl-input"></mt-field>
                <p class="error">{{validateMsg.validate_name}}</p>

                <div v-if="type == '2'">
                    <mt-field label="微信账号" v-model="data.wechart" placeholder="请确保微信账号与姓名/企业名称相符合" class="djl-input"></mt-field>
                    <p class="error">{{validateMsg.validate_wxcode}}</p>
                </div>
                <div v-else>
                    <mt-field label="支付宝账号" v-model="data.zfb" placeholder="请确保支付宝账号与姓名/企业名称相符合" class="djl-input"></mt-field>
                    <p class="error">{{validateMsg.validate_zfbcode}}</p>
                </div>
                <mt-field label="本次提现金额" v-model="data.cashNum" :placeholder="'可提现金额：'+userInfo.balance+'元'" class="djl-input" type="number">
                    <mt-button size="small" @click="allmoney">全部提现</mt-button>
                </mt-field>
                <p class="error">{{validateMsg.validate_money}}</p>
                <mt-field label="手机号码" v-model="data.tel" class="djl-input" type="number">
                    <mt-button size="small" v-if="codeIntervalTime === 60" @click="sendCode">发送验证码</mt-button>
                    <mt-button size="small" disabled v-else>{{codeIntervalTime}}s后再获取</mt-button>
                </mt-field>
                <p class="error">{{validateMsg.validate_phone}}</p>
                <div v-if="needVerifycode">
                    <mt-field label="验证码" v-model="verifycode" placeholder="请输入验证码" class="djl-input">
                        <img :src="verifycodeUrl" alt="" class="verifycode" @click="fetchCodeImg"></mt-field>
                    <p class="error">{{validateMsg.validate_imgcode}}</p>
                </div>
                <mt-field label="手机验证码" v-model="data.code" class="djl-input" type="number"></mt-field>
                <p class="error">{{validateMsg.validate_phonecode}}</p>
            </div>
            <div style="height:.95rem"></div>
        </div>
        <mt-button size="large" @click="publish" class="big-btn withdrawal">申请提现</mt-button>
    </div>
</template>

<script>
import djlheader from '../components/index/Header.vue'
import api from '@/api'
import { mapState } from 'vuex'
import { Field, Button, Toast } from 'mint-ui'

export default {
    data() {
        return {
            type: '1',
            codeIntervalTime: 60,
            verifycode: '',
            verifycodeUrl: '',
            needVerifycode: false,
            data: {
                name: '',
                wechart: '',
                cashNum: '',
                tel: '',
                code: '',
                zfb: '',
            },
            validateMsg: {
                validate_name: '',
                validate_wxcode: '',
                validate_zfbcode: '',
                validate_money: '',
                validate_imgcode: '',
                validate_phone: '',
                validate_phonecode: '',
            }
        }
    },
    mounted() {
        this.fetchCodeImg()
    },
    components: {
        djlheader,
        Field,
        "mt-button": Button
    },
    computed: {
        ...mapState({
            userInfo: state => state.User.userInfo,
            ftpPath: state => state.Public.ftpPath
        })
    },
    watch: {
        codeIntervalTime(val) {
            if (!val) {
                this.codeIntervalTime = 60;
                clearInterval(this.update)
            }
        },
    },
    methods: {
        goback() {
            this.$router.go(-1);
        },
        async publish() {
            const result = await this.verifyinfo();
            if (!result) return;// 验证不通过
            if (this.type == 1) {//支付宝申请提现
                if (this.data.name && this.data.zfb && this.data.code !== '') {
                    api.post('', {
                        type: this.type,
                        name: this.data.name,
                        zfb: this.data.zfb,
                        cashNum: this.data.cashNum,
                        tel: this.data.tel,
                    }).then(e => {
                        if (e.status !== 200) {
                            Toast({ message: '操作成功' });
                        }
                    })
                }
            }
            if(this.type == 2) {//微信申请提现
                if (this.data.name && this.data.wechart && this.data.code !== '') {
                    api.post('', {
                        type: this.type,
                        name: this.data.name,
                        wechart: this.data.wechart,
                        cashNum: this.data.cashNum,
                        tel: this.data.tel,
                    }).then(e => {
                        if (e.status !== 200) {
                            Toast({ message: '操作成功' });
                        }
                    })
                }
            }

        },
        allmoney() {
            this.data.cashNum = this.userInfo.balance
        },
        fetchCodeImg() {
            this.verifycodeUrl = api.getVerifyCode();
        },
        async sendCode() {
            if (this.data.tel === "") {
                Toast('请输入手机号');
            } else {
                if (!/^1[34578]\d{9}$/.test(this.data.tel)) {
                    Toast('请输入正确的手机号');
                    return resolve(null);
                } else {
                    api.postRoot('auth/sendcode', {
                        phone: this.data.tel,
                        verifycode: this.verifycode
                    }).then(e => {
                        if (e.status !== 200) {
                            this.needVerifycode = true;
                            this.validateMsg.validate_imgcode = '请输入图形验证码'
                            this.codeIntervalTime = 60;
                            clearInterval(this.update);
                        } else {
                            this.codeIntervalTime--;//60秒倒计时
                            this.update = setInterval(() => {
                                this.codeIntervalTime--
                            }, 1000);
                            this.validateMsg.validate_imgcode = ''
                            this.data.code = e.data;
                        }
                        if (e.status === 403) {
                            this.validateMsg.validate_imgcode = e.msg;
                            this.fetchCodeImg();
                        }
                    })

                }
            }
        },
        verifyinfo() {//验证填写信息，为空是提示
            if (!this.data.name) {
                this.validateMsg.validate_name = '请输入姓名或企业名称'
            } else {
                this.validateMsg.validate_name = '';
            }
            if (!this.data.zfb) {
                this.validateMsg.validate_zfbcode = '请输入支付宝账号'
            } else {
                this.validateMsg.validate_zfbcode = '';
            }
            if (!this.data.wechart) {
                this.validateMsg.validate_wxcode = '请输入微信账号'
            } else {
                this.validateMsg.validate_wxcode = '';
            }
            if (this.data.cashNum === '') {
                this.validateMsg.validate_money = '请输入提现金额'
            } else {
                this.validateMsg.validate_money = '';
            }
            if (!this.verifycode) {
                this.validateMsg.validate_imgcode = '请输入图形验证码'
            } else {
                this.validateMsg.validate_imgcode = '';
            }
            if (!this.data.tel) {
                this.validateMsg.validate_phone = '请输入手机号'
            } else {
                this.validateMsg.validate_phone = '';
            }
            if (!this.data.code) {
                this.validateMsg.validate_phonecode = '请输入短信验证码'
            } else {
                this.validateMsg.validate_phonecode = '';
            }
            return true

        }
    },
    destroyed() {
        clearInterval(this.update)
    }
}
</script>

<style scoped>
.con {
    padding: 0 0.21rem;
}

.desc {
    padding-top: 0.25rem;
    color: #f54203;
    font-size: 0.22rem;
    height: 0.75rem;
}

.tab {
    height: 1.08rem;
    font-size: 0.26rem;
}

.box-item {
    height: 0.7rem;
    flex-grow: 1
}

.icon {
    height: 0.4rem;
    width: 0.4rem;
}

.icon2 {
    height: 0.59rem;
    width: 0.59rem;
    margin-right: 0.18rem;
}

.box-left {
    border-right: 1px solid #dadada;
    margin-right: 0.5rem;
    padding-right: 0.5rem;
}

.input-item {
    margin-top: 0.33rem;
}

img.verifycode {
    flex-grow: 1;
    height: 0.7rem;
}

.error {
    color: red;
    font-size: 0.18rem;
    display: block;
    /* margin-top: 0.1rem; */
}

.withdrawal {
    position: fixed;
    bottom: 0rem;
    left: 0;
}
</style>
<style>
.input-item .mint-button--small {
    height: 0.73rem;
    border-radius: 0;
}

.djl-input .mint-cell-text {
    font-size: 0.12rem;
    color: #5a5a5a;
}
</style>
