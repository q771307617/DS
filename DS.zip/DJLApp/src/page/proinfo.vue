<template>
    <div>
      <!-- <netraffic></netraffic> -->
        <djlheader :title="proinfo.name">
            <span @click="goback" slot="headleft">
                <mt-button icon="back"></mt-button>
            </span>
        </djlheader>
        <div v-html="proinfo.details" class="proimg"></div>
        <img @click="todinfo" :src="ftpPath + '/jl-btn.png'" class="jlbtn" />
    </div>
</template>

<script>
import djlheader from '@/components/index/Header'
import { Lazyload } from 'mint-ui'
import { mapState } from 'vuex';

export default {
    components: { djlheader, Lazyload },
    data() {
        return {
            proid: 0,
            proinfo: []
        }
    },
    mounted() {
        this.proid = this.$route.params.id;
        this.getInfo();
    },
    computed: {
        ...mapState({
            ftpPath: state => state.Public.ftpPath
        })
    },
    methods: {
        getInfo() {
            this.$ajax.get('product/get', { id: this.proid }).then((e) => {
                if (e.status == 200) {
                    this.proinfo = e.data;
                }
            })
        },
        goback() {
            this.$router.go(-1);
        },
        todinfo() {
            this.$router.push({
                name: 'dinfo',
                params: { id: this.proinfo.user_id }
            })
        }
    }
}
</script>

<style scoped>
.jlbtn {
    width: 0.97rem;
    height: 0.97rem;
    border-radius: 50%;
    position: fixed;
    bottom: 2.51rem;
    right: 0.18rem;
}

.proimg {
    width: 6.16rem;
    height: 100%;
    margin: 0px auto;
    overflow: hidden;
    margin-top: 0.18rem;
}
</style>

<style>
.proimg img {
    width: 100%;
}
</style>
