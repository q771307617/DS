<template>
  <mt-loadmore style="font-size: 0.24rem;" :top-method="loadTop" :bottom-method="loadBottom" @top-status-change="handleTopChange" :bottom-all-loaded="allLoaded" ref="loadmore">
    <ul>
      <li v-for="item in list" :key="item.user_id" style="display: flex;height: 2rem;">
        <div style="width: 0.74rem;">
          <a :href="'/dinfo/'+item.user_id">
            <img v-lazy="item.image_url" width="100%" :alt="item.nickname">
          </a>
        </div>
        <div style="flex:1">
          <div style="display: flex;">
            <div>
              <a :href="'/dinfo/'+item.user_id">{{ item.realname }}({{item.nickname}}) </a>
            </div>
            <div style="display: flex;align-items: center;">
              <p v-if="item.gender" style="width:0.18rem;font-size: 0.12rem;">
                <img :src="'icon/female.png' | randomPath " width="100%" alt="女">
              </p>
              <p v-else style="width:0.18rem;font-size: 0.12rem;">
                <img :src="'icon/male.png' | randomPath " width="100%" alt="男">
              </p>
              <p style="width:0.18rem;font-size: 0.12rem;">
                <img :src="'icon/security.png' | randomPath" width="100%" alt="保障">
              </p>
              <p style="width:0.18rem;font-size: 0.12rem;">
                <img :src="'icon/certification.png' | randomPath" width="100%" alt="认证">
              </p>
            </div>
          </div>
          <p>类目：{{item.skilful | SKILLFULL_LIST_TEXT(cla2, ' | ') }}</p>
          <div style="display: flex;justify-content: space-between;">
            <p>工作经验：{{item.exp}}年</p>
            <p style="text-align: right;">
              <span>{{item.salary}}</span>元/月</p>
          </div>
        </div>
      </li>
      <div style="height:0.95rem;"></div>
    </ul>
  </mt-loadmore>
</template>

<script>
  import {mapState} from 'vuex';
  import {Indicator, Cell, Lazyload, InfiniteScroll, Loadmore,Toast } from 'mint-ui';
  export default {
    data() {
      return {
        popupVisible: true,
        state: 'warning',
        list: [],
        topStatus:'',
        allLoaded:false,
        params: {
          classId: '', //	擅长行业	number	@mock=1
          expEnd: '', //	工作年限最大值	number	@mock=1
          expStart: '', //	工作年限最小值	number	@mock=5
          salaryStart: '',
          salaryEnd: '',
          gender: '', //	性别	number	@mock=1
          name: '', //	名称(昵称 用户名)	string	@mock=黄依
          pageNum: 1,
          pageSize: 10
        },
        configData: {
          pageCount: 0,
        }
      }
    },
    components: {},
    computed: {
      ...mapState({
        cla2: state => state.Public.cla2, //二级分类
      })
    },
    mounted() {
      this.getListData();
      this.$store.commit('setTitle', '搜索设计师')
    },
    methods: {
      handleTopChange(status) {
        this.topStatus = status;
      },
      loadTop() {
        // 加载更多数据
        this.list = [];
        this.params.pageNum = 1 ;
        this.allLoaded = false;
        this.getListData();
        this.$refs.loadmore.onTopLoaded();
      },
      loadBottom() {
      // 加载更多数据
        if (this.params.pageNum > this.configData.pageCount  ) {
          Toast('提示信息');
          this.allLoaded = true;// 若数据已全部获取完毕
          this.$refs.loadmore.onBottomLoaded();
          return false;
        }
        this.loadMore();
        this.$refs.loadmore.onBottomLoaded();
      },
      getListData() {
        Indicator.open({
          text: '加载中...',
          spinnerType: 'fading-circle'
        });
        let params = {
          ...this.params
        }
        this.$ajax.get('designer/list', params).then(e => {
          if (e.status !== 200) {
            Indicator.close();
            return false;
          }
          this.list = this.list.concat(e.data.list);
          this.configData.pageCount = Math.ceil(e.data.count / params.pageSize);
          this.params.pageNum = this.params.pageNum + 1;
          Indicator.close();
          this.loading = false;
        }).catch(function(err){
          Indicator.close();
      });
      },
      loadMore() {
        if (this.configData.pageCount < this.params.pageNum) {
          return false;
        }
        this.loading = true;
        this.getListData();
      }
    }
  }
</script>

<style scoped>
  p {
    width: 100%;
  }
</style>


