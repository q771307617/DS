<template>
  <div class="h5-container">
    <!--头部  -->
    <djlheader title="找回密码">
      <a @click="routerBack" slot="headleft">
        <mt-button style="color: #fff;" icon="back"></mt-button>
      </a>
    </djlheader>

    <!--logo  -->
    <div class="h5-logo">
      <img :src="'h5/logo.png' | randomPath" alt="点将啦">
    </div>

    <!--表单  -->
    <div v-if="isNext" class="h5-form reg">
      <div class="h5-input">
        <div class="icon" :style="'background-image: url('+imgPath(1,'h5/password.png')+')'">
        </div>
        <input type="password" placeholder="输入新密码" class="input" v-model="password" maxlength="11">
      </div>
      <div class="h5-input">
        <div class="icon" :style="'background-image: url('+imgPath(1,'h5/password.png')+')'">
        </div>
        <input type="password" placeholder="确认新密码" class="input" v-model="password2" maxlength="11"
               @keyup.enter="eidtPwd">
      </div>
      <p v-if="msg || successMsg" :class="[msg ? 'err-msg' : 'success']">{{msg || successMsg}}</p>

      <button type="button" class="btn primary" :class="{'err-msg':msg,'success':successMsg}" @click="eidtPwd">重置密码
      </button>
    </div>

    <div v-else class="h5-form reg">
      <div class="h5-input">
        <div class="icon" :style="'background-image: url('+imgPath(1,'h5/username.png')+')'">
        </div>
        <input type="tel" placeholder="用户名/手机号" class="input" v-model="username" maxlength="11">
      </div>

      <div class="h5-input" v-if="needVerifycode">
        <div class="icon" :style="'background-image: url('+imgPath(1,'h5/code1.png')+')'">
        </div>
        <input type="text" placeholder="验证码" class="input code-pic" v-model="verifycode" maxlength="4">
        <img :src="verifycodeUrl" alt="" @click="fetchCodeImg" class="verifycode">
      </div>

      <div class="h5-input">

        <div class="icon" :style="'background-image: url('+imgPath(1,'h5/code.png')+')'">
        </div>
        <input type="text" placeholder="短信验证码" class="input code-tel" v-model="code" maxlength="6">
        <a href="javascript:;" class="sendcode" @click="sendCode" v-if="codeIntervalTime === 60">发送验证码</a>
        <a href="javascript:;" class="disabled" v-else>{{codeIntervalTime}}s后再获取</a>
      </div>
      <p v-if="msg || successMsg" :class="[msg ? 'err-msg' : 'success']">{{msg || successMsg}}</p>

      <button type="button" class="btn primary" :class="{'err-msg':msg,'success':successMsg}" @click="submit">下一步
      </button>
    </div>

    <!--顶部  -->
    <div class="h5-footer">已有账号？
      <a href="javascript:" @click="login">立即登录</a>
    </div>
  </div>
</template>
<script>
  import api from '@/api'
  import { Toast} from 'mint-ui';
  import djlheader from '@/components/index/Header'

  export default {
    data() {
      return {
        username: '',
        verifycode: '',
        code: '',
        password: '',
        password2: '',
        msg: '',
        verifycodeUrl: '',
        codeIntervalTime: 60,
        update: 0,
        needVerifycode: false,
        successMsg: '',
        isNext: false
      }
    },
    mounted() {
      this.fetchCodeImg()
    },
    destroyed() {
      clearInterval(this.update)
    },
    watch: {
      codeIntervalTime(val) {
        if (!val) {
          this.codeIntervalTime = 60;
          clearInterval(this.update)
        }
      },
    },
    methods: {
      login(){
        this.$router.replace({name: 'login'});
      },
      imgPath(index, name) {
        const n = index % 5 + 1;
        return `http://${n}.img.dianjiangla.com/assets/${name}`
      },
      fetchCodeImg() {
        this.verifycodeUrl = api.getVerifyCode();
      },

      async sendCode() {
        const result = await this.verifyUsername();
        if (!result) return;// 验证不通过

        this.codeIntervalTime--;
        this.update = setInterval(() => {
          this.codeIntervalTime--
        }, 1000);

        const r = new Date().getTime();
        api.postRoot('auth/sendcode', {phone: this.username, verifycode: this.verifycode, r: r}).then(e => {
          if (e.status !== 200) {
            this.needVerifycode = true;
            this.msg = this.verifycode ? '验证码错误' : '请输入验证码';
            this.fetchCodeImg()
            this.codeIntervalTime = 60;
            clearInterval(this.update)
            return;
          }

          this.msg = '';
          this.code = e.data;
          this.successMsg = '验证码已发送，注意查收'
        })
      },

      submit() {
        if (!this.verifyCode()) return; //短信验证码不正确
        this.postVerifyPhone();
        this.successMsg = '';
      },

      eidtPwd(){
        if (!this.verifyPassword()) return; //密码格式不正确
        const r = new Date().getTime();
        api.postRoot('auth/password/forget', {
          phone: this.username,
          code: this.code,
          password: this.password
        }).then(e => {
          if (e.status !== 200) {
            this.msg = e.msg;
            return
          }

          api.postRoot('auth/login', {
            password: this.password,
            username: this.username,
            r: r
          }).then(e => {
            if (e.status !== 200) {
              location.href = '/login'
            } else {
              Toast('登录成功');
//              location.href = '/'
              this.$router.replace({name:'index'})
            }
          })
        })
      },
      verifyPassword() {
        const password = this.password.trim();
        if (!password || password.length < 6 || password.length > 11) {
          this.msg = '请输入6-11位数字、字母组合的密码'
          return;
        }
        const password2 = this.password2.trim();
        if (!password2 || password2.length < 6 || password2.length > 11) {
          this.msg = '请输入6-11位数字、字母组合的密码'
          return;
        }
        if (password != password2) {
          this.msg = '两次密码不同'
          return;
        }
        this.msg = '';
        return true;
      },
      verifyUsername() {
        let _this = this;
        return new Promise((resolve, reject) => {
          if (!/^1[34578]\d{9}$/.test(this.username)) {
            _this.msg = '请输入11位数字的手机号'
            return resolve(null);
          }

          api.getRoot('auth/isexist', {username: this.username}).then(e => {
            if (e.status == 200) {
              _this.msg = '该手机号未注册'
              return resolve(false)
            }

            _this.msg = '';
            resolve(true)
          })
        })
      },
      postVerifyPhone(){
        api.postRoot('auth/verify/phone', {
          code: this.code,
        }).then(e => {
          if (e.status !== 200) {
            this.msg = e.msg;
          } else {
            this.isNext = true;
          }
        })
      },
      verifyCode() {
        if (this.username.length < 11) {
          this.msg = '请输入11位数字的手机号'
          return;
        }

        const code = this.code.trim();
        if (!code || code.length < 6 || code.length > 6) {
          this.msg = '请输入6位数字短信验证码'
          return;
        }

        if (!code || code.length < 6 || code.length > 6) {
          this.msg = '短信验证码错误'
          return;
        }

        this.msg = '';
        return true;
      },
      routerBack() {
        this.$router.go(-1);
      },
    },
    components: {djlheader}
  }
</script>
<style scoped>
  /*登录、注册页*/
  * {
    font-size: auto;
    font-family: 微软雅黑
  }

  html {
    font-size: 625%;
  }

  em {
    font-style: normal;
  }

  .h5-container a {
    color: #f54203;
  }

  .h5-header {
    background-color: #fff;
    font-size: 0.28rem;
    text-align: center;
    border-bottom: 1px solid #dddee1;
    height: 0.82rem;
    line-height: 0.82rem;
    color: #282828;
  }

  .h5-header .btn {
    float: left;
    margin-left: 0.38rem;
    color: #282828;
  }

  .h5-header .btn img {
    height: 0.28rem;
  }

  .h5-logo {
    margin-top: 0.8rem;
    text-align: center;
  }

  .h5-logo img {
    width: 4.02rem;
    height: 1.01rem;
  }

  .h5-form {
    margin: 0 0.57rem;
    margin-top: 1.5rem;
  }

  .h5-form.reg {
    margin-top: 1.3rem;
  }

  .h5-form.reg .h5-input {
    margin-top: 0.35rem;
  }

  .h5-form .h5-input {
    width: 5.36rem;
    display: flex;
    border: 1px solid #dddee1;
    border-radius: 0.08rem;
  }

  .h5-form .h5-input input.code-tel {
    width: 2.5rem;
  }

  .h5-form .h5-input input.code-pic {
    width: 2.5rem;
  }

  .h5-form .h5-input .sendcode {
    white-space: nowrap;
    line-height: 0.7rem;
    margin-right: 0.25rem;
    color: #737373;
    font-size: 0.25rem;
    flex-grow: 1;
    text-align: right;
  }

  .h5-form .h5-input img.verifycode {
    flex-grow: 1;
    height: 0.7rem;
  }

  .h5-form .h5-input .disabled {
    white-space: nowrap;
    line-height: 0.7rem;
    margin-right: 0.25rem;
    cursor: not-allowed;
    color: #888888;
    font-size: 0.25rem;
  }

  .h5-form .h5-input .input {
    width: 100%;
    height: 0.7rem;
    font-size: 0.24rem;
    text-indent: 0.24rem;
    color: #888888;
    border: none;
    border-top-right-radius: 0.06rem;
    border-bottom-right-radius: 0.06rem;
  }

  .h5-form .h5-input .icon {
    width: 0.74rem;
    background-color: #dddee1;
    text-align: center;
    float: left;
    padding: 0.04rem 0;
    border-top-left-radius: 0.06rem;
    border-bottom-left-radius: 0.06rem;
    background-position: center center;
    background-repeat: no-repeat;
    background-size: 0.3rem 0.3rem;
  }

  .h5-form .h5-input-pwd {
    margin-top: 0.36rem;
  }

  .h5-form .forgetpwd {
    width: 5.36rem;
    font-size: 0.24rem;
    text-align: right;
    color: #f54203;
    margin-top: 0.2rem;
  }

  .h5-form .btn {
    color: #fff;
    border: none;
    border-radius: 0.05rem;
  }

  .h5-form .btn.err-msg, .h5-form .btn.success {
    margin-top: 1rem;
  }

  .h5-form p.success {
    font-size: 0.24rem;
    color: #19be6b;
  }

  .h5-form .btn.primary {
    margin-top: 0.6rem;
    width: 5.36rem;
    height: 0.7rem;
    background-color: #f54203;
    font-size: 0.28rem;
  }

  .h5-form.reg .btn.primary {
    margin-top: 0.5rem;
  }

  .h5-form p.err-msg {
    font-size: 0.22rem;
    color: #FF3030;
    margin: 0.02rem 0;
  }

  .h5-form .h5-form p.success {
    font-size: 0.18rem;
    color: #19be6b;
    margin: 0.02rem 0;
  }

  .h5-footer {
    margin-top: 0.52rem;
    text-align: center;
    font-size: 0.24rem;
    margin-bottom: 0.55rem;

    color: #282828
  }
</style>

