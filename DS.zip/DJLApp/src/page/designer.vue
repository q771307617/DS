<template>
  <div class="main" style="font-size: 0.12rem;">
    <router-view></router-view>
  </div>
</template>

<script>
  export default {
    data() {
      return {}
    },
  }
</script>

<style scoped>

</style>


