<template>
    <div class="account">
        <div class="header">
            <p class="title">
                <span @click="goback" class="title-icon">
                    <mt-button icon="back" class="backbtn"></mt-button>
                </span>
                <span>
                    账户管理
                </span>
            </p>
            <div class="money_info">
                <money-info></money-info>
            </div>
        </div>

        <!-- <div class="list">
            <mt-cell title="我的优惠券" is-link :to="{ name: 'coupon' }" class="cell">
                <img :src="ftpPath + '/icon-arrow.png'" class="list-right" />
                <img slot="icon" :src="ftpPath+ '/icon-coupon.png'" class="list-left">
            </mt-cell>
        </div> -->

        <div class="btn-item clearfix">
            <mt-button size="large" class="large-btn" @click="recharge">充值</mt-button>
            <!-- <mt-button size="large" class="large-btn" @click="cash">提现</mt-button> -->
            <mt-button size="large" class="large-btn outbtn" @click="logout">退出登录</mt-button>
        </div>
    </div>
</template>

<script>
import { Button, Cell } from 'mint-ui'
import { mapState, mapActions } from 'vuex'
import moneyInfo from '@/components/personal/moneyInfo'
export default {
    data() {
        return {}
    },
    components: {
        Cell,
        'mt-button': Button,
        'money-info': moneyInfo
    },
    computed: {
        ...mapState({
            isLogin: state => state.User.isLogin,
            ftpPath: state => state.Public.ftpPath
        })
    },
    methods: {
        ...mapActions(["outLogin", "getLoginState"]),
        goback() {
            this.$router.go(-1);
        },
        recharge() {
            this.$router.push({
                name: 'recharge'
            });
        },
        cash() {
            this.$router.push({
                name: 'cash'
            });
        },
        logout() {
            this.outLogin();
            //跳转到首页
            this.$router.push({ path: '/' });
        }
    }
}
</script>

<style scoped>
.header {
    height: 3.3rem;
    background: linear-gradient(to top, #fe8e01, #f54102);
}

.title {
    padding: 0.4rem 0;
    text-align: center;
    font-size: 0.36rem;
    color: #fff;
    line-height: 1;
}

.title-icon {
    position: fixed;
    left: 0;
}

.line {
    padding-top: 0.2rem;
    height: 0.7rem;
    width: 0.02rem;
}

.list {
    padding: 0.5rem 0.18rem 0 0.18rem;
}

.cell {
    height: 0.89rem;
    border-top: 1px solid #e4e4e4;
    border-bottom: 1px solid #e4e4e4;
}

.list-left {
    height: 0.26rem;
    width: 0.39rem;
    margin-right: 0.08rem;
}

.list-right {
    height: 0.31rem;
    width: 0.17rem;
}

.btn-item {
    position: fixed;
    bottom: 0.3rem;
    width: 6.15rem;
    margin-left: 0.18rem;
}
.large-btn{
    color: #fff;
    font-size: 0.3rem;
    margin-top: 0.3rem;
    border-radius: 0;
    height: 0.73rem;
    background: #f54102;
}
.outbtn {
    background: #5a5a5a;
    font-size: 0.26rem;
}

.backbtn {
    background: transparent;
    border: 0;
    color: #fff;
    box-shadow: none;
}

.money_info {
    margin-top: 0.35rem;
}
</style>

<style>
.header .mint-button {
    height: inherit;
}

.account .mint-cell-wrapper {
    height: 0.89rem;
    padding: 0;
}

.account .mint-cell-allow-right::after {
    border: 0;
}

.account .mint-cell-text {
    color: #5a5a5a;
    font-size: 0.28rem;
}

.account .mint-cell-value.is-link {
    margin-right: 0
}
</style>