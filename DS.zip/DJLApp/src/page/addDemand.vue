<template>
    <div class="main">
        <djlheader :title="'发布需求'">
            <span @click="goback" slot="headleft">
                <mt-button icon="back"></mt-button>
            </span>
        </djlheader>
        <div class="con">
            <p class="tit">*需求标题</p>
            <textarea placeholder="一句话描述您的需求，例如：**旗舰店，首页设计等" class="txt height100" v-model="demand_tittle"></textarea>
            <p class="error">{{err_msg.err_tilte}}</p>
            <p class="tit">*需求详情</p>
            <textarea placeholder="请填写您具体需求" class="txt height147" v-model="demand_details"></textarea>
            <p class="error">{{err_msg.err_del}}</p>
            <p class="tit">*店铺信息</p>
            <div class="dianpu" @click="ptclick">
                <p>选择平台</p>
                <span> {{pt_name}}&nbsp<img :src="ftpPath + '/jt_right.png'" class="dianpuimg"></span>
            </div>
            <p class="error">{{err_msg.err_pt}}</p>
            <div class="dianpu" @click="hyclick">
                <p>选择类目</p>
                <span> {{lm_name}}&nbsp<img :src="ftpPath + '/jt_right.png'" class="dianpuimg"></span>
            </div>
            <p class="error">{{err_msg.err_lm}}</p>
            <div class="dianpu" @click="qyclick">
                <p>设计类型</p>
                <span> {{sj_name}}&nbsp<img :src="ftpPath + '/jt_right.png'" class="dianpuimg"></span>
            </div>
            <p class="error">{{err_msg.err_sj}}</p>
            <div class="dianpu" @click="popupVisible3">
                <p>预算</p>
                <span> {{budget}}元&nbsp<img :src="ftpPath + '/jt_right.png'" class="dianpuimg"></span>
            </div>
            <p class="error">{{err_msg.err_ys}}</p>
            <div style="height:.75rem"></div>
            <mt-button size="large" class="big-btn fbxqbtn" @click="push_demand">发布需求</mt-button>
        </div>

        <div class="pop" v-if="popupVisible">
            <djlheader :title="poptitle" class="pop-header">
                <span @click="close" slot="headleft">
                    <mt-button icon="back"></mt-button>
                </span>
                <span slot="headright" @click="close">X</span>
            </djlheader>

            <mt-popup v-model="popupVisible" position="bottom" popup-transition="popup-fade" class="pop-body">
                <ul>
                    <li v-for="item in lists" :key="item.id" @click="select(item)">{{item.name}}</li>
                </ul>
            </mt-popup>
        </div>
    </div>
</template>

<script>
import djlheader from '@/components/index/Header'
import { mapActions, mapState } from 'vuex'
import { MessageBox, Toast } from 'mint-ui';

export default {
    data() {
        return {
            popupVisible: false,
            lists: '',
            pt_name: '',
            lm_name: '',
            classId: '',
            sj_name: '',
            typeId: '',
            poptitle: '',
            budget: '0',
            demand_tittle: '',
            demand_details: '',
            err_msg: {
                err_tilte: '',
                err_del: '',
                err_pt: '',
                err_lm: '',
                err_sj: '',
                err_ys: ''
            }
        }
    },
    computed: {
        ...mapState({
            ftpPath: state => state.Public.ftpPath,
            classlist: state => state.Public.classlist,//平台
            qylist: state => state.Public.qylist,//设计类型
            cla2: state => state.Public.cla2,//类目
        })
    },
    components: { djlheader, },
    mounted() {
        this.getHY();
        this.getQY();
    },
    methods: {
        ...mapActions(['getHY', 'getQY']),
        select(item) {
            this.name = item.name;
            if (this.poptitle == "选择平台") {
                this.pt_name = item.name
            }
            if (this.poptitle == "选择类目") {
                this.lm_name = item.name
                this.classId = item.id
            }
            if (this.poptitle == "设计类型") {
                this.sj_name = item.name
                this.typeId = item.id
            }
            this.close()
        },
        popupVisible3() {
            MessageBox.prompt(' ', '请输入您的预算', { closeOnClickModal: false, inputType: 'number' }).then(({ value }) => {
                if (value > 0) {
                    this.budget = value
                } else {
                    Toast({ message: '请输入大于0的金额', duration: 2000 });
                }
            });
        },
        async  push_demand() {
            console.log(this.qylist)
            const result = await this.verifyinfo();
            if (!result) return; // 验证不通过
            this.$ajax.post('demand/add', {
                budget: this.budget,
                title: this.demand_tittle,
                details: this.demand_details,
                classStr: `${this.pt_name},${this.lm_name}`,
                typeId: this.typeId,
                classId: this.classId,
            }).then((e) => {
                if (e.status != 200) {
                    return
                }
                Toast({ message: '需求发布成功！！', duration: 2000 });
                this.$router.push({ name: 'demand' });
            })
        },
        ptclick() {
            this.lists = this.classlist;
            this.poptitle = "选择平台";
            this.popupVisible = true;
        },
        hyclick() {
            this.lists = this.cla2;
            this.poptitle = "选择类目";
            this.popupVisible = true;
        },
        qyclick() {
            this.lists = this.qylist;
            this.poptitle = "设计类型";
            this.popupVisible = true;
        },
        verifyinfo() {//验证填表单信息，为空是提示
            if (!this.demand_tittle) {
                this.err_msg.err_tilte = '请输入需求标题'
                return;
            } else {
                this.err_msg.err_tilte = '';
            }
            if (!this.demand_details) {
                this.err_msg.err_del = '请输入需求详情'
                return;
            } else {
                this.err_msg.err_del = '';
            }
            if (!this.pt_name) {
                this.err_msg.err_pt = '请选择一个平台'
                return;
            } else {
                this.err_msg.err_pt = '';
            }
            if (!this.lm_name) {
                this.err_msg.err_lm = '请选择一个类目'
                return;
            } else {
                this.err_msg.err_lm = '';
            }
            if (!this.sj_name) {
                this.err_msg.err_sj = '请选择一个类型'
                return;
            } else {
                this.err_msg.err_sj = '';
            }
            if (this.budget == 0) {
                this.err_msg.err_ys = '请输入您的预算'
                return;
            } else {
                this.err_msg.err_ys = '';
            }
            return true;
        },
        close() {
            this.popupVisible = false;
        },
        goback() {
            this.$router.go(-1);
        },
    }
}
</script>

<style>
.con .mint-button-text {
    order: -1;
}
</style>

<style scoped>
.con {
    padding: 0 0.2rem;
}

.icon {
    display: flex;
}

.tit {
    font-size: 0.3rem;
    color: #f54203;
    height: 0.5rem;
    line-height: 0.5rem;
    margin-top: 0.1rem;
}

.dianpu {
    font-size: 0.24rem;
    height:0.42rem;
    display: flex;
    justify-content: space-between;
    box-shadow: 0 0 1px #b8bbbf;
    align-items: center;
    padding:0.15rem;
    margin:0.05rem;
    background: #fff;
}

.dianpu p {
    align-self: center;
}

.dianpu span {
    display: flex;
    align-items: center;
    text: center;
}

.dianpuimg {
    display: inline-block;
    width: 0.17rem;
    height: 0.31rem;
    overflow: hidden;
}

.error {
    font-size: 0.15rem;
    color: #f54203;
}

.height100 {
    height: 1rem;
}

.height147 {
    height: 1.47rem;
}

.txt {
    width: 100%;
    display: block;
    border-color: #ddd;
}

.btn {
    overflow: hidden;
    font-size: 0.22rem;
    display: flex;
    color: #5a5a5a;
    border-radius: 0;
    background: #fff;
    /*border:1px solid #dddddd;*/
    height: 0.74rem;
    padding: 0 0.15rem;
    margin-top: 0.05rem;
}

.btn img {
    display: inline-block;
    width: 0.17rem;
    height: 0.31rem;
    /*position: relative;
    right:0.15rem;*/
}

.fbxqbtn {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    border-radius: 0;
    background: #f54203;
    color: #fff;
    font-size: 0.3rem;
}

.pop {
    position: relative;
    top: 0;
    left: 0;
    bottom: 0;
    height: 100%;
    width: 6.5rem;
}

.pop-header {
    position: fixed;
    top: 0;
    left: 0;
    width: 6.5rem;
    z-index: 9999;
}

.pop-body {
    width: 100%;
    text-align: center;
    position: fixed;
    top: 0.75rem;
    right: 0;
    bottom: 0;
    overflow: scroll;
    font-size: 0.26rem;
}

.pop-body ul li {
    height: 0.74rem;
    line-height: 0.74rem;
    border-bottom: 1px solid #eee;
}
</style>
