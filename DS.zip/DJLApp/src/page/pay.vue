<template>
  <div>
    <djlheader :title="nickname">
      <a @click="routerBack" slot="headleft">
        <mt-button style="color: #fff;" icon="back"></mt-button>
      </a>
    </djlheader>
    <div v-if="orderType == 'recharge'" class="xinfo">
      <div>
        <p>充值订单号：{{order.orderId}}</p>
      </div>
      <div>
        <p>下单时间：{{start_time}}</p>
      </div>
      <div style="border-bottom: 0.1rem solid #f7f7f7;">充值金額：<span style="color: #f54203;">{{order.amount}}元</span>
      </div>
    </div>
    <div v-else-if="orderType != 'demand'">
      <itemDesignerInfo :info="mg"></itemDesignerInfo>
      <div class="info">
        <ul>
          <li class="box space-between">
            <div>雇佣类型：{{types[order.type]}}</div>
            <div v-if="order.type == 0 || order.type == 1 ">雇佣时间：
              <span v-if="order.type == 0">{{ start_time | getDateDiff(end_time, 'month') }}个月</span>
              <span v-else>{{ start_time | getDateDiff(end_time, 'day') }}天</span>
            </div>
          </li>
          <li class="box space-between ">
            <div>{{ start_time }}</div>
            <div style="width:2rem; "><img width="100%" :src="'h5/icon-jiantou.png' | randomPath" alt="<----->"></div>
            <div>{{ end_time}}</div>
          </li>
          <li class="box space-between">
            <div>托管工资</div>
            <div style="color: #f54203;">{{order.price}}元</div>
          </li>
        </ul>
      </div>
    </div>
    <div v-else class="xinfo">
      <div style="border-bottom: 0.1rem solid #f7f7f7;">需求名称：<span style="display: inline-block;">{{order.title}}</span>
      </div>
      <div style="border-bottom: 1px solid #c8c8c8;">
        <p>设计师：{{order.designer_nickname}}</p>
        <p style="margin-top: 0.26rem;">预计完成时间：{{end_time}}</p>
      </div>
      <div class="box space-between">
        <p>托管工资</p>
        <p style="color: #f54203;">{{order.price}}元</p>
      </div>
    </div>
    <div class="pay-style">
      <ul>
        <li t="pay-item" @click="setPaytype(3)" class="box space-between" v-if="orderType != 'recharge'">
          <div class="icon-big"><img :src="'h5/icon-pay-ye.png' | randomPath" alt="余额支付"></div>
          <div style="flex: 1;text-indent:0.3rem;">
            <span :class="payType == 3? 'fontcolor':''">可用余额：{{userInfo.balance || 0}}元</span><span v-if="userInfo.balance < order.price" style="color: #f54203;">（余额不足）</span>
          </div>
          <div v-show="payType==3" class="icon-min"><img :src="'h5/icon-pay-active.png' | randomPath"></div>
          <div v-show="payType!=3" class="icon-min"><img :src="'h5/icon-pay-default.png' | randomPath"></div>
        </li>
        <li t="pay-item" @click="setPaytype(2)" class="box space-between">
          <div class="icon-big"><img :src="'h5/icon-pay-wx.png' | randomPath" alt="微信支付"></div>
          <div :class="payType == 2? 'fontcolor':''" style="flex: 1;text-indent:0.3rem;">微信支付</div>
          <div v-show="payType==2" class="icon-min"><img :src="'h5/icon-pay-active.png' | randomPath"></div>
          <div v-show="payType!=2" class="icon-min"><img :src="'h5/icon-pay-default.png' | randomPath"></div>
        </li>
        <li t="pay-item" v-if="!isWX" @click="setPaytype(1)" class="box space-between">
          <div class="icon-big"><img :src="'h5/icon-pay-zf.png' | randomPath" alt="支付宝支付"></div>
          <div :class="payType == 1? 'fontcolor':''" style="flex: 1;text-indent:0.3rem;">支付宝支付</div>
          <div v-show="payType==1" class="icon-min"><img :src="'h5/icon-pay-active.png' | randomPath"></div>
          <div v-show="payType!=1" class="icon-min"><img :src="'h5/icon-pay-default.png' | randomPath"></div>
        </li>
      </ul>
      <div v-if="!userInfo.pay_password && !balancState && payType==3" class="zf">
        <router-link class="zf-btn" :to="{name:'passwordManage',params:{active:1}}">设置支付密码</router-link>
      </div>
      <div @click="setPWD()" v-if="userInfo.pay_password && !balancState && payType==3" class="box space-between zf">
        <div class="pwd-btn">输入支付密码</div>
        <div class="pwd-input"><input v-model="params.password" type="password" disabled></div>
      </div>
    </div>
    <mt-tabbar fixed>
      <a id="pay-btn" :class=" balancState ? 'disabled':''" @click="paySubmit" class="big-btn">{{payBtnTxt}}</a>
    </mt-tabbar>
  </div>
</template>
<script>
  import api from '@/api'
  import {
    mapState,
    mapActions
  } from 'vuex';
  import {
    Toast,
    Tabbar,
    MessageBox
  } from 'mint-ui';
  import djlheader from '@/components/index/Header'
  import itemDesignerInfo from '@/components/designer/item-designer-info'
  import moment from "moment";
  import * as filter from "@/filter";
  export default {
    data() {
      return {
        order: {},
        mg: {},
        msg: '',
        nickname: '',
        types: ['包月', '定制'],
        payType: 2,
        orderType: '',
        payBtnTxt: '确认支付宝支付',
        isWX: false,
        balancState: true,
        isPwd: 0,
        params: {
          hireId: '',
          password: ''
        },
        orderId: '',
        start_time: '',
        end_time: '',
      }
    },
    methods: {
      ...mapActions(["getUserData"]),
      submit() {
        const r = new Date().getTime();
      },
      getDesigner(id) {
        api.getRoot("designer/get", {
          id: id
        }).then((e) => {
          if (e.status == 200 && e.data) {
            this.mg = e.data;
            this.nickname = e.data.nickname + ' 的简历';
            this.setPaytype(2);
            return;
          }
          this.$router.push('/');
          Toast('订单不存在');
        });
      },
      setPaytype(val) {
        this.payType = val;
        if (val == 1) {
          this.payBtnTxt = '确认支付宝支付'
        } else if (val == 2) {
          this.payBtnTxt = '确认微信支付'
        } else {
          this.payBtnTxt = '确认余额支付'
        }
        if (this.userInfo.balance < this.order.price && this.payType == 3) {
          this.balancState = true;
        } else {
          this.balancState = false;
        }
      },
      setPWD() {
        MessageBox.prompt('请输入支付密码', '', {
          inputType: 'password',
        }).then((e) => {
          if (e.action == 'confirm') {
            this.params.password = e.value;
            this.paySubmit();
          }
        });
      },
      //微信支付
      payWX() {
        /**五分钟倒计时，超时不查询 */
        setTimeout(() => {
          clearInterval(this.update)
        }, 1000 * 60 * 5);
        if (!api.isWX()) { //非微信端，使用h5支付
          api.h5PayWX(this.orderId);
          this.update = setInterval(() => {
            api.getRoot('pay/wx/query', { out_trade_no: String(this.orderId) }).then(e => {
              if (e.status !== 200) {
                return;
              }
              if (e.data === 'SUCCESS') {
                clearInterval(this.update);
                this.jumpPage();
              }
            })
          }, 1500)
        }
        //微信内部使用公众号支付
        api.getRoot('pay/wx/js', { //获取微信支付参数
          id: this.orderId
        }).then((e) => {
          if (e.status == 200 && e.data) {
            let _this = this;
            WeixinJSBridge.invoke('getBrandWCPayRequest', e.data, function(res) {
              switch (res.err_msg) {
                case 'get_brand_wcpay_request:ok':
                  _this.jumpPage();
                  break;
                case 'get_brand_wcpay_request:cancel':
                  Toast('您已取消支付');
                  break;
                case 'get_brand_wcpay_request:fail':
                  Toast('支付失败');
                  break;
                default:
                  break;
              }
            })
          } else {
            Toast('授权异常:' + e.msg);
          }
        }).catch((e) => {
          Toast('授权异常:' + JSON.stringify(e));
        })
      },
      paySubmit() {
        if (this.payType == 1) { //支付宝
          api.h5PayAli(this.orderId)
        } else if (this.payType == 2) { //微信支付
          this.payWX()
        } else { //余额支付
          if (this.balancState) {
            Toast('余额不足请充值');
            return;
          }
          if (!this.params.password) {
            this.setPWD();
            return;
          }
          this.payPost();
        }
      },
      payPost() {
        let params = {
          ...this.params
        }
        params.id = this.orderId;
        api.postRoot("/pay/account", params).then((e) => {
          if (e.status === 200) {
            Toast('支付成功');
            this.jumpPage();
            return;
          }
          this.toastMsg(e.msg);
        });
      },
      toastMsg(msg) {
        MessageBox.prompt(msg, '', {
          confirmButtonText: '找回密码',
          showInput: false
        }).then(() => {
          this.$router.push({
            name: 'passwordManage',
            params: {
              active: 1
            }
          });
        });
      },
      jumpPage() {
        if (this.orderType == 'recharge') {
          this.$router.replace({
            name: 'personal',
          });
          return;
        }
        if (this.orderType == 'demand') {
          this.$router.replace({
            name: 'demand',
            params: {
              active: 3
            }
          });
          return;
        }
        this.$router.replace({
          name: 'paylist',
          params: {
            status: 1
          }
        });
      },
      getDemandInfo() {
        api.get('demand/get', {
          id: this.params.hireId
        }).then((e) => {
          if (e.status == 200 && e.data) {
            this.order = e.data;
            this.orderId = e.data.order_id;
            this.end_time = moment(e.data.plan_complete_date).format("YYYY-MM-DD")
            this.order.price = e.data.budget;
            this.nickname = '需求支付确认';
            this.setPaytype(2);
            return;
          }
          this.$router.push('/');
          Toast('订单不存在')
        })
      },
      getHireInfo() {
        api.getRoot("hire/info", {
          hireId: this.params.hireId
        }).then((e) => {
          if (e.status == 200 && e.data) {
            this.order = e.data;
            this.orderId = e.data.order_id;
            this.start_time = moment(e.data.start_time).format("YYYY-MM-DD")
            this.end_time = moment(e.data.end_time).format("YYYY-MM-DD")
            this.getDesigner(e.data.designer_id)
            this.setPaytype(2);
            return;
          }
          this.$router.push('/');
          Toast('订单不存在')
        });
      },
      getpayInfo() {
        api.getRoot('order/get', {
          id: this.params.hireId
        }).then((e) => {
          if (e.status == 200) {
            this.order = e.data;
            this.orderId=e.data.orderId
            this.start_time = moment(e.data.createTime).format("YYYY-MM-DD hh:mm:ss")
            this.nickname = '立即充值';
            this.setPaytype(2);
            return;
          }
          this.$router.push('/');
          Toast('订单不存在')
        });
      },
      routerBack() {
        this.$router.go(-1);
      },
    },
    mounted() {
      this.params.hireId = this.$route.query.hireId
      this.orderType = this.$route.query.orderType
      // this.orderId = this.$route.query.order
      this.getUserData();
      if (this.orderType == 'recharge') {
        this.getpayInfo();
      } else if (this.orderType == 'demand') {
        this.getDemandInfo();
      } else {
        this.getHireInfo();
      }
      if (api.isWX()) {
        this.isWX = true;
        this.setPaytype(2);
      }
    },
    computed: {
      ...mapState({
        userInfo: state => state.User.userInfo,
      })
    },
    components: {
      djlheader,
      itemDesignerInfo
    },
  }
</script>
<style scoped>
  .xinfo {
    font-size: 0.26rem;
    color: #5a5a5a;
    line-height: 0.4rem;
    border-bottom: 0.1rem solid #f7f7f7;
  }
  .xinfo div {
    padding: 0.26rem .42rem;
  }
  .info {
    background-color: #fff;
    border-bottom: 0.1rem solid #f7f7f7;
  }
  .info ul {
    overflow: hidden;
  }
  .info ul li {
    border-bottom: 1px solid #c8c8c8;
    padding: 0.15rem 0.42rem;
    line-height: 0.45rem;
    font-size: 0.26rem;
    color: #5a5a5a;
  }
  .info ul li:last-child {
    border-bottom: none;
  }
  .pay-style {
    overflow: hidden;
    background-color: #fff;
  }
  .pay-style ul {
    overflow: hidden;
  }
  .pay-style ul li {
    border-bottom: 1px solid #c8c8c8;
    padding: 0.15rem 0.42rem;
    line-height: 0.45rem;
    font-size: 0.26rem;
    color: #5a5a5a;
    align-items: center;
  }
  .pay-style ul li img {
    width: 100%;
  }
  .icon-big {
    width: 0.45rem;
    height: 0.45rem;
  }
  .icon-min {
    width: 0.3rem;
    height: 0.3rem;
  }
  .disabled {
    background-color: #ccc;
  }
  .zf {
    margin-top: 0.77rem;
    align-items: center;
    padding: 0 0.42rem;
  }
  .zf-btn {
    display: block;
    width: 1.82rem;
    height: 0.5rem;
    line-height: 0.5rem;
    color: #fff;
    background-color: #f54203;
    border-radius: 0.06rem;
    font-size: 0.26rem;
    text-align: center;
  }
  .fontcolor {
    color: #f54203;
  }
  .pwd-btn {
    width: 2.48rem;
    color: #f54203;
    font-size: 0.28rem;
  }
  .pwd-input {
    border: 1px solid #c8c8c8;
    width: 3.69rem;
    height: 0.5rem;
    overflow: hidden;
  }
  .pwd-input input {
    height: 0.45rem;
    width: 100%;
    border: none;
  }
</style>
