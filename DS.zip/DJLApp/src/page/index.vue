<template>
    <div class="main">
        <!-- <netraffic></netraffic> -->
        <djlheader :title="'点将啦'">
            <router-link :to="{ path: '/personal' }" slot="headright" v-if="info.id">
                <img :src="ftpPath + '/icon_tx.png'" class="headtx"/>
            </router-link>
            <router-link :to="{ path: '/login' }" slot="headright" v-else>
                <img :src="ftpPath + '/icon_tx.png'" class="headtx"/>
            </router-link>
        </djlheader>
        <banner></banner>
        <designer></designer>
        <djlnav></djlnav>
        <release></release>
        <djlfooter></djlfooter>
    </div>
</template>

<script>
import djlheader from '@/components/index/Header'
import banner from '@/components/index/Banner'
import designer from '@/components/index/RecommendedDesigner'
import djlnav from '@/components/index/Nav'
import release from '@/components/index/Release'
import djlfooter from '@/components/index/Footer'
import { mapState } from 'vuex'

export default {
    data () {
        return {}
    },
    computed: {
        ...mapState({
            ftpPath: state => state.Public.ftpPath,
            info: state => state.User.userInfo
        })
    },
    components: {
        djlheader,
        banner,
        designer,
        djlnav,
        release,
        djlfooter
    }
}
</script>

<style scoped>
.headtx{
    height:0.33rem;
    width:0.33rem;
}
</style>

