<template>
    <div>
        <djlheader title="立即充值">
            <span @click="goback" slot="headleft">
                        <mt-button icon="back"></mt-button>
                    </span>
        </djlheader>
        <div class="con">
            <mt-field label="充值金额：" placeholder="点击输入充值金额" v-model="money" class="item" type="number"></mt-field>
        </div>
        <mt-button size="large" class="large-btn footerbtn" @click="payment">确认支付</mt-button>
    </div>
</template>

<script>
    import djlheader from '../components/index/Header.vue'
    import {
        Field,
        Cell,
        Button,
        Toast
    } from 'mint-ui'
    import api from '@/api'
    import {
        mapState,
        mapActions
    } from 'vuex';
    import * as filter from "@/filter";
    export default {
        data() {
            return {
                money: '',
                radio: '1',
                orderId: '',
                isWX: false,
            }
        },
        components: {
            djlheader,
            Field,
            Cell,
            'mt-button': Button
        },
        computed: {
            ...mapState({
                ftpPath: state => state.Public.ftpPath,
                userInfo: state => state.User.userInfo,
            })
        },
        mounted() {
            if (api.isWX()) {
                this.isWX = true;
            }
        },
        methods: {
            jumpPage() {
                location.href = "/user/pay/?hireId=" +this.orderId+ "&orderType=recharge"
            },
            payment() {
                if (this.money !== '') {
                    api.getRoot('pay/account/create', {
                        amount: this.money
                    }).then(e => {
                        if (e.status === 200) {
                            this.orderId = e.data;
                            this.jumpPage()
                        }
                        Toast({
                            message: e.msg
                        });
                    })
                } else {
                    Toast({
                        message: '请输入充值金额',
                        duration: 2000
                    });
                }
            },
            goback() {
                this.$router.go(-1);
            },
        }
    }
</script>

<style>
    .item .mint-field-core {
        text-align: right;
    }
</style>

<style scoped>
    .con {
        background: rgba(247, 247, 247, 1);
        padding: 0.2rem 0.18rem;
    }
    .item {
        height: 0.8rem;
        background: #fff;
    }
    .item-cell {
        margin-top: 0.2rem;
        margin-bottom: 0.05rem;
    }
    .icon {
        height: 0.4rem;
        width: 0.4rem;
    }
    .icon2 {
        height: 0.59rem;
        width: 0.59rem;
    }
    .footerbtn {
        bottom: 0;
        left: 0;
        color: #fff;
        background-color: #f54203;
    }
</style>
