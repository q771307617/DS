<template>
  <div class="main">
    <div class="title_info">
      <router-link :to="{name:'information'}" class="box space-between">
        <div class="avatar"><img style="width:100%;" :src="userInfo.image_url" alt="头像"></div>
        <div class="title_account">
          <div class="acount_name">
            <p> {{ userInfo | getRealnameName }}</p>
          </div>
          <div calss="acount_phone">
            <p>手机号码：{{userInfo.phone}}</p>
          </div>
        </div>
        <div class="title_arrow"><img :src="'h5/grzx/userarrow.png' | randomPath" alt="" ></div>
      </router-link>
      <router-link :to="{name:'account'}">
        <div class="money_info">
          <money-info></money-info>
        </div>
      </router-link>
    </div>
    <div class="list">
      <router-link :to="{name:'demand'}">
        <div><img :src="'h5/grzx/demand.png' | randomPath " alt=""></div>
        <div style="flex:1;margin-left: 0.3rem;font-size: 0.28rem;">需求记录</div>
        <div class="list_arrow">></div>
      </router-link>

      <router-link :to="{name:'paylist'}">
        <div><img :src="'h5/grzx/employ.png' | randomPath " alt=""></div>
        <div style="flex:1;margin-left: 0.25rem;font-size: 0.28rem;">雇佣记录</div>
        <div class="list_arrow">></div>
      </router-link>

      <router-link :to="{name:'trading'}">
        <div><img :src="'h5/grzx/changelist.png' | randomPath " alt=""></div>
        <div style="flex:1;margin-left: 0.25rem;font-size: 0.28rem;">交易记录</div>
        <div class="list_arrow">></div>
      </router-link>

      <router-link :to="{name:'passwordManage'}">
        <div><img :src="'h5/grzx/password.png' | randomPath " alt=""></div>
        <div style="flex:1;margin-left: 0.25rem;font-size: 0.28rem;">密码管理</div>
        <div class="list_arrow">></div>
      </router-link>
      <div style="height:1.75rem"></div>
    </div>
    <mt-button type="danger" @click="logout()" size="large" class="big-btn logout">退出登录</mt-button>
  </div>
</template>

<script>
import { Header } from 'mint-ui';
import { mapState, mapActions } from 'vuex'
import djlheader from '@/components/index/Header'
import moneyInfo from '@/components/personal/moneyInfo'
export default {
  data() {
    return {}
  },

  mounted() {
    this.getLoginState();

  },
  computed: {
    ...mapState({
      isLogin: state => state.User.isLogin,
      userInfo: state => state.User.userInfo,
      ftpPath: state => state.Public.ftpPath
    })
  },
  methods: {
    ...mapActions(["outLogin", "getLoginState"]),
    checkLogin() {
      if (!this.isLogin) {
        this.$router.push({ path: '/login?redirect=' + encodeURIComponent(location.pathname) });
        return;
      }
    },
    logout() {
      this.outLogin();
      //跳转到首页
      this.$router.push({ path: '/' });
    },

  },
  watch:{
'$route':'refresh',
refresh(){
this.location.reload()
}

  },
  beforeUpdate() {
    this.checkLogin();
  },
  components: { djlheader, 'money-info': moneyInfo },
}
</script>

<style scoped>
.main {
  font-size: 0.24rem;
  background-color: #f7f7f7;
}

.box {
  height: 2.1rem;
}

.title_info {
  background: linear-gradient(to bottom, #f54102, #fe8e01);
  margin-bottom: 0.2rem;
  overflow: hidden;
  font-size: 0.25rem;
  height: 4.2rem;
}

.avatar {
  width: 1.3rem;
  height: 1.3rem;
  overflow: hidden;
  border-radius: 50%;
  margin: 0.4rem 0.36rem 0 0.18rem;
}

.title_account {
  flex: 1;
  color: #fff;
  align-self: center;
}

.acount_name {
  font-size: 0.36rem;
  margin-bottom: 0.2rem;
}

.account_phone {
  font-size: 0.24rem;
}

.title_arrow {
  margin-right: 0.18rem;
  align-self: center;
}
.title_arrow img{
  width: 0.25rem;
}
.list_arrow {
  font-size: 0.35rem;
  color: #dfdfdf;
}

.money_info {
  margin-top: 0.35rem;
}

.list {
  padding-left: 3px;
  overflow: hidden;
  background-color: #fff;
}

.list a {
  overflow: hidden;
  display: flex;
  align-items: center;
  height: 0.88rem;
  border-bottom: 1px solid #e4e4e4;
  padding: 0 0.18rem 0 0.18rem;
}

.list a img {
  width: 0.45rem;
}

.logout {
  left:0;
}
</style>
