import Vue from "vue";
import Router from "vue-router";

Vue.use(Router)

const Tpl1 = r => require.ensure([], () => r(require('@/components/template/tpl-1')), 'tpl1'); //模板1 带底部按钮页面使用
const Home = r => require.ensure([], () => r(require('@/page/index')), 'index'); //首页
const Login = r => require.ensure([], () => r(require('@/page/login')), 'login'); //登录页面
const Register = r => require.ensure([], () => r(require('@/page/register')), 'register'); //注册页面
const Findpwd = r => require.ensure([], () => r(require('@/page/findpwd')), 'findpwd'); //找回密码页面
const Prolist = r => require.ensure([], () => r(require('@/page/prolist')), 'prolist'); //产品
const Proinfo = r => require.ensure([], () => r(require('@/page/proinfo')), 'proinfo');
const Demand = r => require.ensure([], () => r(require('@/page/demand')), 'demand'); //需求
const Audit = r => require.ensure([], () => r(require('@/components/demand/audit')), 'audit');
const Work = r => require.ensure([], () => r(require('@/components/demand/work')), 'work');
const Check = r => require.ensure([], () => r(require('@/components/demand/check')), 'check');
const UserPay = r => require.ensure([], () => r(require('@/page/pay')), 'UserPay'); //雇佣支付页面
const Account = r => require.ensure([], () => r(require('@/page/account')), 'account'); //账户
const Coupon = r => require.ensure([], () => r(require('@/page/coupon')), 'coupon'); //优惠券
const Recharge = r => require.ensure([], () => r(require('@/page/recharge')), 'recharge'); //立即充值
const Cash = r => require.ensure([], () => r(require('@/page/cash')), 'cash'); //提现
const Personal = r => require.ensure([], () => r(require('@/page/personal')), 'personal'); //个人中心主页面
const Information = r => require.ensure([], () => r(require('@/components/personal/information')), 'information'); //修改个人信息
const PasswordManage = r => require.ensure([], () => r(require('@/components/personal/passwordManage')), 'passwordManage'); //密码管理
const AddDemand = r => require.ensure([], () => r(require('@/page/addDemand')), 'addDemand'); //发布需求


const Tpl2 = r => require.ensure([], () => r(require('@/components/template/tpl-2')), 'tpl2'); //模板2 不带底部按钮页面使用
const Designer = r => require.ensure([], () => r(require('@/page/designer')), 'designer'); //设计师模块
const DesignerIndex = r => require.ensure([], () => r(require('@/components/designer/index')), 'designer'); //设计师列表
const Dinfo = r => require.ensure([], () => r(require('@/page/dinfo')), 'designer'); //设计师详情
const Resume = r => require.ensure([], () => r(require('@/components/designer/resume')), 'designer'); //设计师详情--简历页面
const ServiceRecord = r => require.ensure([], () => r(require('@/components/designer/service-record')), 'designer'); ////设计师详情--服务记录页面
const DesignerProduces = r => require.ensure([], () => r(require('@/components/designer/designer-produces')), 'designer'); ////设计师详情--作品页面
const Info = r => require.ensure([], () => r(require('@/components/designer/info')), 'designer'); //设计师详情--详情内容
const Hire = r => require.ensure([], () => r(require('@/page/hire')), 'hire'); //设计师详情--雇佣页面
const Rules = r => require.ensure([], () => r(require('@/page/rules')), 'rules'); //平台规则页面
const Trading = r => require.ensure([], () => r(require('@/page/trading')), 'trading'); //交易记录列表
const Employ = r => require.ensure([], () => r(require('@/page/employ')), 'employ'); //雇佣记录
const Paylist = r => require.ensure([], () => r(require('@/components/employ/paylist')), 'employ'); //雇佣记录--支付记录列表
const Noaywageslist = r => require.ensure([], () => r(require('@/components/employ/nopay-wageslist')), 'employ'); //雇佣记录--代发放工资列表
const Wageslist = r => require.ensure([], () => r(require('@/components/employ/wageslist')), 'employ'); //雇佣记录--已发放工资列表


const Test = r => require.ensure([], () => r(require('@/page/test')), 'test'); //测试页面

export default new Router({
    mode: 'history',
    routes: [
      /*****  PC路径重定向  *****/
      { path: '/designers/:id', redirect: { name: 'info' } },//设计师详情
      { path: '/search/designer', redirect: { name: 'designer' } },//设计师列表
      { path: '/paySuccess', redirect: { name: 'trading' } },//支付成功
      { path: '/payFail', redirect: { name: 'trading' } },//支付成功
      { path: '/payWait', redirect: { name: 'trading' } },//支付成功
      /*****  PC路径重定向  *****/
        {
            path: '/', component: Tpl1, //模板1 带底部按钮页面使用
            children: [
                { path: '/', name: 'index', component: Home }, //首页
                { path: '/test', name: 'test', component: Test }, //测试页面
                { path: '/login', name: 'login', component: Login }, //登录页面
                { path: '/register', name: 'register', component: Register }, //注册页面
                { path: '/findpwd', name: 'findpwd', component: Findpwd }, //找回密码
                { path: '/prolist', name: 'prolist', component: Prolist }, //作品列表页面
                { path: '/personal', name: 'personal', component: Personal }, //个人中心
            ]
        },
        {
            path: '/', component: Tpl2,//模板2 不带底部按钮页面使用
            children: [
                {
                    path: '/designer', component: Designer, //设计师模块
                    children: [
                        { path: '/', name: 'designer', component: DesignerIndex }, //设计师列表
                        {
                            path: 'dinfo/:id', component: Dinfo, //设计师详情
                            children: [
                                { path: '/', name: 'dinfo', redirect: { name: 'info' } },
                                {
                                    path: 'info', component: Info,
                                    children: [
                                        { path: 'info', name: 'info', redirect: { name: 'resume' } },
                                        { path: 'resume', name: 'resume', component: Resume }, //设计师详情--简历页面
                                        { path: 'service-record', name: 'service-record', component: ServiceRecord }, //设计师详情--服务记录页面
                                        { path: 'designer-produces', name: 'designer-produces', component: DesignerProduces }, //设计师详情--作品页面
                                    ]
                                },
                                { path: 'hire', name: 'hire', component: Hire },//设计师详情--雇佣页面

                            ]
                        }
                    ],
                },
                { path: '/user/pay', name: 'userpay', component: UserPay }, //雇佣支付页面
                { path: '/demand/:active?', name: 'demand', component: Demand }, //需求记录
                /* 需求编辑 */
                { path: '/audit', name: 'audit', component: Audit },
                { path: '/work', name: 'work', component: Work },
                /* 需求编辑 */
                { path: '/account', name: 'account', component: Account }, //账户管理
                { path: '/check', name: 'check', component: Check }, //待验收需求
                { path: '/proinfo/:id', name: 'proinfo', component: Proinfo }, //作品详情
                { path: '/coupon', name: 'coupon', component: Coupon }, //优惠券
                { path: '/recharge', name: 'recharge', component: Recharge }, //立即充值
                { path: '/cash', name: 'cash', component: Cash }, //提现
                { path: 'information', name: 'information', component: Information },
                { path: '/rules', name: 'rules', component: Rules },
                {
                    path: '/employ', component: Employ,//雇佣记录
                    children: [
                        { path: 'paylist/:status?', name: 'paylist', component: Paylist },//雇佣记录--支付记录列表
                        { path: 'noaywageslist', name: 'noaywageslist', component: Noaywageslist },//雇佣记录--代发放工资列表
                        { path: 'wageslist', name: 'wageslist', component: Wageslist },//雇佣记录--已发放工资列表
                    ]
                },//雇佣记录
                { path: '/passwordManage', name: 'passwordManage', component: PasswordManage }, //密码管理
                { path: '/adddemand', name: 'addDemand', component: AddDemand }, //发布需求
                { path: '/trading/:status?', name: 'trading', component: Trading }, //交易记录
            ]
        },
        { path: '*', redirect: { name: 'index' } }
    ]
})
