import moment from 'moment';
import Vue from "vue";

Date.prototype.Format = function (fmt) { //author: meizz
  var o = {
    "M+": this.getMonth() + 1, //月份
    "d+": this.getDate(), //日
    "h+": this.getHours(), //小时
    "m+": this.getMinutes(), //分
    "s+": this.getSeconds(), //秒
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度
    "S": this.getMilliseconds() //毫秒
  };
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
  return fmt;
};

const format = (time, f) => {
  return time ? moment(time).format(f) : ''
}

const toLabel1 = (id, arr) => {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i].id == id) {
      return arr[i].name
    }
  }
  return "";
}

const toLabels = (arr1, arr2) => {
  let text = [];
  if (!arr1) return [];

  for (let i of arr1) {
    for (let item of arr2) {
      if (i == item.id) {
        text.push(item.name);
        break;
      }
    }
  }

  return text.join();
}

const toLabel = (value, arr) => {
  if (!value) {
    return ''
  }

  if (arr.constructor !== Array) {
    return ''
  }
  // value-label
  if (value.constructor === Array) {
    if (!value.length) {
      return ''
    }

    let labels = '';
    for (let item of arr) {
      for (let val of value) {
        if (item.value == val) {
          labels += item.label + ' ';
          break;
        }
      }
    }
    return labels;
  } else {
    for (let item of arr) {
      if (item.value == value) {
        return item.label
      }
    }

    return ''
  }
};

const replaceName = (name) => {
  if (!name) return '';
  return name.substr(0, 1) + new Array(name.length).join('*');
}

export const getRealnameName = (obj = {}) => {
  return obj.realname || obj.nickname || obj.username || obj.phone
}

export const getName = (obj = {}) => {
  return obj.nickname || obj.username || obj.realname || obj.phone
}
export const getNameDesigner = (obj = {}) => {
  return obj.designer_nickname || obj.designer_username || obj.designer_realname || obj.designer_phone
}
const getGender = (obj = {}) => {
  if (obj.gender == 0) {
    return "先生"
  } else {
    return "女士"
  }

}

const SKILLFULL_LIST_TEXT = (skilful, skillfulList = [], delimiter = ',') => {
  if (!skilful) {
    return;
  }
  var name = [];

  if (typeof (skilful) == 'string') {
    for (let v of skilful.split(',')) {
      for (let k = 0, len = skillfulList.length; k < len; k++) {
        if (skillfulList[k].id == v) {
          name.push(skillfulList[k].name);
        }
      }
    }
  } else {
    for (let k = 0, len = skillfulList.length; k < len; k++) {
      if (skillfulList[k].id == skilful) {
        name.push(skillfulList[k].name);
      }
    }
  }


  return name.join(delimiter);
}


const randomPath = (name, size = '') => {
  const n = Math.floor(Math.random() * 5) + 1;
  return `http://${n}.img.dianjiangla.com/assets/${name}${size}`
}
/*
 * 获得时间差,时间格式为 年-月-日 小时:分钟:秒 或者 年/月/日 小时：分钟：秒
 * 其中，年月日为全格式，例如 ： 2010-10-12 01:00:00
 * 返回精度为：秒，分，小时，天
 */
const getDateDiff = (startTime, endTime, diffType) => {
//将xxxx-xx-xx的时间格式，转换为 xxxx/xx/xx的格式
  startTime = startTime.replace(/-/g, "/");
  endTime = endTime.replace(/-/g, "/");
  //将计算间隔类性字符转换为小写
  diffType = diffType.toLowerCase();
  var sTime = new Date(startTime); //开始时间
  var eTime = new Date(endTime); //结束时间
  //作为除数的数字
  var divNum = 1;
  switch (diffType) {
    case "second":
      divNum = 1000;
      break;
    case "minute":
      divNum = 1000 * 60;
      break;
    case "hour":
      divNum = 1000 * 3600;
      break;
    case "day":
      divNum = 1000 * 3600 * 24;
      break;
    case "month":
      divNum = 1000 * 3600 * 24*30;
      break;
    default:
      break;
  }
  return parseInt((eTime.getTime() - sTime.getTime()) / parseInt(divNum)) || 1;

}

Vue.filter('format', format);
Vue.filter('toLabel', toLabel);
Vue.filter('toLabels', toLabels);
Vue.filter('toLabel1', toLabel1);
Vue.filter('SKILLFULL_LIST_TEXT', SKILLFULL_LIST_TEXT);
Vue.filter('replaceName', replaceName);
Vue.filter("getName", getName);
Vue.filter('randomPath', randomPath);
Vue.filter('getRealnameName', getRealnameName);
Vue.filter('getDateDiff', getDateDiff);
