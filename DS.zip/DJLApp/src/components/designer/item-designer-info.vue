<template>
  <div class="main">
    <div class="user">
      <div class="userinfo">
        <router-link class="box" :to="{name:'dinfo',params:{id:info.user_id}}">
        <div class="userimg"><img v-lazy="info.image_url" :alt="info.nickname"></div>
        <div class="info">
          <div class="name">
            <div>{{ info | getRealnameName}}　({{info.nickname}})</div>
            <div class="infotxt">
              <p v-if="info.gender">
                <img :src="'icon/female.png' | randomPath " width="100%" alt="女">
              </p>
              <p v-else>
                <img :src="'icon/male.png' | randomPath " width="100%" alt="男">
              </p>
              <p>
                <img :src="'icon/security.png' | randomPath" width="100%" alt="保障">
              </p>
              <p>
                <img :src="'icon/certification.png' | randomPath" width="100%" alt="认证">
              </p>
              <p>
                <img :src="'icon/'+info.rank+'.png' | randomPath" width="100%">
              </p>
            </div>
          </div>
          <p>擅长类目：{{info.skilful | SKILLFULL_LIST_TEXT(cla2, ' | ') }}</p>
          <div style="display: flex;justify-content: space-between;">
            <p>工作经验：{{info.exp}}年</p>
            <slot name="mony"></slot>
          </div>
        </div>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script>
  import {mapState, mapActions} from 'vuex'
  export default {
    props: ['info'],
    data() {
      return {}
    },
    components: {},
    computed: {
      ...mapState({
        cla2: state => state.Public.cla2, //二级分类
        ftpPath: state => state.User.ftpPath,
      })
    },
    mounted() {
    },
    methods: {}
  }
</script>

<style scoped>
  .user {
    font-size: 0.2rem;
    border-bottom: 1px solid #c8c8c8;
  }

  .userinfo {
    display: flex;
    padding: 0.15rem 0.31rem;
  }

  .userimg {
    width: 1.48rem;
    height: 1.74rem;
    overflow: hidden;
  }

  .userimg a {
    display: block;
  }

  .userimg img {
    width: 100%;
  }

  .info {
    flex: 1;
    padding-left: 0.22rem;
    line-height: 0.5rem;
    color: #5a5a5a;
  }

  .info .name {
    display: flex;
    line-height: 0.6rem;
  }

  .info .name a {
    color: #5a5a5a;
  }

  .info .infotxt {
    display: flex;
    align-items: center;
    padding-left: 0.12rem;
    height: 0.6rem;
  }

  .info .infotxt p {
    width: 0.20rem;
    height: 0.20rem;
    overflow: hidden;
    font-size: 0.12rem;
    padding: 0 0.04rem;
    line-height: 0.18rem;
  }

  .info .mony {
    color: #f54203;
    font-size: 0.24rem;
  }
</style>


