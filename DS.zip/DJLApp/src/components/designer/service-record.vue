<template>
  <div class="main" style="font-size: 0.12rem;">
    <mt-loadmore class="list" :top-method="loadTop" :bottom-method="loadBottom" @top-status-change="handleTopChange"
                 :bottom-all-loaded="allLoaded" ref="loadmore">
      <ul class="box space-between wrap">
        <li v-for="item in list" :key="item.id">
          <div class="top box space-between">
            <p>{{item.storeName}}</p>
            <div>
              <span>{{item.classId | SKILLFULL_LIST_TEXT(cla2) }}</span>
              <router-link v-if="item.products[0] > 0" :to="{name:'proinfo',params:{id:item.products[0]}}">查看作品</router-link>
            </div>
          </div>
          <div class="details">{{item.details}}</div>
        </li>
      </ul>
      <div style="height:0.8rem"></div>
    </mt-loadmore>
  </div>
</template>

<script>
  import djlheader from '@/components/index/Header'
  import {mapState} from 'vuex';
  import {Loadmore, Indicator, Toast} from 'mint-ui';
  import menu from '@/components/prolist/menu'
  export default {
    data() {
      return {
        allLoaded: false,
        topStatus: '',
        list: [],
        params: {
          id: '',
          pageNum: 1,
          pageSize: 10
        },
        configData: {
          pageCount: 0,
        }
      }
    },
    components: {},
    computed: {
      ...mapState({
        cla2: state => state.Public.cla2
      })
    },
    mounted() {
      this.params.id = this.$route.params.id;
      this.getProList();
    },
    methods: {
      loadTop() {
        // 刷新数据
        this.list = [];
        this.params.pageNum = 1;
        this.allLoaded = false;
        this.getProList();
        this.$refs.loadmore.onTopLoaded();
      },
      loadBottom(){
        // 加载更多数据
        if (this.params.pageNum > this.configData.pageCount) {
          Toast('没有更多了！');
          this.allLoaded = true; // 若数据已全部获取完毕
          this.$refs.loadmore.onBottomLoaded();
        }
        this.loadMore();
        this.$refs.loadmore.onBottomLoaded();
      },
      handleTopChange(){
        this.topStatus = status;
      },
      getProList(){
        Indicator.open({
          text: '加载中...',
          spinnerType: 'fading-circle'
        });
        let params = {
          ...this.params
        }
        this.$ajax.get('designer/work2product', params).then(e => {
          if (e.status !== 200) {
            Indicator.close();
            return false;
          }
          this.list = this.list.concat(e.data.list);
          let count = e.data.count == 'undefined' ? 0 : e.data.count;
          this.configData.pageCount = Math.ceil(count / params.pageSize);
          this.params.pageNum = this.params.pageNum + 1;
          Indicator.close();
          this.loading = false;
        }).catch(function(err){
          Indicator.close();
      })
      },
      loadMore() {
        if (this.configData.pageCount < this.params.pageNum) {
          return false;
        }
        this.loading = true;
        this.getProList();
      }
    }
  }
</script>

<style scoped>
  .list {
    font-size: 0.18rem;
    color: #8b8b8b;
    line-height: 2;
  }

  .list ul {
    overflow: hidden;
    background-color: #f7f7f7;
  }

  .list ul li {
    background-color: #fff;
    width: 6.5rem;
    margin-bottom: 0.1rem;
    padding: 0.25rem 0.45rem;
  }

  .list ul li:last-child {
    margin-bottom: 0;
  }

  .list .top {
    height: 0.5rem;
    color: #5a5a5a;
  }

  .list .top p {
    font-size: 0.24rem;
  }

  .list .top span {
    font-size: 0.22rem;
  }

  .list .top a {
    font-size: 0.2rem;
    color: #fff;
    background-color: #f54203;
    border-radius: 0.06rem;
    padding: 0.05rem 0.1rem;
    margin-left: 0.1rem;
  }

  .list .details {
    overflow: hidden;
    border-top: 1px solid #f5f5f5;
  }
</style>


