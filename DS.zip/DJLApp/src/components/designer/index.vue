<template>
  <div class="main" style="font-size: 0.12rem;">
    <!-- <netraffic></netraffic> -->
    <sxtabbar></sxtabbar>
    <djlheader>
      <input type="text" v-model="params.name" @keyup.13="loadTop" slot="headleft" placeholder="输入昵称进行搜索" class="headleft" />
      <img :src="ftpPath + '/icon_search.png'" slot="headright" class="headright" @click="loadTop" />
    </djlheader>
    <djl-menu :searchData="configData" :callback="loadTop"></djl-menu>
    <div style="height: 0.68rem"></div>
    <div>
      <mt-loadmore class="user" :top-method="loadTop" :bottom-method="loadBottom" @top-status-change="handleTopChange"
                   :bottom-all-loaded="allLoaded" ref="loadmore">
        <ul>
          <li v-for="item in list" :key="item.user_id">
            <itemDesignerInfo :info="item">
              <p slot="mony"  class="mony" style="text-align: right;">{{item.salary}}元/月</p>
            </itemDesignerInfo>
          </li>
        </ul>
        <div style="height: 0.95rem"></div>
      </mt-loadmore>
    </div>
  </div>
</template>

<script>
  import djlheader from '@/components/index/Header'
  import sxtabbar from '@/components/index/Tabbar'
  import itemDesignerInfo from '@/components/designer/item-designer-info'
  import {mapState} from 'vuex';
  import {Indicator, Cell, Lazyload, InfiniteScroll, Loadmore, Toast} from 'mint-ui';
  import menu from '@/components/prolist/menu'
  export default {
    data() {
      return {
        popupVisible: true,
        title: '搜索设计师',
        state: 'warning',
        list: [],
        topStatus: '',
        allLoaded: false,
        params: {
          classId: '', //	擅长行业	number	@mock=1
//          expEnd: '', //	工作年限最大值	number	@mock=1
//          expStart: '', //	工作年限最小值	number	@mock=5
          rank:'',
          gender: '', //	性别	number	@mock=1
          name: '', //	名称(昵称 用户名)	string	@mock=黄依
          pageNum: 1,
          pageSize: 20
        },
        configData: {
          pageCount: 0,
          pageName: 'designer',
          experienceid: 0,
          experience_text: '按级别',
          genderid: -1,
          gender_text: '按性别',

          classIds: 0,
          class_text: '按行业',

          rank:'',// 级别

//          expEnd: '',//经验结束
//          expStart: '',//经验开始
        }
      }
    },
    components: {
      djlheader,
      sxtabbar,
      itemDesignerInfo,
      'djl-menu': menu
    },
    computed: {
      ...mapState({
        ftpPath: state => state.Public.ftpPath
      })
    },
    mounted() {
      this.getListData();
    },
    methods: {
      setParams(){
//        this.params.expStart = this.configData.expStart;
//        this.params.expEnd = this.configData.expEnd;
        this.params.rank = this.configData.rank;
        this.params.classId = this.configData.classIds || '';
        this.params.gender = this.configData.genderid == -1 ? '' : this.configData.genderid;
      },
      handleTopChange(status) {
        this.topStatus = status;

      },
      loadTop() {
        // 刷新数据
        this.list = [];
        this.params.pageNum = 1;
        this.allLoaded = false;
        this.getListData();
        this.$refs.loadmore.onTopLoaded();
      },
      loadBottom() {
        // 加载更多数据
        if (this.params.pageNum > this.configData.pageCount) {
          Toast('没有更多了！');
          this.allLoaded = true; // 若数据已全部获取完毕
          this.$refs.loadmore.onBottomLoaded();
        }
        this.loadMore();
        this.$refs.loadmore.onBottomLoaded();
      },
      getListData() {
        this.setParams();
        Indicator.open({
          text: '加载中...',
          spinnerType: 'fading-circle'
        });
        let params = {
          ...this.params
        }
        this.$ajax.get('designer/list', params).then(e => {
          if (e.status !== 200) {
            Indicator.close();
            return false;
          }
          this.list = this.list.concat(e.data.list);
          this.configData.pageCount = Math.ceil(e.data.count / params.pageSize);
          this.params.pageNum = this.params.pageNum + 1;
          Indicator.close();
          this.loading = false;
        }).catch(function(err){
          Indicator.close();
      });
      },
      loadMore() {
        if (this.configData.pageCount < this.params.pageNum) {
          return false;
        }
        this.loading = true;
        this.getListData();
      }
    }
  }
</script>

<style scoped>
  .headleft {
    margin-left: 0.07rem;
    padding-left: 0.29rem;
    font-size: 0.22rem;
    color: #949494;
    width: 4.95rem;
    height: 0.34rem;
  }

  .headright {
    width: 0.4rem;
    height: 0.4rem;
    margin-right: 0.24rem;
  }

  .user {
    font-size: 0.22rem;
  }

  .user ul li {
    border-bottom: 1px solid #c8c8c8;
  }
</style>


