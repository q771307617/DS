<template>
  <div class="main">
    <!-- <netraffic></netraffic> -->
    <div class="userscore box">
      <div class="score">
        <p>服务态度：
          <span>5</span>
        </p>
        <p>设计能力：
          <span>5</span>
        </p>
        <p>响应速度：
          <span>5</span>
        </p>
      </div>
      <div class="phone">
        <ul class="box">
          <li v-if="!isLogin || !!this.params.qq">
            <a @click="altMaessage(1)">
              <div>
                <img src="http://2.img.dianjiangla.com/assets/h5/icon-d-qq.png" alt="联系QQ">
              </div>
              <p>联系QQ</p>
            </a>
          </li>
          <li v-if="!isLogin || !!this.params.wechat.length">
            <a @click="altMaessage(2)">
              <div>
                <img src="http://2.img.dianjiangla.com/assets/h5/icon-d-wechat.png" alt="联系微信">
              </div>
              <p>联系微信</p>
            </a>
          </li>
          <li v-if="!isLogin || !!this.params.phone.length">
            <a @click="altMaessage(3)">
              <div>
                <img src="http://2.img.dianjiangla.com/assets/h5/icon-d-phone.png" alt="联系电话">
              </div>
              <p>联系电话</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="tab-btn space-between box">
      <router-link to="resume" replace>简历</router-link>
      <router-link style="border-left: 1px solid #c8c8c8;border-right: 1px solid #c8c8c8;" to="service-record" replace>服务记录
      </router-link>
      <router-link to="designer-produces" replace>作品</router-link>
    </div>
    <mt-tabbar fixed>
      <a @click="jumpPage()" class="big-btn">雇佣TA ({{info.salary}}元/月)</a>
    </mt-tabbar>
    <router-view></router-view>
  </div>
</template>

<script>
  import {mapState} from 'vuex'
  import {Indicator, MessageBox, Tabbar, TabItem} from 'mint-ui';
  export default {
    data() {
      return {
        params: {
          id: '',
          phone: '',
          qq: '',
          wechat: ''
        },
        info: []
      }
    },
    components: {},
    computed: {
      ...mapState({
        isLogin: state => state.User.isLogin,
      })
    },
    mounted() {
      this.params.id = this.$route.params.id;
      this.getInfoData();
    },
    methods: {
      getInfoData() {
        Indicator.open({
          text: '加载中...',
          spinnerType: 'fading-circle'
        });
        let params = {
          ...this.params
        }
        this.$ajax.get('designer/get', params).then(e => {
          if (e.status !== 200) {
            Indicator.close();
            return false;
          }
          this.info = e.data;
          Indicator.close();
          this.loading = false;
          if(this.isLogin){
            this.getUserContactWayData();
          }
        }).catch(function(err){
          Indicator.close();
      });
      },
      routerBack() {
        this.$router.push({name: 'designer'});
      },
      jumpPage(){
        if (!this.isLogin) {
          this.$router.replace({path: '/login?redirect=' + encodeURIComponent(location.pathname)});
          return;
        }
        this.$router.push({name:'hire',query:{mony:this.info.salary}})
      },
      altMaessage(type) {
        if (!this.isLogin) {
          this.$router.replace({path: '/login?redirect=' + encodeURIComponent(location.pathname)});
          return;
        }
        this.getUserContactWay(type);
      },
      getUserContactWayData(){
        this.$ajax.get('designer/contractInfo', {id: this.params.id}).then(e => {
            if (e.status !== 200) {
              return false;
            }
            this.params.phone = e.data.phone;
            this.params.qq = e.data.qq;
            this.params.wechat = e.data.wechat;
      })
      },
      getUserContactWay(type) {
          switch (type) {
            case 1:
              if (this.params.qq) {
                MessageBox.alert(this.params.qq, 'QQ号码',{confirmButtonText:'关闭窗口'});
              } else {
                MessageBox.alert('未提供QQ', 'QQ号码',{confirmButtonText:'关闭窗口'});
              }
              break;
            case 2:
              if (this.params.wechat) {
                MessageBox.alert(this.params.wechat, '微信号码',{confirmButtonText:'关闭窗口'});
              } else {
                MessageBox.alert('未提供微信', '微信号码',{confirmButtonText:'关闭窗口'});
              }
              break;
            case 3:
              if (this.params.phone) {
                MessageBox.alert(this.params.phone, '电话号码',{confirmButtonText:'关闭窗口'});
              } else {
                MessageBox.alert('未提供电话', '电话号码',{confirmButtonText:'关闭窗口'});
              }
              break;
          }
      }
    }
  }
</script>

<style scoped>
  .userscore {
    font-size: 0.18rem;
    padding: 0 0.31rem;
    border-bottom: 1px solid #c8c8c8;
  }

  .userscore .score {
    width: 2.2rem;
    text-indent:0.4rem;
    line-height: 0.25rem;
    padding: 0.1rem 0;
    color: #5a5a5a;
  }

  .userscore .score span {
    color: #f54203;
  }

  .userscore .phone {
    flex: 1;
    padding-left: 0.22rem;
  }

  .userscore .phone ul {
    text-align: center;
    overflow: hidden;
  }

  .userscore .phone ul li a {
    display: block;
    width: 0.96rem;
    /*height: 0.96rem;*/
    margin-right: 0.27rem;
  }

  .userscore .phone ul li a div {
    padding-top: 0.15rem;
    width: 0.41rem;
    height: 0.41rem;
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .userscore .phone ul li a div img {
    width: 100%;
  }

  .userscore .phone ul li a p {
    /*height: 0.3rem;*/
    line-height: 0.3rem;
  }

  .tab-btn {
    height: 0.54rem;
  }

  .tab-btn a {
    flex: 1;
    display: block;
    border-bottom: 1px solid #c8c8c8;
    text-align: center;
    line-height: 0.54rem;
    font-size: 0.24rem;
  }

  .tab-btn a.router-link-active {
    color: #fff;
    background-color: #f54203;
    border-bottom: 1px solid #f54203;
  }
</style>
