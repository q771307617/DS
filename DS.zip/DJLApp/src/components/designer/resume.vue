<template>
  <div class="main" style="font-size: 0.12rem;">
    <div class="content" v-html="info.details"></div>
    <div style="height:0.8rem;"></div>
  </div>
</template>

<script>
  import {Indicator} from 'mint-ui';
  export default {
    data() {
      return {
        params: {
          id: '',
        },
        info: [],
      }
    },
    components: {},
    computed: {},
    mounted() {
      this.params.id = this.$route.params.id;
      this.getInfoData();
    },
    methods: {
      getInfoData() {
        Indicator.open({
          text: '加载中...',
          spinnerType: 'fading-circle'
        });
        let params = {
          ...this.params
        }
        this.$ajax.get('designer/get', params).then(e => {
          if (e.status !== 200) {
            Indicator.close();
            return false;
          }
          this.info = e.data;
          Indicator.close();
          this.loading = false;
        }).catch(function(err){
          Indicator.close();
      });
      },
    }
  }
</script>
<style>
  .content img {
    width: 100%;
    max-width: 6.5rem;
  }
</style>
<style scoped>
  .main {
    width: 6.5rem;
  }

  .content, .content div, .content p {
    overflow: hidden;
    width: 100%;
    max-width: 6.5rem;
    border: 0;
    margin: 0;
    padding: 0;
    line-height: 0;
  }

</style>


