<template>
  <div class="main" style="font-size: 0.12rem;">
    <mt-loadmore class="pro" :top-method="loadTop" :bottom-method="loadBottom" @top-status-change="handleTopChange" :bottom-all-loaded="allLoaded" ref="loadmore">
      <ul class="box space-between wrap">
        <li v-for="item in list" :key="item.id">
          <router-link class="img" :to="{name:'proinfo',params:{id:item.id}}"><img :src="item.image_url" :alt="item.name"></router-link>
          <router-link class="txt" :to="{name:'proinfo',params:{id:item.id}}">{{item.name}}</router-link>
        </li>
      </ul>
      <div style="height:0.8rem"></div>
    </mt-loadmore>
  </div>
</template>

<script>
  import {Loadmore, Indicator, Toast} from 'mint-ui';
  import menu from '@/components/prolist/menu'
  export default {
    data() {
      return {
        allLoaded: false,
        topStatus: '',
        list: [],
        params: {
          id: '',
          pageNum: 1,
          pageSize: 10
        },
        configData: {
          pageCount: 0,
        }
      }
    },
    components: {},
    computed: {},
    mounted() {
      this.params.id = this.$route.params.id;
      this.getProList();
    },
    methods: {
      loadTop() {
        // 刷新数据
        this.list = [];
        this.params.pageNum = 1;
        this.allLoaded = false;
        this.getProList();
        this.$refs.loadmore.onTopLoaded();
      },
      loadBottom(){
        // 加载更多数据
        if (this.params.pageNum > this.configData.pageCount) {
          Toast('没有更多了！');
          this.allLoaded = true; // 若数据已全部获取完毕
          this.$refs.loadmore.onBottomLoaded();
        }
        this.loadMore();
        this.$refs.loadmore.onBottomLoaded();
      },
      handleTopChange(){
        this.topStatus = status;
      },
      getProList(){
        Indicator.open({
          text: '加载中...',
          spinnerType: 'fading-circle'
        });
        let params = {
          ...this.params
        }
        this.$ajax.get('designer/product', params).then(e => {
          if (e.status !== 200) {
            Indicator.close();
            return false;
          }
          this.list = this.list.concat(e.data.list);
          let count = e.data.count == 'undefined' ? 0 : e.data.count;
          this.configData.pageCount = Math.ceil(count / params.pageSize);
          this.params.pageNum = this.params.pageNum + 1;
          Indicator.close();
          this.loading = false;
        }).catch(function(err){
          Indicator.close();
      })
      },
      loadMore() {
        if (this.configData.pageCount < this.params.pageNum) {
          return false;
        }
        this.loading = true;
        this.getProList();
      }
    }
  }
</script>

<style scoped>
  .pro {
    font-size: 0.20rem;
  }

  .pro ul {
    padding: 0.17rem;
  }

  .pro ul li {
    width: 2.88rem;
    margin-bottom: 0.21rem;
  }

  .pro ul li a.img {
    display: block;
    width: 2.88rem;
    height: 3.1rem;
    overflow: hidden;;
  }

  .pro ul li a img {
    width: 100%;
  }

  .pro ul li a.txt {
    display: block;
    height: 0.5rem;
    line-height: 0.5rem;
    text-align: center;
    color: #090909;
  }
</style>


