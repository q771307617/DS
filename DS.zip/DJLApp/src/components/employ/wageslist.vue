<template>
  <div class="main" style="font-size: 0.12rem;">
    <mt-loadmore class="paylist" :top-method="loadTop" :bottom-method="loadBottom" @top-status-change="handleTopChange"
                 :bottom-all-loaded="allLoaded" ref="loadmore">
      <ul>
        <li v-for="item in list" :key="item.id">
          <p>订单号:　{{item.orderId}}</p>
          <p>设计师:　{{item.designerName}}</p>
          <p>雇佣类型:　{{typelist[item.type]}}</p>
          <p>雇佣金额:　{{item.amount}}元</p>
          <p class="tiem-span">雇佣日期:
            <span>{{item.startTime}}--{{item.endTime}}</span>
            <span v-if="item.type == 0">{{ item.startTime | getDateDiff(item.endTime, 'month') }}个月</span>
            <span v-else>{{ item.startTime | getDateDiff(item.endTime, 'day') }}天</span>
          </p>
        </li>
      </ul>
    </mt-loadmore>
  </div>
</template>

<script>
  import {Loadmore, Indicator, Toast} from 'mint-ui';
  import menu from '@/components/prolist/menu'
  import moment from "moment";
  export default {
    data() {
      return {
        allLoaded: false,
        topStatus: '',
        list: [],
        typelist: ['包月雇佣', '定制雇佣'],
        params: {
          pageNum: 1,
          pageSize: 10
        },
        configData: {
          pageCount: 0,
        }
      }
    },
    components: {},
    computed: {},
    mounted() {
      this.getList();
    },
    methods: {
      loadTop() {
        // 刷新数据
        this.list = [];
        this.params.pageNum = 1;
        this.allLoaded = false;
        this.getList();
        this.$refs.loadmore.onTopLoaded();
      },
      loadBottom() {
        // 加载更多数据
        if (this.params.pageNum > this.configData.pageCount) {
          Toast('没有更多了！');
          this.allLoaded = true; // 若数据已全部获取完毕
          this.$refs.loadmore.onBottomLoaded();
        }
        this.loadMore();
        this.$refs.loadmore.onBottomLoaded();
      },
      handleTopChange() {
        this.topStatus = status;
      },
      getList() {
        Indicator.open({
          text: '加载中...',
          spinnerType: 'fading-circle'
        });
        let params = {
          ...this.params
        }

        this.$ajax.get('hire/pay/log', params).then(e => {
          if (e.status !== 200) {
            Indicator.close();
            return false;
          }

          let listarr = e.data.list.map((item) => {
            item.startTime = moment(item.startTime).format("YYYY-MM-DD")
            item.endTime = moment(item.endTime).format("YYYY-MM-DD")
            return item;
          });
          this.list = this.list.concat(listarr);
          let count = e.data.count == 'undefined' ? 0 : e.data.count;
          this.configData.pageCount = Math.ceil(count / params.pageSize);
          this.params.pageNum = this.params.pageNum + 1;
          Indicator.close();
          this.loading = false;
        }).catch(function (err) {
          Indicator.close();
        })
      },
      loadMore() {
        if (this.configData.pageCount < this.params.pageNum) {
          return false;
        }
        this.loading = true;
        this.getList();
      }
    },
    watch: {
      '$route': function () {
        this.loadTop();
      }
    }
  }
</script>

<style scoped>
  .paylist {
    font-size: 0.22rem;
    color: #5a5a5a;
  }

  .paylist ul li {
    padding: 0.2rem 0.3rem;
    line-height: 0.5rem;
    border-bottom: 0.1rem solid #f7f7f7;
  }

  .topay-btn {
    display: block;
    width: 1.66rem;
    height: 0.63rem;
    line-height: 0.63rem;
    text-align: center;
    background-color: #f54203;
    color: #fff;
  }

  .tiem-span span {
    display: inline-block;
  }
</style>


