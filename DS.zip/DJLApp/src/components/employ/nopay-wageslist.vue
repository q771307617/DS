<template>
  <div class="main" style="font-size: 0.12rem;">
    <mt-loadmore class="paylist" :top-method="loadTop" :bottom-method="loadBottom" @top-status-change="handleTopChange"
                 :bottom-all-loaded="allLoaded" ref="loadmore">
      <ul>
        <li v-if="item.type != 1 || item.isShow" v-for="item in list" :key="item.id">
          <p>订单号:　{{item.orderId}}</p>
          <div class="box space-between">
            <div style="flex: 1;">

              <p>设计师:　{{item.designerName}}</p>
              <p>雇佣类型:　{{typelist[item.type]}}</p>
              <p>雇佣金额:　{{item.price}}元</p>
            </div>
            <div class="box item-center vertical-center" style="width: 1.66rem;font-size: 0.26rem;">
              <div v-if="!item.type == 0">
                <span v-if="!item.nopayPrice <= 0 && item.isShow">
                  <a @click="paySalary(item.id)" class="topay-btn" style="margin-bottom: 0.25rem;">确认发放</a>
                  <a @click="delayPaySalary(item.id)" v-if="item.delayPaySalary != 1" class="topay-btn">延期发放</a>
                </span>
              </div>
              <span v-else>自动发放</span>
            </div>
          </div>
          <p class="tiem-span">雇佣日期:
            <span>{{item.startTime}}--{{item.endTime}}</span>
            <span v-if="item.type == 0">{{ item.startTime | getDateDiff(item.endTime, 'month') }}个月</span>
            <span v-else>{{ item.startTime | getDateDiff(item.endTime, 'day') }}天</span>
          </p>
          <div>确认发放剩余天数:  <span
            style="text-indent:0.3rem;color: #f54203;">{{ item.nowDate | getDateDiff(item.surplus, 'day') }}天</span>
          </div>
        </li>
      </ul>
    </mt-loadmore>
  </div>
</template>

<script>
  import {Loadmore, Indicator, Toast} from 'mint-ui';
  import menu from '@/components/prolist/menu'
  import moment from "moment";

  export default {
    data() {
      return {
        allLoaded: false,
        topStatus: '',
        list: [],
        typelist: ['包月雇佣', '定制雇佣'],
        params: {
          pageNum: 1,
          pageSize: 10
        },
        configData: {
          pageCount: 0,
        }
      }
    },
    components: {},
    computed: {},
    mounted() {
      this.getList();
    },
    methods: {
      // /hire/paySalary 发放薪水
      paySalary(hireId) {
        this.$ajax.post("hire/paySalary", {
          hireId: hireId
        }).then((e) => {
          if (e.status == 200) {
            Toast('发放薪水成功')
            this.loadTop();
          } else {
            Toast(e.msg)
          }
        });
      },
      // /hire/delayPaySalary 延时发放薪水
      delayPaySalary(hireId){
        this.$ajax.post("hire/delayPaySalary", {
          hireId: hireId
        }).then((e) => {
          if (e.status == 200) {
            Toast('延时发放薪水成功')
            this.loadTop();
          } else {
            Toast('延时发放薪水失败');
          }
        });
      },
      loadTop() {
        // 刷新数据
        this.list = [];
        this.params.pageNum = 1;
        this.allLoaded = false;
        this.getList();
        this.$refs.loadmore.onTopLoaded();
      },
      loadBottom() {
        // 加载更多数据
        if (this.params.pageNum > this.configData.pageCount) {
          Toast('没有更多了！');
          this.allLoaded = true; // 若数据已全部获取完毕
          this.$refs.loadmore.onBottomLoaded();
        }
        this.loadMore();
        this.$refs.loadmore.onBottomLoaded();
      },
      handleTopChange() {
        this.topStatus = status;
      },
      getList() {
        Indicator.open({
          text: '加载中...',
          spinnerType: 'fading-circle'
        });
        let params = {
          ...this.params
        }

        this.$ajax.get('hire/pay/no', params).then(e => {
          if (e.status !== 200) {
            Indicator.close();
            return false;
          }
          let listarr = e.data.list.map((item) => {
            item.startTime = moment(item.startTime).format("YYYY-MM-DD")
            item.endTime = moment(item.endTime).format("YYYY-MM-DD")
            item.nowDate = moment().format("YYYY-MM-DD");
            item.surplus = this.getSurplusDate(item) || '';

            let endTime = moment(item.endTime).format('x');
            let nowTime= moment( moment(new Date()).format('YYYY-MM-DD')).format('x');
            item.isShow = nowTime > endTime && item.type == 1 ? true : false;

            return item;
          });
          this.list = this.list.concat(listarr);
          let count = e.data.count == 'undefined' ? 0 : e.data.count;
          this.configData.pageCount = Math.ceil(count / params.pageSize);
          this.params.pageNum = this.params.pageNum + 1;
          Indicator.close();
          this.loading = false;
        }).catch(function (err) {
          Indicator.close();
        })
      },
      getSurplusDate(item){
          if(item.type == 0){
            // 开始时间到现在过了几个月
            let monthDate = this.getDateDiff(item.startTime, moment().format("YYYY-MM-DD"), 'month')+1;
            return  moment(item.startTime).add(monthDate,'month').format("YYYY-MM-DD");
          }
        return moment(item.endTime).add(item.delayPaySalary == 1 ? 15 : 10, 'day').format("YYYY-MM-DD");
      },
      loadMore() {
        if (this.configData.pageCount < this.params.pageNum) {
          return false;
        }
        this.loading = true;
        this.getList();
      },
      /*
       * 获得时间差,时间格式为 年-月-日 小时:分钟:秒 或者 年/月/日 小时：分钟：秒
       * 其中，年月日为全格式，例如 ： 2010-10-12 01:00:00
       * 返回精度为：秒，分，小时，天
       */
      getDateDiff(startTime, endTime, diffType){
//将xxxx-xx-xx的时间格式，转换为 xxxx/xx/xx的格式
        startTime = startTime.replace(/-/g, "/");
        endTime = endTime.replace(/-/g, "/");
        //将计算间隔类性字符转换为小写
        diffType = diffType.toLowerCase();
        var sTime = new Date(startTime); //开始时间
        var eTime = new Date(endTime); //结束时间
        //作为除数的数字
        var divNum = 1;
        switch (diffType) {
          case "second":
            divNum = 1000;
            break;
          case "minute":
            divNum = 1000 * 60;
            break;
          case "hour":
            divNum = 1000 * 3600;
            break;
          case "day":
            divNum = 1000 * 3600 * 24;
            break;
          case "month":
            divNum = 1000 * 3600 * 24 * 30;
            break;
          default:
            break;
        }
        return parseInt((eTime.getTime() - sTime.getTime()) / parseInt(divNum)) || 0;

      }
    },
    watch: {
      '$route': function () {
        this.loadTop();
      }
    }
  }
</script>

<style scoped>
  .paylist {
    font-size: 0.22rem;
    color: #5a5a5a;
  }

  .paylist ul li {
    padding: 0.2rem 0.3rem;
    line-height: 0.5rem;
    border-bottom: 0.1rem solid #f7f7f7;
  }

  .topay-btn {
    display: block;
    width: 1.66rem;
    height: 0.63rem;
    line-height: 0.63rem;
    text-align: center;
    background-color: #f54203;
    color: #fff;
  }

  .tiem-span span {
    display: inline-block;
  }
</style>


