<template>
  <div class="headtab">
    <div class="nav box space-between">
      <div @click="popshow(1,'按行业')" class="flex-grow1">
        {{searchData.class_text}}
        <img :src="ftpPath + '/icon_down.png'" class="icondown" />
      </div>
      <div v-if="pageName == 'works'" @click="popshow(2,'按区域')" class="flex-grow1">
        {{searchData.type_text}}
        <img :src="ftpPath + '/icon_down.png'" class="icondown" />
      </div>
      <div v-else @click="popshow(2,'按性别')" class="flex-grow1">
        {{searchData.gender_text}}
        <img :src="ftpPath + '/icon_down.png'" class="icondown" />
      </div>
      <div @click="popshow(3,'按等级')" class="flex-grow1">
        {{searchData.experience_text}}
        <img :src="ftpPath + '/icon_down.png'" class="icondown" />
      </div>
    </div>

    <div class="pop" v-if="hypopup || qypopup || jypopup || genderup">
      <djlheader :title="poptitle" class="pop-header">
        <span @click="close" slot="headleft">
            <mt-button icon="back"></mt-button>
        </span>
        <span slot="headright" @click="close">X</span>
      </djlheader>

      <mt-popup :modal="false" v-model="hypopup" position="bottom" popup-transition="popup-fade" class="pop-list">
        <ul style="padding: 0 0.2rem">
          <li @click="choose(1,{name:'按行业',id:''})" class="listitem">全部</li>
          <li v-for="item in classlist" :key="item.id" @click="choose(1,item)" class="listitem">{{item.name}}</li>
        </ul>
      </mt-popup>

      <mt-popup :modal="false" v-model="qypopup" position="bottom" popup-transition="popup-fade" class="pop-list">
         <ul>
          <li @click="choose(2,{name:'按区域',id:''})" class="listitem">全部</li>
          <li v-for="item in qylist" :key="item.id" @click="choose(2,item)" class="listitem">{{item.name}}</li>
        </ul>
      </mt-popup>

      <mt-popup :modal="false" v-model="genderup" position="bottom" popup-transition="popup-fade" class="pop-list">
        <ul>
          <li @click="choose(2,{name:'按性别',id:'-1'})" class="listitem">全部</li>
          <li v-for="item in genderlist" :key="item.id" @click="choose(2,item)" class="listitem">{{item.name}}</li>
        </ul>
      </mt-popup>

      <mt-popup :modal="false" v-model="jypopup" position="bottom" popup-transition="popup-fade" class="pop-list">
        <ul style="padding: 0 0.2rem">
          <li @click="choose(3,{name:'按等级',id:''})" class="listitem">全部</li>
          <li v-for="item in rank" :key="item.id" @click="choose(3,item)" class="listitem">{{item.name}}</li>
        </ul>
      </mt-popup>
    </div>
  </div>
</template>

<script>
  import djlheader from '@/components/index/Header'
  import { Popup } from 'mint-ui';
  import { mapActions, mapState } from 'vuex';

  export default {
    components: { djlheader, Popup },
    props: {
      searchData: {
        type: Object,
        default: {}
      },
      callback: {
        type: Function,
        default: function () { }
      }
    },
    data() {
      return {
        poptitle: '',
        hypopup: false,
        qypopup: false,
        jypopup: false,
        genderup: false,
        pageName: '',
      }
    },
    computed: {
      ...mapState({
        ftpPath: state => state.Public.ftpPath,
        classlist: state => state.Public.cla2,
        qylist: state => state.Public.qylist,
        rank: state => state.Public.rank,
        genderlist: state => state.Public.genderlist,
        expEndList: state => state.Public.expEndList,
        expStartList: state => state.Public.expStartList,
      })
    },
    mounted() {
      this.getHY();
      this.getQY();

      this.pageName = this.searchData.pageName || 'works';
    },
    methods: {
      ...mapActions(['getHY', 'getQY']),
      choose(index, item) {
        if (index == 1) {
          this.searchData.class_text = item.name;
          this.searchData.classIds = item.id;
        } else if (index == 2) {
          if (this.pageName == 'works') {
            this.searchData.type_text = item.name;
            this.searchData.typeid = item.id;
          } else {
            this.searchData.genderid = item.id;
            this.searchData.gender_text = item.name;
          }
        } else if (index == 3) {
//          this.searchData.expEnd = this.expEndList[item.id], //	工作年限最大值	number	@mock=1
//            this.searchData.expStart = this.expStartList[item.id], //	工作年限最小值	number	@mock=5
          this.searchData.rank = item.id
          this.searchData.experienceid = item.id;
          this.searchData.experience_text = item.name;
        }
        this.close();
        this.callback();
      },
      popshow(index, title) {
        if (index == 1) {
          this.hypopup = true
        } else if (index == 2) {
          if (this.pageName == 'works') {
            this.qypopup = true
          } else {
            this.genderup = true
          }
        } else if (index == 3) {
          this.jypopup = true
        }
        this.poptitle = title;
      },
      close() {
        this.hypopup = false
        this.qypopup = false,
        this.jypopup = false
        this.genderup = false
      },
      goback(){
          this.$router.go(-1);
      }
    }
  }
</script>

<style scoped>
  .headtab {
    font-size: 0.26rem;
    color: #5a5a5a;
    height: 0.68rem;
    line-height: 0.68rem;
    position: fixed;
    top: 0.75rem;
    right: 0;
    left: 0;
    z-index: 999;
  }
  .nav{
    background: #fff;
    border-bottom: 0.01rem solid #c8c8c8;
  }
  .flex-grow1 {
    flex-grow: 1;
    text-align: center;
  }

  .icondown {
    height: 0.13rem;
    width: 0.24rem;
    margin-left: 0.06rem;
  }

  .pop-header {
    position: fixed;
    top: 0;
    left: 0;
    width: 6.5rem;
    z-index: 9999;
  }


  /*.pop-list{
	  width: 100%;
	  text-align:center;
	  top: 0.75rem;
  }*/

  .listitem {
    border-bottom: 1px solid #eee;
  }




  .pop {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    height: 100%;
    width: 6.5rem;
  }

  .pop-list {
    width: 100%;
    text-align: center;
    position: absolute;
    top: 0.75rem;
    right: 0;
    bottom: 0;
    overflow: scroll;
  }
</style>
