<template>
        <!--<div class="height20"></div>-->
        <div class="height50">
            <img :src="ftpPath + '/copyright.png'" class="copyright"/>
        </div>
        <!--<p style="width:4.12rem;margin: 0px auto;">备案号：浙ICP备12026518号-58 Copyright2008-2017 All rights reserved.</p>
        <p style="width:4.78rem;margin: 0px auto;">杭州四喜信息技术有限公司版权所有 地址：杭州市西湖区西湖科技园西园八路11号B座5楼</p>-->
</template>

<script>
import { mapState } from 'vuex'
export default {
  computed:{
      ...mapState({
        ftpPath: state => state.Public.ftpPath
      })
  },
}
</script>

<style scoped>
.height50{
    height:0.55rem;
    overflow: hidden;
    padding:0.1rem 0;
}
.copyright{
    width: 6.5rem;
    height:0.45rem;
    display: block;
}
</style>
