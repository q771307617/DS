<template>
    <div>
        <mt-swipe :auto="4000" class="banner">
            <!-- <mt-swipe-item><img :src="ftpPath + '/banner1.png'" class="banner-img" /></mt-swipe-item>-->            
            <mt-swipe-item v-for = "(item,index) in imgList" :key="index"><img :src="item.imgUrl" class="banner-img" /></mt-swipe-item>
        </mt-swipe>
        <!--<div class="content">
            <div class="box notice">
                <div class="gy">雇佣动态</div>
                <div class="scroll-txt">
                    <marquee behavior="scroll" direction="left" scrollamount="4">
                        <span class="marquee" v-for="item in dynamicList" :key="item.text">
                            {{item.name1}}雇佣了{{item.name2}} <span class="red">{{item.money}}</span> {{item.time}}
                        </span>
                    </marquee>
                </div>
            </div>
            <div class="height10 bgf7"></div>
        </div>-->
    </div>
</template>
<script>
import { Swipe, SwipeItem } from 'mint-ui';
import { mapState } from 'vuex'
export default {
  data(){
      return{
        imgList :"",
        dynamicList: [
            {
                name1: '王**',
                name2: '李**',
                money: '3800元',
                time: '12分钟前',
            },
            {
                name1: '黄**',
                name2: '须**',
                money: '4500元',
                time: '15分钟前',
            },
            {
                name1: '吴**',
                name2: '汪**',
                money: '5600元',
                time: '一小时前',
            },
            {
                name1: '王**',
                name2: '林**',
                money: '4500元',
                time: '两小时前',
            },
            {
                name1: '王**',
                name2: '张**',
                money: '5000元',
                time: '两小时前',
            }
        ]
      }
  },
  mounted(){
        this.$ajax.getRoot("common/config/get",{key:"bannerkey"}).then((e) => {
                if (e.status == 200) {
                    this.imgList = JSON.parse(e.data)                               
                }                
        });
  },
  computed: {
    ...mapState({
        ftpPath: state => state.Public.ftpPath
    })
  },

  compontens:{
      Swipe,
      SwipeItem
  }
  
}
</script>

<style>
.banner .mint-swipe-indicators{
    height: 45%;
}
.banner .mint-swipe-indicator{
    background: #fff;
    width: 0.12rem;
    height: 0.12rem;
}
.banner .mint-swipe-indicator.is-active{
    opacity: 1;
    background: #f54203;
}
</style>

<style scoped>
.banner{
    height: 2.17rem;
}
.banner-img{
    width:100%;
    max-width: 7.5rem;
    height:2.17rem;
}
.content{
    /*padding: 0 0.17rem;*/
}
.notice{
    height:0.4rem;
    padding: 0 0.17rem;
    color:#5a5a5a;
    /*横向平铺*/
    flex-direction: row;
    /*水平居中*/
    align-items: center;
}
.gy{
    font-size: 0.22rem;
    flex-grow: 1;
    height: 0.4rem;
    line-height: 0.4rem;
    width: 4rem;
}
.scroll-txt{
    font-size: 0.16rem;
    flex-grow: 6;
    height: 0.4rem;
    line-height: 0.4rem;
}
.marquee{
    margin-right: 1.1rem;
}
.red{
    color:red;
}
</style>

