<template>
    <div class="main release">
        <p class="title-box box space-between">
            <span class="title">点将啦免费匹配设计师</span>
            <span class="desc">已免费匹配
                <span class="num">{{matchingNum + 1000}}次</span>
            </span>
        </p>
        <mt-field label="店铺名称" v-model="title" :state="title_validate" placeholder="填写您的店铺名称" class="djl-input"></mt-field>
        <mt-field label="薪资预算" v-model="budget" type="number" :state="budget_validate" placeholder="填写您的预算" class="djl-input"></mt-field>
        <mt-field label="联系方式" v-model="contact" :state="contact_validate" placeholder="手机号码/QQ/微信/信息安全仅工作人员可见" class="djl-input"></mt-field>
        <mt-field label="验证码" v-model="verifycode" :state="verifycode_validate" placeholder="输入图片验证码" class="djl-input">
            <img @click="reImg" :src="imgcodeurl" style="height: 0.73rem;"/>
        </mt-field>
        <mt-button type="danger" size="large" @click="publish" class="demand-btn">立即发布</mt-button>
        <mt-button size="large" class="demand-btn log-btn" v-if="!info.id" @click="login">登录 | 注册</mt-button>
    </div>
</template>

<script>
import { Button, Field, Toast } from 'mint-ui';
import { mapState } from 'vuex'
import Api from '../../api'

export default {
    data() {
        return {
            imgcodeurl: Api.getVerifyCode(),
            title: '',
            budget: '',
            contact: '',
            verifycode: '',
            title_validate: '',
            budget_validate: '',
            contact_validate: '',
            verifycode_validate: '',
            matchingNum:0
        }
    },
    computed: {
        ...mapState({
            info: state => state.User.userInfo
        })
    },
    mounted(){
        this.getMatching();
    },
    methods: {
        getMatching(){
            this.$ajax.get('index/collection/count').then((e)=>{
                if(e.status == 200){
                    this.matchingNum = e.data;
                }
            })
        },
        reImg() {
            this.imgcodeurl = Api.getVerifyCode();
        },
        login() {
            this.$router.push({ name: 'login' })
        },
        clearData(){
            this.title = '';
            this.budget = '';
            this.contact = '';
            this.verifycode = '';
            this.title_validate = '';
            this.budget_validate = '';
            this.contact_validate = '';
            this.verifycode_validate = '';
        },
        publish() {
            if (!this.title) {this.title_validate = 'error';return;} else {this.title_validate = 'success';}
            if (!this.budget) {this.budget_validate = 'error';return;} else {this.budget_validate = 'success';}
            if (!this.contact) {this.contact_validate = 'error';return;} else {this.contact_validate = 'success';}
            if (!this.verifycode || this.verifycode.length !== 4) {this.verifycode_validate = 'error';return;} else {this.verifycode_validate = 'success';}
            this.$ajax.post('index/collection',{
                title: this.title,
                budget: this.budget,
                contact: this.contact,
                verifycode: this.verifycode
            }).then((e)=>{
                if(e.status == 200){
                    Toast('发布成功');
                    this.clearData();
                    this.reImg();
                }else{
                    Toast(e.msg);
                    this.verifycode_validate = "error";
                    this.reImg();
                }
            })
        }
    }
}
</script>

<style scoped>
.main {
    padding: 0.25rem 0.17rem 0 0.17rem;
}

.title-box {
    color: #5a5a5a;
    height: 0.78rem;
    line-height: 0.78rem;
    color: #5a5a5a;
}

.title {
    font-size: 0.26rem;
}

.desc {
    font-size: 0.2rem;
}

.num {
    color: #f54210;
}

.log-btn {
    background: #5a5a5a !important;
    color: #fff !important;
}

</style>
