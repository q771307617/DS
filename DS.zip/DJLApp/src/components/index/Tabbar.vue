<template>
    <mt-tabbar v-model="selected" fixed class="tab">
        <mt-tab-item v-for="item in mentitem" :key="item.id" :id="item.id">
            <div v-on:click="clickHandle(item.id)" class="mint-tab-item-icon"><img slot="icon" :src="ftpPath + '/' + item.icon + '.png' " class="icon"></div>
            <div v-on:click="clickHandle(item.id)" class="mint-tab-item-label">{{item.text}}</div>
        </mt-tab-item>
    </mt-tabbar>
</template>

<script>
import { Tabbar, TabItem } from 'mint-ui';
import { mapState } from 'vuex'

export default {
    data(){
        return {
            selected: 1,
            mentitem:[
                {
                    id: 1,
                    name: 'index',
                    text: '首页',
                    icon: 'home2'
                },
                {
                    id: 2,
                    name: 'designer',
                    text: '所有设计师',
                    icon: 'all-designer'
                },
                {
                    id: 3,
                    name: 'prolist',
                    text: '所有作品',
                    icon: 'all-works'
                },
                {
                    id: 4,
                    name: 'personal',
                    text: '个人中心',
                    icon: 'personal'
                }
            ]
        }
    },
    components: {
        Tabbar,
        TabItem
    },
    mounted(){
        this.setActiveMenu();
    },
    methods: {
        setActiveMenu(){
            this.mentitem.map((v)=>{
                if(v.name === this.$route.name){
                    this.selected = v.id
                }
            })
        },
        clickHandle(val){
            if(this.selected == val){
                this.mentitem.map((v)=>{
                    if(v.id == val){
                        this.$router.push({ name: v.name });
                    }
                })
            }
        }
    },
    computed: {
        ...mapState({
            ftpPath: state => state.Public.ftpPath
        })
    },
    watch:{
        '$route':'setActiveMenu',
        selected(val,oldval){
            this.mentitem.map((v)=>{
                if(v.id == oldval){
                    v.icon = v.icon.replace('2','');
                }
                if(v.id == val){
                    v.icon = v.icon + '2';
                    this.$router.push({ name: v.name });
                }
            })
        }
    }
}
</script>

<style>
.tab .mint-tab-item{
    padding-top: 0.16rem;
}
.tab .mint-tab-item-icon{
    width: 0.4rem;
    height: auto;
    margin: 0 auto 0.1rem;
}
.tab .mint-tab-item-label{
    font-size: inherit;
    color: #5a5a5a;
}
.tab > .mint-tab-item.is-selected ,
.tab > .mint-tab-item.is-selected .mint-tab-item-label{
    color: #f54102;
    background: #fff;
}
</style>

<style scoped>
.tab{
    height:0.95rem;
    font-size:0.22rem;
    border-top: 1px solid #eee;
    background:#fff;
}
.icon{
    height:0.36rem;
    width:0.4rem
}
</style>


