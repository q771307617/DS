<template>
    <div class="title">
        <mt-header fixed :title="title">
            <div slot="left">
                <slot name="headleft"></slot>
            </div>
            <div slot="right">
                <slot name="headright"></slot>
            </div>
        </mt-header>
    </div>
</template>

<script>
import { Header } from 'mint-ui';

export default {
    props: ['title'],
    component:{ Header,headName:Header.name },
    data () {
        return {

        }
    }
}
</script>

<style scoped>
  .title{height: 0.75rem;}
  .title .mint-header{
    height: 0.75rem;
    background: linear-gradient(to right,#fe8e01, #f54102);
}
</style>

<style>
.title .mint-header .mint-header-title{
    font-size: 0.35rem;
}
.title .mintui{
    font-size: 0.35rem;
}
</style>

