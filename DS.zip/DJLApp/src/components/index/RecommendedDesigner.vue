<template>
    <div class="main">
        <p class="title">推荐设计师</p>

            <mt-swipe style="height:5.7rem;" :auto="0" :show-indicators="false">
                <mt-swipe-item v-for="i in getPage()" :key="i">
                    <div class="box space-between wrap">
                        <div class="list-box" v-for="el in getPageData(i)" :key="el.id">
                            <div class="img-box" @click="toinfo(el.user_id)">
                                <img :src="el.image_url" />
                            </div>
                            <div class="txt-box txt bgf7">
                                <img :src="ftpPath + '/icon-designer.png'" class="icon">
                                <span @click="toinfo(el.user_id)">{{el.nickname}}</span>
                                <br>
                                <img :src="ftpPath + '/icon-money.png'" class="icon" />  
                                <span class="color-red">{{el.salary}}/月</span>
                            </div>
                        </div>
                    </div>
                </mt-swipe-item>
            </mt-swipe>

        <mt-button type="danger" size="large" class="more" @click="tolist">查看更多</mt-button>
    </div>
</template>

<script>
import { mapState } from 'vuex'
import { Button, Swipe, SwipeItem } from 'mint-ui';

export default {
    data() {
        return {
            lists: [],
            pageSize: 6
        }
    },
    computed: {
        ...mapState({
            ftpPath: state => state.Public.ftpPath
        }),

    },
    components: {
        'mt-button': Button,
        Swipe,
        SwipeItem
    },
    mounted() {
        this.getDeg();
    },
    methods: {
        toinfo(id){
            this.$router.push({
                name: 'dinfo',
                params: { id }
            });
        },
        tolist(){
            this.$router.push({
                name: 'designer'
            });
        },
        // 计算总页数
        getPage() {
            var total = this.lists.length;
            let p = this.pageSize;
            if (total % p == 0) {
                // console.log(parseInt(total / p));
                return parseInt(total / p);
            } else {
                // console.log(parseInt(total / p)+1);
                return parseInt(total / p) + 1;
            }
        },
        // 返回每页数据
        getPageData(index) {
            var dataList = [];
            var p = this.pageSize;
            var e = 0;
            if (index > 1) {
                e = (index - 1) * p;
            }
            for (let i = e; i < index * p; i++) {
                if (!this.lists[i]) {
                    break;
                }
                dataList.push(this.lists[i]);
            }
            return dataList;
        },
        getDeg() {
            this.$ajax.get('index/recommend').then((e) => {
                if (e.status != 200) { return; }
                this.lists = e.data;
                if(this.lists.length < 18){
                    this.lists.push(this.lists[0]);
                    this.lists.push(this.lists[1]);
                }
            })
        }
    }
}
</script>

<style>

</style>

<style scoped>
.main {
    padding: 0 0.17rem;
}

.title {
    font-size: 0.22rem;
    color: #f54102;
    height: 0.45rem;
    line-height: 0.45rem;
}

.list-box {
    width: 1.95rem;
    height: 2.73rem;
    margin-top: 0.15rem;
}

.img-box {
    height: 2.15rem;
    width: 1.95rem;
}

.img-box img {
    height: inherit;
    width: inherit;
}

.txt-box {
    padding-left: 0.17rem;
    height: 0.58rem;
    line-height: 0.29rem;
}

.icon {
    height: 0.17rem;
    width: 0.17rem;
}

.txt {
    font-size: 0.2rem;
    color: #090909;
}

.more {
    height: 0.73rem;
    margin-top: 0.15rem;
    margin-bottom: 0.15rem;
    font-size: 0.26rem;
    border-radius: 0;
    background: #f54102;
}
.color-red{
    color:#f54203;
}
</style>
