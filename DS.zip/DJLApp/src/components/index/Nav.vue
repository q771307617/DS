<template>
    <div class="main">
        <div class="height10 bgf7"></div>
        <p class="title">
            点将啦为您保驾护航
        </p>
        <ul class="con box space-around">
            <li>
                <router-link :to="{name:'rules'}">
                    <div>
                        <img :src="ftpPath + '/design.png'" />
                    </div>
                    <div>
                        专业设计
                    </div>
                </router-link>
            </li>
            <li>
                <router-link :to="{name:'rules'}">
                    <div>
                        <img :src="ftpPath + '/matching.png'" />
                    </div>
                    <div>
                        极速匹配
                    </div>
                </router-link>
            </li>
            <li>
                <router-link :to="{name:'rules'}">
                    <div>
                        <img :src="ftpPath + '/tryout.png'" />
                    </div>
                    <div>
                        三天试用
                    </div>
                </router-link>
            </li>
            <li>
                <router-link :to="{name:'rules'}">
                    <div>
                        <img :src="ftpPath + '/guarantee.png'" />
                    </div>
                    <div>
                        平台担保
                    </div>
                </router-link>
            </li>
        </ul>
        <div class="height10 bgf7"></div>
    </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
    computed: {
        ...mapState({
            ftpPath: state => state.Public.ftpPath
        })
    },
}
</script>

<style scoped>
.title {
    font-size: 0.28rem;
    color: #f54102;
    height: 0.63rem;
    line-height: 0.63rem;
    border-bottom: 1px solid #eee;
    text-align: center;
}
.con {
    font-size: 0.19rem;
    color: #5a5a5a;
    padding-top: 0.29rem;
    padding-bottom: 0.14rem;
}
.con li{
    text-align: center;
}
</style>

