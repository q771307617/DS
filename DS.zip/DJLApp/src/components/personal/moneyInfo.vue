<template>
    <div >
        <div class="box space-between" >
            <div  class="box_balance">
                <p>账户余额</p>
                <p class="deposit"><span >{{userInfo.balance}}</span>元</p>
                
            </div>
            <div  class="line"></div>
            <div  class="box_deposit">
                <p>平台监管金额</p>
                <p class="deposit"><span >{{userInfo.deposit}}</span>元</p>
            </div>
        </div>
    </div>
</template>

<script scoped>
import {mapState} from 'vuex'
export default {
     data() {
		return {
		
		}
	},
      computed: {	
      ...mapState({
		userInfo: state => state.User.userInfo,
      })
    },
}
</script>

<style scoped>
.box{
text-align:center;
align-items:center;
color: #fff;

}
.box_balance{
flex: 1;
font-size: 0.26rem;
}
.box_deposit{
flex: 1;
font-size: 0.26rem;
}
.line{
border-right:1px solid #e4e4e4;
width:1px;
height:0.7rem;
}
.deposit{
    font-size: 0.3rem;
}
.deposit span{
    font-size: 0.54rem;
}

</style>
