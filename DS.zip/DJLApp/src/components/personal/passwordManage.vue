<template>
    <div class="main">
        <djlheader :title="'密码管理'">
            <span @click="goback" slot="headleft">
                <mt-button icon="back"></mt-button>
            </span>
        </djlheader>
        <ul class="tab box">
            <li @click="isactive = false" :class="{active: !isactive}">登录密码</li>
            <li @click="isactive = true" :class="{active: isactive}">支付密码</li>
        </ul>
        <div class="demand-inputItem" v-if="!isactive">
            <mt-field label="原登录密码" type="password" v-model="loginData.old_pwd" :state="loginData.validate_old_pwd" placeholder="填写原登录密码" class="djl-input"></mt-field>
            <p class="error">{{loginMsg.old_pwd_msg}}</p>
            <mt-field label="新登录密码" type="password" v-model="loginData.new_pwd" :state="loginData.validate_new_pwd" placeholder="填写新登录密码" class="djl-input"></mt-field>
            <p class="error">{{loginMsg.new_pwd_msg}}</p>
            <mt-field label="确认登录密码" type="password" v-model="loginData.again" :state="loginData.validate_again" placeholder="再次输入新密码" class="djl-input"></mt-field>
            <p class="error">{{loginMsg.again_msg}}</p>
            <mt-button size="large" @click="sub" class="demand-btn">确认</mt-button>
        </div>
        <!--<div class="demand-inputItem" v-else-if="!info.pay_password">
                <mt-field label="设置支付密码" type="password" v-model="payData._payPw" :state="payData.validate_payPw" placeholder="填写支付密码" class="djl-input"></mt-field>
                <p class="prompt">请设置至少6位数字或字母</p>
                <mt-field label="确认支付密码" type="password" v-model="payData.payPw" :state="payData.validate_againPwd" placeholder="再次输入支付密码" class="djl-input"></mt-field>
                <mt-button size="large" @click="paySub" class="demand-btn">确认</mt-button>
            </div>-->
        <div class="demand-inputItem" v-else>
            <mt-field label="图片验证码" v-if="needVerifycode" v-model="payData.verifycode"  placeholder="输入图片验证码" type="text" :attr="{ maxlength: 4 }" class="djl-input">
                <img @click="reImg" :src="imgcodeurl" style="height: 0.73rem;" />
            </mt-field>
            <p class="error" v-if="needVerifycode">{{payMsg.verifycode_msg}}</p>

            <mt-field label="您的手机号" v-model="info.phone" readonly class="djl-input">
                <span @click="sendcode" class="sendcode" v-if="codeIntervalTime==60">发送验证码</span>
                <span class="sendcode" v-else>{{codeIntervalTime}}后重新发送</span>
            </mt-field>
            <mt-field label="手机验证码" v-model="payData.phoneCode"  placeholder="请输入手机验证码" class="djl-input" type="number"></mt-field>
            <p class="error">{{payMsg.phoneCode_msg}}</p>

            <mt-field label="输入支付密码" type="password" v-model="payData._payPw" :state="payData.validate_payPw" placeholder="再次输入支付密码" class="djl-input"></mt-field>
            <p class="error">{{payMsg._payPw_msg}}</p>

            <mt-field label="再次输入" type="password" v-model="payData.payPw" :state="payData.validate_againPw" placeholder="再次输入支付密码" class="djl-input"></mt-field>
            <p class="error">{{payMsg.payPw_msg}}</p>

            <mt-button size="large" @click="paySub" class="demand-btn">确认</mt-button>
        </div>
    </div>
</template>

<script>
import djlheader from '@/components/index/Header'
import Api from '../../api'
import { mapState, mapActions } from 'vuex'
import { Toast } from 'mint-ui'

export default {
    components: { djlheader },
    data() {
        return {
            isactive: false,
            needVerifycode:false,//需要验证码
            imgcodeurl: Api.getVerifyCode(),
            codeIntervalTime: 60,
            loginData: {
                old_pwd: '',
                new_pwd: '',
                again: '',
                validate_old_pwd: '',
                validate_new_pwd: '',
                validate_again: '',
            },
            loginMsg: {
                old_pwd_msg: '',
                new_pwd_msg: '',
                again_msg: ''
            },
            payData: {
                _payPw: '',
                payPw: '',
                phoneCode: '',
                verifycode: '',
                validate_verifycode: '',
                validate_phoneCode: '',
                validate_payPw: '',
                validate_againPw: ''
            },
            payMsg: {
                verifycode_msg: '',
                phoneCode_msg: '',
                _payPw_msg: '',
                payPw_msg: ''
            },
        }
    },
    computed: {
        ...mapState({
            info: state => state.User.userInfo
        })
    },
    mounted() {
        this.watchActive();
        this.getUserData();
    },
    methods: {
        ...mapActions(['getUserData']),
        watchActive(){
            if(this.$route.params.active){
                this.isactive = this.$route.params.active;
            }
        },
        validate() {
            if (!this.loginData.old_pwd) { this.loginMsg.old_pwd_msg = '请输入原登录密码'; return false; }
            else { this.loginMsg.old_pwd_msg = ''; this.loginData.validate_old_pwd = 'success'; }

            if (!/^(\S){6,20}$/.test(this.loginData.new_pwd)) { this.loginMsg.new_pwd_msg = '密码只能输入字母、数字，密码长度限制6~20!'; return false; }
            else { this.loginMsg.new_pwd_msg = ''; this.loginData.validate_new_pwd = 'success'; }

            if (!/^(\S){6,20}$/.test(this.loginData.again)) { this.loginMsg.again_msg = '密码只能输入字母、数字，密码长度限制6~20!'; return false; }
            else if (this.loginData.new_pwd !== this.loginData.again) { this.loginMsg.again_msg = '两次密码输入不一致'; return false; }
            else { this.loginMsg.again_msg = ''; this.loginData.validate_again = 'success'; }

            return true;
        },
        clearLoginData() {
            this.loginData.old_pwd = '';
            this.loginData.new_pwd = '';
            this.loginData.again = '';
            this.loginData.validate_old_pwd = '';
            this.loginData.validate_new_pwd = '';
            this.loginData.validate_again = '';
        },
        sub() {
            if (!this.validate()) {
                return;
            }
            this.$ajax.postRoot('user/password/reset', {
                new_pwd: this.loginData.new_pwd,
                old_pwd: this.loginData.old_pwd
            }).then((e) => {
                if (e.status == 200) {
                    Toast({
                        message: '密码设置成功！',
                        iconClass: 'mintui mintui-success'
                    });
                    this.clearLoginData();
                    this.goPersonal();
                } else {
                    Toast(e.msg);
                    this.loginData.old_pwd = '';
                    this.loginData.validate_old_pwd = 'error';
                }
            })
        },
        // validateBackPay(){
        //     if(!this.backPayPwd.phoneCode){ this.backPayPwd.validate_phoneCode = 'error'; return false; } else{ this.backPayPwd.validate_phoneCode = 'success';}
        //     if(!this.payData._payPw){ this.payData.validate_payPw = 'error'; return false; } else{ this.payData.validate_payPw = 'success';}
        //     if(!this.payData.payPw || this.payData.payPw !== this.payData._payPw){ this.payData.validate_againPwd = 'error'; return false; } else{ this.payData.validate_againPwd = 'success';}
        //     return true;
        // },

        // backPaySub(){
        //     if(!this.validateBackPay()){
        //         return;
        //     }
        //     this.$ajax.postRoot('user/updatepaypw',{
        //         _payPw: this.payData._payPw,
        //         payPw: this.payData.payPw,
        //     }).then((e)=>{
        //         if(e.status == 200){
        //             Toast('操作成功！');
        //         }else{
        //             Toast(e.msg);
        //         }
        //     })
        // },
        clearPayData() {
            this.payData._payPw = '',
                this.payData.payPw = '',
                this.payData.phoneCode = '',
                this.payData.verifycode = '',
                this.payData.validate_verifycode = '',
                this.payData.validate_phoneCode = '',
                this.payData.validate_payPw = '',
                this.payData.validate_againPw = '',
                this.payMsg.verifycode_msg = '',
                this.payMsg.phoneCode_msg = '',
                this.payMsg._payPw_msg = '',
                this.payMsg.payPw_msg = ''
        },
        validateImgCode() {
            if (!this.payData.verifycode) { this.payMsg.verifycode_msg = "请输入图片验证码"; return false;} 
            else { this.payMsg.verifycode_msg = ""; this.payData.validate_verifycode = 'success';}
            return true;
        },
        validatePay() {
            if(!this.validateImgCode()){this.payMsg.verifycode_msg = '请输入验证码';}
              if(!this.payData.verifycode){this.payMsg.verifycode_msg = '请输入图片验证码';}
                        else if(this.payData.verifycode.length<4){this.payMsg.verifycode_msg = '需要四位验证码';}
                        else{}
            if (!this.payData.phoneCode) { this.payMsg.phoneCode_msg = '请填写手机验证码'; return false; }
            else { this.payMsg.phoneCode_msg = ''; this.payData.validate_phoneCode = 'success'; }

            if (!this.payData._payPw) { this.payMsg._payPw_msg = '请填写支付密码'; return false; }
            else if (this.payData._payPw.length < 6) { this.payMsg._payPw_msg = '支付密码不能小于6位'; return false; }
            else { this.payMsg._payPw_msg = ''; this.payData.validate_payPw = 'success'; }

            if (this.payData.payPw !== this.payData._payPw) { this.payMsg.payPw_msg = '两次密码输入不一致'; return false; }
            else { this.payMsg.payPw_msg = ''; this.payData.validate_againPw = 'success'; }

            return true;
        },
        validatePhoneCode(){
            this.$ajax.postRoot('auth/verify/phone',{
                code: this.payData.phoneCode
            }).then((e)=>{
                if(e.status != 200){
                    Toast(e.msg);
                    this.clearPayData();
                    this.reImg();
                    return false;
                }else{
                    // console.log(123456789);
                    return true;
                }
            })
        },
        paySub() {
            if (!this.validatePay()) {
                return;
            }
            this.$ajax.postRoot('auth/verify/phone',{
                code: this.payData.phoneCode
            }).then((e)=>{
                if(e.status != 200){
                    Toast(e.msg);
                    this.clearPayData();
                    this.reImg();
                    return;
                }
                this.$ajax.postRoot('user/updatepaypw', {
                    _payPw: this.payData._payPw,
                    payPw: this.payData.payPw,
                    phoneCode: this.payData.phoneCode
                }).then((e) => {
                    if (e.status == 200) {
                        Toast({
                            message: '支付密码设置成功',
                            iconClass: 'mintui mintui-success'
                        });
                        this.clearPayData();
                        this.goPersonal();
                    } else {
                        Toast(e.msg);
                    }
                })
            })
           
        },
        goPersonal(){
            this.$router.push({
                name: 'personal'
            });
        },
        // 发送验证码
        sendcode() {
            this.reImg();
            this.$ajax.postRoot('auth/sendcode', {
                phone: this.info.phone,
                verifycode: this.payData.verifycode
            }).then((e) => {
                if (e.status !== 200) {
                        this.needVerifycode = true;
                        this.codeIntervalTime = 60;
                        clearInterval(this.update);
                        this.reImg()
                        if(!this.payData.verifycode){Toast('请输入图片验证码');}
                        else if(this.payData.verifycode.length<4){Toast('需要四位验证码');}
                        else{Toast(e.msg)}
                    } else {
                        Toast({
                        message: '发送成功',
                    });
                        this.codeIntervalTime--;//60秒倒计时
                        this.update = setInterval(() => {
                            this.codeIntervalTime--
                        }, 1000);
                       this.payData.phoneCode = e.data  // 获取到的验证码
                    }
            })
        },
        goback() {
            this.$router.go(-1);
        },
        reImg() {
            this.imgcodeurl = Api.getVerifyCode();
        },
        
    },
    watch: {
        codeIntervalTime(val) {
            if (!val) {
                this.codeIntervalTime = 60;
                clearInterval(this.update)
            }
        },
    },
}
</script>

<style scoped>
.tab {
    width: 100%;
    font-size: 0.24rem;
    margin-top: 0.3rem;
}

.tab li {
    flex-grow: 1;
    height: 0.54rem;
    line-height: 0.54rem;
    text-align: center;
    border: 1px solid #f4f4f4;
}

.active {
    background: #f54203;
    color: #fff;
}

.prompt {
    font-size: 0.18rem;
    color: #f54203;
    margin-top: 0.05rem;
}

.sendcode {
    font-size: 0.24rem;
    color: #5a5a5a;
    margin-right: 0.2rem;
}

.error {
    color: red;
    font-size: 0.14rem;
}
</style>
