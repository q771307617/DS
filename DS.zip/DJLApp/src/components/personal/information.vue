<template>
    <div class="title">
        <djlheader title="个人信息">
            <router-link :to="{name:'personal'}" slot="headleft">
                <mt-button icon="back" style="color: #fff;"></mt-button>
            </router-link>
            <router-link to="/" slot="headright">
            </router-link>
        </djlheader>

        <mt-cell title="手机号码" :value="userInfo.phone"></mt-cell>
        <mt-cell title="昵称" is-link :value="userInfo.nickname" @click.native="openPromptname">
        </mt-cell>
        <mt-cell title="QQ号" is-link :value="userInfo.qq" @click.native="openPromptqq">
        </mt-cell>

    </div>
</template>

<script scoped>
import djlheader from '@/components/index/Header'
import { mapState, mapActions } from 'vuex'
import { MessageBox } from 'mint-ui';
import { Toast } from 'mint-ui';
export default {
    components: { djlheader },
    data() {
        return {
        }
    },
    computed: {
        ...mapState({
            userInfo: state => state.User.userInfo,
        })
    },
    mounted() {
        this.getUserData();
    },
    methods: {
        ...mapActions([
            'getUserData'
        ]),
        openPromptname() {
            MessageBox.confirm(' ', '请输入新的昵称',{inputValue: this.userInfo.nickname,closeOnClickModal:false,showInput:true}).then(({ value }) => {
                if(value.length >10){
                  alert('昵称太长，请不要超过10个字符')
                  return ;
                }
                this.$ajax.postRoot('user/update/nickname', {
                    nickname: value,
                }).then((e) => {
                    if (e.status == 200) {
                        Toast({
                            message: '更新成功',
                            duration: 2000
                        });
                        this.getUserData();
                    } else {
                        Toast({
                            message: '编辑失败:）',
                            duration: 2000
                        });
                    }
                })
            });
        },
        openPromptqq() {
            MessageBox.confirm(' ', '请输入新的QQ', {inputValue: this.userInfo.qq,closeOnClickModal:false,inputType:'number',showInput:true}).then(({ value }) => {
                this.$ajax.postRoot('user/update/qq', {
                    qq: value,
                }).then((e) => {
                    if (e.status == 200) {
                        Toast({
                            message: '更新成功',
                            duration: 2000
                        });
                        this.getUserData();
                    } else {
                        Toast({
                            message: '编辑失败:）',
                            duration: 2000
                        });
                    }
                })
            });
        }
    }
}
</script>

<style>
.title {
    height: 0.75rem;
}

.title .mint-header {
    height: 0.75rem;
}

.title .mint-header .mint-header-title {
    font-size: 0.35rem;
}

.title .mintui {
    font-size: 0.35rem;
}
</style>
