<template>
  <div>
    <netraffic v-if="isShow" src="http://tajs.qq.com/stats?sId=63353741"></netraffic>
    <netraffic v-if="isShow" src="https://hm.baidu.com/hm.js?27a52ece913b7a181e7e8267a6de1d61"></netraffic>
  </div>
</template>
<script>
  export default{
    data(){
        return {
            isShow:false
        }
    },
    mounted() {
      if(location.host.indexOf('dianjiangla') >-1){
          this.isShow = true;
      }
    },
    components: {
      'netraffic': {
        render(createElement) {
          return createElement('script', { attrs: { type: 'text/javascript', src: this.src }});
        },
        props: {
          src: { type: String, required: true },
        },
      },
    }
  }
</script>

<style scoped>

</style>
