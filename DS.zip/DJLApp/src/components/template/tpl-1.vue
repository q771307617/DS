<template>
  <div id="app">
    <router-view></router-view>
    <djltabbar></djltabbar>
    <div style="height: 0.95rem;"></div>
  </div>
</template>

<script>
import djltabbar from '@/components/index/Tabbar'

export default {
  name: 'app',
  components: {
        djltabbar
  },
}
</script>
