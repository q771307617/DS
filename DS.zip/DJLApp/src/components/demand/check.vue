<template>
  <div>
    <djlheader :title="'待验收需求'">
            <span @click="routerBack" slot="headleft">
                <mt-button icon="back"></mt-button>
            </span>
    </djlheader>
    <div class="tab">
      <p>订单编号：{{info.order_id}}</p>
      <ul>
        <li>
          <p>需求名称</p>
          <div>{{info.title}}</div>
        </li>
        <li>
          <p>薪资预算</p>
          <div>{{info.budget}}元</div>
        </li>
        <li>
          <p>设计师</p>
          <div>{{info.designer_nickname}}</div>
        </li>
        <li>
          <p>联系方式</p>
          <div>{{info.designer_phone}}</div>
        </li>
        <li>
          <p>预计完成时间</p>
          <div>{{info.plan_complete_date}}</div>
        </li>
        <li>
          <p>实际交付时间</p>
          <div>{{info.deliver_date}}</div>
        </li>
        <li>
          <p>选择验收结果</p>
          <div v-if="info.accept_status != 1" class="radiogroup box space-between">
            <span @click="setAccept(1)">
             <input name="accept" type="radio" value="1" v-model="params.accept">通过
            </span>
            <span @click="setAccept(-1)">
             <input name="accept" type="radio" value="-1" v-model="params.accept">不通过
            </span>
          </div>
          <div v-else>{{typelist[info.accept_status]}}</div>
        </li>
        <li v-if="info.accept_status != 1">
          <textarea v-model="params.view" style="width: 100%;color: #5a5a5a;" rows="5"
                    placeholder="备注：请输入验收意见"></textarea>
          <div></div>
        </li>
        <li v-else>
          <p>备注</p>
          <div>{{info.accept_view}}</div>
        </li>
      </ul>
    </div>
    <a v-if="info.accept_status != 1 " @click="editAccept()" class="big-btn">确认验收</a>
  </div>
</template>

<script>
  import djlheader from '@/components/index/Header'
  import moment from "moment";
  import {Toast} from 'mint-ui';

  export default {
    data() {
      return {
        id: '',
        params: {
          id: '',
          accept: 1,//验收状态(待处理=0 通过=1 不通过=-1)
          view: '',//验收描述
        },
        typelist: {'0': '待处理', '1': '通过', '-1': '不通过'},
        info: {},
      }
    },
    mounted(){
      this.id = this.$route.query.id;
      this.getInfo();
    },
    components: {djlheader},
    methods: {
      setAccept(type){
        this.params.accept = type;
      },
      editAccept(){
        if (!this.params.view) {
          Toast('请填写备注，验收意见')
          return;
        }

        let params = {
          ...this.params
        }

        this.$ajax.post('demand/accept', params).then((e) => {
          if (e.status != 200) {
            Toast(e.msg)
            return;
          }

          Toast(e.msg)
          this.routerBack()
        })
      },
      getInfo(){
        this.$ajax.get('demand/get', {id: this.id}).then((e) => {
          if (e.status != 200) {
            return;
          }
          e.data.plan_complete_date = moment(e.data.plan_complete_date).format("YYYY-MM-DD")
          e.data.deliver_date = moment(e.data.deliver_date).format("YYYY-MM-DD")
          this.info = e.data;
          this.params.id = e.data.id;
          this.params.accept = e.data.accept_status || 1;
          this.params.view = e.data.accept_view;

        })
      },
      routerBack(){
        this.$router.go(-1);
      }
    }
  }
</script>
<style scoped>
  .tab {
    font-size: 0.22rem;
    padding: 0.25rem;
    color: #5a5a5a;
  }

  .tab ul li {
    display: flex;
    justify-content: space-between;
    border: 1px solid #e4e4e4;
    margin-top: 0.25rem;
  }

  .tab ul li p {
    width: 1.83rem;
    height: 0.74rem;
    line-height: 0.74rem;
    text-align: center;
    background-color: #f7f7f7;
    border-right: 1px solid #e4e4e4;
  }

  .tab ul li div {
    flex: 1;
    text-align: center;
    line-height: 0.74rem;
  }

  .radiogroup span {
    flex: 1
  }
</style>
