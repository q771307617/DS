<template>
  <div>
    <djlheader :title="'工作中需求'">
            <span @click="routerBack" slot="headleft">
                <mt-button icon="back"></mt-button>
            </span>
    </djlheader>
    <div class="tab">
      <p>订单编号：{{info.order_id}}</p>
      <ul>
        <li>
          <p>需求名称</p>
          <div>{{info.title}}</div>
        </li>
        <li>
          <p>薪资预算</p>
          <div>{{info.budget}}元</div>
        </li>
        <li>
          <p>设计师</p>
          <div>{{info.designer_nickname}}</div>
        </li>
        <li>
          <p>联系方式</p>
          <div>{{info.designer_phone}}</div>
        </li>
        <li>
          <p>预计完成时间</p>
          <div>{{info.plan_complete_date}}</div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
  import djlheader from '@/components/index/Header'
  import {Field} from 'mint-ui';
  import moment from "moment";

  export default {
    data() {
      return {
        id:'',
        info:{},
      }
    },
    mounted(){
      this.id = this.$route.query.id;
      this.getInfo();
    },
    components: {djlheader, Field},
    methods: {
      getInfo(){
        this.$ajax.getRoot('demand/get',{id:this.id}).then((e)=>{
          if(e.status != 200){
            return ;
          }
          e.data.plan_complete_date = moment(e.data.plan_complete_date).format("YYYY-MM-DD")
          this.info = e.data;
        })
      },
      routerBack(){
        this.$router.go(-1);
      }
    }
  }
</script>
<style scoped>
  .tab{
    font-size: 0.22rem;
    padding: 0.25rem;
    color: #5a5a5a;
  }
  .tab ul li{
    display: flex;
    justify-content: space-between;
    border: 1px solid #e4e4e4;
    margin-top: 0.25rem;
  }
  .tab ul li p{
    width: 1.83rem;
    height: 0.74rem;
    line-height: 0.74rem;
    text-align: center;
    background-color: #f7f7f7;
    border-right: 1px solid #e4e4e4;
  }
  .tab ul li div{
    flex:1;
    text-align: center;
    line-height: 0.74rem;
  }

</style>
