<template>
    <div>
        <djlheader :title="'待审核需求'">
            <span @click="goback" slot="headleft">
                <mt-button icon="back"></mt-button>
            </span>
        </djlheader>
        <div class="demand-inputItem">
            <div class="red">
                <p>需求名称</p>
                <span>{{info.demandName}}</span>
            </div>
            <div class="red">
                <p style="color: red;">点击薪资预算</p>
                <input type="number" :placeholder="info.placeholder+'元'" v-model="info.budget">
            </div>
            <div class="red">
                <p>联系方式</p>
                <span>{{info.contact}}</span>
            </div>
            <mt-button size="large" @click="publish" class="demand-btn">确认</mt-button>
        </div>
    </div>
</template>
<script>
import djlheader from '@/components/index/Header'
import { Button, Field, Toast } from 'mint-ui';

export default {
    data() {
        return {
            id: '',
            info: {
                demandName: '',
                budget: '',
                contact: '',
                placeholder: ''
            },
        }
    },
    components: { djlheader, Field, "mt-button": Button },
    mounted() {
        this.getinfo()
    },
    methods: {
        goback() {
            this.$router.go(-1);
        },
        getinfo() {
            this.$ajax.get('demand/get', {
                id: this.$route.query.id
            }).then((e) => {
                if (e.status != 200) {
                    return
                }
                this.info.demandName = e.data.title
                this.info.contact = e.data.employer_phone
                this.info.placeholder = e.data.budget
            })
        },
        publish() {
            if (this.info.budget < 0) {
                Toast({ message: '请输入大于0的金额', duration: 2000 });
            } else {
                this.$ajax.post('demand/budget', {
                    budget: this.info.budget,
                    id: this.$route.query.id
                }).then((e) => {
                    if (e.status != 200) {
                        return
                    }
                    Toast({ message: '保证金修改成功！！' });
                    this.$router.push({ name: 'demand' });
                })
            }
        }
    }
}
</script>
<style scoped>
.red {
    display: flex;
    font-size: 0.24rem;
    height: 0.73rem;
    border: 1px solid #e4e4e4;
    margin-top: 0.25rem;
    min-height: initial;
}

.red p {
    width: 1.83rem;
    height: 0.74rem;
    line-height: 0.74rem;
    text-align: center;
    background-color: #f7f7f7;
    border-right: 1px solid #e4e4e4;
}

.red input {
    margin-left: 0.22rem;
    border: 0px solid #e4e4e4;
}

.red span {
    flex: 1;
    margin-left: 0.22rem;
    line-height: 0.74rem;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
}
</style>

