// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import Api from './api'
import router from './router'
import Mint from 'mint-ui'
import 'mint-ui/lib/style.css'
import axios from 'axios'
import store from './store'
import Filter from '@/filter'
import { MessageBox } from 'mint-ui'
import netraffic from '@/components/public/netraffic'

Vue.use(Mint);
Vue.prototype.$ajax = Api;

Vue.config.productionTip = false

let goLogin = ()=>{
  MessageBox('提示','您还没有登录，请先登录');
  router.push({name: 'login'})
}
// 添加一个请求拦截器
axios.interceptors.request.use(function (config) {
    // Do something before request is sent
    // console.log(config);
    return config;
  }, function (error) {
    // Do something with request error
    return Promise.reject(error);
  });

  // 添加一个响应拦截器
axios.interceptors.response.use(function (res) {
    // console.log(res);

    if(res.data && res.data.status == "401"){
      goLogin();
    }
    if(res && res.data && res.data.status != "200"){
      res.data.data = {

      };
    }
    return res;
  }, function (error) {
    // Do something with response error
    return Promise.reject(error);
  });
Vue.component('netraffic', netraffic)
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App }
})
