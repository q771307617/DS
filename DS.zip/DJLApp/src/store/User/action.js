import Vue from 'vue'
import Api from '@/api/index'


export default {
    outLogin({ commit }) {
        //退出登录
        Api.postRoot('auth/logout', {}).then(e => {
            if (e.status !== 200) return;
        })
        commit("setUserData", {});
        commit("setLoginState", false);
    },
    getUserData({ commit }) {
        //获取用户信息
        Api.getRoot('user/info', {}).then(e => {
            if (e.status !== 200) return;
            commit("setUserData", e.data);
            commit("setLoginState", true);
        })
    },
    getLoginState({ commit, dispatch }) {
        // 判断是或否登录
        Api.getRoot('auth/login/status', { timestamp: Date.now() }).then(e => {
            if (e.status != 200) {
                commit("setUserData", {});
                commit("setLoginState", false);
                return;
            }
            dispatch('getUserData');
        });
    }
}