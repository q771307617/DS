export default {
  setUserData(state, info){
    state.userInfo = info;
  },
  setLoginState(state,value){
    state.isLogin = value;
  }
}
