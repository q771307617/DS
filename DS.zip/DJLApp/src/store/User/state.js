export default {
  isLogin: false,
  userInfo: [],
}
