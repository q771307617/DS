export default {
    defaultSrc: 'http://3.img.dianjiangla.com/assets/icon/loading.png',
    ftpPath: "http://2.img.dianjiangla.com/assets/app",
    classlist: [],
    qylist: [],
    jylist: [{ id: 1, name: '1年以内' }, { id: 2, name: '1-3年' }, { id: 3, name: '3-5年' }, { id: 4, name: '5年以上' }],
    genderlist: [{ id: 0, name: '帅哥' }, { id: 1, name: '美女' }],
    expEndList: ["", "1", "3", "5", "100"],
    expStartList: ["", "0", "1", "3", "5"],
    rank:[{ value: 1, name: '助理',id:'ASSISTANT' }, { value: 2, name: '初级',id:'PRIMARY' }, { value: 3, name: '中级',id:'MIDDLE' },{ value: 4, name: '高级',id:'HIGH' }, { value: 5, name: '专家',id:'EXPERT' }],//级别
    cla2: [],//二级分类，行业列表
}
