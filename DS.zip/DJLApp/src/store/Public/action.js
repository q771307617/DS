import Vue from 'vue'
import Api from '@/api/index'

export default {
    getHY({ commit }){
        Api.getRoot('class/child').then((e)=>{
            if(e.status != 200){return;}
            commit('getClasslist',e.data);
        })
    },
    getQY({ commit }){
        Api.getRoot('type/list').then((e)=>{
            if(e.status != 200){return;}
            commit('getQylist',e.data);
        })
    },
    getCal2({ commit }) {
        // 目前只有 pid == 4的时候可以获取到
        Api.getRoot('class/child', { pid: 4 }).then(e => {
            if (e.status != 200) return;
            commit("setCla2", e.data);
        });
    }
}
