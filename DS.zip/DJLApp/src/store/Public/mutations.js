export default {
    setTitle(state, value) {
        state.title = value;
    },
    getClasslist(state, value){
        state.classlist = value;
    },
    getQylist(state, value){
        state.qylist = value;
    },
    setCla2(state, data) {
        state.cla2 = data;
    },
}
