import Vue from 'vue'
import Vuex from 'vuex'
import User from './User'
import Public from './Public'

Vue.use(Vuex);

let Store = new Vuex.Store({
    modules: {
        User,
        Public,
    }
})
export default Store
