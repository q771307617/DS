import Vue from 'vue'
import axios from 'axios'
import qs from 'qs'

axios.defaults.baseURL = '/api';
axios.defaults.timeout = 10000;

let path = (process.env.NODE_ENV === "development")
    ?"/api/"
    :"/api/";

let getVerifyCode = ()=>{
    return path+"/auth/verifycode"+"?time="+ new Date().getTime();
}

let isWX=()=>{
  var ua = navigator.userAgent.toLowerCase();
  return ua.indexOf('micromessenger') != -1
}

let h5PayAli=(orderId)=>{
  location.href=path+'/pay/ali/wap?id='+orderId;
}
let toWXAuth=(url)=>{
    // location.href=path+'/oauth/wx/?return_url='+url
    location.replace(path+'/oauth/wx/?return_url='+url)
    //http://172.30.34.95:6023/api/auth/login/status
}
let h5PayWX=(orderId)=>{
  location.href=path+'/pay/wx/wap?id='+orderId;
}

let payMoney = (orderNo) => {
 window.open(path + 'finance/deposit?orderNo=' + orderNo);
};
export default {
    getVerifyCode,
    isWX,
    payMoney,
    h5PayAli,
    h5PayWX,
    toWXAuth,
    getRoot:(urlName='',params={})=>{
        return axios.get(urlName,{ params: params }).then((res)=>{
            return res.data;
        })
    },
    postRoot:(urlName='',params={})=>{
      return axios.post(urlName,qs.stringify(params)).then((res)=>{
        return res.data;
      })
    },
    get:(urlName='',params={})=>{
        return axios.get('/app/'+ urlName,{ params: params }).then((res)=>{
            return res.data;
        })
    },
    post:(urlName='',params={})=>{
        return axios.post('/app/'+ urlName,qs.stringify(params)).then((res)=>{
            return res.data;
        })
    }
}
