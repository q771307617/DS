// 设置sessionstorage缓存信息
const setItem = (key, data) => {
  if (!key || !data) return;
  sessionStorage.setItem(key, data)
}

// 获取sessionstorage缓存信息
const getItem = (key) => {
  if (!key) return;
  let data = sessionStorage.getItem(key);
  if (!data) return;
  return JSON.parse(data);
}

//移除sessionstorage缓存信息
const removeItem = (key) => {
  if (!key) return;
  sessionStorage.removeItem(key);
}
