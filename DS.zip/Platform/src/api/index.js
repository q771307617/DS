import Vue from 'vue';
// 通过process.env.NODE_ENV配置开发还是线上环境
// console.log(process.env.NODE_ENV);

let path = (process.env.NODE_ENV === "development")
    ? "/api/"
    : "/api/";
let pathUpload = "/api/upload";


let getApiUrl = (apiName) => {
    return path + apiName
};

export default {
    pathUpload: pathUpload,
    //接口名字和接口参数 测试可行
    get: (apiName = "", params = {}) => {
        let apiUrl = getApiUrl(apiName);
        return Vue.http.get(apiUrl, { params: params }).then((e) => {
            return e.data;
        });
    },
    post: (apiName = "", body = {}) => {
        let apiUrl = getApiUrl(apiName);
        // console.log(apiUrl)
        return Vue.http.post(apiUrl, body).then((e) => {
            return e.data;
        });
    }
};
