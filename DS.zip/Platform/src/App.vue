<style scoped>
  .layout {
    border: 1px solid #d7dde4;
    background: #f0eef1 url(./assets/images/bjTop.png) no-repeat center;
    position: fixed;
    top: 0;
    width: 100%;
    height:80px;
    line-height:60px;
    padding:0 30px 0 10px;
    font-size: 14px;
    border-radius: 4px;
    z-index: 1000;
    overflow: hidden;
  }

  .layout-breadcrumb {
    padding: 10px 15px 0;
  }

  .layout-content {
    min-height: 200px;
    margin: 15px;
    overflow: hidden;
    background: #fff;
    border-radius: 4px;
  }

  .layout-content-main {
    padding: 10px;
    min-height: 700px;
  }

  .layout-copy {
    text-align: center;
    padding: 10px 0 20px;
    color: #9ea7b4;
  }

  .layout-menu-left {
    background: #464c5b;
  }

  .layout-header {
    height: 80px;
    background: #fff;
    box-shadow: 0 1px 1px rgba(0, 0, 0, .1);
  }

  .layout-logo-left {
    width: 90%;
    height: 30px;
    background: #5b6270;
    border-radius: 3px;
    margin: 15px auto;
  }

  .layout-3-main a {
    color: #9ba7b5;
  }

  .layout-hide-text .layout-text {
    display: none;
  }

  .ivu-col {
    transition: width .2s ease-in-out;
  }

  .layout-top {
    padding: 10px 0;
    height:60px;
    overflow: hidden;
  }

  .layout-top-main {
    float: right;
    margin-right: 15px;
  }

  .layout-top-main a {
    color: #fff;
  }

  .layout-top-main-left {
    color: #fff;
    float: left;
    margin-left: 15px;
    line-height:60px;
  }

  .cfff {
    color: #fff;
  }

  .ivu-menu-item-active a {
    color: #2d8cf0
  }
  .username{
    color: #ffc948;
  }
  img{
    display: inline-block;
    margin-bottom:-4px;
  }
</style>
<style>
html,body{
  position: relative;
  top:0;
  width:100%;
  height:100%; 
}
#app{
    width:100%;
    height:100%;
}
.formDiy .ivu-form .ivu-form-item-label{
  font-size: 14px!important;
}
.ivu-btn-info,.ivu-btn-info:hover,.ivu-btn-primary,.ivu-btn-primary:hover,.ivu-page-item-active,.ivu-switch-checked{
  background:#FF8463!important;
  border-color: #FF8463!important;
}
.ivu-page-item:hover{
  border-color: #FF8463!important;
  color:#FF8463!important;
}
.ivu-table,.ivu-table-wrapper,.tableDiy{
  background: #FFFFFF;
  border-radius:3px;
  box-shadow: 0 4px 6px 0 rgba(48,48,77,0.05), 0 2px 4px 0 rgba(48,48,77,0.05);
}
.rapidScreening{
  height:auto;
  background: #FFFFFF;
  border: 1px solid #E0E0E0;
  box-shadow: 0 4px 6px 0 rgba(48,48,77,0.05), 0 2px 4px 0 rgba(48,48,77,0.05);
  border-radius: 10px;
  padding:20px;
  margin:30px 0;
}
.rapidScreenings{
  margin:0 0 30px;
  border-radius: 0 10px 10px;
}
.radioGroup .ivu-radio-group-button .ivu-radio-wrapper-checked{
  border:1px solid #FF8463!important;
  box-shadow: -1px 0 0 0 #FF8463!important;
  color:#FF8463!important;
}
.ivu-tabs.ivu-tabs-card>.ivu-tabs-bar .ivu-tabs-tab:hover{
  color:#FF8463!important;
}
.radioGroup .ivu-radio-group-button .ivu-radio-wrapper:first-child, .radioGroup .ivu-radio-group-button .ivu-radio-wrapper:last-child{
  border-radius:0!important;
}
.radioGroup .ivu-radio-group-button.ivu-radio-group-large .ivu-radio-wrapper{
  height: 38px!important;
  line-height: 38px!important;
}
.radioGroupDiy .ivu-radio-group-button.ivu-radio-group-large .ivu-radio-wrapper{
  margin: 0 6px -1px 0!important;
  border-bottom:none!important;;
  padding: 0 26px!important;
  height: 58px!important;
  line-height: 58px!important;
  font-size: 16px!important;
  margin-bottom:-1px!important;
}
.radioGroupDiy .ivu-radio-group-button .ivu-radio-group-item{
  background:#f8f8f9!important;
}
.radioGroupDiy .ivu-radio-group-button .ivu-radio-wrapper-checked{
  background:#FFF!important;
  border:1px solid #dddee1!important;
  /* border-bottom:none!important; */
  box-shadow: 0 0 0 0 #fff!important;
}
.radioGroupDiy .ivu-radio-group-button.ivu-radio-group-large .ivu-radio-wrapper:hover,.radioGroup .ivu-radio-group-button.ivu-radio-group-large .ivu-radio-wrapper:hover{
  color:#FF8463!important;
}
.ivu-tabs-bar, .ivu-tabs-nav-container{
  margin-bottom: 0px!important;
  height: 58px!important;
  line-height: 28px!important;
  font-size: 16px!important;
  margin-bottom:-1px!important;
}
.ivu-tabs.ivu-tabs-card>.ivu-tabs-bar .ivu-tabs-tab{
  height: 58px!important;
  padding: 15px 26px 14px!important;
  border-radius: 0!important;
  z-index: 999!important;
}
.ivu-tabs-nav .ivu-tabs-tab-active{
  color:#FF8463!important;
}
  .font20 {
    font-size: 20px;
  }

  .font22 {
    font-size: 22px;
  }

  .font24 {
    font-size: 24px;
  }

  .float-right {
    float: right;
  }

  .float-left {
    float: left;
  }

  .clearfix:after {
    content: ".";
    display: block;
    height: 0;
    clear: both;
    visibility: hidden
  }
  .clearfix {
    *+height: 1%;
  }
</style>
<template>
  <div id="app" style="height: 100%;">
    <div class="layout" v-if="$router.app._route.name != 'login'">
      <div class="layout-top">
        <div v-if="!userInfo.id">
          <div class="layout-top-main">
            <a @click="loginBtn">登录</a> |
          </div>
        </div>
        <div class="clearfix" v-else>
          <div class="layout-top-main-left">
            <img src="./assets/images/person.png"></img>　<span>欢迎 <span class="username">{{ userInfo.nickname || userInfo.username }}</span> {{userInfo.type == 4 ? '管理员' : '设计师'}}登录</span> 
          </div>
          <div class="layout-top-main">
            <a @click="logoutBtn">登出 <img src="./assets/images/exit.png"></img></a>
          </div>
        </div>
      </div>
    </div>
    <div style="padding-top:80px;width:100%;height:100%;">
    <router-view></router-view></div>
  </div>
</template>
<script>

import { mapState, mapActions } from 'vuex'
export default {
  data() {
    return {}
  },
  computed: {
    ...mapState({
      userInfo: state => state.User.info,
    }),
  },
  mounted() {
    console.log(this.$router.app._route.name);
  },
  methods: {
    ...mapActions(['OUT_LOGIN']),
    loginBtn() {
      this.$router.push({ name: 'login' })
    },
    logoutBtn() {
      this.OUT_LOGIN();
      this.$router.push({ name: 'login' })
    }
  },

}
</script>
