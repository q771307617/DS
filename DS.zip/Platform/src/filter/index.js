import Vue from 'vue';
import moment from "moment";
//获取雇佣类型、工作状态、公用状态
const getStatusValue = (complete_status, audit_status, budget_status, accept_status) => {
  if (audit_status == 0) {
    return "待分配"
  }
  if (budget_status == 0) {
    return "未支付";
  }
  if (complete_status == 0) {
    return "工作中";
  }
  if (accept_status == 0 || accept_status === -1) {
    return "已交付";
  }
  if (accept_status == 1) {
    return "已完成";
  } else {
    return "已取消";
  }
}
const auditStatus = ['待审核', '已审核', '未通过'];
const getAuditStatusValue = (v) => {
  return v == null ? '--' : auditStatus[v];
}
const gyType = ['包月雇佣', '定制雇佣'];
const getEmployTypeValue = (v) => {
  return v == null ? '--' : gyType[v];
}

const getTimeStampStr = (v, f) => {
  return v && moment(v).format(f || 'YYYY-MM-DD HH:mm') || '';
}

const getPayStatusValue = (v) => {
  if (v == 1) {
    return "已支付";
  } else if (v == 0) {
    return "未支付";
  } else if (v == 2) {
    return "工作中";
  } else if (v == 3) {
    return '已完成';
  } else if (v == -1) {
    return '已取消';
  } else {
    return '--';
  }
}


const toName = (ids, arr) => {
  let a = [];
  ids = String(ids) && String(ids).split(',') || [];
  for (let i = 0, length = arr.length; i < length; i++) {
    for (let j = 0, l = ids.length; j < l; j++) {
      if (ids[j] == arr[i].id) {
        a.push(arr[i].name)
      }
    }
  }
  return a.join();
}

const getgydzType = (v) => {
  if (v == 0) {
    return '待验收';
  }
  if (v == 1) {
    return '通过';
  }
  if (v == -1) {
    return '不通过';
  }
  return '';
}

Vue.filter('getStatusValue', getStatusValue);
Vue.filter('getAuditStatusValue', getAuditStatusValue);
Vue.filter('getEmployTypeValue', getEmployTypeValue);
Vue.filter('getTimeStampStr', getTimeStampStr);
Vue.filter('getPayStatusValue', getPayStatusValue);
Vue.filter('getgydzType', getgydzType);
Vue.filter('toName', toName);

/* 当前的,以后按照这种风格来 */
// const TYPE_LIST_FILTER = (v,arr)=>{
//     console.error(v,arr,"TYPE_LIST_FILTER");
//     return "xxxx";
// };
// Vue.filter("TYPE_LIST_FILTER",TYPE_LIST_FILTER);




/*
          * 获得时间差,时间格式为 年-月-日 小时:分钟:秒 或者 年/月/日 小时：分钟：秒
          * 其中，年月日为全格式，例如 ： 2010-10-12 01:00:00
          * 返回精度为：秒，分，小时，天
          */
const getDateDiff = (startTime, endTime, diffType) => {
  //将xxxx-xx-xx的时间格式，转换为 xxxx/xx/xx的格式
  startTime = startTime.replace(/-/g, "/");
  endTime = endTime.replace(/-/g, "/");
  //将计算间隔类性字符转换为小写
  diffType = diffType.toLowerCase();
  var sTime = new Date(startTime); //开始时间
  var eTime = new Date(endTime); //结束时间

  var _total = eTime.getTime() - sTime.getTime(); //total
  var _second = parseInt(1000); //second
  var _minute = parseInt(1000 * 60); //minute
  var _hour = parseInt(1000 * 3600); //hour
  var _day = parseInt(1000 * 3600 * 24); //day
  var _month = parseInt(1000 * 3600 * 24 * 30); //month

  var day = parseInt(_total / _day) || 0; //天
  var hour = parseInt((_total - day * _day) / _hour) || 0; //时
  var minute =
    parseInt((_total - day * _day - hour * _hour) / _minute) || 0; //分
  var second =
    parseInt(
      (_total - day * _day - hour * _hour - minute * _minute) / _second
    ) || 0; //秒

  //作为除数的数字
  var divNum = 1;
  switch (diffType) {
    case "dhm":
      let value = '还有';
      if (eTime.getTime() - sTime.getTime() > 0) {
      } else {
        value = "已超时";
      }
      return value + Math.abs(day) + " 天 " + Math.abs(hour) + " 时 " + Math.abs(minute) + " 分 ";
      break;
    case "second":
      divNum = _second;
      break;
    case "minute":
      divNum = _minute;
      break;
    case "hour":
      divNum = _hour;
      break;
    case "day":
      divNum = _day;
      break;
    case "month":
      divNum = _month;
      break;
    default:
      break;
  }
  return (
    parseInt((eTime.getTime() - sTime.getTime()) / parseInt(divNum)) || 0
  );
};
// 获取服务器图片
const randomPath = (name, size = '') => {
  const n = Math.floor(Math.random() * 5) + 1;
  return `http://${n}.img.dianjiangla.com/assets/${name}${size}`;
};
Vue.filter("getDateDiff", getDateDiff);
Vue.filter('randomPath', randomPath);

