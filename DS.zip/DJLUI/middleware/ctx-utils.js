var qsTmp = require('querystring');
var rpTmp = require('request-promise');
var tough = require('tough-cookie');
var path2 = require('path');
const fn = require(path2.join(path2.resolve('.'), '/utils/fn.js'));
var axios = require('axios');
axios.defaults.withCredentials = true;
var instance = axios.create({
    transformRequest: [function (data) {
        data = qsTmp.stringify(data);
        return data;
    }],
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
})

/**
 * 请求http，保留指定cookie，如（名为SESSION的cookie）
 * @param {*} j 
 * @param {*} resultType 远程内容返回类型 0：json 1：默认
 */
function rp2Tmp(ctx) {
    return async function (path, param = null, initData = null, resultType = 0) {
        var url = fn.getApiPath(path);
        var config = {
            url,
            responseType: 'json',
            headers: {
                'Cookie': ctx.request.header['cookie'] || ''
            }
        };
        if (param) {
            config.params = param
        }
        if (initData) {
            config.method = initData.method;
            config.data = initData.form;
        }
        if (resultType != 0) {
            config.responseType = 'arraybuffer';
        }
        let result = await instance.request(config);
        setCookie(ctx, result.headers['set-cookie'])
        return result.data;
    }
}

function setCookie(ctx, cookie) {
    if (cookie) {
        cookie.forEach(function (c) {
            var cc = c.split(';')[0];
            var arr = cc.split('=');
            ctx.cookies.set(arr[0], arr[1]);
        })
    }
}

var ctxutils = function () {
    return async (ctx, next) => {
        // console.log('-----------------------------------------------------------------------------ctxutils');
        ctx.qs = qsTmp; //a=1&b=2 与 json 相互转化
        ctx.rp = rpTmp; //request-promise
        ctx.rp2 = rp2Tmp(ctx); //对request-promise封装，并自动处理登录信息
        ctx.getLoginStatus = fn.islogin(ctx); //判断用户是否登录
        ctx.staticData = fn.staticData;
        ctx.iget = ctx.query;
        ctx.ipost = ctx.request.body;
        ctx.setNoCache = fn.setNoCache(ctx);
        ctx.pageHtml = fn.pageHtml;
        await next();
    };
}

module.exports = ctxutils;