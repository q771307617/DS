const nunjucks = require('nunjucks');
const path2 = require('path');
const fn = require(path2.join(path2.resolve('.'),'/utils/fn.js'));

function createEnv(path, opts) {
    var
        autoescape = opts.autoescape === undefined ? true : opts.autoescape,
        noCache = opts.noCache || false,
        watch = opts.watch || false,
        throwOnUndefined = opts.throwOnUndefined || false,
        env = new nunjucks.Environment(
            new nunjucks.FileSystemLoader(path || 'views', {
                noCache: noCache,
                watch: watch,
            }), {
                autoescape: autoescape,
                throwOnUndefined: throwOnUndefined
            });
    if (opts.filters) {
        for (var f in opts.filters) {
            env.addFilter(f, opts.filters[f]);
        }
    }
    return env;
}

function templating(path, opts) {
    // 创建Nunjucks的env对象:
    var env = createEnv(path, opts);

    //根据id（1，2，3）获取行业
    env.addFilter('getDesignerType', fn.getDesignerType);
    //获取设计师名，真实姓名为空时显示花名
    env.addFilter('getUserName',fn.getUserName);

    env.addGlobal('w',djconfig.website);
    env.addGlobal('cdn',fn.getRandCdn);
    env.addGlobal('staticData',fn.staticData);

    return async (ctx, next) => {
        // 给ctx绑定render函数:
        ctx.render = function (view, model) {
            // 把render后的内容赋值给response.body:
            ctx.response.body = env.render(view, Object.assign({}, ctx.state || {}, model || {}));
            // 设置Content-Type:
            ctx.response.type = 'text/html';
        };
        // 继续处理请求:
        await next();
    };
}

module.exports = templating;