
console.log('-------------------------------------------------');
console.log('-----------------load config test-----------------');
console.log('-------------------------------------------------');
global.djconfig={
    api:'http://test.djl.yumc.pw',//后端数据调用
    apiCookieDomain1:'http://test.djl.yumc.pw',
    apiCookieDomain2:'test.djl.yumc.pw',
    website:'http://test.djl.yumc.pw',//用与超链接

    apiSessionName:'SESSION',//登录标识名
    static:'pub',//静态资源目录
    cdnMAX:5,
    port:8287
}
