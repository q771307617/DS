
console.log('-------------------------------------------------');
console.log('-----------------load config dev-----------------');
console.log('-------------------------------------------------');
global.djconfig={
    // api:'http://www.dianjiangla.com',
    // apiCookieDomain1:'http://www.dianjiangla.com',
    // apiCookieDomain2:'dianjiangla.com',
    // api:'http://192.168.2.200:8282',
    // api:'http://172.30.34.114:6019',//后端数据调用

    api:'http://172.30.34.95:6021',//后端数据调用
    apiCookieDomain1:'http://172.30.34.95',
    apiCookieDomain2:'172.30.34.95',
    website:'http://172.30.34.95:6021',//用与超链接

    // api:'http://192.168.31.80:6021',//后端数据调用
    // apiCookieDomain1:'http://192.168.31.80',
    // apiCookieDomain2:'192.168.31.80',
    // website:'http://192.168.31.80:6021',//用与超链接

    // api:'http://www.dianjiangla.com',//后端数据调用
    // apiCookieDomain1:'http://www.dianjiangla.com',
    // apiCookieDomain2:'dianjiangla.com',
    // website:'http://www.dianjiangla.com',//用与超链接

    apiSessionName:'SESSION',//登录标识名
    static:'pub',//静态资源目录
    cdnMAX:5,
    port:8081

}
