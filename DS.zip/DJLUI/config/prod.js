

console.log('-------------------------------------------------');
console.log('-----------------load config prod-----------------');
console.log('-------------------------------------------------');
global.djconfig={

    api:'http://www.dianjiangla.com',//后端数据调用
    apiCookieDomain1:'http://www.dianjiangla.com',
    apiCookieDomain2:'dianjiangla.com',
    website:'http://www.dianjiangla.com',//用与超链接

    apiSessionName:'SESSION',//登录标识名
    static:'pub',//静态资源目录
    cdnMAX:5,
    port:8287

}
