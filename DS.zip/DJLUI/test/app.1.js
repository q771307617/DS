// var http = require("http");
// var fs = require('fs');
// var url = require('url');
const Koa = require('koa');
const router = require('koa-router')();
const app = new Koa();

app.use(async (ctx, next) => {
    console.log(`Process ${ctx.request.method} ${ctx.request.url}...`);

    // console.log(111);
    // ctx.response.type = 'text/html';
    // ctx.response.body = '<h1>Hello, koa2!</h1>';
    await next();
});

router.get('/hello/:name', async (ctx, next) => {
    var name = ctx.params.name;
    ctx.response.body = `<h1>Hello, ${name}!</h1>`;
});

app.use(router.routes());
app.listen(8081);


// app.use(async (ctx, next) => {
//     console.log(222);
//     ctx.response.type = 'text/html';
//     ctx.response.body = '<h1>Hello, koa2!</h1>';
//     await next();
// });

// app.use(ctx => {
//      console.log(222);
//     ctx.body = 'Hello Koa';
//     await next();
// });

// app.use(async (ctx, next) => {
//   const start = Date.now();
//   await next();
//   const ms = Date.now() - start;
//   console.log(`${ctx.method} ${ctx.url} - ${ms}ms`);
// });

// app.use((ctx, next) => {
//   const start = Date.now();
//   return next().then(() => {
//     const ms = Date.now() - start;
//     console.log(`${ctx.method} ${ctx.url} - ${ms}ms`);
//   });
// });


// http.createServer(function (request, response) {
//     var pathname = url.parse(request.url).pathname;
//     console.log('--------------------');
//     console.log(pathname);
//     console.log('--------------------');

//     fs.readFile(pathname.substr(1), function (err, data) {
//         console.log('readFile');
//       //if error occured during file read
//       //send a error response to client
//       //that web page is not found.
//       if (err) {
//          console.log(err.stack);
//          // HTTP Status: 404 : NOT FOUND
//          // Content Type: text/plain
//          response.writeHead(404, {'Content-Type': 'text/html'});
//       }else{	
//          //Page found
//          // HTTP Status: 200 : OK
//          // Content Type: text/plain
//          response.writeHead(200, {'Content-Type': 'text/html'});	
//          // write the content of the file to response body
//          response.write(data.toString());		
//       }
//       // send the response body 
//       response.end();
//    });   


// //    // HTTP Status: 200 : OK
// //    // Content Type: text/plain
// //    response.writeHead(200, {'Content-Type': 'text/plain'});
// //    // send the response body as "Hello World"
// //    //response.write('sdfdsdfdddddsfsf');
// //    response.end('test\n');
   
// }).listen(8081);
// console.log('Server running at http://127.0.0.1:8081/');