// var http = require("http");
// var fs = require('fs');
// var url = require('url');
const Koa = require('koa');//框架
const router = require('koa-router')();//路由
const bodyParser = require('koa-bodyparser');//表单解析
const app = new Koa();

app.use(async (ctx, next) => {
    console.log(`Process ${ctx.request.method} ${ctx.request.url}...`);

    // console.log(111);
    // ctx.response.type = 'text/html';
    // ctx.response.body = '<h1>Hello, koa2!</h1>';
    await next();
});

router.get('/', async (ctx, next) => {
    ctx.response.body = '<h1>Index</h1>';
});

router.get('/hello/:name', async (ctx, next) => {
    var name = ctx.params.name;
    ctx.response.body = `<h1>Hello, ${name}!</h1>`;
});



app.use(router.routes());
app.listen(8081);
