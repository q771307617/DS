var pageHtml = function (pageNum,count) {
    var args = {
        pageCount : count,
        current : pageNum
    };
    var page = ''
    if(args.current > 1){
        page = page+ '<a href="javascript:;" onclick="jumpUrl('+(args.current-1)+')" class="prevPage"></a>';
    }else{
        page = page+ '<span class="disabled prevPage"></span>';
    }

    //中间页码
    if(args.current != 1 && args.current >= 4 && args.pageCount != 4){
        page = page+ '<a href="javascript:;" onclick="jumpUrl(1)" class="tcdNumber">'+1+'</a>';
    }

    if(args.current-2 > 2 && args.current <= args.pageCount && args.pageCount > 5){
        page = page+ '<span>...</span>';
    }
    var start = args.current -2,end = args.current+2;
    if((start > 1 && args.current < 4)||args.current == 1){
        end++;
    }
    if(args.current > args.pageCount-4 && args.current >= args.pageCount){
        start--;
    }
    for (;start <= end; start++) {
        if(start <= args.pageCount && start >= 1){
            if(start != args.current){
                page = page+ '<a href="javascript:;" onclick="jumpUrl('+start+')" class="tcdNumber">'+ start +'</a>';
            }else{
                page = page+ '<span class="current">'+ start +'</span>';
            }
        }
    }
    if(args.current + 2 < args.pageCount - 1 && args.current >= 1 && args.pageCount > 5){
        page = page+ '<span>...</span>';
    }
    if(args.current < args.pageCount){
        page = page+ '<a href="javascript:;"  onclick="jumpUrl('+(args.current+1)+')" class="nextPage"></a>';
    }else{
        page = page+ '<span class="disabled nextPage"></span>';
    }
    return page
}

var loadSernav=function(){
	$("#ser-nav a").click(function(){
		$('#ser-nav a').removeClass("active");
		$(this).addClass("active");
		var action='/prolist'
		$('input[name=name]').attr('placeholder','作品名称');
		if($(this).attr('t')==1){
			var action = '/search/designer';
			$('input[name=name]').attr('placeholder','设计师名称');
		}
		
		$('#ser-form').attr('action',djc.w+action)
	});
}

var loginEvent=function(f){
	$.get('/common/islogin',function(data){
		f(data);
	})
}

var loadUserInfo=function(){
	var _this = this;
	$.get('/common/userinfo',function(d){
		if(d.status==200){
			if(!d.data) return;
			if(d.data.type != 1 && d.data.type != 2){
				_this.loginout()
			}

			djc.u=d.data;
			
			if(djc.u.nickname){
				$('#userinfo_name').html(djc.u.nickname+' ▼');
			}else{
				$('#userinfo_name').html(djc.u.username+' ▼');
			}
			if(djc.u.image_url){
				$('#userinfo_img img').attr("src",djc.u.image_url);

			}

			//登录类型 发布需求
			if(djc.u.type == 1){
				$("#demand-btn-header").show();
				$("#demand-btn-header2").show();
				$("#designer-contact-btn").show();//联系方式 按钮
				$("#connentList").show();//联系方式 模块
				$("#designerCenter").remove();//设计师中心
				$("#designerCenterTop").remove();//设计师中心
			}else if(djc.u.type == 2){
				$("#demand-btn-header").remove();
				$("#demand-btn-header2").remove();
				$("#designer-contact-btn").remove();//	联系方式 按钮
				$("#connentList").remove();// 联系方式 模块
				$("#designerCenter").show();//设计师中心
				$("#designerCenterTop").show();//设计师中心
			}
		}
	})
}

var inletJumpUrl = function(){//个人中心
	var type = djc.u.type;
	if(type == 1){
		window.location.href = "/emloyerBackstage/home";
	}else if(type == 2){
		window.location.href = "/personalCenter/manageHall";
	}
}

var setJumpUrl = function(){//设置
	var type = djc.u.type;
	if(type == 1){
		window.location.href = "/emloyerBackstage/settings/userinfo/editinfo";
	}else if(type == 2){
		window.location.href = "/personalCenter/personalCenter";
	}
}

/** 登录后显示被隐藏的信息，或隐藏被显示的信息 */
var showLogined=function(){
	loginEvent(function(d){
		if(d.status==200){

			djc.s=0;
			loadUserInfo();
			
			$('*[t=logined]').show();
			$('*[t=logout]').hide();
		}else{
			$('*[t=logined]').hide();
			$('*[t=logout]').show();
			$("#demand-btn-header").show();//发布需求
			$("#demand-btn-header2").show();//发布需求
			$("#designer-contact-btn").show();//联系方式 按钮
		}
	})
}

var loginout=function(){
	sessionStorage.setItem('USER','{}')
	$.get('/common/loginout',function(data){
		window.location.reload()
	})
}

/** 打开页面到新窗口 */
var openNewWindow=function(url){
	// console.log(url);
	$('#__djform').remove();
	$('body').append('<a href="'+url+'" id="__djform" target="_blank" style="font-size:1px"></a>')
	// if(param!=undefined){
	// 	for(var x in param){
	// 		$('#__djform').append('<input type="hidden" name="'+x+'" value="'+param[x]+'" />');
	// 	}
	// }
	document.getElementById('__djform').click();
	// $('#__djform2').click();
}

/** 登录后跳转页面 */
var loginedJump=function(nologined,logined){
	if(djc.s==1){
		openNewWindow(logined)
	}else{
		openNewWindow(nologined)
	}
}
/**顶部用户悬停 */
var userinfoNav=function(){
    var showUserinfo=function(name,t){
        if(t){
            $('ul[t='+name+'-nav]').show();
        }else{  
            $('ul[t='+name+'-nav]').hide();
        }
    }

    $('div[t2=userinfo]').on('mouseenter',function(){showUserinfo('userinfo',true)})
    $('div[t2=userinfo]').on('mouseleave',function(){showUserinfo('userinfo',false)})
}
var djslider=function(param){
	var conf={
		width:1280,
		time:400,
		intervalTime:10,
		autoWidth:false,
		autoHeight:false,
		maxHeight:600,
		claName:''
	}

	for(x in conf){
		if(param[x]!=undefined){
			conf[x]=param[x];
		}
	}

	conf.intervalTime=conf.intervalTime*1000;
	
	var claName=conf.claName

	var i,left,right,box,boxli,boxleng,width,dot,first,last,IsAuto;
	i = 0; 
	left = $(claName+' .homeleft'); 
	right = $(claName+' .homeright');
	box = $(claName+' .homeslider ul.slid');
	boxli = $(claName+' .homeslider li.slid');
	dotbox = $(claName+' .homedot');
	dot = $(claName+' .homedot').find('a');
	width = boxli.width();
	boxleng = boxli.length;
	boxli.css({width:width});
	box.css({width:width*(boxleng)})
	
	dot.eq(0).addClass("cur");
	boxli.eq(0).addClass("cur");
	
	var updateWidth=function(){
		var w = $('body').width();
		//console.log(w+' - '+conf.width + ' - '+boxli.width());
		if(w==conf.width){
			return;
		}
		conf.width=w;
		box.css({width:w*(boxleng)})
		boxli.css({width:w});
	}

	var updateHeight=function(){
		var h=boxli.height();

		if(h==box.height()){
			return;
		}

		if(h>conf.maxHeight){
			h=conf.maxHeight;
		}
		box.css({height:h})
	}
	updateWidth();
	updateHeight();
	$(function(){
		updateWidth();
		updateHeight();
	})

	$(window).resize(function() {
		if(conf.autoWidth){
			updateWidth();
		}
		if(conf.autoHeight){
			updateHeight();
		}
	});
	
	boxli.each(function(index) {
       zindex = boxleng-(index+1);
	   $(this).css({"z-index":zindex})
    });
	
	IsAuto = true;

	var curSlider='right';
	var defSlider='left';
	var isClick=false;
	
	left.click(function(){
		if(box.is(":animated")){return}
		i--;
		if(i<0){i=boxleng-1};
		curSlider='left'
		isClick=true;
		boxanimate();
	})
	
	right.click(function(){
		if(box.is(":animated")){return}
		i++;
		curSlider='right'
		isClick=true;
		boxanimate();
	})
	
	function boxanimate(){
		if(i>boxleng-1){
			i=0;
		}

		boxli.addClass("cur1");

		var f=function(){
			var t=conf.time;
			if(curSlider=='left'){
				boxli.eq(i).stop().css({left:-conf.width});//后面显示设置到右边
				boxli.stop().animate({left:conf.width},t);//当前显示移出
			}else if(curSlider=='right'){
				boxli.eq(i).stop().css({left:conf.width});//后面显示设置到左边
				boxli.stop().animate({left:-conf.width},t);//当前显示移出
				
			}
			boxli.css({'z-index':10})
			boxli.eq(i).stop().animate({left:0,"z-index":11},t)//后面显示移进

			bannerdot(i)
		}

		if(isClick){
			f();
		}else{
			setTimeout(f,400)
		}
	}

	function bannerdot(i){
		if(i>boxleng-1){i=0}
		dot.removeClass("cur").eq(i).addClass("cur");
	}

	dot.click(function(){
		var j=i;
		i = $(this).index();
		if(i==j){
			return;
		}
		if(i>j){
			curSlider='left'
		}else{
			curSlider='right'
		}

		//bannerdot(i);
		isClick=true;
		boxanimate(i);
	})
	
	setInterval(function(){
		if(IsAuto){
			i++;
			isClick=false;
			//bannerdot(i)
			boxanimate();
		}
	},conf.intervalTime)
	
	box.hover(function(){
		IsAuto = false;
	},function(){
		IsAuto = true;
	})
	
	dotbox.hover(function(){
		IsAuto = false;
	},function(){
		IsAuto = true;
	})
	
	left.hover(function(){
		IsAuto = false;
	},function(){
		IsAuto = true;
	})
	
	right.hover(function(){
		IsAuto = false;
	},function(){
		IsAuto = true;
	})
}

/** home class tab */
var tabSwitch={
  data:{},
  'load':function(nameList){
    var tabShow=function(name,t){
        if(t){
            $('ul[t=tab_'+name+']').show();
        }else{  
            $('ul[t=tab_'+name+']').hide();
        }
    }

    $.each(nameList,function(i,x){
      tabSwitch['data'][x]=''
      $('li[t='+x+']').on('mouseenter',function(){tabShow(x,true)})
      $('li[t='+x+']').on('mouseleave',function(){tabShow(x,false)})
    })

    $('#ser-tab ul[t^=tab_] li').on('click',function(){
      var key=$(this).attr('k');
      var val=$(this).attr('v');
      tabSwitch['data'][key]=val
      $($(this).parent().parent().find('a').get(0)).html($(this).html());
      tabShow(key,false)
    })

    $('#ser_tab_submit').on('click',function(){
      tabSwitch.submit();
    })
  },
  'submit':function(){
    var param=[];
    var sermap={hy:'hy',xb:'workyears',jy:'jb',xz:'salary'}
    $.each(tabSwitch.data,function(i,x){
		// param[sermap[i]]=x;
		param.push(sermap[i]+'='+x);
	})
    //console.log(param)
    // openNewWindow(djc.w+'/search/designer',param);
    openNewWindow(djc.w+'/search/designer?'+param.join('&'));
  }
}


/** 选中样式 */
var active = function (id,v) {
    $('#'+id+' *[v='+v+']').addClass('active').siblings().removeClass('active');
}

$(function(){
	$('form').attr('autocomplete','off')
	showLogined();

	/** 百度统计代码 */
    if(location.host.indexOf('dianjiangla') >-1){
        var _hmt = _hmt || [];
        (function () {
            var hm = document.createElement("script");
            hm.src = "https://hm.baidu.com/hm.js?27a52ece913b7a181e7e8267a6de1d61";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
		})();

	/**腾讯统计代码 */
		(function() {
			var s = document.createElement('script');
			s.type = 'text/javascript';
			s.async = true;
			s.src = 'http://tajs.qq.com/stats?sId=63353741';
			var x = document.getElementsByTagName('script')[0];
			x.parentNode.insertBefore(s, x);
	})();
	}

    $('#toTop').click(function(){
        $('html,body').animate({scrollTop: '0px'}, 0);
    });
})