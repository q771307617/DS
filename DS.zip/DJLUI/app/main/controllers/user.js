/** 登录页 */
var fn_login = async (ctx, next) =>  {
    vm={};
    ctx.render('user/login.html',vm)
}
/** 登录提交 */
var fn_login_post=async(ctx,next) => {
    var username = ctx.ipost.username || ''
    var password = ctx.ipost.password || ''
    var type = ctx.ipost.type || '1'

    var d=await ctx.rp2('/auth/login',null,{
        method:'POST',
        form:{
            username:username,
            password:password,
            type:type,
        }
    });
    ctx.response.body=d;
    ctx.setNoCache();
}

/** 注册页 */
var fn_register = async (ctx, next) =>  {
    vm={};
    ctx.render('user/register.html',vm)
}

/** 注册提交 */
var fn_register_post = async (ctx, next) =>  {
    var username = ctx.ipost.username || ''
    var password = ctx.ipost.password || ''
    var code = ctx.ipost.telcode || ''
    var type = ctx.ipost.type || '1'
    
    var d=await ctx.rp2('/auth/register',null,{
        method:'POST',
        form:{
            username:username,
            phone:username,
            password:password,
            code:code,
            type:type
        }
    });

    var d2=await ctx.rp2('/auth/login',null,{
        method:'POST',
        form:{
            username:username,
            password:password,
            type:type,
        }
    });

    ctx.response.body=d;
    ctx.setNoCache();
}

/** 找回密码页 */
var fn_findpassword = async (ctx, next) =>  {
    vm={};
    ctx.render('user/findpassword.html',vm)
}

/** 修改密码页 */
var fn_editpassword = async (ctx, next) =>  {
    vm={};
    vm.code = ctx.iget.code || ''
    vm.phone = ctx.iget.phone || ''
    ctx.render('user/editpassword.html',vm)
}

/** 登录提交 */
var fn_editpassword_post=async(ctx,next) => {
    var code = ctx.ipost.code || ''
    var password = ctx.ipost.password || ''
    var phone = ctx.ipost.phone || ''

    var d=await ctx.rp2('/auth/password/forget',null,{
        method:'POST',
        form:{
            code:code,
            password:password,
            phone:phone,
        }
    });
    ctx.response.body=d;
    ctx.setNoCache();
}

/** 是否注册 */
var fn_isregister = async (ctx,next) =>{
    var username=ctx.iget.username || ''
    var d = await ctx.rp2('/auth/isexist',{username:username})
    ctx.response.body=d;
    ctx.setNoCache();
}

module.exports = {
    'GET /user/login':fn_login,
    'POST /user/login_post':fn_login_post,
    'GET /user/register':fn_register,
    'POST /user/register_post':fn_register_post,
    'GET /user/isregister':fn_isregister,
    'GET /user/findpassword':fn_findpassword,
    'GET /user/editpassword':fn_editpassword,
    'POST /user/editpassword_post':fn_editpassword_post,
}