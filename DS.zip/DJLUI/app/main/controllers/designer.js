/**
 * Created by 狂龙 on 2017/7/19.
 */
/** 设计师列表 */
var fn_designer_list = async(ctx,next) => {
    var vm={};
    var rank='';
    var salaryStart='';
    var salaryEnd='';
    var expStart='';
    var expEnd='';
    var pageSize=10;

    var hy=ctx.iget.hy || '';
    var gender=ctx.iget.gender || '';
    var seq=ctx.iget.seq || '';
    var jb=ctx.iget.jb || 0;
    var salary=ctx.iget.salary || 0;
    var workyears = ctx.iget.workyears || 0;
    var pageNum=parseInt(ctx.iget.pageNum) || 1;
    var name= ctx.iget.name || '';


    var rankList = ctx.staticData.rankList;
    var salaryStartList = ctx.staticData.salaryStartList;
    var salaryEndList = ctx.staticData.salaryEndList;
    var expStartList = ctx.staticData.expStartList;
    var expEndList = ctx.staticData.expEndList;
    

    rank = rankList[jb];
    salaryStart = salaryStartList[salary];
    salaryEnd = salaryEndList[salary];
    expStart = expStartList[workyears];
    expEnd = expEndList[workyears];

    vm.hy = hy;
    vm.gender = gender;
    vm.jb = jb;
    vm.salary = salary;
    vm.workyears = workyears;
    vm.seq = seq;
    vm.isSeq = seq == 2 || seq == 3 ? true:false;
    vm.name = decodeURI(name);

    vm.cla2=await ctx.rp2('/class/child',{pid:4})//二级分类
    vm.area=await ctx.rp2('/type/list')//区域列表
    vm.dlist=await ctx.rp2('/designer/list',{
        classId:hy,
        salaryStart:salaryStart,
        salaryEnd:salaryEnd,
        expStart:expStart,
        expEnd:expEnd,
        gender:gender,
        rank:rank,
        seq:seq,
        name:name,
        pageNum:pageNum,
        pageSize:pageSize,
    })//设计师列表
    vm.pathname = encodeURIComponent(ctx.path);
    vm.dlist_count=await ctx.rp2('/designer/count');
    var d_list = vm.dlist.data.list;
    var d_list_arr = [];
    for(var i = 0, len = d_list.length; i < len; i++){
        var id = d_list[i].user_id;
        var isFav = await ctx.rp2('/fav/designer/isFav',{userId:id});
        d_list[i]._isFav = isFav;
    }
    vm.loginStatus = await ctx.getLoginStatus()//登录状态
    vm.pageCount =  Math.ceil(vm.dlist.data.count / pageSize);
    pageNum = pageNum > vm.pageCount ? vm.pageCount : pageNum < 1 ? 1: pageNum ;
    vm.pageNum = pageNum;
    vm.pageHtml =await ctx.pageHtml(pageNum,vm.pageCount);
    ctx.render('designer/dlist.html',vm);
};

/** 设计师详情 */
var fn_designer_info = async(ctx,next) => {
    var vm={};
    var id = ctx.params.id || '' ;
    var classId = ctx.iget.classesid || '';
    var isShow = ctx.iget.isShow || '';
    var fwjl = ctx.iget.fwjl || 0;
    var schoolheight = ctx.staticData.schoolheight;
    var provs = ctx.staticData.provs;

    vm.id = id;
    vm.fwjl = fwjl;
    vm.isShow = isShow;
    vm.classId = classId;
    vm.schoolheight = schoolheight;
    vm.provs = provs;
    vm.info = await ctx.rp2('/designer/get',{id:id}) || {};//设计师信息
    vm.cla2=await ctx.rp2('/class/child',{pid:4})//二级分类
    vm.loginStatus = await ctx.getLoginStatus()//登录状态
    vm.classes = await ctx.rp2('/designer/classes',{id:id})//服务记录分类
    vm.worksProduct = await ctx.rp2('/designer/work2product',{id:id,classId:classId})//服务记录，相关产品
    vm.isFav = await ctx.rp2('/fav/designer/isFav',{userId:id})//判断是否收藏了该设计师
    var list = await ctx.rp2('/designer/product',{id:id,classId:classId});//设计师所有作品
    vm.serviceRating = await ctx.rp2('/designer/appraise',{id:id, pageNum: 1,pageSize: 5})//评论记录
    var designStyle = await ctx.rp2('/demand/style/list')//设计风格
    /**  服务过的网店，字符转数组 */
    if(vm.info.status == '200' && vm.info.data != null){
        vm.info =  vm.info.data;
        vm.info.stores = vm.info.stores != null? vm.info.stores.split(',') : '';
    }
    /** 设计师风格获取数据处理 */
    function getstyle(x, data){
        let arr=[]  
        x=x.split(',')      
        for (k in data) {
            for(var i =0; i<x.length;i++){
                if(data[k].id==x[i]){
                           arr.push(data[k].name);
                       }
                     }   
                   }  
                   return arr.join(",");           
    }
    vm.info.design_style=getstyle(vm.info.design_style,designStyle.data);
 /** 所在城市获取处理 */
 function geteducation(x, data){  
    if(x&&x!=","){
       x= x.split(",");
        let city = "";
              city += data[Number(x[0])-1].label +" / " + data[Number(x[0]-1)].children[Number(x[1])-1].label ;                                                    
              return city;   
    } else{
        return '';
    }                      
}
vm.info.city=geteducation(vm.info.city,provs);
 /** 设计师学历 */ 
 function getducation(i, data){  
    if(i!=null&&i!=","){
       return  data[parseInt(i)-1].label
    }else{
          return "";
    }           
}
vm.info.education=getducation(vm.info.education,schoolheight);
    /** 获取设计师联系方式 */
    if(vm.loginStatus){
        vm.designer_contractInfo=await ctx.rp2('/designer/contractInfo',{id:id})//获取设计师联系方式
    }
    /**  服务评论 */
if (vm.serviceRating.data.list!=null) {
    var type={"DEMAND":"需求订单","HIRE_MONTH":"包月雇佣","HIRE_CUSTOM":"定制雇佣"}
    vm.serviceRating.data.list.map((x)=>{
        function getDate(tm){ 
            var tt=new Date(tm).toLocaleString(); 
            return tt; 
        } 
         x.orderType=type[x.orderType]
        //   x.createTime=getDate(x.createTime)
        //   x.username=x.username != null? x.username.replace(x.username.substr(3, 6), "***") :x.username != null ? x.realname.replace(x.realname.substr(3, 6), "***"): "未命名";
    })    
    }
    /**  服务记录，相关产品 操作 */
    if(vm.worksProduct.status == '200') {
        vm.worksProduct = vm.worksProduct.data;
        vm.worksProduct.worknum = vm.worksProduct.workList.length;
        vm.worksProduct.productCount = vm.worksProduct.productCount || vm.worksProduct.productList.length;
        if (vm.worksProduct.worknum > 20 && vm.isShow != '2') {
            var arr = [];
            for (var i = 0; i < 20; i++) {
                arr.push(vm.worksProduct.workList[i])
            }
            vm.worksProduct.workList = arr;
        }
    }
    vm.pathname = encodeURIComponent(ctx.path);
    if(isNull(vm.info.attitude)){
        vm.info.attitude = 5;
    }
    if(isNull(vm.info.ability)){
        vm.info.ability = 5;
    }
    if(isNull(vm.info.speed)){
        vm.info.speed = 5;
    }
    vm.info.pf = {
        fw: new Array(Math.round(vm.info.attitude)),
        fw2: new Array(5-Math.round(vm.info.attitude)),
        sj: new Array(Math.round(vm.info.ability)),
        sj2: new Array(5-Math.round(vm.info.ability)),
        xy: new Array(Math.round(vm.info.speed)),
        xy2: new Array(5-Math.round(vm.info.speed))
    };
    vm.list = list;
    ctx.render('designer/dinfo.html',vm)
}

var fn_designer_info_post = async(ctx,next) => {
    var id = ctx.ipost.id || '' ;
    var classId = ctx.ipost.classesid || '';
    var cla2=await ctx.rp2('/class/child',{pid:4})//二级分类
    var d = await ctx.rp2('/designer/work2product',{id:id,classId:classId})//服务记录，相关产品
  

    for (var item in d.data.workList){
        var cid = d.data.workList[item]['classId'];
        for(var i in cla2.data){
            if(cid == cla2.data[i]['id']) {
                d.data.workList[item]['classId'] = cla2.data[i]['name'];
                break;
            }
        }
    }
    ctx.response.body=d;
   
}
/**
 * 收藏设计师
 */
var fn_designer_fav_add_post = async(ctx,next) => {
    var userId = ctx.ipost.userId || '' ;
    var d = await ctx.rp2('/fav/designer/add',null,{
        method:'POST',
        form:{
            userId:userId
        }
    })//添加收藏
    ctx.response.body=d;
}

/**
 * 取消设计师收藏
 */
var fn_designer_fav_del_post = async(ctx,next) => {
    var userId = ctx.ipost.userId || '' ;
    var d = await ctx.rp2('/fav/designer/del',null,{
        method:'POST',
        form:{
            userId:userId
        }
    })//移除收藏
    ctx.response.body=d;
}

function isNull(v){
    if(v == null || v == undefined || v == ""){
        return true;
    }
    return false;
}

//服务评价
var  fn_designer_appraise = async(ctx, next) =>{
    var id = ctx.iget.id || '';
    var pageNum = parseInt(ctx.iget.pageNum) || 1;
    var pageSize = parseInt(ctx.iget.pageSize) || 5;
    var d = await ctx.rp2('/designer/appraise',{id:id, pageNum: pageNum,pageSize: pageSize,});
    if (d.status == '200' && d.data.list != 'null') {
        var type={"DEMAND":"需求订单","HIRE_MONTH":"HIRE_MONTH","HIRE_CUSTOM":"定制雇佣"}
        d.data.list.map((x) => {
            function getDate(tm) {
                var tt = new Date(tm).toLocaleString();
                return tt;
            }
            x.createTime = getDate(x.createTime)
            x.orderType=type[x.orderType]
           // x.username = x.username != null ? x.username.replace(x.username.substr(3, 6), "***") : x.realname != null ? x.realname.replace(x.realname.substr(3, 6), "***") : "未命名";
        })
    }
    ctx.response.body=d;
    ctx.setNoCache();
}

module.exports = {
    'GET /search/designer':fn_designer_list,
    'GET /designers/:id':fn_designer_info,
    'GET /designers/appraise': fn_designer_appraise,
    'POST /designers_post':fn_designer_info_post,
    'POST /designers/fav_add':fn_designer_fav_add_post,
    'POST /designers/fav_del':fn_designer_fav_del_post,
}