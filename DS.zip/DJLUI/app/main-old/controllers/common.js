const path2 = require('path');
const fn = require(path2.join(path2.resolve('.'),'/utils/fn.js'));

/** 是否登录 */
var fn_islogin = async (ctx, next) =>  {

    var data=await ctx.rp2('/auth/login/status')
    ctx.response.body=data;

    ctx.setNoCache();
    
};

/** 退出登录  */
var fn_loginout = async(ctx,next)=>{
    var data=await ctx.rp2('/auth/logout',null,{method:'POST'})
    ctx.response.body=data;
    ctx.setNoCache();
}

/** 获取用户信息 */
var fn_userinfo = async(ctx,next)=>{
    var data=await ctx.rp2('/user/info')
    ctx.response.body=data;
    ctx.setNoCache();
}

/** 根据登录状态跳转 */
var fn_userjump = async(ctx,next)=>{
    var islogin=await ctx.getLoginStatus()

    ctx.query.nourl=ctx.query.nourl || djconfig.website//未登录url
    ctx.query.url=ctx.query.url || djconfig.website//登录后url
    ctx.query.redirect=ctx.query.redirect || '' //跳转前路径

    if(islogin){
        ctx.redirect(ctx.query.url)
    }else{
        ctx.redirect(ctx.query.nourl+'?redirect='+encodeURIComponent(ctx.query.redirect))
    }
}

/** 获取图片验证码 */
var fn_piccode = async(ctx,next)=>{
    //var d = await ctx.rp({uri:url,method:'GET',encoding:null})
    var d = await ctx.rp2('/auth/verifycode',{r:new Date().getTime()},{method:'GET',encoding:null},1)
    var buffer = new Buffer(d);
    ctx.type = 'image/jpeg';
    ctx.body = d;
    ctx.setNoCache();
}

/** 获取短信动态码 */
var fn_sendcode = async (ctx, next) =>  {
    var phone = ctx.iget.phone || ''
    var piccode = ctx.iget.piccode || ''
    var param={phone:phone};
    if(piccode){
        param.verifycode=piccode;
    }

    console.log(param)

    var d = await ctx.rp2('/auth/sendcode',null,{method:'POST',form:param})
    ctx.response.body=d;
    ctx.setNoCache();
}

var fn_bad = (ctx,next) => {
    var vm = {};
    vm.stateId = ctx.iget.stateId || '';
    ctx.render('404.html', vm);
}

var common = async (ctx, next) => {
    /**
     * 
     * 获取底部友情链接
     * 获取侧边栏的QQ和手机 
     * 
     * */
    var customerInfo = [], e, links;
    e = await ctx.rp2('/common/config/gets', { keys: "supermanage_qq,supermanage_phone,Links" }, { method: 'GET' })
    e.data.map(function (item) {
        if (item.key == "Links") {
            links = JSON.parse(item.value);
        }
        if (item.key == "supermanage_qq") {
            customerInfo.push(item);
        }
        if (item.key == "supermanage_phone") {
            customerInfo.push(item);
        }
    })
    ctx.state = Object.assign(ctx.state, { "customerInfo": customerInfo, "links": links });
}

var auth_verify_phone = async (ctx, netx) => {
    var code = ctx.iget.code || '' ;
    var d = await ctx.rp2('/auth/verify/phone',null,{
        method:'POST',
        form:{
            code:code
        }
    })
    ctx.response.body=d;
}

module.exports = {
    'GET /*':common,
    'GET /common/bad':fn_bad,
    'GET /common/islogin':fn_islogin,
    'GET /common/loginout':fn_loginout,
    'GET /common/userinfo':fn_userinfo,
    'GET /common/userjump':fn_userjump,
    'GET /common/sendcode':fn_sendcode,
    'GET /common/piccode':fn_piccode,
    'GET /common/verify_code':auth_verify_phone,
}