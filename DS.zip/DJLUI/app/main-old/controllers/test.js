var test1 = async (ctx, next) => {
    var data={ 
        name: '小明',
        num:123, 
        proList:[
            {proName:'aaa',price:2},
            {proName:'bbb',price:223},
            {proName:'ccc',price:342},
            {proName:'ddd',price:2435},
        ]
    }

    var data2={ 
        header: 'Hello 2222',
        body: 'bla bla bla...'
    }
    data2.data=await ctx.rp2({uri:'/api/class/child',qs:{pid:4}});
    data2.list=await ctx.rp2('/api/type/list');

    ctx.render('test/test1.html',data2)
}

var test2 = async (ctx, next) => {
    var a=[
        {a:1},
        {a2:12}
    ]
    console.log(typeof(JSON.stringify(a)))
    console.log(typeof(JSON.parse(JSON.stringify(a))))
    console.log(typeof(a));
    ctx.response.body=a;
};

var test3=async(ctx)=>{
    ctx.response.body='aaa1111';
    console.log('------test3-----')
    //console.log(ctx.req)
    console.log(ctx.cookies.get('cookie_lang'));
    ctx.cookies.set('SESSION','d7525caa-f911-47a4-9307-59a2357449cf')
    // console.log(ctx.req._parsedUrl.query)
    // console.log(ctx.cookies.cookie_lang);
    console.log('-----------')
}

var getCookie=async(ctx)=>{
    console.log(ctx.params.name)
    console.log(ctx.cookies);
    console.log('获取cookie:'+ctx.params.name+' = '+ctx.cookies.get(ctx.params.name));
    ctx.response.body={msg:'',state:1,data:ctx.cookies.get(ctx.params.name)};
   
}

var testSetCookie = async(ctx)=>{
    var s='ASP.NET_SessionIdsctrmu55dts1femfu50ghj45';
     var qs=require('querystring');
     
    console.log(qs.parse(s,'; '));
    console.log(qs.parse('','; ').abc);
    console.log(qs.parse(null,'; ').SESSION);
    console.log(qs.parse(undefined,'; '));
    console.log(qs.parse('; '));


    // ctx.qs.
    

    // var u1='http://www.dianjiangla.com/api/demand/list?endTime=1500283126503&startTime=1497691126000&pageNum=1&pageSize=10';
    // var u2='http://www.dianjiangla.com'
    // var u3='dianjiangla.com'
// var rp=require('request-promise');
// rp.jar().getCookieString
    // var tough = require('tough-cookie');
    // let cookie = new tough.Cookie({
    //     key: "SESSION",
    //     value: "f66e3c06-5818-45c4-bd9c-29da4d9ee773",
    //     //domain: '127.0.0.1:8081',
    //     domain: u3,
    //     httpOnly: true,
    //     maxAge: 31536000
    // });
    // console.log(111111111);
     var cookiesJar=ctx.rp.jar();
    // // cookiesJar.setCookie(cookie,'http://127.0.0.1:8081');
    // cookiesJar.setCookie(cookie,u2);
    // //cookiesJar.getCookie(cookie);
    // console.log(22222222222);
    console.log('1111111111111111')
    console.log(cookiesJar);
    console.log('1111111111111111')
    var data=await ctx.rp({
        // uri:'http://127.0.0.1:8081/test/getCookie/sixicookie',
        uri:'http://www.dianjiangla.com/api/class/company',
        // uri:'http://www.china-315.com/',
         jar: cookiesJar
       // resolveWithFullResponse: true
    }).then(function (data) {
        console.log(3333333333333);
        console.log(cookiesJar);
        console.log('//////////////////');
        console.log(cookiesJar.getCookieString(djconfig.apiCookieDomain1));
        console.log(ctx.qs.parse(cookiesJar.getCookieString(djconfig.apiCookieDomain1),'; '));

        console.log(cookies);
        var cookies=ctx.qs.parse(cookiesJar.getCookieString(djconfig.apiCookieDomain1),'; ');
        console.log(cookies.SESSION);
        if(cookies.SESSION!=undefined){
            ctx.cookies.set('SESSION',cookies.SESSION);
        }


        // console.log(cookiesJar.getCookies('http://www.china-315.com'));
        // console.log('////--////////');
        // console.log(cookiesJar.getCookieString('http://www.china-315.com'));
        // console.log(data);
    })
    .catch(function (err) {
        console.log(44444444444444);
        console.log(err);
    });
    console.log(555555555555);
    console.log(data);
    ctx.response.body=666666;
}

var getDJLData=async(ctx)=>{
    var data=await ctx.rp2({
        uri:'/api/demand/list',
        qs:{endTime:'1500283126503',startTime:'1497691126000',pageNum:2,pageSize:20}
    });
    //console.log(data);
    ctx.response.body=data;
}

var test4=async(ctx)=>{
    var d=await ctx.getLoginStatus()
    console.log(d);
    //ctx.redirect('http://www.baidu.com')
}

module.exports = {
    'GET /test/test1': test1,
    'GET /test/test2': test2,
    'GET /test/test3': test3,
    'GET /test/test4': test4,
    'GET /test/getCookie/:name': getCookie,
    'GET /test/testSetCookie': testSetCookie,
    'GET /test/getDJLData':getDJLData
};