/**
 * Created by 狂龙 on 2017/7/19.
 */
var fn_prolist = async(ctx,next) => {
    var vm={};
    var rank='';
    var pageSize = 20;

    var qy = ctx.iget.qy || '';
    var jb = ctx.iget.jb || 0;
    var lm = ctx.iget.lm || '';
    var pageNum =parseInt( ctx.iget.pageNum )|| 1;
    var name = ctx.iget.name || '';

    var rankList = ctx.staticData.rankList;
    rank = rankList[jb];

    vm.qy = qy;
    vm.jb = jb;
    vm.lm = lm;
    vm.name = decodeURI(name);

    vm.cla2=await ctx.rp2('/class/child',{pid:4})//二级分类
    vm.area=await ctx.rp2('/type/list')//区域列表
    vm.product_list=await ctx.rp2('/product/list',{
        classIds:lm,
        rank:rank,
        name:name,
        pageNum:pageNum,
        pageSize:pageSize,
        typeId:qy
    })//作品列表

    vm.pageCount =  Math.ceil(vm.product_list.data.count / pageSize);
    pageNum = pageNum > vm.pageCount ? vm.pageCount : pageNum < 1 ? 1: pageNum ;
    vm.pageNum = pageNum;
    vm.pageHtml =await ctx.pageHtml(pageNum,vm.pageCount);
    ctx.render('products/prolist.html',vm);
};

var fn_proInfo = async(ctx,next) => {
    var vm={};
    var id = ctx.params.id || '' ;
    var designerWorkId = ctx.params.designerWorkId || '';
    var info = await ctx.rp2('/product/get',{id:id,designerWorkId:designerWorkId});
    if(info.data == null){
        ctx.render('404.html');
        return;
    }

    vm.info = info.data;
    vm.loginStatus = await ctx.getLoginStatus()//登录状态
    vm.pid = ctx.iget.pid || id ||'';
    /** 获取设计师联系方式 */
    if(vm.loginStatus){
        vm.designer_contractInfo=await ctx.rp2('/designer/contractInfo',{id:vm.info.user.user_id})//获取设计师联系方式
    }

    if (info.data.designerWorkProductList == 'undefined') {
        var proid = info.data.id;
        vm.tag = info.data.tag;
        vm.details = info.data.details;
    } else {
        if (info.data.designerWorkProductList.length > 0) {
            var designerWorkProductList = info.data.designerWorkProductList;
            if (id) {
                for (var k in designerWorkProductList) {
                    if (designerWorkProductList[k].id == vm.pid) {
                        var proid = designerWorkProductList[k].id;
                        vm.tag = designerWorkProductList[k].tag;
                        vm.details = designerWorkProductList[k].details;
                        vm.label=designerWorkProductList[k].label.replace(/\,/g,' / ');
                    }
                }
            } else {
                var proid = designerWorkProductList[0].id;
                vm.tag = designerWorkProductList[0].tag;
                vm.details = designerWorkProductList[0].details;
            }
        }
    }
    vm.pid = ctx.iget.pid || id || proid ||'';
    vm.isFav = await ctx.rp2('/fav/product/isFav',{productId:vm.pid})//判断是否收藏了该作品
    vm.pathname = encodeURIComponent(ctx.path);
    ctx.render('products/proInfo.html',vm);
}

var fn_designer_prolist = async(ctx,next) => {
    var vm = {};
    var id = ctx.params.id || '' ;
    var classId = ctx.iget.classId || '';
    var info = await ctx.rp2('/designer/get',{id:id});
    var classes = await ctx.rp2('/designer/product/classes',{id:id});
    var list = await ctx.rp2('/designer/product',{id:id,classId:classId});
    vm.loginStatus = await ctx.getLoginStatus()//登录状态
    vm.pid = ctx.iget.pid || id ||'';
    /** 获取设计师联系方式 */
    if(vm.loginStatus){
        vm.designer_contractInfo=await ctx.rp2('/designer/contractInfo',{id:info.data.user_id})//获取设计师联系方式
    }
    vm.classId = classId;
    vm.info = info.data;
    vm.classes = classes.data;
    vm.list = list;
    vm.pathname = encodeURIComponent(ctx.path);
    ctx.render('products/designerProList.html',vm)
}

/**
 * 收藏作品
 */
var fn_pro_fav_add_post = async(ctx,next) => {
    var productId = ctx.ipost.productId || '' ;
    var d = await ctx.rp2('/fav/product/add',null,{
        method:'POST',
        form:{
            productId:productId
        }
    })//添加收藏
    ctx.response.body=d;
}

/**
 * 取消设计师收藏
 */
var fn_pro_fav_del_post = async(ctx,next) => {
    var productId = ctx.ipost.productId || '' ;
    var d = await ctx.rp2('/fav/product/del',null,{
            method:'POST',
            form:{
                productId:productId
            }
        })//移除收藏
    ctx.response.body=d;
}

module.exports = {
    'GET /prolist':fn_prolist,
    'GET /proInfo/:id':fn_proInfo,
    'GET /proInfoList/:designerWorkId':fn_proInfo,
    'GET /designer/:id':fn_designer_prolist,
    'POST /proInfo/fav_add':fn_pro_fav_add_post,
    'POST /proInfo/fav_del':fn_pro_fav_del_post
}