
var fn_ali = async (ctx, next) =>  {
    var id=ctx.iget.id || ''

    var d=await ctx.rp2('/pay/ali/wap/hire',{id:id},null,1);
    ctx.response.body=d;
}

module.exports = {
    'GET /paycenter/ali':fn_ali,
}