const path2 = require('path');
const fn = require(path2.join(path2.resolve('.'),'/utils/fn.js'));

var fn_index = async (ctx, next) =>  {
    var vm={};
    vm.cla1=await ctx.rp2('/class/company')//一级分类
    vm.cla2=await ctx.rp2('/class/child',{pid:4})//二级分类
    vm.area=await ctx.rp2('/type/list')//区域列表
    vm.loginStatus=await ctx.rp2('/auth/login/status')//登录状态
    vm.product_fine=await ctx.rp2('/product/fine')//优秀案例--作品列表
    vm.designer_recommend=await ctx.rp2('/designer/recommend')//设计师推荐
    vm.designer_newest=await ctx.rp2('/designer/newest')//新晋设计师
    vm.carousel=await ctx.rp2('/index/carousel',{pageSize:100,pageIndex:1})//获取订单轮播信息
    var banner = await ctx.rp2('/common/config/get', { key: "bannerkey" }) //获取前台banner轮播信息
    vm.banner = JSON.parse(banner['data']);
    vm.carousel.data.list.map(function (item) {
        item.time = new Date(item.time).toLocaleDateString();
        return item;
    });
    //合作客户渲染用
    vm.hzkh=[]
    for (var i = 1; i <= 18; i++) {
        vm.hzkh.push(i);
    }

    vm.designer_recommend2=fn.dataGroup(vm.designer_recommend.data,8);
    vm.designer_newest2=fn.dataGroup(vm.designer_newest.data.list,4);
    vm.product_fine2=fn.dataGroup(vm.product_fine.data.list,4);
    ctx.render('index/index.html',vm)
   // await next();
};

var fn_proposal = async (ctx, next) =>  {
        var vm = {};
        ctx.render('index/proposal.html',vm)
    }

var fn_proposal_post = async (ctx, next) => {
    var contact = ctx.ipost.contact || '';
    var content = ctx.ipost.content || '';
    var title = ctx.ipost.title || '';
    var verifycode = ctx.ipost.verifycode || '';

    var d=await ctx.rp2('/feedback/add',null,{
        method:'POST',
        form:{
            contact:contact,
            content:content,
            title:title,
            verifycode:verifycode
        }
    });

    ctx.response.body=d;
    ctx.setNoCache();
}

module.exports = {
    'GET /':fn_index,
    'GET /proposal':fn_proposal,
    'POST /proposal_post':fn_proposal_post
}