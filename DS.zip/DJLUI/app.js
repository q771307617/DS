const Koa = require('koa');//框架
const bodyParser = require('koa-bodyparser');//表单解析
const controller = require('./middleware/controller');
const templating = require('./middleware/templating');
const ctxutils = require('./middleware/ctx-utils');
let staticFiles = require('./middleware/static-files');

let isProduction = false;
const app = new Koa();
console.log('NODE_DJL_PC');
switch(process.env.NODE_DJL_PC){
    case 'dev':
        require('./config/dev.js');
        break;
    case 'test':
        require('./config/test.js');
        break;
    case 'prod':
        isProduction=true;
        require('./config/prod.js');
        break;
    default:
        require('./config/dev.js');
        break;
}

app.use(async (ctx, next) => {
    console.log(`Process ${ctx.request.method} ${ctx.request.url}...`);
    var
        start = new Date().getTime(),
        execTime;
    await next();
    execTime = new Date().getTime() - start;
    ctx.response.set('X-Response-Time', `${execTime}ms`);
});

app.use(bodyParser());
app.use(ctxutils());
app.use(staticFiles('/'+djconfig.static+'/', __dirname + '/'+djconfig.static));

app.use(templating('app/main/views', {
    noCache: !isProduction,
    watch: !isProduction
}));

app.use(controller());

app.use(async (ctx) => {//not found
    switch (ctx.status) {
        case 404:
        await ctx.render('404.html');
        break;
        case 500:
        await ctx.render('404.html');
        break;
    }
})

app.on('error', async (err, ctx) =>{//500
    console.log(err);
    ctx.res.writeHead(302, {
        'Location': '/common/bad?stateId=500'
    });
    ctx.res.end()
});

app.listen(djconfig.port);
console.log('http://127.0.0.1:'+djconfig.port);

