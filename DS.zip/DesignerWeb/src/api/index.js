/* eslint-disable */
import Vue from 'vue';
import axios from 'axios';
import qs from 'qs';
import iView from 'iview';

Vue.use(iView); // iView
// 通过process.env.NODE_ENV配置开发还是线上环境
// console.log(process.env.NODE_ENV);

axios.defaults.baseURL = '/api';
axios.defaults.timeout = 10000;
axios.defaults.headers.common['If-Modified-Since'] = '0';
axios.defaults.headers.common['Cache-Control'] = 'no-cache';

let path = process.env.NODE_ENV === 'development' ? '/api/' : '/api/';

let getApiUrl = apiName => {
  return path + apiName;
};
let payAli = orderId => {
  window.open(path + 'pay/ali?id=' + orderId);
};
let payMoney = orderNo => {
  window.open(path + 'finance/deposit?orderNo=' + orderNo);
};
let hirePay = (hireId, referralCode) => {
  window.open(
    path +
      'finance/hirePay/alipay?hireId=' +
      hireId +
      '&referralCode=' +
      referralCode
  );
};
let demandPay = (demandId, referralCode) => {
  window.open(
    path +
      'finance/demand/alipay?demandId=' +
      demandId +
      '&referralCode=' +
      referralCode
  );
};

let getVerifyCode = () => {
  return path + 'auth/verifycode' + '?time=' + new Date().getTime();
};

let toLogin = () => {
  location.href = '/user/login';
};

axios.interceptors.request.use(
  function(config) {
    return config;
  },
  function(error) {
    return Promise.reject(error);
  }
);

function instance(content) {
  iView.Modal.error({
    title: ' ',
    content: content,
    loading: true,
    onOk: () => {
      goBack();
    }
  });
}
function goBack(time = 2000) {
  setTimeout(() => {
    iView.Modal.remove();
    toLogin();
  }, time);
}
axios.interceptors.response.use(
  function(res) {
    if (res.data && res.data.status == '401') {
      instance(res.data.msg);
      goBack(4000);
      //   toLogin();
    }
    if (res && res.data && res.data.status != '200') {
      res.data.data = {};
    }
    return res;
  },
  function(error) {
    return Promise.reject(error);
  }
);
let pathUpload = '/api/upload';
export default {
  pathUpload: pathUpload,
  getVerifyCode: getVerifyCode,
  payMoney: payMoney,
  hirePay: hirePay,
  demandPay: demandPay,
  payAli: payAli,
  //接口名字和接口参数 测试可行
  get: (apiName = '', params = {}) => {
    return axios.get(apiName, { params: params }).then(res => {
      return res.data;
    });
  },
  getmoney: () => {
    // Vue.http.get("http://172.30.34.121:8080/aliApi/directPay?totalFee=0.01");
  },

  post: (apiName = '', body = {}) => {
    return axios.post(apiName, qs.stringify(body)).then(res => {
      return res.data;
    });
  }
};
