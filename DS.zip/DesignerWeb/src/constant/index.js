export default {
  //交易类型
  TRADE_TYPE: {
    DEPOSIT: '充值',
    WITHDRAW: '提现',
    DEMAND_DEPOSIT: '支付需求保证金',
    DEMAND_WITHDRAW: '退回需求保证金',
    DIRECT_PAY: '直接支付订单',
    HIRE_DEPOSIT: '支付雇佣保证金',
    HIRE_WITHDRAW: '退回雇佣保证金'
  },
  TRADE_STATUS: {
    TRADE_SUCCESS: '已支付',
    WAIT_BUYER_PAY: '等待付款',
    TRADE_FAILED: '失败',
    TRADE_CLOSED: '已关闭',
    REFUND_SUCCESS: '退款成功',
    AUDIT: '审核中',
    REFUND_AUDIT: '退款审核', //退款审核
    REFUND_WAIT: '等待退款' //等待退款
  },
  acceptStatus: [
    {
      value: 0,
      label: '待验收'
    },
    {
      value: 1,
      label: '已验收'
    },
    {
      value: -1,
      label: '未通过'
    }
  ],
  auditStatus: [
    {
      value: 0,
      label: '待审核'
    },
    {
      value: 1,
      label: '已审核'
    },
    {
      value: -1,
      label: '未通过'
    }
  ],
  platformList: [
    {
      value: '0',
      label: '淘宝'
    },
    {
      value: '1',
      label: '天猫'
    },
    {
      value: '2',
      label: '京东'
    },
    {
      value: '3',
      label: '苏宁'
    },
    {
      value: '4',
      label: '唯品会'
    },
    {
      value: '5',
      label: '1号店'
    }
  ],
  categoryList: [
    {
      value: '0',
      label: '服装内衣'
    },
    {
      value: '1',
      label: '母婴玩具'
    },
    {
      value: '2',
      label: '精品鞋包'
    },
    {
      value: '3',
      label: '生活百货'
    },
    {
      value: '4',
      label: '3C数码'
    },
    {
      value: '5',
      label: '家电办公'
    },
    {
      value: '6',
      label: '化妆美容'
    },
    {
      value: '7',
      label: '家具家纺'
    }
  ],
  designTypeList: [
    {
      value: '0',
      label: '首页'
    },
    {
      value: '1',
      label: '详情页模板'
    },
    {
      value: '2',
      label: '爆款策划'
    },
    {
      value: '3',
      label: '海报BANNER'
    },
    {
      value: '4',
      label: '营销活动'
    },
    {
      value: '5',
      label: '钻石展位'
    },
    {
      value: '6',
      label: '直通车'
    },
    {
      value: '7',
      label: '其他'
    }
  ]
};

// export const categories = [{ value: 5, label: '服装内衣' }, { value: 2, label: '化妆美容' }, { value: 3, label: '家具家纺' }, { value: 4, label: '3C数码' }, { value: 5, label: '家电办公' }, { value: 7, label: '精品鞋包' }, { value: 6, label: '母婴玩具' }, { value: 8, label: '食品保健' }, { value: 9, label: '珠宝手表' }, { value: 10, label: '汽车配件' }, { value: 8, label: '生活百货' }, { value: 12, label: '户外运动' }];

export const categories = [
  { value: 5, label: '服装内衣' },
  { value: 6, label: '母婴玩具' },
  { value: 7, label: '精品鞋包' },
  { value: 8, label: '生活百货' },
  { value: 9, label: '内衣' },
  { value: 10, label: '短裤' }
];

export const worktypes = [
  { value: 0, label: '全职' },
  { value: 1, label: '兼职' }
];

export const designTypes = [
  { value: 1, label: '首页' },
  { value: 2, label: '详情页模板' },
  { value: 3, label: '爆款策划' },
  { value: 4, label: '海报BANNER' },
  { value: 5, label: '营销活动' },
  { value: 6, label: '钻石展位' },
  { value: 7, label: '直通车' },
  { value: 8, label: '其他' }
];

export const levels = [
  { value: 5, label: '专家（3年以上）' },
  { value: 4, label: '高级（2-3年）' },
  { value: 3, label: '中级（1.5-2年）' },
  { value: 2, label: '初级（1-1.5年）' },
  { value: 1, label: '助理（1年以下）' }
];

export const workyears = [
  { value: 1, label: '0.5年-1年' },
  { value: 2, label: '1年-1.5年' },
  { value: 3, label: '1.5年-2年' },
  { value: 4, label: '2年-3年' },
  { value: 5, label: '3年以上' }
];

export const gender = [
  { value: 0, label: '帅哥' },
  { value: 1, label: '美女' }
];

export const platforms = [
  { value: '1', label: '淘宝' },
  { value: '2', label: '天猫' },
  { value: '3', label: '京东' },
  { value: '4', label: '苏宁' },
  { value: '5', label: '唯品会' },
  { value: '6', label: '1号店' }
];

export const salaryBudget = [
  { value: '1', label: '1500-2999元' },
  { value: '2', label: '3000-3999元' },
  { value: '3', label: '4000-5999元' },
  { value: '4', label: '6000-9999元' },
  { value: '5', label: '10000元以上' }
];
