import api from '@/api/index'

export default {
    LIST_GET({state,commit}){
        //目前只有 pid == 4的时候可以获取到
		api.get('class/child', {pid:4}).then(e => {
			if (e.status != 200) return;
            commit("CHILD_LIST_4_GET",e.data);
		});
        //获取到公司行业类型
        api.get('class/company').then(e =>{
            if (e.status != 200) return;
            commit("COMPANY_LIST_GET",e.data);
        });
        //获取到区域列表
        api.get('type/list').then(e=>{
            if(e.status != 200) return;
            commit("TYPE_LIST_GET",e.data);
        });
        //获取父分类列表
        api.get('class/parent').then(e=>{
            if(e.status != 200) return;
            commit("PARENT_LIST_GET",e.data);
        });
        //获取风格列表
        api.get('demand/style/list').then(e=>{
            if(e.status != 200) return;
            commit("STYLE_LIST_GET",e.data);
        });
	}
}