import {user} from '@/sessionstorage/index'
export default {
  typeList: [],    // 区域分类
  companyList: [], // 公司分类
  parentList: [],  // 父分类
  childList4: [],  // 子分类
  styles: [],       // 风格列表
  ranks: [
    {id: "ASSISTANT", name: "助理"}, //设计师等级
    {id: "PRIMARY", name: "初级"},
    {id: "MIDDLE", name: "中级"},
    {id: "HIGH", name: "高级"},
    {id: "EXPERT", name: "专家"}
  ],
};
