export default {
	CHILD_LIST_4_GET(state,data){
		state.childList4 = data;
	},
	COMPANY_LIST_GET(state,data){
		state.companyList = data;
	},
	TYPE_LIST_GET(state,data){
		state.typeList = data;
	},
	PARENT_LIST_GET(state,data){
		state.parentList = data;
	},
	STYLE_LIST_GET(state,data){
		state.styles = data;
	},
}