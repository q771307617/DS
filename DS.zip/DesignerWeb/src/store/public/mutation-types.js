export const FETCH_TYPES = 'fetch_types';
export const FETCH_CATES = 'fetch_cates';
export const REFLASH = 'reflash';
export const SET_PROLIST = 'set_productList';
export const GET_SALARY = 'get_salary';
