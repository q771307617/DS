import * as types from './mutation-types.js';
import api from '@/api/index';

export default {
    fetchTypes({ commit }) {
        api.get('type/list', {}).then(e => {
            if (e.status !== 200) return;
            commit(types.FETCH_TYPES, e.data)
        })
    },
    fetchCates({ commit }) {
        api.get('class/child', { pid: 4 }).then(e => {
            if (e.status !== 200) return;
            commit(types.FETCH_CATES, e.data)
        })
    },
    // 获取薪资范围
    getSalary ({ commit }) {
      api.get("/common/config/get", {key: "salary"}).then((e) => {
          if (e.status == 200) {
            const data = JSON.parse(e.data) || [];
            commit(types.GET_SALARY, data);
          }
        });
      },
}
