import * as t from './mutation-types.js';
import { types, cates } from '@/sessionstorage/index';

export default {
    [t.FETCH_TYPES](state, data) {
        state.types = data;
        types.set(data)
    },
    [t.FETCH_CATES](state, data) {
        state.cates = data;
        cates.set(data)
    },
    [t.REFLASH](state, value) {
        state.reflash = value;
    },
    [t.SET_PROLIST](state, data) {
        state.productList = data;
    },
    [t.GET_SALARY](state, data) {
        state.salaryBudget = data;
    }
}
