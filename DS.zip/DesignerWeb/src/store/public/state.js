import {types, cates} from '@/sessionstorage/index';
export default {
  cates: cates.get() || [],
  types: types.get() || [],
  reflash: false,
  // Mad Dragon 【 395548460@qq.com 】 2017/11/20 14:36 设计师入驻类型
  workPlaceList: [
    {key: 0, name: '在家办公'},
    {key: 1, name: '众创空间'},
    {key: 2, name: '自营'},
    {key: 3, name: '自营'},
  ],
  /**
   * @Title: 设计师等级
   * @Author: Mad Dragon 【 395548460@qq.com 】
   * @Date: 2017/11/23 11:28
   * @Version V2.0.2
   * @Description:
   */
  ranksList: [
    {key: "ASSISTANT", name: "助理"},
    {key: "PRIMARY", name: "初级"},
    {key: "MIDDLE", name: "中级"},
    {key: "HIGH", name: "高级"},
    {key: "EXPERT", name: "专家"}
  ],
  /**
   * @Title: 订单类型
   * @Author: Mad Dragon 【 395548460@qq.com 】
   * @Date: 2017/11/23 11:10
   * @Version V2.0.2
   * @Description:
   */
  orderTypeList: [
    //            {id: "-1", name: "全部"},
    {key: "DEMAND", name: "需求订单"},
    {key: "HIRE_MONTH", name: "包月订单"},
    {key: "HIRE_CUSTOM", name: "定制订单"}
  ],
  /**
   * @Title: 退款状态列表
   * @Author: Mad Dragon 【 395548460@qq.com 】
   * @Date: 2017/11/22 15:33
   * @Version V2.0.2
   * @Description: 所有订单状态列表
   * 0: 全部
   *
   * 正常订单
   *     1: 待支付 2: 待开始 3: 待交付 4: 待验收 16:验收不通过(需求订单) 5: 已完成 6: 已取消 7: 待评价 8: 已评价
   *
   * 退款订单
   *     9: 退款审核中 10: 等待设计师审核 11: 等待总监审核 12: 等待财务审核 13: 退款中 14: 已退款 15: 退款失败
   */
  refundStatusTypeList: [
    {key: 'PENDING_DESIGNER_AUDIT', name: '等待设计师审核', title: 10},
    {key: 'PENDING_MANAGER_AUDIT', name: '等待总监审核', title: 11},
    {key: 'PENDING_FINANCE_AUDIT', name: '等待财务审核', title: 12},
    {key: 'PROCESSING', name: '退款处理中', title: 13},
    {key: 'CLOSED', name: '退款已关闭', title: 15},
    {key: 'FAIL', name: '退款失败', title: 15},
    {key: 'APPLY_SUCCESS', name: '审核通过,退款失败', title: 13},
    {key: 'APPLY_FAIL', name: '审核未通过', title: 15},
    {key: 'SUCCESS', name: '退款成功', title: 14},
  ],
  // Mad Dragon 【 395548460@qq.com 】 2017/11/21 14:53 所有订单状态集合
  allStatusList: [
    {key: "0", name: "未知类型", title: "未知类型"},
    {key: "-1", name: "全部订单", title: "全部订单"},
    {key: "1", name: "待支付", title: "等待雇主付款"},
    {key: "2", name: "待开始", title: "等待开始工作"},
    {key: "3", name: "待交付", title: "等待设计师提交验收"},
    {key: "4", name: "待验收", title: "等待雇主验收"},
    {key: "5", name: "已完成", title: "订单已完成"},
    {key: "6", name: "已取消", title: "订单已取消"},
    {key: "7", name: "待评价", title: "等待雇主评价"},
    {key: "8", name: "已评价", title: "订单已评价"},
    {key: "9", name: "退款审核中", title: "退款审核中"},
    {key: "10", name: "等待设计师审核", title: "等待设计师审核"},
    {key: "11", name: "等待总监审核", title: "等待总监审核"},
    {key: "12", name: "等待财务审核", title: "等待财务审核"},
    {key: "13", name: "退款中", title: "退款中"},
    {key: "14", name: "已退款", title: "已退款"},
    {key: "15", name: "退款失败", title: "退款失败"},
    {key: "16", name: "验收未通过", title: "验收未通过"},
  ],
  productList: [],
  /*薪资范围 */
  salaryBudget: {},
  /*入驻设计师学历 */
  schoolheight: [{value: '1', label: '初中'}, {value: '2', label: '高中'}, {value: '3', label: '大专'}, {
    value: '4',
    label: '本科'
  }, {value: '5', label: '研究生'}, {value: '6', label: '其他'}],
  /*入驻设计师工作经验 */
  employTimeData: {1: '1年以内', 2: '1-2年', 3: '2-3年', 4: '3-5年', 5: '5年以上',},
  /*入驻设计师默认薪资 */
  salayParams: {0: '2500', 1: '3500', 2: '5000', 3: '7000', 4: '10000',},
  /* 省市二级联动 */
  provs: [{label: "北京市", value: "1", children: [{value: "1", label: "北京市"}]}, {
    label: "天津市",
    value: "2",
    children: [{value: "1", label: "天津市"}]
  }, {
    label: "河北省",
    value: "3",
    children: [{value: "1", label: "石家庄市"}, {value: "2", label: "唐山市"}, {value: "3", label: "秦皇岛市"}, {
      value: "4",
      label: "邯郸市"
    }, {value: "5", label: "邢台市"}, {value: "6", label: "保定市"}, {value: "7", label: "张家口市"}, {
      value: "8",
      label: "承德市"
    }, {value: "9", label: "沧州市"}, {value: "10", label: "廊坊市"}, {value: "11", label: "衡水市"}]
  }, {
    label: "山西省",
    value: "4",
    children: [{value: "1", label: "太原市"}, {value: "2", label: "大同市"}, {value: "3", label: "阳泉市"}, {
      value: "4",
      label: "长治市"
    }, {value: "5", label: "晋城市"}, {value: "6", label: "朔州市"}, {value: "7", label: "晋中市"}, {
      value: "8",
      label: "运城市"
    }, {value: "9", label: "忻州市"}, {value: "10", label: "临汾市"}, {value: "11", label: "吕梁市"}]
  }, {
    label: "内蒙古自治区",
    value: "5",
    children: [{value: "1", label: "呼和浩特市"}, {value: "2", label: "包头市"}, {value: "3", label: "乌海市"}, {
      value: "4",
      label: "赤峰市"
    }, {value: "5", label: "通辽市"}, {value: "6", label: "鄂尔多斯市"}, {value: "7", label: "呼伦贝尔市"}, {
      value: "8",
      label: "巴彦淖尔市"
    }, {value: "9", label: "乌兰察布市"}, {value: "10", label: "兴安盟"}, {value: "11", label: "锡林郭勒盟"}, {
      value: "12",
      label: "阿拉善盟"
    }]
  }, {
    label: "辽宁省",
    value: "6",
    children: [{value: "1", label: "沈阳市"}, {value: "2", label: "大连市"}, {value: "3", label: "鞍山市"}, {
      value: "4",
      label: "抚顺市"
    }, {value: "5", label: "本溪市"}, {value: "6", label: "丹东市"}, {value: "7", label: "锦州市"}, {
      value: "8",
      label: "营口市"
    }, {value: "9", label: "阜新市"}, {value: "10", label: "辽阳市"}, {value: "11", label: "盘锦市"}, {
      value: "12",
      label: "铁岭市"
    }, {value: "13", label: "朝阳市"}, {value: "14", label: "葫芦岛市"}]
  }, {
    label: "吉林省",
    value: "7",
    children: [{value: "1", label: "长春市"}, {value: "2", label: "吉林市"}, {value: "3", label: "四平市"}, {
      value: "4",
      label: "辽源市"
    }, {value: "6", label: "通化市"}, {value: "7", label: "白山市"}, {value: "8", label: "松原市"}, {
      value: "9",
      label: "白城市"
    }, {value: "10", label: "延边朝鲜族自治州"}]
  }, {
    label: "黑龙江省",
    value: "8",
    children: [{value: "1", label: "哈尔滨市"}, {value: "2", label: "齐齐哈尔市"}, {value: "3", label: "鸡西市"}, {
      value: "4",
      label: "鹤岗市"
    }, {value: "5", label: "双鸭山市"}, {value: "6", label: "大庆市"}, {value: "7", label: "伊春市"}, {
      value: "8",
      label: "佳木斯市"
    }, {value: "9", label: "七台河市"}, {value: "10", label: "牡丹江市"}, {value: "11", label: "黑河市"}, {
      value: "12",
      label: "绥化市"
    }, {value: "13", label: "大兴安岭地区"}]
  }, {label: "上海市", value: "9", children: [{value: "1", label: "上海市"}]}, {
    label: "江苏省",
    value: "10",
    children: [{value: "1", label: "南京市"}, {value: "2", label: "无锡市"}, {value: "3", label: "徐州市"}, {
      value: "4",
      label: "常州市"
    }, {value: "5", label: "苏州市"}, {value: "6", label: "南通市"}, {value: "7", label: "连云港市"}, {
      value: "8",
      label: "淮安市"
    }, {value: "9", label: "盐城市"}, {value: "10", label: "扬州市"}, {value: "11", label: "镇江市"}, {
      value: "12",
      label: "泰州市"
    }, {value: "13", label: "宿迁市"}]
  }, {
    label: "浙江省",
    value: "11",
    children: [{value: "1", label: "杭州市"}, {value: "2", label: "宁波市"}, {value: "3", label: "温州市"}, {
      value: "4",
      label: "嘉兴市"
    }, {value: "5", label: "湖州市"}, {value: "6", label: "绍兴市"}, {value: "7", label: "金华市"}, {
      value: "8",
      label: "衢州市"
    }, {value: "9", label: "舟山市"}, {value: "10", label: "台州市"}, {value: "11", label: "丽水市"}]
  }, {
    label: "安徽省",
    value: "12",
    children: [{value: "1", label: "合肥市"}, {value: "2", label: "芜湖市"}, {value: "3", label: "蚌埠市"}, {
      value: "4",
      label: "淮南市"
    }, {value: "5", label: "马鞍山市"}, {value: "6", label: "淮北市"}, {value: "7", label: "铜陵市"}, {
      value: "8",
      label: "安庆市"
    }, {value: "9", label: "黄山市"}, {value: "10", label: "滁州市"}, {value: "11", label: "阜阳市"}, {
      value: "12",
      label: "宿州市"
    }, {value: "13", label: "六安市"}, {value: "14", label: "亳州市"}, {value: "15", label: "池州市"}, {
      value: "16",
      label: "宣城市"
    }]
  }, {
    label: "福建省",
    value: "13",
    children: [{value: "1", label: "福州市"}, {value: "2", label: "厦门市"}, {value: "3", label: "莆田市"}, {
      value: "4",
      label: "三明市"
    }, {value: "5", label: "泉州市"}, {value: "6", label: "漳州市"}, {value: "7", label: "南平市"}, {
      value: "8",
      label: "龙岩市"
    }, {value: "9", label: "宁德市"}]
  }, {
    label: "江西省",
    value: "14",
    children: [{value: "1", label: "南昌市"}, {value: "2", label: "景德镇市"}, {value: "3", label: "萍乡市"}, {
      value: "4",
      label: "九江市"
    }, {value: "5", label: "新余市"}, {value: "6", label: "鹰潭市"}, {value: "7", label: "赣州市"}, {
      value: "8",
      label: "吉安市"
    }, {value: "9", label: "宜春市"}, {value: "10", label: "抚州市"}, {value: "11", label: "上饶市"}]
  }, {
    label: "山东省",
    value: "15",
    children: [{value: "1", label: "济南市"}, {value: "2", label: "青岛市"}, {value: "3", label: "淄博市"}, {
      value: "4",
      label: "枣庄市"
    }, {value: "5", label: "东营市"}, {value: "6", label: "烟台市"}, {value: "7", label: "潍坊市"}, {
      value: "8",
      label: "济宁市"
    }, {value: "9", label: "泰安市"}, {value: "10", label: "威海市"}, {value: "11", label: "日照市"}, {
      value: "12",
      label: "莱芜市"
    }, {value: "13", label: "临沂市"}, {value: "14", label: "德州市"}, {value: "15", label: "聊城市"}, {
      value: "16",
      label: "滨州市"
    }, {value: "17", label: "菏泽市"}]
  }, {
    label: "河南省",
    value: "16",
    children: [{value: "1", label: "郑州市"}, {value: "2", label: "开封市"}, {value: "3", label: "洛阳市"}, {
      value: "4",
      label: "平顶山市"
    }, {value: "5", label: "安阳市"}, {value: "6", label: "鹤壁市"}, {value: "7", label: "新乡市"}, {
      value: "8",
      label: "焦作市"
    }, {value: "9", label: "濮阳市"}, {value: "10", label: "许昌市"}, {value: "11", label: "漯河市"}, {
      value: "12",
      label: "三门峡市"
    }, {value: "13", label: "南阳市"}, {value: "14", label: "商丘市"}, {value: "15", label: "信阳市"}, {
      value: "16",
      label: "周口市"
    }, {value: "17", label: "驻马店市"}, {value: "18", label: "省直辖县级行政区划"}]
  }, {
    label: "湖北省",
    value: "17",
    children: [{value: "1", label: "武汉市"}, {value: "2", label: "黄石市"}, {value: "3", label: "十堰市"}, {
      value: "4",
      label: "宜昌市"
    }, {value: "5", label: "襄阳市"}, {value: "6", label: "鄂州市"}, {value: "7", label: "荆门市"}, {
      value: "8",
      label: "孝感市"
    }, {value: "9", label: "荆州市"}, {value: "10", label: "黄冈市"}, {value: "11", label: "咸宁市"}, {
      value: "12",
      label: "随州市"
    }, {value: "13", label: "恩施土家族苗族自治州"}, {value: "14", label: "省直辖县级行政区划"}, {value: "15", label: "仙桃市"}, {
      value: "16",
      label: "潜江市"
    }, {value: "17", label: "天门市"}, {value: "18", label: "神农架林区"}]
  }, {
    label: "湖南省",
    value: "18",
    children: [{value: "1", label: "长沙市"}, {value: "2", label: "株洲市"}, {value: "3", label: "湘潭市"}, {
      value: "4",
      label: "衡阳市"
    }, {value: "5", label: "邵阳市"}, {value: "6", label: "岳阳市"}, {value: "7", label: "常德市"}, {
      value: "8",
      label: "张家界市"
    }, {value: "9", label: "益阳市"}, {value: "10", label: "郴州市"}, {value: "11", label: "永州市"}, {
      value: "12",
      label: "怀化市"
    }, {value: "13", label: "娄底市"}, {value: "14", label: "湘西土家族苗族自治州"}]
  }, {
    label: "广东省",
    value: "19",
    children: [{value: "1", label: "广州市"}, {value: "2", label: "韶关市"}, {value: "3", label: "深圳市"}, {
      value: "4",
      label: "珠海市"
    }, {value: "5", label: "汕头市"}, {value: "6", label: "佛山市"}, {value: "7", label: "江门市"}, {
      value: "8",
      label: "湛江市"
    }, {value: "9", label: "茂名市"}, {value: "10", label: "肇庆市"}, {value: "11", label: "惠州市"}, {
      value: "12",
      label: "梅州市"
    }, {value: "13", label: "汕尾市"}, {value: "14", label: "河源市"}, {value: "15", label: "阳江市"}, {
      value: "16",
      label: "清远市"
    }, {value: "17", label: "东莞市"}, {value: "18", label: "中山市"}, {value: "19", label: "潮州市"}, {
      value: "20",
      label: "揭阳市"
    }, {value: "21", label: "云浮市"}]
  }, {
    label: "广西壮族自治区",
    value: "20",
    children: [{value: "1", label: "南宁市"}, {value: "2", label: "柳州市"}, {value: "3", label: "桂林市"}, {
      value: "4",
      label: "梧州市"
    }, {value: "5", label: "北海市"}, {value: "6", label: "防城港市"}, {value: "7", label: "钦州市"}, {
      value: "8",
      label: "贵港市"
    }, {value: "9", label: "玉林市"}, {value: "10", label: "百色市"}, {value: "11", label: "贺州市"}, {
      value: "12",
      label: "河池市"
    }, {value: "13", label: "来宾市"}, {value: "14", label: "崇左市"}]
  }, {
    label: "海南省",
    value: "21",
    children: [{value: "1", label: "海口市"}, {value: "2", label: "三亚市"}, {value: "3", label: "三沙市"}, {
      value: "4",
      label: "省直辖县级行政区划"
    }, {value: "5", label: "五指山市"}, {value: "6", label: "琼海市"}, {value: "7", label: "儋州市"}, {
      value: "8",
      label: "文昌市"
    }, {value: "9", label: "万宁市"}, {value: "10", label: "东方市"}, {value: "11", label: "定安县"}, {
      value: "12",
      label: "屯昌县"
    }, {value: "13", label: "澄迈县"}, {value: "14", label: "临高县"}, {value: "15", label: "白沙黎族自治县"}, {
      value: "16",
      label: "昌江黎族自治县"
    }, {value: "17", label: "乐东黎族自治县"}, {value: "18", label: "陵水黎族自治县"}, {
      value: "19",
      label: "保亭黎族苗族自治县"
    }, {value: "20", label: "琼中黎族苗族自治县"}]
  }, {label: "重庆市", value: "22", children: [{value: "1", label: "重庆市"}]}, {
    label: "四川省",
    value: "23",
    children: [{value: "1", label: "成都市"}, {value: "2", label: "自贡市"}, {value: "3", label: "攀枝花市"}, {
      value: "4",
      label: "泸州市"
    }, {value: "5", label: "德阳市"}, {value: "6", label: "绵阳市"}, {value: "7", label: "广元市"}, {
      value: "8",
      label: "遂宁市"
    }, {value: "9", label: "内江市"}, {value: "10", label: "乐山市"}, {value: "11", label: "南充市"}, {
      value: "12",
      label: "眉山市"
    }, {value: "13", label: "宜宾市"}, {value: "14", label: "广安市"}, {value: "15", label: "达州市"}, {
      value: "16",
      label: "雅安市"
    }, {value: "17", label: "巴中市"}, {value: "18", label: "资阳市"}, {value: "19", label: "阿坝藏族羌族自治州"}, {
      value: "20",
      label: "甘孜藏族自治州"
    }, {value: "21", label: "凉山彝族自治州"}]
  }, {
    label: "贵州省",
    value: "24",
    children: [{value: "1", label: "贵阳市"}, {value: "2", label: "六盘水市"}, {value: "3", label: "遵义市"}, {
      value: "4",
      label: "安顺市"
    }, {value: "5", label: "毕节市"}, {value: "6", label: "铜仁市"}, {value: "7", label: "黔西南布依族苗族自治州"}, {
      value: "8",
      label: "黔东南苗族侗族自治州"
    }, {value: "9", label: "黔南布依族苗族自治州"}]
  }, {
    label: "云南省",
    value: "25",
    children: [{value: "1", label: "昆明市"}, {value: "2", label: "曲靖市"}, {value: "3", label: "玉溪市"}, {
      value: "4",
      label: "保山市"
    }, {value: "5", label: "昭通市"}, {value: "6", label: "丽江市"}, {value: "7", label: "普洱市"}, {
      value: "8",
      label: "临沧市"
    }, {value: "9", label: "楚雄彝族自治州"}, {value: "10", label: "红河哈尼族彝族自治州"}, {
      value: "11",
      label: "文山壮族苗族自治州"
    }, {value: "12", label: "西双版纳傣族自治州"}, {value: "13", label: "大理白族自治州"}, {
      value: "14",
      label: "德宏傣族景颇族自治州"
    }, {value: "15", label: "怒江傈僳族自治州"}, {value: "16", label: "迪庆藏族自治州"}]
  }, {
    label: "西藏自治区",
    value: "26",
    children: [{value: "1", label: "拉萨市"}, {value: "2", label: "昌都地区"}, {value: "3", label: "山南地区"}, {
      value: "4",
      label: "日喀则地区"
    }, {value: "5", label: "那曲地区"}, {value: "6", label: "阿里地区"}, {value: "7", label: "林芝地区"}]
  }, {
    label: "陕西省",
    value: "27",
    children: [{value: "1", label: "西安市"}, {value: "2", label: "铜川市"}, {value: "3", label: "宝鸡市"}, {
      value: "4",
      label: "咸阳市"
    }, {value: "5", label: "渭南市"}, {value: "6", label: "延安市"}, {value: "7", label: "汉中市"}, {
      value: "8",
      label: "榆林市"
    }, {value: "9", label: "安康市"}, {value: "10", label: "商洛市"}]
  }, {
    label: "甘肃省",
    value: "28",
    children: [{value: "1", label: "兰州市"}, {value: "2", label: "嘉峪关市"}, {value: "3", label: "金昌市"}, {
      value: "4",
      label: "白银市"
    }, {value: "5", label: "天水市"}, {value: "6", label: "武威市"}, {value: "7", label: "张掖市"}, {
      value: "8",
      label: "平凉市"
    }, {value: "9", label: "酒泉市"}, {value: "10", label: "庆阳市"}, {value: "11", label: "定西市"}, {
      value: "12",
      label: "陇南市"
    }, {value: "13", label: "临夏回族自治州"}, {value: "14", label: "甘南藏族自治州"}]
  }, {
    label: "青海省",
    value: "29",
    children: [{value: "1", label: "西宁市"}, {value: "2", label: "海东市"}, {value: "3", label: "海北藏族自治州"}, {
      value: "4",
      label: "黄南藏族自治州"
    }, {value: "5", label: "海南藏族自治州"}, {value: "6", label: "果洛藏族自治州"}, {value: "7", label: "玉树藏族自治州"}, {
      value: "8",
      label: "海西蒙古族藏族自治州"
    }]
  }, {
    label: "宁夏回族自治区",
    value: "30",
    children: [{value: "1", label: "银川市"}, {value: "2", label: "石嘴山市"}, {value: "3", label: "吴忠市"}, {
      value: "4",
      label: "固原市"
    }, {value: "宁夏回族自治区", label: "中卫市"}]
  }, {
    label: "新疆维吾尔自治区",
    value: "31",
    children: [{value: "1", label: "乌鲁木齐市"}, {value: "2", label: "克拉玛依市"}, {value: "3", label: "吐鲁番地区"}, {
      value: "4",
      label: "哈密地区"
    }, {value: "5", label: "昌吉回族自治州"}, {value: "6", label: "博尔塔拉蒙古自治州"}, {value: "7", label: "巴音郭楞蒙古自治州"}, {
      value: "8",
      label: "阿克苏地区"
    }, {value: "9", label: "克孜勒苏柯尔克孜自治州"}, {value: "10", label: "喀什地区"}, {value: "11", label: "和田地区"}, {
      value: "12",
      label: "伊犁哈萨克自治州"
    }, {value: "13", label: "塔城地区"}, {value: "14", label: "阿勒泰地区"}, {value: "15", label: "自治区直辖县级行政区划"}, {
      value: "16",
      label: "石河子市"
    }, {value: "17", label: "阿拉尔市"}, {value: "18", label: "图木舒克市"}, {value: "19", label: "五家渠市"}]
  }, {
    label: "台湾省",
    value: "32",
    children: [{value: "1", label: "台北市"}, {value: "2", label: "高雄市"}, {value: "3", label: "基隆市"}, {
      value: "4",
      label: "台中市"
    }, {value: "5", label: "台南市"}, {value: "6", label: "新竹市"}, {value: "7", label: "嘉义市"}, {value: "8", label: "省直辖"}]
  }, {
    label: "香港特别行政区",
    value: "33",
    children: [{value: "1", label: "香港岛"}, {value: "2", label: "九龙"}, {value: "3", label: "新界"}]
  }, {
    label: "澳门特别行政区",
    value: "34",
    children: [{value: "1", label: "澳门半岛"}, {value: "2", label: "澳门离岛"}, {value: "3", label: "无堂区划分区域"}]
  }],
}
