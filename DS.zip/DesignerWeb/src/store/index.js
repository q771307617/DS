import Vue from 'vue';
import Vuex from 'vuex';
import User from './User';   //用户模块
import Modal from './Modal'; //弹窗模块
import pub from './public';  //弹窗模块
import Lists from './Lists'; //各种下拉框的数据
import refund from './refund';//退款信息

//文件导出内容
Vue.use(Vuex);

let Store = new Vuex.Store({
  modules: {
    User,
    Modal,
    pub,
    Lists,
    refund
  }
});
export default Store; 