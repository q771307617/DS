import { user } from '@/sessionstorage/index'
export default {
    info: user.get() || {},
    defaultSrc: 'http://3.img.dianjiangla.com/assets/icon/loading.png',
    ftpPath: "http://2.img.dianjiangla.com/assets/",
    code: '',
    phone: '',
    /** 专属客服信息配置-雇主后台，左侧底部。 */
    customServiceinfo:{phone:'',weChat:'',QQ:''}
};