import * as t from './mutation-types.js';
import { user } from '@/sessionstorage/index'
export default {
	// 退出登录
	[t.OUT_LOGIN](state) {
		state.userInfo = { name: "" };
		state.login = false;
	},
	[t.RECORD_USERINFO](state, info) {
		state.userInfo = info;
		state.login = true;
	},
	[t.SET_USER_DATA](state, data) {
		state.info = data;
		user.set(data)
	},
	[t.VERIFYINFO](state, { code, phone }) {
		state.code = code;
		state.phone = phone;
	},
	[t.CUSTOM_SERVICE_INFO](state,data) {
		data.map((i) => {
			if (i.key == "supermanage_qq") {
				state.customServiceinfo.QQ = i.value
			}
			if (i.key == "supermanage_phone") {
				state.customServiceinfo.phone = i.value
			}
			if (i.key == "supermanage_wechat") {
				state.customServiceinfo.weChat = i.value
			}
		})
	}
}