export const OUT_LOGIN = 'OUT_LOGIN';
export const RECORD_USERINFO = 'RECORD_USERINFO';
export const USER_REFRESH = 'USER_REFRESH';
export const LOGIN = 'login';
export const SET_USER_DATA = 'set_user_data'
export const VERIFYINFO = 'verifyinfo'
export const CUSTOM_SERVICE_INFO = 'customServiceinfo'