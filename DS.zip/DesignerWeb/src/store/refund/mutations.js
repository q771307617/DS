export default {
	setRefund(state, { step, info }) {
		state.step = step;
		state.info = info;
	}
}