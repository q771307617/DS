export default {
    info: {},
    step: ''
};