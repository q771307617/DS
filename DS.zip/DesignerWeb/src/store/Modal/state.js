export default {
    acct_visible: false,
    eval_visible: false,
    payment_visible: false,
    recharge_visible:false,
    demand_visible: false,
    loginModal: false,
    resetModal: false,
    verifyModal: false
};