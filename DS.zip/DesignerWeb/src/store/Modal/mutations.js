import {
	SETTING_ACCT_VISIBLE,
	SETTING_EVAL_VISIBLE,
	SETTING_PAYMENT_VISIBLE,
	SETTING_DEMAND_VISIBLE,
	SETTING_LOGIN_MODAL,
	SETTING_RESET_MODAL,
	SETTING_RECHARGE_VISIBLE,
	SETTING_VERIFY_USER_MODAL
} from './mutation-types.js';

export default {
	[SETTING_ACCT_VISIBLE](state, value) {
		state.acct_visible = value;
	},
	[SETTING_EVAL_VISIBLE](state, value) {
		state.eval_visible = value;
	},
	[SETTING_PAYMENT_VISIBLE](state, value) {
		state.payment_visible = value;
	},
	[SETTING_RECHARGE_VISIBLE](state, value) {
		state.recharge_visible = value;
	},
	[SETTING_DEMAND_VISIBLE](state, value) {
		state.demand_visible = value;
	},
	[SETTING_LOGIN_MODAL](state, value) {
		state.loginModal = value;
		state.resetModal = false;
		state.verifyModal = false;
	},
	[SETTING_RESET_MODAL](state, value) {
		state.resetModal = value;
		state.loginModal = false;
		state.verifyModal = false;
	},
	[SETTING_VERIFY_USER_MODAL](state, value) {
		state.verifyModal = value;
		state.resetModal = false;
		state.loginModal = false;
	}
}