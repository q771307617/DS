<template>
  <div>
      {{number}}
  </div>
</template>

<script>
export default {
  data() {
    return {
      number: 111
    };
  },

  beforeCreate: function() {
    console.log('beforeCreate 钩子执行...');
    console.log(this.number);
  },
  cteated: function() {
    console.log('cteated 钩子执行...');
    console.log(this.number);
  },
  beforeMount: function() {
    console.log('beforeMount 钩子执行...');
    console.log(this.number);
  },
  mounted: function() {
    console.log('mounted 钩子执行...');
    console.log(this.number);
  },
  beforeUpdate: function() {
    console.log('beforeUpdate 钩子执行...');
    console.log(this.number);
  },
  updated: function() {
    console.log('updated 钩子执行...');
    console.log(this.number);
  },
  beforeDestroy: function() {
    console.log('beforeDestroy 钩子执行...');
    console.log(this.number);
  },
  destroyed: function() {
    console.log('destroyed 钩子执行...');
    console.log(this.number);
  }
};
</script>
