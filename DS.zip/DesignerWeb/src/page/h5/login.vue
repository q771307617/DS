<template>
  <div class="h5-container">
    <!--头部  -->
    <div class="h5-header">
      <a class="btn" href="/">
        < </a>
          登录
    </div>

    <!--logo  -->
    <div class="h5-logo">
      <img src="http://1.img.dianjiangla.com/assets/h5/logo.png" alt="点将啦">
    </div>

    <!--表单  -->
    <div class="h5-form">
      <div class="h5-input">
        <div class="icon" style="background-image: url(http://1.img.dianjiangla.com/assets/h5/username.png);">
        </div>
        <input type="text" placeholder="手机号" class="input" v-model="username">
      </div>

      <div class="h5-input">
        <div class="icon" style="background-image: url(http://1.img.dianjiangla.com/assets/h5/password.png);">
        </div>
        <input type="password" placeholder="密码" class="input" v-model="password" @keyup.enter="submit">
      </div>

      <p style="font-size: 24px;margin-top: -.296rem;text-align: right;">
        <a href="javascript:;" style="color: #f54203;">忘记密码</a>
      </p>
      <p v-if="msg" :class="{'err-msg':msg}">{{msg}}</p>
      <button type="button" class="btn primary" :class="{'err-msg':msg}" @click="submit">登录</button>
    </div>

    <!--顶部  -->
    <div class="h5-footer">没有账号？
      <a href="/user/register">立即注册</a>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      username: '',
      password: '',
      msg: ''
    };
  },
  methods: {
    submit() {
      const username = this.username;
      if (!username || !/^1[34578]\d{9}$/.test(username)) {
        this.msg = '请输入11位数字的手机号';
        return;
      }

      const password = this.password.trim();
      if (!password || password.length < 6 || password.length > 20) {
        this.msg = '请输入6-20位数字、字母组合的密码';
        return;
      }

      this.$ajax.post('auth/login', { username, password, type: 2 }).then(e => {
        if (e.status !== 200) {
          this.msg = e.msg;
          return;
        }

        this.msg = '';
        const redirect = this.$route.query.redirect;
        location.href = (redirect && decodeURIComponent(redirect)) || '/';
      });
    }
  }
};
</script>
<style scoped>

</style>

