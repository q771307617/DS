<template>
  <div class="h5-container">
    <!--头部  -->
    <div class="h5-header">
      <a class="btn" href="/">
        < </a>
          注册
    </div>

    <!--logo  -->
    <div class="h5-logo">
      <img src="http://1.img.dianjiangla.com/assets/h5/logo.png" alt="点将啦">
    </div>

    <!--表单  -->
    <div class="h5-form">
      <div class="h5-input">
        <div class="icon" style="background-image: url(http://1.img.dianjiangla.com/assets/h5/username.png);">
        </div>
        <input type="tel" placeholder="手机号" class="input" v-model="username" maxlength="11">
      </div>

      <div class="h5-input" v-if="needVerifycode">
        <div class="icon" style="background-image: url(http://1.img.dianjiangla.com/assets/h5/code1.png);">
        </div>
        <input type="text" placeholder="验证码" class="input" v-model="verifycode" maxlength="4">
        <img :src="verifycodeUrl" alt="" @click="fetchCodeImg" class="verifycode">
      </div>

      <div class="h5-input">
        <div class="icon" style="background-image: url(http://1.img.dianjiangla.com/assets/h5/code.png);">
        </div>
        <input type="text" placeholder="验证码" class="input" v-model="code" maxlength="6">
        <a href="javascript:;" style="font-size: 16px;white-space: nowrap;padding: 0 .463rem;line-height: 1.37rem;" @click="sendCode" v-if="codeIntervalTime === 60">发送验证码</a>
        <a href="javascript:;" class="disabled" style="font-size: 16px;white-space: nowrap;padding: 0 .463rem;line-height: 1.37rem;" v-else>{{codeIntervalTime}}s后再获取</a>
      </div>

      <div class="h5-input" style="margin-bottom: 0">
        <div class="icon" style="background-image: url(http://1.img.dianjiangla.com/assets/h5/password.png);">
        </div>
        <input type="password" placeholder="密码（6-11位字母、数字、无空格）" class="input" v-model="password" maxlength="11" @keyup.enter="submit">
      </div>
      <p v-if="msg || successMsg" :class="[msg ? 'err-msg' : 'success']">{{msg || successMsg}}</p>

      <button type="button" class="btn primary" :class="{'err-msg':msg,'success':successMsg}" @click="submit">注册查看设计师简历</button>
    </div>

    <!--顶部  -->
    <div class="h5-footer">已有账号？
      <a href="/user/login">立即登录</a>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      username: '',
      verifycode: '',
      code: '',
      password: '',
      msg: '',
      verifycodeUrl: '',
      codeIntervalTime: 60,
      update: 0,
      needVerifycode: false,
      successMsg: ''
    };
  },
  mounted() {
    this.fetchCodeImg();
  },
  destroyed() {
    clearInterval(this.update);
  },
  watch: {
    codeIntervalTime(val) {
      if (!val) {
        this.codeIntervalTime = 60;
        clearInterval(this.update);
      }
    }
  },
  methods: {
    fetchCodeImg() {
      this.verifycodeUrl = this.$ajax.getVerifyCode();
    },

    async sendCode() {
      const result = await this.verifyUsername();
      if (!result) return; // 验证不通过

      this.codeIntervalTime--;
      this.update = setInterval(() => {
        this.codeIntervalTime--;
      }, 1000);

      this.$ajax
        .post('auth/sendcode', {
          phone: this.username,
          verifycode: this.verifycode
        })
        .then(e => {
          if (e.status !== 200) {
            this.needVerifycode = true;
            this.msg = this.verifycode ? '验证码错误' : '请输入验证码';
            this.codeIntervalTime = 60;
            clearInterval(this.update);
            return;
          }

          this.msg = '';
          this.code = e.data;
          this.successMsg = '验证码已发送，注意查收';
        });
    },

    submit() {
      if (!this.verifyPassword()) return; //密码格式不正确

      this.$ajax
        .post('auth/register', {
          phone: this.username,
          code: this.code,
          password: this.password,
          type: 2,
          username: this.username
        })
        .then(e => {
          if (e.status !== 200) {
            this.msg = e.msg;
            return;
          }

          location.href = '/user/login';
        });
    },

    verifyUsername() {
      let _this = this;
      return new Promise((resolve, reject) => {
        if (!/^1[34578]\d{9}$/.test(this.username)) {
          _this.msg = '请输入11位数字的手机号';
          return resolve(null);
        }

        this.$ajax.get('auth/isexist', { username: this.username }).then(e => {
          if (e.status !== 200) {
            _this.msg = '该手机号已注册';
            return resolve(false);
          }

          _this.msg = '';
          resolve(true);
        });
      });
    },

    verifyPassword() {
      const password = this.password.trim();
      if (!password || password.length < 6 || password.length > 11) {
        this.msg = '请输入6-11位数字、字母组合的密码';
        return;
      }

      this.msg = '';
      return true;
    }
  }
};
</script>
<style scoped>

</style>

