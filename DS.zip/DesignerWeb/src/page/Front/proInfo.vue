<template>
    <div class="proinfo bg">
        <div class="con marginauto1280 clearfix">
            <div class="top clearfix">
                <ul class="desc float-left">
                    <li>{{infoData.storeName}}</li>
                    <li>
                        <a @click="setProinfo(e)" :class="e.id == proinfo.id ? 'active':''" class="wsl-btn-tag-style" href="javascript:;" v-for="e in designerWorkProductList" :key="e.id">{{e.name}}</a>
                    </li>
                    <li>本案例由{{userData.nickname}}原创，未经作者许可，禁止转载或商业使用。</li>
                    <li>上传时间：{{infoData.create_time_value}}</li>
                </ul>
                <div class="psl-info float-right">
                    <p>
                        <span class="marginright10">{{userData.nickname}}</span>
                        <span>
                            <img :src="`icon/female.png` | randomPath" alt="女" v-if="userData.gender">
                            <img :src="`icon/male.png` | randomPath" alt="男" v-else>
                        </span>
                        <img :src="`icon/security.png` | randomPath" alt="保障">
                        <img :src="`icon/certification.png` | randomPath" alt="平台认证">
                    </p>
                    <p>{{userData.gender == 1 ? '女':'男'}}&nbsp;&nbsp;{{userData.age}}岁&nbsp;&nbsp;{{userData.city}}</p>
                    <p>薪资：{{userData.salary}}/月</p>
                    <p class="margintop10">
                        <Button class="btn btn1" @click="go">查看简历</Button>
                        <Dropdown v-if="info.id" class="dropitem">
                            <Button long type="warning" class="btn btn2">
                                联系{{userData.gender == 1 ? '她':'他'}}
                                <Icon type="arrow-down-b"></Icon>
                            </Button>
                            <Dropdown-menu slot="list">
                                <Dropdown-item v-if="userData.phone">
                                    电话：</Icon>&nbsp;&nbsp;{{userData.phone}}
                                </Dropdown-item>
                                <Dropdown-item v-if="userData.qq">
                                    QQ：</Icon>&nbsp;&nbsp;{{userData.qq}}
                                    <Button type="ghost" size="small" :data-clipboard-text="userData.qq" class="copyBtn">复制</Button>
                                </Dropdown-item>
                            </Dropdown-menu>
                        </Dropdown>
                        <Button type="error" @click="login" v-else class="btn btn2">联系{{userData.gender == 1 ? '她':'他'}}</Button>
                    </p>
                </div>
                <div class="float-right marginright25">
                    <img :src="userData.image_url+'!140x169'" height="165px" width="140px" alt="">
                </div>
            </div>
            <div v-if="proinfo.details" class="btm">
                <p class="font16 proname">{{proinfo.tag}}</p>
                <div class="btm-con" v-html="proinfo.details" style="overflow:hidden;line-height:0;"></div>
                <p class="ckjl">
                    <Button @click="go">
                        <Icon type="ios-eye-outline" class="font38"></Icon>
                        <span class="font20 float-left">&nbsp;查看简历</span>
                    </Button>
                </p>
            </div>
            <h3 v-else class="text-center message">该作者很懒，还没有上传作品！</h3>
        </div>
        <div class="ivu-modal-mask" v-if="registerModal"></div>
        <div class="ivu-modal-wrap" v-if="registerModal">
            <Register :cancle="cancle"></Register>
        </div>
    </div>
</template>

<script>
import Register from '@/components/register.vue';
import router from '@/router/index.js';
import moment from 'moment';
import { mapState } from 'vuex';
export default {
  data() {
    return {
      infoData: {},
      userData: {},
      registerModal: false,
      designerWorkProductList: [],
      proinfo: {
        id: '',
        details: '',
        name: '',
        tag: ''
      }
    };
  },
  computed: {
    ...mapState({
      defaultSrc: state => state.User.defaultSrc,
      info: state => state.User.info,
      ftpPath: state => state.User.ftpPath
    })
  },
  components: {
    Register
  },
  mounted() {
    this.getinfo();
    let _this = this;
    // eslint-disable-next-line
    let clipboard = new Clipboard('.copyBtn');
    clipboard.on('success', function(e) {
      _this.$Message.info('已复制');
      e.clearSelection();
    });
  },
  methods: {
    setProinfo(e) {
      this.proinfo.id = e.id;
      this.proinfo.details = e.details;
      this.proinfo.name = e.name;
      this.proinfo.tag = e.tag;
    },
    go() {
      this.$router.push({
        name: 'detailForDesigner',
        params: {
          id: this.infoData.user_id
        }
      });
    },
    login() {
      window.location.href = `/user/login?redirect=${encodeURIComponent(
        location.pathname
      )}`;
      // this.$store.commit('SETTING_LOGIN_MODAL', true);
    },
    cancle() {
      this.registerModal = false;
    },
    loginout() {
      this.$store.commit('set_user_data', {});
      //  this.$root.$emit("LOGIN_OUT");
      this.$ajax.post('auth/logout').then(e => {});
    },
    phoneModal() {
      let id = this.infoData.user_id;
      this.$router.push({
        name: 'detailForDesigner',
        params: {
          id
        }
      });
    },
    getinfo() {
      const id = this.$route.params.id;
      const designerWorkId = this.$route.params.designerWorkId;
      if (!id && !designerWorkId) return;
      this.$ajax
        .get('product/get', {
          id: id,
          designerWorkId: designerWorkId
        })
        .then(e => {
          if (e.status != 200) {
            return;
          }
          if (e.data.create_time > 0) {
            e.data.create_time_value = moment(e.data.create_time).format(
              'YYYY-MM-DD hh:mm:ss'
            );
          }
          this.infoData = e.data;
          this.userData = e.data.user;
          this.storeName = e.data.storeName;
          if (e.data.designerWorkProductList == 'undefined') {
            let arrStr = [];
            arrStr['id'] = e.data.id;
            arrStr['tag'] = e.data.tag;
            arrStr['details'] = e.data.details;
            this.setProinfo(arrStr);
          } else {
            if (e.data.designerWorkProductList.length > 0) {
              this.designerWorkProductList = e.data.designerWorkProductList;
              if (id) {
                for (let k in this.designerWorkProductList) {
                  if (this.designerWorkProductList[k].id == id) {
                    this.setProinfo(this.designerWorkProductList[k]);
                  }
                }
              } else {
                this.setProinfo(this.designerWorkProductList[0]);
              }
            }
          }
        });
    },
    hirePage() {
      router.push({
        path: '/hire/' + this.infoData.user_id
      });
    }
  }
};
</script>
<style>
.bg {
  background: #eeeeee;
}

.proinfo {
  padding: 22px 0;
}

.marginauto1280 {
  margin: 0 auto;
  width: 1280px;
}

.proinfo .con {
  background: #eee;
  box-shadow: 0 0 10px #ccc;
}

.proinfo .con .top {
  padding: 45px 50px;
  background: #fff;
  margin-bottom: 25px;
}

.proinfo .con .top ul.desc li {
  width: 805px;
  line-height: 24px;
  height: 24px;
  overflow: hidden;
  font-size: 14px;
  color: #bababa;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.proinfo .con .top ul.desc li:first-child {
  font-size: 20px;
  color: #646464;
}

.proinfo .con .top ul.desc li:nth-child(2) {
  color: #888888;
  max-height: 70px;
  overflow: hidden;
  width: 806px;
  height: auto;
  margin-top: 28px;
}

.proinfo .con .top ul.desc li:nth-child(3) {
  margin-top: 37px;
}

.psl-info {
  margin-right: 30px;
}

.psl-info p {
  font-size: 14px;
  color: #888888;
}

.psl-info .ivu-select-dropdown {
  left: inherit !important;
}

.psl-info p:first-child {
  font-size: 16px;
  color: #646464;
  height: 88px;
  line-height: 130px;
}

.psl-info p .btn {
  height: 25px;
  line-height: 25px;
  width: 82px;
  border-radius: 2px;
  font-size: 14px;
}

.psl-info .btn {
  padding: 0;
}

.psl-info p .btn1 {
  color: #bababa;
}

.proinfo .con .btm {
  padding-top: 25px;
  background: #fff;
}

.ckjl {
  text-align: center;
  height: 170px;
  line-height: 170px;
}

.ckjl span:first-child {
  display: inline-flex;
  height: 30px;
  line-height: 30px;
}

.proinfo .con .btm .proname {
  padding-left: 50px;
  padding-right: 50px;
  height: 80px;
  line-height: 80px;
  color: #646464;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.proinfo .con .btm-con {
  text-align: center;
  overflow: hidden;
  line-height: 0;
  /*padding:0 245px;*/
  width: 100%;
  word-wrap: break-word;
}

.proinfo .con .btm-con img {
  max-width: 970px;
  min-width: 200px;
}

.psl-info .btn1:hover {
  border: 1px solid #d7dde4;
}

.psl-info .btn2 {
  border: 1px solid #f54203;
  background: #f54203;
}

.psl-info .btn2:hover {
  background: #f54203;
  border: 1px solid #f54203;
}

.psl-info .copyBtn {
  padding: 0 2px;
  float: right;
}

.wsl-btn-tag-style {
  margin-right: 33px;
  margin-top: 5px;
  padding: 0 10px;
  display: block;
  float: left;
  height: 28px;
  line-height: 28px;
  color: #646464;
  font-size: 14px;
}

.wsl-btn-tag-style:hover,
.wsl-btn-tag-style.active {
  background-color: #f54203;
  color: #fff;
  border-radius: 5px;
}
</style>

<style>
.ckjl .ivu-btn {
  height: 45px;
  line-height: 45px;
  width: 170px;
  background: #f54203;
  color: #fff;
  border: 1px solid #f54203;
  font-size: 20px;
}

.ckjl .ivu-icon {
  line-height: inherit;
}

.proinfo .con .top .dropitem .ivu-dropdown-item:hover,
.dropitem .ivu-btn-ghost.active,
.ivu-btn-ghost:active,
.dropitem .ivu-btn-ghost:hover {
  color: #f54203;
}

.dropitem .ivu-btn:hover,
.dropitem .ivu-btn-ghost.active,
.dropitem .ivu-btn-ghost:active {
  border-color: #f54203;
}

.dropitem .ivu-select-dropdown {
  min-width: 160px;
  margin: 0;
}

.dropitem .ivu-dropdown-item {
  padding: 3px 4px;
  line-height: 20px;
}

.dropitem .ivu-dropdown-item:hover {
  background: #fff;
}
</style>
