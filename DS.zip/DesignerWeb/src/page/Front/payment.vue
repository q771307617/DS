<template>
  <div class="container">
    <p class="font18 f54102">您的设计师工资将由点将啦网站作为托管，完结后转放给设计师，请放心支付！</p>
    <div style="display: flex;align-items: center;margin-top: 35px;margin-bottom: 10px;overflow: hidden;">
      <p class="font16 c646464" style="float: left;">订单提交成功后，请尽快付款！订单号：{{orderInfo.order_id}}</p>
      <Dropdown :visible="visible" style="margin-left: 20px;float: left;">
        <Button @click="handleOpen" type="ghost">
          订单详情
          <Icon type="arrow-down-b"></Icon>
        </Button>
        <Dropdown-menu slot="list">
          <p class="orderInfo-p">
            <span>订单号：</span>{{orderInfo.order_id}}</p>
          <p class="orderInfo-p">
            <span>设计师：</span>{{orderInfo.designer_name}}</p>
          <p class="orderInfo-p">
            <span>雇佣类型：</span>{{types[orderInfo.type]}}</p>
          <p class="orderInfo-p">
            <span>雇佣周期：</span>{{orderInfo.start_time | format('YYYY.M.DD')}}-{{orderInfo.end_time | format('YYYY.M.DD')}}</p>
          <p class="orderInfo-p">
            <span>应付金额：</span>{{orderInfo.price}}元</p>
          <p class="orderInfo-p">
            <span>制作内容：</span>{{orderInfo.invitation}}
          </p>
        </Dropdown-menu>
      </Dropdown>
    </div>
    <div class="order-tips" style="overflow: hidden;height:25px;line-height: 25px;margin-bottom:10px;">
      <div class="font14 c888888" style="float: left;">请您在提交订单后24小时内完成支付，否则订单会自动取消</div>
    </div>
    <div class="order-tips" style="overflow: hidden;height:40px;margin-bottom:10px;">
      <div class="font16 c646464">
        <!-- 邀请码：
                          <Input v-model="referralCode" placeholder="请输入..." style="width: 192px"></Input>
                          <Alert type="error" style="display: inline-block;" v-if="msg">{{msg}}</Alert> -->
      </div>
      <div class="font16 c646464" style="float: right;line-height: 40px;">
        <span>应付金额</span>
        <span class="font26 f54102">{{orderInfo.price}}</span>
        <span>元</span>
      </div>
    </div>
    <div style="background-color: #f5f7f7;border-radius: 8px;padding: 10px 5px;">
      <div class="row" style="overflow: hidden;">
        <label class="radio-box" style="float: left;">
          <div style="height: 34px;float:left;">
            <img :src="'icon/passlog.png' | randomPath" alt="账户余额支付" v-show="picked == '0'">
          </div>
          <div style="height: 38px;line-height: 45px;float:left;">
            <input type="radio" value="0" v-model="picked" v-show="picked != '0'">
          </div>
          <div style="height: 38px;line-height: 38px;float:left;">
            <span class="font16 fontBold c646464" style="margin: 0 30px;">账户可用余额 {{info.balance}} 元</span>
          </div>
          <div style="height: 38px;line-height: 38px;float:left;">
            <Button size="large" type="error" v-show="picked == '0'" @click="handleClick" :disabled="info.balance < orderInfo.price">确认余额支付</Button>
          </div>
        </label>
        <div style="float: right;height: 40px;line-height: 40px;" class="font16 c646464" v-show="picked == '0'">
          支付
          <span class="f54102">{{orderInfo.price}}</span>元
        </div>
      </div>
      <div class="row" style="overflow: hidden;">
        <label class="radio-box" style="float: left;">
          <div style="height: 38px;line-height: 38px;float:left;">
            <input type="radio" value="1" v-model="picked" v-show="picked != '1'">
          </div>
          <div style="height: 38px;line-height: 38px;float:left;">
            <img :src="'icon/passlog.png' | randomPath" alt="支付宝支付" v-show="picked == '1'">
          </div>
          <div style="height: 38px;line-height: 38px;float:left;">
            <img :src="'icon/zfb.png' | randomPath" alt="支付宝支付" style="margin: 0 30px;">
          </div>
          <div style="height: 38px;line-height: 38px;float:left;">
            <Button type="error" @click="goPayByAli" v-show="picked == '1'">立即跳转支付</Button>
          </div>
        </label>
        <div style="float: right;height: 40px;line-height: 40px;" class="font16 c646464" v-show="picked == '1'">支付
          <span class="f54102">{{orderInfo.price}}</span>元</div>
      </div>
      <div class="row" style="overflow: hidden;">
        <label class="radio-box" style="float: left;">
          <div style="height: 38px;line-height: 50px;float:left;">
            <input type="radio" value="2" v-model="picked" v-show="picked != '2' ">
          </div>
          <div style="height: 38px;line-height: 45px;float:left;">
            <img :src="'icon/passlog.png' | randomPath" alt="微信支付" v-show="picked == '2'" style="vertical-align: middle;">
          </div>
          <div style="height: 38px;line-height: 38px;float:left;">
            <img :src="'icon/wechat.png' | randomPath" alt="微信支付" style="margin: 0 7px 0 30px;vertical-align: middle;">
            <span class="font20 c646464">微信支付</span>
          </div>
          <div style="height: 38px;line-height: 38px;float:left;">
            <Button type="error" v-show="picked == '2'" @click="wechat" style="margin-left: 20px;">立即跳转支付</Button>
          </div>
        </label>
        <div style="float: right;height: 40px;line-height: 40px;" class="font16 c646464" v-show="picked == '2'">支付
          <span class="f54102">{{orderInfo.price}}</span>元</div>
      </div>
    </div>
    <div v-if="modal && picked =='0'" style="margin-top: 18px;">
      <p class="font16 c646464">账户余额支付密码</p>
      <Input v-model="password" type="password" style="width:192px"></Input>
      <p class="font14 c888888" style="margin: 11px 0 23px;">请在这里输入支付密码</p>
      <Button type="error" @click="ok" style="width:130px">确认付款</Button>
    </div>
  </div>
</template>
<style>
.vertical-center-modal {
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
<style scoped>
.container {
  width: 1280px;
  margin: 10px auto 0;
  padding: 40px 60px;
  border: 1px solid #dddee1;
}

.orderInfo-p {
  margin: 16px;
  font-size: 12px;
  color: #888888;
}

.order-tips {
  display: flex;
  justify-content: space-between;
}

.orderInfo-p span {
  width: 70px;
  display: inline-block;
  text-align: right;
}

.f54102 {
  color: #f54102;
}

.c888888 {
  color: #888888;
}

.c646464 {
  color: #646464;
}

.font26 {
  font-size: 26px;
}

.row {
  background-color: #fff;
  padding: 40px 26px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 116px;
  margin-bottom: 10px;
}

.row:last-child {
  margin-bottom: 0;
}

.flex-box {
  display: flex;
  align-items: center;
  width: 360px;
  justify-content: space-between;
}

.fontBold {
  font-weight: bold;
}

.radio-box {
  display: flex;
  align-items: center;
}

.radio-box input {
  margin: 0 10px;
}
</style>

<script>
import { mapState } from 'vuex';
export default {
  data() {
    return {
      password: '',
      referralCode: '',
      modal: false,
      picked: '1',
      orderInfo: {},
      visible: false,
      types: ['包月', '定制'],
      msg: ''
    };
  },
  mounted() {
    this.$ajax
      .get('hire/info', {
        hireId: this.$route.query.hireId
      })
      .then(e => {
        if (e.status == 200 && e.data) {
          this.orderInfo = e.data;
          return;
        }
        this.$router.push('/');
        this.$Message.error('订单不存在');
      });
  },
  computed: {
    ...mapState({
      info: state => state.User.info,
      ftpPath: state => state.User.ftpPath
    })
  },
  methods: {
    handleClick() {
      // 判断有没有设置支付密码
      if (this.info.pay_password) {
        this.modal = true;
        return;
      }
      let _this = this;
      this.$Modal.confirm({
        title: '提示',
        content: '你需要设置支付密码才能付款',
        onOk() {
          _this.$router.push({
            path: '/emloyerBackstage/settings'
          });
        }
      });
    },
    handleOpen() {
      this.visible = true;
    },
    handleClose() {
      this.visible = false;
    },
    ok(p) {
      // 余额支付
      if (!this.password) return;
      this.$ajax
        .get('pay/account', {
          id: this.orderInfo.order_id,
          password: this.password
        })
        .then(e => {
          if (e.status === 200) {
            this.$Message.success('支付成功');

            this.$router.push({
              name: 'employmentManagement'
            });
            return;
          }
          this.$Message.error(e.msg);
          this.msg = e.msg;
        });
    },
    goPayByAli() {
      if (!this.orderInfo.order_id) return;
      this.$ajax.payAli(this.orderInfo.order_id);
    },
    wechat() {
      // 微信支付
      if (!this.orderInfo.order_id) return;
      window.open(
        `/wechat/orderId?orderId=${this.orderInfo.order_id}&type=hire`
      );
      this.$Modal.confirm({
        title: '微信支付',
        content: '微信支付已完成？',
        onOk: () => {
          this.$router.push({ name: 'employmentManagement' });
        }
      });
    }
  }
};
</script>
