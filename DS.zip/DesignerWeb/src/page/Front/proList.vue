<template>
    <div class="container">
        <div class="main">
            <div class="filter-wrapper">
                <div class="filter">
                    <label class="">区域：</label>
                    <ul class="filter-ul">
                        <li :class="{active : !query.qy}">
                            <router-link :to="{ name: 'proList', query: { qy: '', lx: query.lx, jb: query.jb, lm: query.lm, sortStr: query.sortStr, name: query.name }}">不限</router-link>
                        </li>
                        <li v-for="item in typeList" :key="item.id" :class="{active : query.qy == item.id && query.qy !== ''}">
                            <router-link :to="{ name: 'proList', query: { qy: item.id ,lx: query.lx, jb: query.jb, lm: query.lm, sortStr: query.sortStr, name: query.name }}">{{item.name}}</router-link>
                        </li>
                    </ul>
                </div>
                <div class="filter">
                    <label class="">类目：</label>
                    <ul class="filter-ul">
                        <li :class="{active : !query.lm}">
                            <router-link :to="{ name: 'proList', query: { lm: '', qy: query.qy, lx: query.lx, jb: query.jb, sortStr: query.sortStr, name: query.name}}">不限</router-link>
                        </li>
                        <li v-for="item in childList4" :key="item.id" :class="{active : query.lm == item.id && query.lm !== ''}">
                            <router-link :to="{ name: 'proList', query: { lm: item.id, qy: query.qy, lx: query.lx, jb: query.jb, sortStr: query.sortStr, name: query.name}}">{{item.name}}</router-link>
                        </li>
                    </ul>
                </div>
                <div class="filter">
                    <label class="">级别：</label>
                    <ul class="filter-ul">
                        <li :class="{active : !query.jb}">
                            <router-link :to="{ name: 'proList', query: { jb: '', qy: query.qy, lx: query.lx, lm: query.lm, sortStr: query.sortStr, name: query.name}}">不限</router-link>
                        </li>
                        <li v-for="item in types.workyears" :key="item.id" :class="{active : query.jb == item.value && query.jb !== ''}">
                            <router-link :to="{ name: 'proList', query: { jb: item.value, qy: query.qy, lx: query.lx, lm: query.lm, sortStr: query.sortStr, name: query.name}}">{{item.label}}</router-link>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="pro-list-wrapper">
                <ul class="products-ul" v-if="products.length">
                    <li v-for="product in products" :key="product.id" style="overflow:hidden;">
                        <div class="product-image">
                            <router-link :to="{ name: 'proInfo', params: { id: product.id}}" target="_blank">
                                <img :src="product.image_url+'!288x310'" :alt="product.name">
                            </router-link>
                        </div>
                        <div style="padding: 17px 20px 20px;border-top: 1px solid #efefef;">
                            <div style="font-size: 14px;color: #646464;overflow: hidden;text-overflow:ellipsis;white-space:nowrap;" :title="product.name">{{product.name}}</div>
                            <div style="font-size: 12px;color: #bbbbbb;overflow: hidden;text-overflow:ellipsis;white-space:nowrap;" :title="product.tag">{{product.tag}}</div>
                        </div>
                        <router-link :to="{ name: 'detailForDesigner', params: { id: product.user_id}}" target="_blank">
                            <div class="designer">
                                <div class="avatar">
                                    <img :src="product.designer_image_url" :alt="product.designer_name" width="100%" height="100%">
                                </div>
                                <div style="float: left;">
                                    <div style="margin-top: 4px;">
                                        <span style="color: #646464;">{{product.designer_name}}</span>&nbsp;&nbsp;
                                        <span class="icon">
                                            <img :src="'icon/security.png' | randomPath" alt="平台保障">
                                        </span>&nbsp;&nbsp;
                                        <span class="icon" style="margin-left: -7px;">
                                            <img :src="'icon/certification.png' | randomPath" alt="平台认证">
                                        </span>
                                    </div>
                                    <div style="width:200px;font-size: 14px;color: #888888;overflow: hidden;text-overflow:ellipsis;white-space:nowrap;">
                                        {{product.skilful | SKILLFULL_LIST_TEXT(childList4, ' | ')}}
                                    </div>
                                </div>
                            </div>
                        </router-link>
                    </li>
                </ul>
                <h3 v-else class="text-center message">没有找到符合条件的作品</h3>
            </div>
            <page :current="pageNum" :pageSize="pageSize" :total="total" v-on:on-change="paging"></page>
        </div>
        <div class="ivu-modal-mask" v-if="registerModal"></div>
            <div class="ivu-modal-wrap" v-if="registerModal">
            <Register :cancle="cancle"></Register>
        </div>
    </div>
</template>
<script>
import * as types from '@/constant';
import { mapState } from 'vuex';
import page from '@/components/page';
import Register from '@/components/register.vue';
let expRate = [
  {},
  { expStart: 0.5, expEnd: 1 },
  { expStart: 1, expEnd: 1.5 },
  { expStart: 1.5, expEnd: 2 },
  { expStart: 2, expEnd: 3 },
  { expStart: 3, expEnd: '' }
];
export default {
  components: { page, Register },
  data() {
    return {
      registerModal: false,
      types: types,
      items: [],
      products: [],
      total: 0,
      pageNum: 1,
      pageSize: 20,
      query: this.$route.query
    };
  },
  mounted() {
    // this.cancle()
    this.fetchData();
    let isLogin = this.$route.query.isLogin;
    if (isLogin && !this.userInfo.id) {
      if (isLogin == 1) {
        this.login();
      } else if (isLogin == 2) {
        this.registerModal = true;
      }
    }
  },
  computed: {
    ...mapState({
      typeList: state => state.Lists.typeList,
      companyList: state => state.Lists.companyList, //公司分类
      parentList: state => state.Lists.parentList, //父分类
      childList4: state => state.Lists.childList4, //子分类
      defaultSrc: state => state.Lists.defaultSrc,
      ftpPath: state => state.User.ftpPath,
      userInfo: state => state.User.info
    })
  },
  methods: {
    cancle() {
      this.registerModal = false;
    },
    fetchData() {
      this.pageNum =
        (this.$route.query.pageNum && parseInt(this.$route.query.pageNum)) || 1;
      this.query = this.$route.query;
      // this.pageNum = this.$route.query.pageNum && parseInt(this.$route.query.pageNum) || 1;
      let expStart = (this.query.jb && expRate[this.query.jb].expStart) || '';
      let expEnd = (this.query.jb && expRate[this.query.jb].expEnd) || '';
      this.$ajax
        .get('product/list', {
          expStart,
          expEnd,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          classIds: this.query.lm,
          state: this.query.lx,
          typeId: this.query.qy,
          name: this.query.name
        })
        .then(e => {
          if (e.status === 200) {
            this.products = e.data.list;
            this.total = e.data.count;
          } else {
            this.products = [];
            this.total = 0;
            this.pageNum = 1;
          }
        });
    },
    login() {
      window.location.href = `/user/login?redirect=${encodeURIComponent(
        location.pathname
      )}`;
      // this.$store.commit('SETTING_LOGIN_MODAL', true);
    },
    paging(p) {
      this.pageNum = p;
      this.$router.push({
        name: 'proList',
        query: {
          ...this.$route.query,
          pageNum: p
        }
      });
    }
  },
  watch: {
    // 如果路由有变化，会再次执行该方法
    $route: 'fetchData'
  }
};
</script>

<style scoped>
.wsl-page-btn-style {
  overflow: hidden;
  padding-top: 5px;
}

.wsl-page-btn-style div {
  float: left;
  height: 23px;
  line-height: 23px;
  color: #c0c0c0;
  margin: 0 5px;
}

.wsl-page-btn-style a {
  display: block;
  width: 45px;
  height: 23px;
  line-height: 23px;
  text-align: center;
  border: 1px solid #dddee1;
  font-size: 12px;
  color: #3c3c3c;
}

.container {
  background-color: #f8f8f8;
  /*margin-top: 20px;*/
  padding-top: 20px;
  margin-bottom: -20px;
}

.main {
  width: 1280px;
  margin: 0 auto;
  /*padding: 10px 20px;*/
  padding-bottom: 20px;
  background-color: #f8f8f8;
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
  font-size: 14px;
}

.filter-wrapper {
  margin-bottom: 10px;
}

.filter {
  padding-bottom: 10px;
  background-color: #fff;
  padding: 10px 20px;
  border-bottom: 1px solid #e9eaec;
}

.filter > label {
  font-size: 16px;
  color: #474747;
  line-height: 31px;
}

.filter-ul {
  display: inline-block;
  width: 1180px;
  vertical-align: top;
}

.filter-ul > li {
  padding: 0 15px;
  display: inline-block;
  height: 31px;
  line-height: 31px;
}

li > a {
  color: #807f7f;
}

.filter-ul > li.active {
  background-color: #ed3f14;
  border-radius: 4px;
}

.filter-ul > li.active a {
  color: #fff;
}

.products-ul li {
  width: 290px;
  margin: 20px;
  display: inline-block;
  border: 1px solid #efefef;
  background-color: #fff;
}

.products-ul li:nth-child(4n + 1) {
  margin-left: 0;
}

.products-ul li:nth-child(4n) {
  margin-right: 0;
}

.product-image {
  overflow: hidden;
  height: 310px;
}

img {
  width: 100%;
}

.designer {
  padding: 12px 17px;
  border-top: 1px solid #efefef;
  overflow: auto;
  zoom: 1;
}

.avatar {
  width: 37px;
  height: 45px;
  overflow: hidden;
  margin-right: 15px;
  float: left;
}

.icon {
  display: inline-block;
  height: 21px;
  vertical-align: middle;
}

.icon img {
  width: 17px;
  height: 17px;
}
</style>
