<template>
    <div class="backgroundcontent">
        <suspensionframe></suspensionframe>
        <div class="container">
            <Breadcrumb separator=">" class="minnav">
                您的位置：
                <a href="/">点将啦</a><span style="margin:0 10px;">></span>
                <!-- <Breadcrumb-item href="/">点将啦</Breadcrumb-item> -->
                <Breadcrumb-item href="/search/designer">推荐设计师</Breadcrumb-item>
                <Breadcrumb-item>设计师{{designer.nickname}}的简历</Breadcrumb-item>
            </Breadcrumb>
            <div class="main content" style="height:270px;">
                <Row :gutter="16">
                    <Col span="4">
                    <div class="u_image">
                        <img :src="designer.image_url+'!185x221'" :alt="designer.nickname">
                    </div>
                    </Col>
                    <Col span="13">
                    <div class="wsl_font18" style="margin-top:10px;">
                        <span class="font20 marginright10">姓名：{{designer.realname | replaceName}} {{"("+designer.nickname+")"}}</span>
                        <span class="deposit" v-if="designer.deposit">保</span>
                    </div>
                    <div class="row">
                        <Row class="wsl_font12">
                            <Col span="6">工作经验：{{designer.exp}}年</Col>
                            <Col span="18">擅长类目：{{designer.skilful| SKILLFULL_LIST_TEXT(childList4)}}</Col>
                        </Row>
                    </div>
                    <div class="row">
                        <Row tppe="flex" justify="space-around" align="middle" class-name="border-area border-bottom0 wsl_height53 star-style">
                            <Col span="8">
                            <div style="float:left;line-height:32px;">
                                <div class="wsl_font12">服务态度：</div>
                            </div>
                            <Rate disabled allow-half v-model="valueDisabled"></Rate>
                            </Col>
                            <Col span="8">
                            <div style="float:left;line-height:32px;">
                                <div class="wsl_font12">设计能力：</div>
                            </div>
                            <Rate disabled allow-half v-model="valueDisabled"></Rate>
                            </Col>
                            <Col span="8">
                            <div style="float:left;line-height:32px;">
                                <div class="wsl_font12">响应速度：</div>
                            </div>
                            <Rate disabled allow-half v-model="valueDisabled"></Rate>
                            </Col>
                        </Row>
                        <div class="border-area  border-bottom0 wsl_icon">
                            <ul>
                                <li>
                                    <router-link to="/rules?index=1" target="_blank">
                                        <img :src="'icon/rz.png' | randomPath" class="img14">
                                        <div>平台自营设计师</div>
                                    </router-link>
                                </li>
                                <li>
                                    <router-link to="/rules?index=1" target="_blank">
                                        <img :src="'icon/bz_icon.png' | randomPath" class="img14">
                                        <div>官方平台保障</div>
                                    </router-link>
                                </li>
                                <li>
                                    <router-link to="/rules?index=3" target="_blank">
                                        <img :src="'icon/num3.png' | randomPath" class="img14">
                                        <div>包月三天无理由退款</div>
                                    </router-link>
                                </li>
                            </ul>
                        </div>
                        <div class="border-area" style="padding: 20px;">
                            个人介绍：{{designer.description}}
                        </div>
                    </div>
                    </Col>
                    <Col span="7" style="border-left:1px solid #e9eaec;height:251px;">
                    <div style="font-size: 16px; color: #807f7f;text-align:center;margin-top:30px;">
                        <span>月薪要求：</span>
                        <span style="font-size: 28px; color: #f54203;">{{designer.salary}}</span>
                        <span>元/月</span>
                    </div>
                    <div class="row" style="text-align:center;margin-top:10px;">
                        <Button style="width:240px;height:50px;background:#f54203;font-size:22px;" type="warning" long @click="hire" v-if="info.id">立即雇佣</Button>
                        <Button style="width:240px;height:50px;background:#f54203;font-size:22px;" type="warning" long @click="login" v-else>立即雇佣</Button>
                    </div>
                    <div class="row" style="text-align:center;">
                        <Dropdown v-if="info.id" class="drop">
                            <Button long type="warning" style="width:240px;height:50px;font-size:22px;background-color:#feece5;border-color:#f54203;color:#f54203;border-radius: inherit;">
                                查看联系方式
                                <Icon type="arrow-down-b"></Icon>
                            </Button>
                            <Dropdown-menu slot="list" style="width:240px;background-color:#fff;">
                                <Dropdown-item>ＱＱ:&nbsp;&nbsp;{{ContractInfo.qq}}
                                    <Button type="ghost" size="small" :data-clipboard-text="ContractInfo.qq" class="copyBtn">复制</Button>
                                </Dropdown-item>
                                <Dropdown-item>电话:&nbsp;&nbsp;{{ContractInfo.phone}}</Dropdown-item>
                            </Dropdown-menu>
                        </Dropdown>
                        <Button style="width:240px;height:50px;font-size:22px;background-color:#feece5;border-color:#f54203;color:#f54203;" type="error" long @click="login" v-else>查看联系方式</Button>
                    </div>
                    </Col>
                </Row>
            </div>
            <div class="divider-area">
                <span style="color:#64646;">服务过的网店：</span>
                <span style="margin:0 10px;" v-for="item in designer.stores && designer.stores.split(',')" :key="item">{{item}}</span>
            </div>
            <div class="row main tabitem">
                <p style="overflow:hidden;border-bottom: 1px solid #dddee1;">
                    <a href="javascript:;" name="tab1" class="tab" style="border-bottom:3px solid #f54203;color:#f54203;" @click="jump('tab1')">个性简历</a>
                    <a href="javascript:;" name="tab2" class="tab" style="color:#888888" @click="jump('tab2')">服务记录</a>
                    <a href="javascript:;" name="tab3" class="tab" style="color:#888888" @click="jumpTo()">相关作品</a>
                </p>
                <resume class="wsl_btm_con" :htmlStr="htmlStr" ref="tab1" style="text-align:center;padding:25px 0;overflow:hidden;line-height:0;"></resume>
            </div>
            <div class="row main tabitem">
                <experience ref="tab2" style="padding:10px"></experience>
            </div>
            <div class="row main tabitem">
                <works ref="tab3" :designerid="designer.user_id" style="padding:10px"></works>
            </div>
        </div>
        <!--登录注册-->
        <div class="ivu-modal-mask" v-if="registerModal"></div>
        <div class="ivu-modal-wrap" v-if="registerModal">
            <Register :cancle="cancle"></Register>
        </div>
    </div>
</template>
<script>
import * as types from '@/constant';
import Register from '@/components/register.vue';
import resume from '@/components/resume';
import experience from '@/components/experience';
import works from '@/components/works';
import { mapState } from 'vuex';
import suspensionframe from '@/components/suspensionframe';
export default {
  components: {
    resume,
    experience,
    works,
    suspensionframe,
    Register
  },
  data() {
    return {
      ContractInfo: {
        phone: '',
        qq: '',
        wechat: ''
      },
      tab: 'tab1',
      types: types,
      designer: {},
      valueDisabled: 5,
      items: [],
      total: 0,
      current: 1,
      htmlStr: '',
      phone_model: false,
      registerModal: false
    };
  },
  computed: {
    ...mapState({
      childList4: state => state.Lists.childList4, //子分类
      defaultSrc: state => state.User.defaultSrc,
      info: state => state.User.info,
      ftpPath: state => state.User.ftpPath
    })
  },
  methods: {
    jump(name) {
      window.scrollTo(0, this.$refs[name].$el.offsetTop);
    },
    jumpTo() {
      console.log(this.$route.params.id);
      this.$router.push({
        name: 'oneDesigner',
        params: {
          id: this.$route.params.id
        }
      });
    },
    login() {
      window.location.href = `/user/login?redirect=${encodeURIComponent(
        location.pathname
      )}`;
    },
    hire() {
      if (this.info.id) {
        this.getContractInfo();
        this.$router.push({
          name: 'hire',
          params: {
            id: this.$route.params.id
          }
        });
      } else {
        this.$Notice.info({
          title: '请先登录'
        });
      }
    },
    phoneModal() {
      if (this.info.id) {
        this.getContractInfo();
        this.$Modal.success({
          title: '联系他/她',
          content: '联系电话：' + (this.designer.phone || '未填写联系电话')
        });
      } else {
        this.$Notice.info({
          title: '请先登录'
        });
      }
    },
    cancle() {
      this.registerModal = false;
    },
    getContractInfo() {
      if (this.info.id) {
        const id = this.$route.params.id;
        if (!id) return;
        this.$ajax
          .get('designer/contractInfo', {
            id
          })
          .then(e => {
            if (e.status === 200) {
              this.ContractInfo = e.data;
            }
          });
      }
    },
    loginout() {
      this.$store.commit('set_user_data', {});
      this.$ajax.post('auth/logout').then(e => {});
    }
  },
  mounted() {
    const id = this.$route.params.id;
    if (!id) return;
    this.$ajax
      .get('designer/get', {
        id
      })
      .then(e => {
        if (e.status === 200) {
          this.designer = e.data;
          this.htmlStr = e.data.details || '';
        }
      });
    if (this.info.id) {
      this.getContractInfo();
    }
    // eslint-disable-next-line
    let clipboard = new Clipboard('.copyBtn');
    clipboard.on('success', e => {
      this.$Message.info('已复制');
      e.clearSelection();
    });
  },
  watch: {
    'info.id': 'getContractInfo'
  }
};
</script>
<style>
.wsl_icon {
  overflow: hidden;
}

.wsl_icon li {
  display: inline-block;
  width: 210px;
}

.wsl_icon li div {
  display: inline-block;
  line-height: 25px;
  height: 25px;
  margin: 0 3px;
  font-size: 14px;
  color: #646464;
}

.ivu-breadcrumb-item-separator {
  color: #80848f;
}

.drop .ivu-select-dropdown {
  background-color: #fff;
  border: 1px solid #ccc;
  border-radius: inherit;
  box-shadow: none;
  color: #646464;
  width: 242px;
  margin: 0;
}

.drop .ivu-dropdown-item:hover {
  width: 240px;
  background-color: #fff;
  color: #f54203;
}

.drop .ivu-dropdown-item {
  color: #646464;
  font-size: 16px !important;
  display: flex;
  justify-content: space-between;
  /*text-indent: 20px;*/
}

.star-style .ivu-rate-star-full:before,
.star-style .ivu-rate-star-half .ivu-rate-star-content:before {
  color: #f54203;
}

.drop .ivu-dropdown-item .ivu-btn-ghost:hover {
  color: #f54203;
  border-color: #f54203;
}

.wsl_btm_con img {
  max-width: 970px;
  min-width: 200px;
}
</style>

<style scoped>
.wsl_font12 {
  font-size: 12px;
  color: #646464;
}

.wsl_font14 {
  font-size: 14px;
  color: #646464;
}

.wsl_font16 {
  font-size: 16px;
  color: #646464;
}

.wsl_font18 {
  font-size: 18px;
  color: #646464;
}

.wsl_colorf54203 {
  color: #f54203;
}

.wsl_height53 {
  height: 53px;
}

.backgroundcontent {
  overflow: hidden;
  background-color: #f8f8f8;
}

.row {
  margin-top: 10px;
  margin-bottom: 10px;
}

.row2 span {
  margin-right: 20px;
}

.u_image {
  width: 185px;
  height: 221px;
  margin: 15px;
  overflow: hidden;
  border: 1px solid #e9eaec;
  border-radius: 5px;
  /*margin-bottom: 15px;*/
}

.abbrs {
  color: #fff;
  padding: 2px 4px;
  font-size: 14px;
  background-color: #fd9a00;
}

.deposit {
  color: #ee4000;
  padding: 4px;
  background-color: #eead0e;
  border-radius: 50% 25%;
}

.text-center {
  text-align: center;
}

img {
  width: 100%;
}

.main {
  /*overflow: hidden;*/
  background-color: #fff;
}

.content {
  /*overflow: hidden;*/
  /*padding: 15px;*/
  border: 1px solid #e9eaec;
  border-radius: 5px;
}

.border-area {
  border: 1px solid #dddee1;
  padding: 10px 20px;
}

.border-bottom0 {
  border-bottom: 0;
}

.border-area:last-child {
  /*border-top: none;*/
}

.divider-area {
  border: 1px solid #dddee1;
  padding: 11px 20px;
  background-color: #f8f8f9;
  margin-top: -15px;
  font-size: 14px;
  color: #888888;
}

.img25 {
  height: 25px;
  width: 25px;
}

.inline-flex .ivu-col-span-8 {
  display: inline-flex;
}

.main .tab {
  overflow: hidden;
  display: block;
  float: left;
  font-size: 16px;
  border-right: 1px solid #ccc;
  border-bottom: 0px;
  height: 50px;
  line-height: 50px;
  padding: 0 20px;
  /*padding: 10px 30px;*/
}

.main .tab .active {
  border-bottom: 2px solid #ee4000;
}

.tabitem {
  margin-top: 30px;
  /*width: 990px;*/
  border: 1px solid #dddee1;
}

.tabitem .tab:hover {
  color: #fc7c09;
}

.border0 {
  border-left: 0 !important;
  border-right: 0 !important;
}

.wsl_font12 {
  font-size: 12px;
  color: #646464;
}

.wsl_font14 {
  font-size: 14px;
  color: #646464;
}

.wsl_font16 {
  font-size: 16px;
  color: #646464;
}

.wsl_font18 {
  font-size: 18px;
  color: #646464;
}

.wsl_colorf54203 {
  color: #f54203;
}

.wsl_height53 {
  height: 53px;
}

.backgroundcontent {
  overflow: hidden;
  background-color: #f8f8f8;
}

.minnav {
  color: #646464;
  font-size: 12px;
  height: 55px;
  line-height: 55px;
}

.container {
  width: 1274px;
  margin: auto;
  /*padding: 10px 20px;*/
  /*background: #e3e7ea;*/
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
}

.row {
  margin-top: 10px;
  margin-bottom: 10px;
}

.row2 span {
  margin-right: 20px;
}

.u_image {
  width: 185px;
  height: 221px;
  margin: 15px;
  overflow: hidden;
  border: 1px solid #e9eaec;
  border-radius: 5px;
  /*margin-bottom: 15px;*/
}

.abbrs {
  color: #fff;
  padding: 2px 4px;
  font-size: 14px;
  background-color: #fd9a00;
}

.deposit {
  color: #ee4000;
  padding: 4px;
  background-color: #eead0e;
  border-radius: 50% 25%;
}

.text-center {
  text-align: center;
}

img {
  width: 100%;
}

.main {
  /*overflow: hidden;*/
  background-color: #fff;
}

.content {
  /*overflow: hidden;*/
  /*padding: 15px;*/
  border: 1px solid #e9eaec;
  border-radius: 5px;
}

.border-area {
  border: 1px solid #dddee1;
  padding: 10px 20px;
}

.border-bottom0 {
  border-bottom: 0;
}

.border-area:last-child {
  /*border-top: none;*/
}

.divider-area {
  border: 1px solid #dddee1;
  padding: 11px 20px;
  background-color: #f8f8f9;
  margin-top: -15px;
  font-size: 14px;
  color: #888888;
}

.img25 {
  height: 25px;
  width: 25px;
}

.img14 {
  height: 14px;
  width: 14px;
  margin-top: -3px;
  vertical-align: middle;
}

.inline-flex .ivu-col-span-8 {
  display: inline-flex;
}

.main .tab {
  overflow: hidden;
  display: block;
  float: left;
  font-size: 16px;
  border-right: 1px solid #ccc;
  border-bottom: 0;
  height: 50px;
  line-height: 50px;
  padding: 0 20px;
  /*padding: 10px 30px;*/
}

.main .tab .active {
  border-bottom: 2px solid #ee4000;
}

.tabitem {
  margin-top: 30px;
  /*width: 990px;*/
  border: 1px solid #dddee1;
}

.tabitem .tab:hover {
  color: #f54203;
}

.border0 {
  border-left: 0 !important;
  border-right: 0 !important;
}
</style>
