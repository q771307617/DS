<template>
    <div style=" background-color: #f8f8f8;">
        <div class="widht1280">
            <Row>
                <Col span="6">
                <div class="widht283">
                    <div class="wsl-title">
                        <div class="wsl-imgicon"><img width="25" :src="'icon/icon-list.png' | randomPath"></div>
                        <div>平台规则</div>
                    </div>
                    <ul class="wsl-ul">
                        <li :class="show == '1' ? 'show':''">
                            <a @click="setShow(1)" href="javascript:;">平台介绍</a>
                        </li>
                        <li :class="show == '2' ? 'show':''">
                            <a @click="setShow(2)" href="javascript:;">雇佣模式</a>
                        </li>
                        <li :class="show == '3' ? 'show':''">
                            <a @click="setShow(3)" href="javascript:;">3天试用</a>
                        </li>
                        <li :class="show == '4' ? 'show':''">
                            <a @click="setShow(4)" href="javascript:;">服务协议</a>
                        </li>
                    </ul>
                </div>
                </Col>
                <Col span="18" style="text-align:center;">
                <div>
                    <img v-if="show == '2'" :src="ftpPath+'ptgz/rules-2.png!984'" title="雇佣模式">
                    <img v-else-if="show == '3'" :src="ftpPath+'ptgz/rules-3.png!984'" title="3天试用">
                    <img v-else-if="show == '4'" :src="ftpPath+'ptgz/rules-4.png!984'" title="服务协议">
                    <img v-else :src="ftpPath+'ptgz/rules-1.png!984'" title="平台介绍">
                </div>
                </Col>
            </Row>
        </div>
    </div>
</template>

<script>
import { mapState } from 'vuex';
export default {
  data() {
    return {
      show: 1
    };
  },
  methods: {
    setShow(index) {
      this.show = index;
      this.$router.push({ name: 'rules', query: { index: index } });
    }
  },
  computed: {
    ...mapState({
      ftpPath: state => state.User.ftpPath
    })
  },
  mounted() {
    let index = this.$route.query.index;
    if (index < 1 || index > 4) {
      this.show = '1';
    } else {
      this.show = index;
    }
  },
  watch: {
    $route: function() {
      let index = this.$route.query.index;
      if (index < 1 || index > 4) {
        this.show = '1';
      } else {
        this.show = index;
      }
    }
  }
};
</script>
<style scoped>
.widht1280 {
  margin: auto;
  padding: 20px 0;
  width: 1280px;
}

.widht283 {
  width: 283px;
  height: 506px;
  background-color: #fff;
}

.wsl-imgicon {
  float: left;
  margin: 4px 15px 0 65px;
  width: 25px;
  height: 21px;
}

.wsl-title {
  width: 100%;
  height: 55px;
  background-color: #f54203;
  color: #fff;
  font-size: 18px;
  line-height: 55px;
}

.wsl-ul {
  margin: auto;
  width: 200px;
  list-style-position: inside;
  list-style-type: circle;
  text-indent: 30px;
  font-size: 19px;
}

.wsl-ul li {
  height: 40px;
  border-bottom: 1px solid #e1e1e1;
  line-height: 40px;
}

.wsl-ul li a {
  color: #888;
  font-size: 16px;
}

.wsl-ul li.show,
.wsl-ul li.show a,
.wsl-ul li:hover,
.wsl-ul li:hover a {
  color: #f54203;
  list-style-type: disc;
}
</style>
