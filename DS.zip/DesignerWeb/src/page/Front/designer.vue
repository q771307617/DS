<template>
    <div class="backgroundcontent">
        <div class="container">
            <Breadcrumb class="minnav" separator=">">
                您的位置：
                <a href="/">点将啦</a><span style="margin:0 10px;">></span>
                <!-- <Breadcrumb-item href="/">点将啦</Breadcrumb-item> -->
                <Breadcrumb-item>搜索设计师</Breadcrumb-item>
            </Breadcrumb>
            <div class="filter-wrapper">
                <div class="filter clearfix wsl_font18">
                    <label class="float-left wsl_font16">您的招聘需求</label>
                </div>
                <div class="filter clearfix">
                    <label class="float-left wsl_font16">行业：</label>
                    <ul class="filter-ul">
                        <li :class="{active : !query.hy}">
                            <router-link :to="{ name: 'designer', query: { hy: '', gender: query.gender, jb: query.jb, name: query.name,salary:query.salary }}">所有</router-link>
                        </li>
                        <li v-for="item in childList4" :class="{active : query.hy == item.id}" :key="item.id">
                            <router-link :to="{ name: 'designer', query: { hy: item.id, gender: query.gender, jb: query.jb, name: query.name,salary:query.salary }}">{{item.name}}</router-link>
                        </li>
                    </ul>
                </div>
                <div class="filter clearfix">
                    <label class="float-left wsl_font16">级别：</label>
                    <ul class="filter-ul">
                        <li :class="{active : !query.jb}">
                            <router-link :to="{ name: 'designer', query: { hy: query.hy, gender: query.gender, jb: '', name: query.name,salary:query.salary }}">所有</router-link>
                        </li>
                        <li v-for="item in types.workyears" :key="item" :class="{active : query.jb == item.value}">
                            <router-link :to="{ name: 'designer', query: { hy: query.hy, gender: query.gender, jb: item.value, name: query.name,salary:query.salary }}">{{item.label}}</router-link>
                        </li>
                    </ul>
                </div>
                <div class="filter clearfix">
                    <label class="float-left wsl_font16">预算：</label>
                    <ul class="filter-ul">
                        <li :class="{active : !query.salary}">
                            <router-link :to="{ name: 'designer', query: { hy: query.hy, gender: query.gender, jb: query.jb, name: query.name,salary:'' }}">所有</router-link>
                        </li>
                        <li v-for="item in types.salaryBudget" :class="{active : query.salary == item.value}" :key="item">
                            <router-link :to="{ name: 'designer', query: { hy: query.hy, gender: query.gender, jb: query.jb, name: query.name,salary:item.value }}">{{item.label}}</router-link>
                        </li>
                    </ul>
                </div>
                <div class="filter clearfix">
                    <label class="float-left wsl_font16">性别：</label>
                    <ul class="filter-ul">
                        <li :class="{active : !query.gender && query.gender != '0'}">
                            <router-link :to="{ name: 'designer', query: { hy: query.hy, gender: '', jb: query.jb, name: query.name,salary:query.salary }}">所有</router-link>
                        </li>
                        <li v-for="item in types.gender" :key="item" :class="{active : query.gender == item.value && query.gender !== ''}">
                            <router-link :to="{ name: 'designer', query: { hy: query.hy, gender: item.value, jb: query.jb, name: query.name,salary:query.salary }}">{{item.value ? '美女' : '帅哥' }}</router-link>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="designer-list-wrapper" v-if="total">
                <div v-for="(item,index) in items" class="list-item" :key="item.user_id">
                    <div class="designer-info">
                        <div class="u_image">
                            <router-link :to="{ name: 'detailForDesigner', params: { id: item.user_id}}" target="_blank">
                                <img v-lazy="item.image_url+'!168x218'" :alt="item.nickname">
                            </router-link>
                        </div>
                        <div class="u-main">
                            <div class="wsl-desigenernaem">
                                <router-link :to="{ name: 'detailForDesigner', params: { id: item.user_id}}" target="_blank">
                                    <span class="wsl_font18">{{item.realname | replaceName}}</span>
                                    <span class="wsl_font18">（{{item.nickname}}）</span>
                                </router-link>
                                <span class="img-wrap">
                                    <img :src="`icon/female.png` | randomPath" alt="女" v-if="item.gender">
                                    <img :src="`icon/male.png` | randomPath" alt="男" v-else>
                                </span>
                                <span class="img-wrap">
                                    <img :src="`icon/security.png` | randomPath" alt="">
                                </span>
                                <span class="img-wrap">
                                    <img :src="`icon/certification.png` | randomPath" alt="平台认证">
                                </span>
                            </div>
    
                            <Row style="border-bottom:1px solid #ccc;height:90px;">
                                <Col span="6" class="wsl_font14" style="overflow:hidden;margin-top: 60px;">工作经验：{{item.exp }}年
                                </Col>
                                <Col span="13" class="wsl_font14" style="overflow:hidden;margin-top: 60px;"> 擅长类目： {{item.skilful | SKILLFULL_LIST_TEXT(childList4)}}
                                </Col>
                                <Col span="5">
                                <div style="height:90px;">
                                    <p class="text-center">
                                        <span style="font-size: 28px; color: #f54203;"> {{item.salary}}</span>
                                        <span style="font-size: 16px; color: #807f7f;">/月</span>
                                    </p>
                                    <div class="jlbtn">
                                        <router-link :to="{name: 'detailForDesigner',params:{id:item.user_id }}">
                                            <Button type="warning" size="large">
                                                <Icon type="eye"></Icon>&nbsp;查看简历</Button>
                                        </router-link>
                                    </div>
                                </div>
                                </Col>
                            </Row>
                            <Row>
                                <Col span="19">{{item.description}}</Col>
                                <Col span="5" style="padding: 0 40px;" v-if="item.worktimes">
                                <p style="color: #646464;font-weight: bold;font-size: 20px;width: 56px;text-align: center;">{{item.worktimes||0}}</p>
                                累计雇佣
                                </Col>
                            </Row>
                        </div>
                    </div>
                    <ul class="products-ul">
                        <li v-for="pro in item.products" :key="pro" style="position: relative;">
                            <span class="pro-img">
                                <router-link :to="{ name: 'proInfo', params: { id: pro.id }}" target="_blank">
                                    <img v-lazy="pro.image_url+'!180x200'" :alt="pro.name">
                                </router-link>
                            </span>
                            <span class="pro-name">
                                <router-link :to="{ name: 'proInfo', params: { id: pro.id }}" target="_blank">
                                    {{pro.name}}
                                </router-link>
                            </span>
                        </li>
                        <li v-if="item.products.length >= 6 " style="width:110px;text-align:center;cursor: pointer;" @click="jumpPage(item.user_id)">
                            <span class="text-center font16 more-pro">
                                &bull;&bull;&bull;
                                <br> 查看更多
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
            <h3 v-else class="text-center message">没有找到符合条件的设计师</h3>
            <page :current="pageNum" :pageSize="pageSize" :total="total" v-on:on-change="paging"></page>
        </div>
    </div>
</template>

<script>
import * as types from '@/constant';
import suspensionframe from '@/components/suspensionframe';
import page from '@/components/page';
import { mapState } from 'vuex';
export default {
  data() {
    return {
      types: types,
      items: [],
      total: 0,
      pageNum: 1,
      query: this.$route.query,
      pageSize: 10,
      pageCount: 0
    };
  },
  mounted() {
    this.fetchData();
  },
  computed: {
    ...mapState({
      typeList: state => state.Lists.typeList,
      companyList: state => state.Lists.companyList, //公司分类
      parentList: state => state.Lists.parentList, //父分类
      childList4: state => state.Lists.childList4, //子分类
      defaultSrc: state => state.User.defaultSrc
    })
  },
  methods: {
    fetchData() {
      this.pageNum =
        (this.$route.query.pageNum && parseInt(this.$route.query.pageNum)) || 1;
      let jb = this.$route.query.jb || 0;
      let salary = this.$route.query.salary || 0;
      let expEndList = ['', '1', '1.5', '2', '3', '100'];
      let expStartList = ['', '0.5', '1', '1.5', '2', '3'];
      let salaryStartList = ['', '1500', '3000', '4000', '6000', '10000'];
      let salaryEndList = ['', '2999', '3999', '5999', '9999', '99999999'];
      this.query = this.$route.query;
      let obj = {
        classId: this.$route.query.hy || '', //擅长行业 number @mock=1
        expEnd: expEndList[jb], //工作年限最大值 number @mock=1
        expStart: expStartList[jb], //工作年限最小值 number @mock=5
        salaryStart: salaryStartList[salary],
        salaryEnd: salaryEndList[salary],
        gender:
          this.$route.query.gender === 0 ? 0 : this.$route.query.gender || '', //性别number@mock=1
        name: this.$route.query.name || '', //名称(昵称 用户名) string@mock=黄依
        pageNum: this.pageNum,
        pageSize: this.pageSize
      };
      this.$ajax.get('designer/list', obj).then(e => {
        if (e.status === 200) {
          this.items = e.data.list;
          this.total = e.data.count;
        } else {
          this.items = [];
          this.total = 0;
          this.pageNum = 1;
        }
      });
    },
    paging(p) {
      this.pageNum = p;
      this.$router.push({
        name: 'designer',
        query: {
          ...this.$route.query,
          pageNum: p
        }
      });
    },
    /** 设计师作品列表 */
    jumpPage(id) {
      this.$router.push({
        name: 'oneDesigner',
        params: {
          id
        }
      });
    }
  },
  watch: {
    // 如果路由有变化，会再次执行该方法
    $route: 'fetchData'
  },
  components: {
    suspensionframe,
    page
  }
};
</script>
<style>
.wsl-page-btn-style {
  overflow: hidden;
  padding-top: 5px;
}

.wsl-page-btn-style div {
  float: left;
  height: 23px;
  line-height: 23px;
  color: #c0c0c0;
  margin: 0 5px;
}

.wsl-page-btn-style a {
  display: block;
  width: 45px;
  height: 23px;
  line-height: 23px;
  text-align: center;
  border: 1px solid #dddee1;
  font-size: 12px;
  color: #3c3c3c;
}

.ivu-breadcrumb-item-separator {
  color: #80848f;
}

.jlbtn .ivu-btn {
  border-radius: 10px;
  width: 140px;
}

.jlbtn .ivu-btn-warning.active,
.jlbtn .ivu-btn-warning {
  background-color: #f54203;
  border-color: #f54203;
}
</style>

<style scoped>
.wsl-tag {
  overflow: hidden;
}

.wsl-tag > span {
  display: block;
  float: left;
  border: 1px solid #e9eaec;
  padding: 5px 15px;
  margin: 0 15px 0 0;
}

.wsl-desigenernaem {
  padding: 20px 0;
}

.wsl-desigenernaem .img-wrap {
  height: 24px;
  width: 18px;
  display: inline-block;
  vertical-align: middle;
}

.wsl_font12 {
  font-size: 12px;
  color: #646464;
}

.wsl_font14 {
  font-size: 14px;
  color: #646464;
}

.wsl_font16 {
  font-size: 16px;
  color: #646464;
}

.wsl_font18 {
  font-size: 18px;
  color: #646464;
}

.wsl_color888 {
  color: #888;
}

.backgroundcontent {
  background-color: #f8f8f8;
  overflow: hidden;
}

.minnav {
  color: #646464;
  font-size: 12px;
  height: 60px;
  line-height: 60px;
}

.container {
  width: 1280px;
  margin: auto;
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
  font-size: 14px;
}

.filter-wrapper {
  border: 1px solid #e9eaec;
  border-radius: 5px;
  margin-bottom: 40px;
}

.filter {
  padding-bottom: 10px;
  background-color: #fff;
  padding: 10px 20px;
  border-bottom: 1px solid #e9eaec;
}

.filter > label {
  font-size: 16px;
  color: #474747;
  min-width: 66px;
  text-align: right;
  height: 31px;
  line-height: 31px;
}

.filter-ul {
  display: inline-block;
  margin-left: 16px;
  width: 1150px;
}

.filter-ul > li {
  display: inline-block;
  height: 31px;
  line-height: 31px;
  padding-left: 15px;
  padding-right: 15px;
}

.filter-ul > li:last-child {
  border-right: none;
}

.filter-ul > li > a {
  color: #646464;
}

.filter-ul > li.active {
  background-color: #f54203;
  border-radius: 5px;
}

li.active a {
  color: #fff;
}

.sort {
  display: inline-block;
  text-align: right;
  padding: 10px;
}

.designer-list-wrapper {
  margin: 10px 0;
}

.designer-info {
  border-bottom: 1px solid #e9eaec;
}

.u-main {
  width: 1040px;
  margin-left: 20px;
  display: inline-block;
  vertical-align: top;
}

.list-item {
  background-color: #fff;
  border: 1px solid #e9eaec;
  border-radius: 5px;
  margin-bottom: 40px;
}

.u_image {
  width: 186px;
  height: 218px;
  border: 1px solid #e9eaec;
  border-radius: 5px;
  margin: 7px;
  overflow: hidden;
  display: inline-block;
}

img {
  width: 100%;
}

.row-inline {
  display: inline-block;
  vertical-align: middle;
  margin-right: 10px;
}

.pro-list {
  padding: 10px 0;
}

.border-area {
  border: 1px solid #dddee1;
}

.abbrs {
  color: #fff;
  padding: 2px 4px;
  background-color: #ee6363;
}

.deposit {
  color: #ee4000;
  padding: 4px;
  background-color: #eead0e;
  border-radius: 50% 25%;
}

.u > i,
.u > span {
  margin-right: 10px;
}

.products-ul {
  padding: 10px;
}

.products-ul > li {
  width: 180px;
  height: 200px;
  display: inline-block;
  margin-right: 6px;
  overflow: hidden;
}

.products-ul > li:last-child {
  margin-right: 0;
}

.products-ul > li:hover .pro-name {
  display: block;
}

.products-ul .pro-name {
  display: none;
  height: 25px;
  text-align: center;
  background-color: rgba(245, 66, 3, 0.7);
  line-height: 25px;
  position: absolute;
  bottom: 0;
  width: 100%;
}

.products-ul .pro-name a {
  color: #fff;
}

.more-pro {
  color: #999;
  display: block;
  width: 100%;
  margin-top: 81px;
}

.jlbtn {
  font-size: 16px;
  color: #fefefe;
  text-align: center;
  height: 46px;
}
</style>

