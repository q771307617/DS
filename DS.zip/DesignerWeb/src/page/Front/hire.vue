<style scoped>
.hire {
  padding-top: 20px;
  margin-bottom: 60px;
}

.marginauto1280 {
  margin: 0 auto;
  width: 1280px;
}

.hire .con {
  background: #fff;
}

.hire .con .right {
  border-left: 1px solid #ccc;
  width: 1010px;
}

.padding6-35 {
  padding: 6px 35px;
}

.img-box {
  width: 224px;
  height: 270px;
  overflow: hidden;
}

.left img {
  width: 100%;
  vertical-align: middle;
  height: auto;
}

.left-nav {
  line-height: 2;
}

.breadcrumb {
  font-size: 12px;
  margin-top: 19px;
  margin-bottom: 19px;
}

.breadcrumb-ul {
  display: inline-block;
}

.breadcrumb-ul li {
  padding-right: 5px;
  display: inline-block;
}

.breadcrumb-ul a {
  color: #646464;
}

.helpinfo {
  font-size: 14px;
  color: #888888;
}

a.helpinfo {
  text-decoration-line: underline;
  padding-left: 10px;
  padding-right: 10px;
}

.time-text {
  font-size: 16px;
  color: #f54203;
}

.form-row {
  /*display: flex;*/
  margin-bottom: 10px;
}

.form-content {
  margin-left: 40px;
  width: 736px;
}

.inline-block {
  display: inline-block;
}

.form-content [type='radio'] {
  width: 14px;
  height: 14px;
}

.form-content-row {
  margin-bottom: 16px;
}

.form-label {
  width: 92px;
  text-align: right;
}

.f54203 {
  color: #f54203;
}

.c888888 {
  color: #888888;
}

.c646464 {
  color: #646464;
}

.required {
  color: #f54203;
  vertical-align: middle;
}

.vertical-middle {
  vertical-align: middle;
}

.margin0-10 {
  margin-left: 10px;
  margin-right: 10px;
}

.form-content > a {
  text-decoration-line: underline;
}
</style>

<template>
  <div class="hire">
    <div class="con marginauto1280 clearfix">
      <div class="breadcrumb">
        <span>您的位置：</span>
        <ul class="breadcrumb-ul">
          <li>
            <a href="/">点将啦</a>
            <!-- <router-link to="/">点将啦</router-link> -->
          </li>
          <li>></li>
          <li>
            <router-link :to="{name:'designer'}">推荐设计师</router-link>
          </li>
          <li>></li>
          <li>
            <router-link :to="{name:'detailForDesigner'}">设计师{{infoData.nickname}}的简历</router-link>
          </li>
          <li>></li>
          <li>
            <a href="#">入职邀请</a>
          </li>
        </ul>
      </div>
      <div class="left float-left left-nav">
        <div class="img-box">
          <img :src="infoData.image_url || defaultSrc" alt="">
        </div>

        <div class="font18" style="">
          <span>{{infoData.realname}}（{{infoData.nickname}}）</span>
          <div style="width: 18px;height:18px;line-height: 18px;display: inline-block;">
            <img :src="`icon/certification.png` | randomPath" alt="平台认证">
          </div>
          <div style="width: 18px;height:18px;line-height: 18px;display: inline-block;">
            <img :src="'icon/bz.png' | randomPath" alt="平台保障">
          </div>
          <div style="width: 18px;height:18px;line-height: 18px;display: inline-block;">
            <img :src="'icon/'+infoData.rank+'.png' | randomPath">
          </div>
        </div>
        <p class="font14">{{infoData.skilful | SKILLFULL_LIST_TEXT(childList4)}}</p>
        <p class="font14">薪资：{{infoData.salary}}/月</p>
      </div>
      <div class="right float-right font14" style="padding-left: 95px;">
        <div class="form-row">
          <div class="form-label inline-block" style="vertical-align: top;">
            <span class="required">*</span>
            <span class="c646464 font16 vertical-middle">雇佣类型：</span>
          </div>
          <div class="form-content inline-block">
            <div class="form-content-row">
              <label class="flex-label">
                <input type="radio" value="0" v-model="type" class="vertical-middle">
                <span class="c888888 font16 vertical-middle">包月雇佣</span>
                <span class="vertical-middle font12 f54203">（全职上班，早九晚六点，按月结算工资）</span>
              </label>
            </div>
            <div class="form-content-row">
              <label class="flex-label">
                <input type="radio" value="1" v-model="type" class="vertical-middle">
                <span class="c888888 font16 vertical-middle">定制</span>
                <span class="vertical-middle" style="background-color: #f54203;color: #ffffff;padding: 1px 5px;border-bottom-left-radius: 10px;border-top-left-radius: 10px;">按照项目完结，结算工资（不包含3天无理由）</span>
              </label>
            </div>
          </div>
        </div>
        <!--包月-->
        <div v-if="type === '0'">
          <div class="form-row">
            <div class="form-label inline-block">
              <span class="required">*</span>
              <span class="c646464 font16 vertical-middle">入职时间：</span>
            </div>
            <div class="form-content inline-block">
              <Date-picker class="inline-block" :options="startTime_options" v-model="startTime" :editable="false" :clearable="false" type="date" placeholder="选择日期" style="width: 214px"></Date-picker>
              <a href="javascript:;" class="c888888 margin0-10" @click="setStartTime(0)">今天</a>
              <a href="javascript:;" class="c888888 margin0-10" @click="setStartTime(1)">明天</a>
              <span class="c888888 margin0-10">请选择您希望或者和设计师约好的时间</span>
            </div>
          </div>
          <div class="form-row">
            <div class="form-label inline-block">
              <span class="required">*</span>
              <span class="c646464 font16 vertical-middle">雇佣周期：</span>
            </div>
            <div class="form-content inline-block">
              <Input-number :max="12" :min="1" v-model="months"></Input-number>&nbsp;个月
              <a href="javascript:;" class="c888888 margin0-10" @click="setMonths(3)">3个月</a>
              <a href="javascript:;" class="c888888 margin0-10" @click="setMonths(6)">6个月</a>
              <a href="javascript:;" class="c888888 margin0-10" @click="setMonths(12)">12个月</a>
            </div>
          </div>
          <div class="form-row">
            <div class="form-label inline-block"></div>
            <div class="form-content inline-block">
              <div style="padding: 5px 0;border: 1px solid #dadada;width: 314px;border-radius: 4px;text-align: center;">
                <span class="f54203 font16">{{startTime | format('YYYY-MM-DD')}}</span>
                <span class="font16">&nbsp;至&nbsp;</span>
                <span class="f54203 font16">{{endTime | format('YYYY-MM-DD')}}</span>
              </div>
            </div>
          </div>
          <div class="form-row">
            <div class="form-label inline-block">
              <span class="required">*</span>
              <span class="c646464 font16 vertical-middle">入职邀请：</span>
            </div>
            <div class="form-content inline-block" style="vertical-align: top;">
              <Input type="textarea" :rows="12" v-model="hireInvitation" placeholder="限制500字符"></Input>
            </div>
          </div>
        </div>

        <!--定制-->
        <div v-if="type === '1'">
          <div class="form-row">
            <div class="form-label inline-block">
              <span class="required">*</span>
              <span class="c646464 font16 vertical-middle">雇佣时间：</span>
            </div>
            <div class="form-content inline-block">
              <Date-picker class="inline-block" :options="startTime_options" @on-change="handleBeginPicker" v-model="startTime" :editable="false" :clearable="false" type="date" placeholder="选择日期" style="width: 214px"></Date-picker>&nbsp;至&nbsp;
              <Date-picker class="inline-block" :options="endTime_options" v-model="endTime_1" :editable="false" :clearable="false" type="date" placeholder="选择日期" style="width: 214px"></Date-picker>
            </div>
          </div>
          <div class="form-row">
            <div class="form-label inline-block">
              <span class="required">*</span>
              <span class="c646464 font16 vertical-middle">托管金额：</span>
            </div>
            <div class="form-content inline-block">
              <Input-number :max="99999.99" :min="0.01" v-model="money" style="width: 214px;"></Input-number>&nbsp;元
              <span class="font16 c888888">具体金额请先联系设计师协商</span>
              <a target="_blank" :href="`http://wpa.qq.com/msgrd?v=3&uin=${contractInfo.qq}&site=qq&menu=yes`" v-if="contractInfo.qq">
                <img border="0" style="vertical-align: middle;" :src="`http://wpa.qq.com/pa?p=2:${contractInfo.qq}:51`" alt="点这里给我发消息">
              </a>
            </div>
          </div>
          <div class="form-row">
            <div class="form-label inline-block">
              <span class="required">*</span>
              <span class="c646464 font16 vertical-middle">制作内容：</span>
            </div>
            <div class="form-content inline-block" style="vertical-align: top;">
              <Input type="textarea" :rows="12" v-model="hireInvitation" placeholder="限制500字符"></Input>
            </div>
          </div>
        </div>

        <div class="form-row">
          <div class="form-label inline-block"></div>
          <div class="form-content inline-block" style="text-align: right;">
            <span class="font16 c888888">应托管工资金额：</span>
            <span class="font16 f54203">{{price}}</span>
            <span class="font16 c888888">元</span>
            <Button type="error" style="width: 130px;height: 40px;font-size: 20px;margin-left: 20px;" @click="submit">确认雇佣</Button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import moment from 'moment';
import { mapState } from 'vuex';

export default {
  data() {
    return {
      type: '0',
      hireInvitation: '',
      startTime: new Date(),
      infoData: {},
      id: this.$route.params.id,
      months: 1,
      startTime_options: {
        disabledDate: date => {
          return date && date.valueOf() < Date.now() - 86400000;
        }
      },
      endTime_options: {
        disabledDate: date => {
          return date && date.valueOf() < this.startTime.valueOf();
        }
      },
      endTime_1: new Date(),
      money: 1,
      contractInfo: {}
    };
  },
  computed: {
    ...mapState({
      defaultSrc: state => state.User.defaultSrc,
      childList4: state => state.Lists.childList4,
      info: state => state.User.info,
      ftpPath: state => state.User.ftpPath
    }),
    endTime() {
      return moment(this.startTime).add(this.months, 'M');
    },
    price() {
      if (this.type === '1') return this.money.toFixed(2);
      return (this.months * this.infoData.salary).toFixed(2);
    }
  },
  watch: {
    'info.id'(val) {
      if (val) {
        this.getContractInfo();
      } else {
        this.contractInfo = {};
      }
    },
    months(val) {
      if (/^[0-9]+$/.test(val)) return;
      this.$nextTick(() => {
        this.months = Math.round(val);
      });
    }
  },
  mounted() {
    this.$ajax.get('designer/get', { id: this.id }).then(e => {
      if (!e.data) {
        return;
      }

      this.infoData = e.data;
    });
    if (this.info.id) {
      this.getContractInfo();
    }
  },
  methods: {
    getContractInfo() {
      const { id } = this.$route.params;
      this.$ajax.get('designer/contractInfo', { id }).then(e => {
        if (e.status !== 200) return;
        this.contractInfo = e.data;
      });
    },
    //提交
    submit() {
      if (this.type === '1' && !this.hireInvitation) {
        this.$Message.error('请填写制作内容');
        return;
      }

      if (this.type === '0' && !this.hireInvitation) {
        this.$Message.error('请填写入职邀请');
        return;
      }

      if (this.hireInvitation.length > 500) {
        this.$Message.error('入职邀请或制作内容字数请限制在500字符内');
        return;
      }

      let addParams = {
        designerId: this.id,
        endTime: moment(this.endTime).format('YYYY-MM-DD') + ' 23:59:59',
        'hireInvitation.invitation': this.hireInvitation,
        price: this.price,
        startTime: moment(this.startTime).format('YYYY-MM-DD') + ' 00:00:00',
        type: this.type
      };
      if (this.type === '1') {
        addParams.endTime =
          moment(this.endTime_1).format('YYYY-MM-DD') + ' 23:59:59';
      }

      this.$ajax.post('hire/add', addParams).then(e => {
        if (e.status == 200) {
          this.$Notice.success({
            title: '雇佣申请成功'
            // desc:e.msg
          });
          //支付操作
          window.location.href = '/payment?hireId=' + e.data;
          // this.$router.push({
          //     path: '/payment',
          //     query: { hireId: e.data }
          // });
        } else {
          this.$Notice.error({
            // title: "发生错误",
            desc: e.msg
          });
        }
      });
    },
    handleBeginPicker(date) {
      this.endTime_1 = moment(date).add(1, 'days');
    },
    // 入职时间
    setStartTime(p) {
      if (p) {
        this.startTime = moment().add(1, 'days');
        return;
      }
      this.startTime = new Date();
    },
    setMonths(p) {
      this.months = p;
    }
  }
};
</script>
