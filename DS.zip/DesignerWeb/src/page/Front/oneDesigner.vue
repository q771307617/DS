<template>
    <div style="background-color: #f8f8f8;">
        <div class="container">
            <div class="breadcrumb">
                <span>您的位置：</span>
                <ul class="breadcrumb-ul">
                    <li>
                        <a href="/">点将啦</a>
                        <!-- <router-link to="/">点将啦</router-link> -->
                    </li>
                    <li>></li>
                    <li>
                        <router-link :to="{name:'designer'}">搜索设计师</router-link>
                    </li>
                    <li>></li>
                    <li>
                        <router-link :to="{name:'detailForDesigner'}">设计师{{item.nickname}}的简历</router-link>
                    </li>
                    <li>></li>
                    <li>
                        <router-link to="#">作品列表</router-link>
                    </li>
                </ul>
            </div>
            <div class="content" style="overflow:hidden;">
                <div class="sidebar" style="float:left;">
                    <div class="bgfff">
                        <div class="u-image">
                            <img :src="item. image_url" :alt="item.nickname">
                        </div>
                        <ul class="designer-ul text-center">
                            <li>姓名：{{item.realname}}（{{item.nickname}}）</li>
                            <li>月薪要求：
                                <span style="color: #f54203; font-weight: bold;">{{item.salary}}</span> /月</li>
                            <li>
                                <Button type="ghost" @click="employ" class="btn-f54203">立即雇佣</Button>
                                <Dropdown v-if="info.id" class="drop" style="margin-left: 20px">
                                    <Button long type="error">
                                            联系他
                                            <Icon type="arrow-down-b"></Icon>
                                        </Button>
                                    <Dropdown-menu slot="list">
                                        <Dropdown-item>
                                            Q Q：{{contractInfo.qq}}&nbsp;&nbsp;
                                            <Button type="ghost" size="small" :data-clipboard-text="contractInfo.qq" class="copyBtn">复制</Button>
                                        </Dropdown-item>
                                        <Dropdown-item>
                                            手机：{{contractInfo.phone}}
                                        </Dropdown-item>
                                    </Dropdown-menu>
                                </Dropdown>
                                <Button type="error" style="margin-left: 20px;width: 78px;" @click="contact" v-else>联系他</Button>
                            </li>
                            <li>
                                <Button type="ghost" long @click="redirect" class="btn-f54203">个人简历</Button>
                            </li>
                        </ul>
                    </div>
                    <div style="margin-top: 40px;">
                        <div style="background-color: #f54203;color: #fff;padding: 15px 0;text-align: center;font-size: 18px;">四大平台保障</div>
                        <ul class="sideimg">
                            <li>
                                <a href="/rules?index=1">
                                    <img :src="'icon/wuyou1.png' | randomPath" alt="选人无忧">
                                </a>
                            </li>
                            <li>
                                <a href="/rules?index=2">
                                    <img :src="'icon/wuyou2.png' | randomPath" alt="雇佣无忧">
                                </a>
                            </li>
                            <li>
                                <a href="/rules?index=3">
                                    <img :src="'icon/wuyou3.png' | randomPath" alt="品质无忧">
                                </a>
                            </li>
                            <li>
                                <a href="/rules?index=4">
                                    <img :src="'icon/wuyou4.png' | randomPath" alt="售后无忧">
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="main-content" style="float:right;">
                    <div class="wsl-tag-style">
                        <div>
                            <span style="font-weight: bold;">作品类目</span>（共{{count}}个原创作品）：</div>
                        <ul>
                            <li>
                                <a @click="setClassid()" :class="classId == '' ? 'active':''" href="javascript:;">全部</a>
                            </li>
                            <li v-for="e in proClassList" :key="e.id">
                                <a :class="classId == e.id ? 'active':''" @click="setClassid(e.id)" href="javascript:;">{{e.name}}</a>
                            </li>
                        </ul>
                    </div>
                    <ul class="products-ul">
                        <li v-for="product in products" :key="product.id">
                            <div class="product-image">
                                <router-link :to="{ name: 'proInfo', params: { id: product.id}}">
                                    <img :src="product.image_url+'!288x310'" :alt="product.name">
                                </router-link>
                            </div>
                            <div style="padding: 10px 20px;border-top: 1px solid #efefef;min-height:66px;">
                                <div style="font-size: 16px;color: #807f7f;overflow: hidden;text-overflow:ellipsis;white-space:nowrap;">{{product.store_name}}</div>
                                <div style="font-size: 14px;color: #a6a6a6;overflow: hidden;text-overflow:ellipsis;white-space:nowrap;">{{product.name}}</div>
                                <div style="height: 46px; display: none; align-items: center;">
                                    <Icon type="eye" size="16"></Icon>&nbsp;&nbsp;
                                    <span>{{product.viewtimes || 0}}</span>&nbsp;&nbsp;
                                    <Icon type="heart" size="16"></Icon>&nbsp;&nbsp;
                                    <span>{{product.loves || 0}}</span>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import { mapState } from 'vuex';
export default {
  data() {
    return {
      item: {},
      products: [],
      contractInfo: {},
      proClassList: [],
      classId: '',
      count: 0
    };
  },
  computed: {
    ...mapState({
      info: state => state.User.info,
      typeList: state => state.Lists.typeList,
      companyList: state => state.Lists.companyList, //公司分类
      parentList: state => state.Lists.parentList, //父分类
      childList4: state => state.Lists.childList4, //子分类
      defaultSrc: state => state.User.defaultSrc,
      ftpPath: state => state.User.ftpPath
    })
  },
  mounted() {
    const { id } = this.$route.params;
    if (!id) return;
    // this.$ajax.get('designer/product', {
    //     id
    // }).then(e => {
    //     if (e.status !== 200) return;
    //     this.products = e.data.list;
    // });
    this.$ajax
      .get('designer/get', {
        id
      })
      .then(e => {
        if (e.status !== 200) return;
        this.item = e.data;
      });
    if (this.info.id) {
      this.getContractInfo();
    }
    // eslint-disable-next-line
    const clipboard = new Clipboard('.copyBtn');
    clipboard.on('success', e => {
      this.$Message.info('已复制');
      e.clearSelection();
    });
    this.getProClass();
    this.getList();
  },
  watch: {
    'info.id'(val) {
      if (val) {
        this.getContractInfo();
      } else {
        this.contractInfo = {};
      }
    }
  },
  methods: {
    getList() {
      let id = this.$route.params.id;
      if (!id) return;
      this.$ajax
        .get('designer/product', {
          id: id,
          classId: this.classId
        })
        .then(e => {
          if (e.status !== 200) return;
          this.products = e.list;
          this.count = e.totalCount;
        });
    },
    getContractInfo() {
      const { id } = this.$route.params;
      this.$ajax
        .get('designer/contractInfo', {
          id
        })
        .then(e => {
          if (e.status !== 200) return;
          this.contractInfo = e.data;
        });
    },
    employ() {
      if (!this.info.id) {
        window.location.href = `/user/login?redirect=${encodeURIComponent(
          location.pathname
        )}`;
        // this.$store.commit('SETTING_LOGIN_MODAL', true);
        return;
      }
      const id = this.$route.params.id;
      if (id) {
        this.$router.push({
          name: 'hire',
          params: {
            id
          }
        });
      }
    },
    contact() {
      if (!this.info.id) {
        window.location.href = `/user/login?redirect=${encodeURIComponent(
          location.pathname
        )}`;
        // this.$store.commit('SETTING_LOGIN_MODAL', true);
        // return;
      }
    },
    redirect() {
      const id = this.$route.params.id;
      if (id) {
        this.$router.push({
          name: 'detailForDesigner',
          params: {
            id
          }
        });
      }
    },
    getProClass() {
      const id = this.$route.params.id;
      if (id) {
        this.$ajax
          .get('designer/product/classes', {
            id: id
          })
          .then(e => {
            if (e.status !== 200) return;
            this.proClassList = e.data;
          });
      }
    },
    setClassid(id) {
      if (id <= 0) {
        id = '';
      }
      this.classId = id;
      this.getList();
    }
  }
};
</script>

<style scoped>
.btn-f54203.ivu-btn-ghost:hover {
  color: #f54102;
  border-color: #f54102;
}
.wsl-tag-style {
  overflow: hidden;
  padding: 23px 22px 0 22px;
}
.wsl-tag-style ul,
.wsl-tag-style div {
  float: left;
  font-size: 14px;
  color: #646464;
}
.wsl-tag-style ul li {
  float: left;
}
.wsl-tag-style a {
  color: #646464;
  display: block;
  margin: 0 10px;
}
.wsl-tag-style a:hover,
.wsl-tag-style a.active {
  color: #f54102;
}
.container {
  width: 1280px;
  margin: 0 auto;
  padding-top: 20px;
}
.breadcrumb {
  font-size: 12px;
}
.breadcrumb-ul {
  display: inline-block;
  vertical-align: bottom;
}
.breadcrumb-ul li {
  padding-right: 5px;
  float: left;
}
.breadcrumb-ul a {
  color: #646464;
}
.content {
  margin-top: 20px;
}
.sidebar {
  width: 250px;
  display: inline-block;
}
.main-content {
  width: 995px;
  display: inline-block;
  background-color: #fff;
  vertical-align: top;
}

.bgfff {
  background-color: #fff;
  padding-bottom: 20px;
}

.u-image {
  width: 210px;
  height: 250px;
  margin: 0 auto;
  padding: 20px 0;
  overflow: hidden;
}
.u-image img {
  width: 100%;
}
.designer-ul {
  width: 185px;
  margin: 0 auto;
}
.designer-ul > li {
  margin: 5px 0;
}
.text-center {
  text-align: center;
}
.products-ul li {
  float: left;
  width: 290px;
  margin: 20px;
  border: 1px solid #efefef;
}
.product-image {
  overflow: hidden;
  height: 310px;
}
.product-image img {
  width: 100%;
}
.ivu-dropdown-item {
  text-align: left;
}
.sideimg {
  background-color: #fff;
  padding-top: 60px;
  padding-bottom: 60px;
}
.sideimg li {
  width: 100px;
  height: 100px;
  margin: 60px auto;
  text-align: center;
}
.sideimg li:first-child {
  margin-top: 0;
}
</style>
