<template>
    <div class="proinfo bg">
        <div class="con marginauto1280 clearfix">
            <div class="top clearfix">
                <ul class="desc float-left">
                    <li style="margin-bottom: 10px;">{{storeName}}</li>
                    <li style="max-height: 70px;overflow: hidden;width: 806px;height: auto;"><a @click="setProinfo(e)" :class="e.id == proinfo.id ? 'active':''" class="wsl-btn-tag-style" href="javascript:;" v-for="e in designerWorkProductList" :key="e.id" >{{e.name}}</a> </li>
                    <li>本案例由{{infoData.nickname}}原创，未经作者许可，禁止转载或商业使用。</li>
                    <li>上传时间：{{infoData.createDate}}</li>
                </ul>
                <div class="psl-info float-right">
                    <p>
                        <span class="marginright10">{{infoData.nickname}}</span>
                        <Icon type="female" v-if="infoData.gender == 1" style="color:#ff2c68;font-size:16px;"></Icon>
                        <Icon type="male" v-else style="color:#0095f3;font-size:16px;"></Icon>
                        <img :src="`icon/security.png` | randomPath" alt="保障">
                        <img :src="`icon/certification.png` | randomPath" alt="平台认证">
                    </p>
                    <p>{{infoData.gender == 1 ? '女':'男'}}&nbsp;&nbsp;{{infoData.age}}岁&nbsp;&nbsp;{{infoData.city}}</p>
                    <p>薪资：{{infoData.salary}}/月</p>
                    <p class="margintop10">
                        <Button @click="phoneModal" v-if="info.id" class="btn btn1">查看简历</Button>
                        <Button @click="login" v-else class="btn btn1">查看简历</Button>

                        <Dropdown v-if="info.id" class="dropitem">
                            <Button long type="warning" class="btn btn2">
                                联系{{infoData.gender == 1 ? '她':'他'}}
                                <Icon type="arrow-down-b"></Icon>
                            </Button>
                            <Dropdown-menu slot="list">
                                <Dropdown-item v-if="infoData.phone">
                                    电话：</Icon>&nbsp;&nbsp;{{infoData.phone}}
                                </Dropdown-item>
                                <Dropdown-item v-if="infoData.qq">
                                    QQ：</Icon>&nbsp;&nbsp;{{infoData.qq}}
                                    <Button type="ghost" size="small" :data-clipboard-text="infoData.qq" class="copyBtn">复制</Button>
                                </Dropdown-item>
                            </Dropdown-menu>
                        </Dropdown>
                        <Button type="error" @click="login" v-else class="btn btn2">联系{{infoData.gender == 1 ? '她':'他'}}</Button>
                    </p>
                </div>
                <div class="float-right marginright25">
                    <img v-lazy="infoData.image_url || defaultSrc" height="165px" width="140px" alt="">
                </div>
            </div>
            <div v-if="proinfo.details" class="btm">
                <p class="font16 proname">{{proinfo.tag}}</p>
                <div class="btm-con" v-html="proinfo.details" style="overflow:hidden;line-height:0;"></div>
                <p class="ckjl">
                    <Button @click="phoneModal" v-if="info.id">
                        <Icon type="ios-eye-outline" style="font-size:38px"></Icon>
                        <span style="font-size:20px">&nbsp;查看简历</span>
                    </Button>
                    <Button @click="login" v-else>
                        <Icon type="ios-eye-outline" style="font-size:38px"></Icon>
                        <span style="font-size:20px">&nbsp;查看简历</span>
                    </Button>
                </p>
            </div>
            <h3 v-else class="text-center message">该作者很懒，还没有上传作品！</h3>
        </div>

        <div class="ivu-modal-mask" v-if="registerModal"></div>
        <div class="ivu-modal-wrap" v-if="registerModal">
            <Register :cancle="cancle"></Register>
        </div>
    </div>
</template>

<script>
import Register from '@/components/register.vue';
import router from '@/router/index.js';
import moment from 'moment';
import { mapState } from 'vuex';

export default {
  data() {
    return {
      infoData: {},
      designerWorkProductList: [],
      registerModal: false,
      storeName: '',
      proinfo: {
        id: '',
        details: '',
        name: '',
        tag: ''
      }
    };
  },
  computed: {
    ...mapState({
      defaultSrc: state => state.User.defaultSrc,
      info: state => state.User.info,
      ftpPath: state => state.User.ftpPath
    })
  },
  components: {
    Register
  },
  mounted() {
    this.getinfo();

    let _this = this;
    let clipboard = new Clipboard('.copyBtn');

    clipboard.on('success', function(e) {
      _this.$Message.info('已复制');
      e.clearSelection();
    });
  },
  methods: {
    login() {
      this.$store.commit('SETTING_LOGIN_MODAL', true);
    },
    cancle() {
      this.registerModal = false;
    },
    loginout() {
      this.$store.commit('set_user_data', {});
      //  this.$root.$emit("LOGIN_OUT");
      this.$ajax.post('auth/logout').then(e => {});
    },
    phoneModal() {
      let id = this.infoData.user_id;
      this.$router.push({ name: 'detailForDesigner', params: { id } });
    },
    getinfo() {
      const id = this.$route.params.id;
      if (!id) return;
      this.$ajax
        .get('designer/work/product/list', { designerWorkId: id })
        .then(e => {
          if (e.status != 200) {
            return;
          }
          e.data.user.createDate = moment(e.data.user.createDate).format(
            'YYYY-MM-DD hh:mm:ss'
          );
          this.infoData = e.data.user;
          this.storeName = e.data.storeName;
          this.designerWorkProductList = e.data.designerWorkProductList;
          if (e.data.designerWorkProductList.length > 0) {
            this.proinfo.id = e.data.designerWorkProductList[0].id;
            this.proinfo.details = e.data.designerWorkProductList[0].details;
            this.proinfo.name = e.data.designerWorkProductList[0].name;
            this.proinfo.tag = e.data.designerWorkProductList[0].tag;
          }
        });
    },
    setProinfo(e) {
      console.log(e);
      this.proinfo.id = e.id;
      this.proinfo.details = e.details;
      this.proinfo.name = e.name;
      this.proinfo.tag = e.tag;
    },
    hirePage() {
      router.push({
        path: '/hire/' + this.infoData.user_id
      });
    }
  }
};
</script>
<style>
.wsl-btn-tag-style {
  margin-right: 33px;
  margin-top: 5px;
  padding: 0 10px;
  display: block;
  float: left;
  height: 28px;
  line-height: 28px;
  color: #646464;
  font-size: 14px;
}
.wsl-btn-tag-style:hover,
.wsl-btn-tag-style.active {
  background-color: #f54203;
  color: #fff;
  border-radius: 5px;
}
.bg {
  background: #eeeeee;
}

.proinfo {
  padding: 10px 0;
}

.marginauto1280 {
  margin: 0 auto;
  width: 1280px;
}

.proinfo .con {
  background: #eee;
  box-shadow: 0 0 1px #ccc;
}

.proinfo .con .top {
  padding: 45px 50px;
  background: #fff;
  margin-bottom: 15px;
}

.proinfo .con .top ul.desc li {
  width: 805px;
  line-height: 24px;
  height: 24px;
  overflow: hidden;
  font-size: 14px;
  color: #bababa;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.proinfo .con .top ul.desc li:first-child {
  font-size: 20px;
  color: #646464;
}

.proinfo .con .top ul.desc li:nth-child(2) {
  color: #888888;
  height: 60px;
  line-height: 60px;
}

.proinfo .con .top ul.desc li:nth-child(3) {
  margin-top: 10px;
  line-height: 30px;
  max-height: 60px;
}

.psl-info {
  margin-right: 30px;
}

.psl-info p {
  font-size: 14px;
  color: #888888;
}

.psl-info .ivu-select-dropdown {
  left: inherit !important;
}

.psl-info p:first-child {
  font-size: 16px;
  color: #646464;
  height: 88px;
  line-height: 130px;
}

.psl-info p .btn {
  height: 25px;
  line-height: 25px;
  width: 82px;
  border-radius: 2px;
}

.psl-info .btn {
  padding: 0;
}

.psl-info p .btn1 {
  color: #bababa;
}

.proinfo .con .btm {
  padding-top: 25px;
  background: #fff;
}

.ckjl {
  text-align: center;
  height: 170px;
  line-height: 170px;
}

.ckjl span:first-child {
  display: inline-flex;
  height: 30px;
  line-height: 30px;
}

.proinfo .con .btm .proname {
  padding-left: 50px;
  padding-right: 50px;
  height: 80px;
  line-height: 80px;
  color: #646464;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.proinfo .con .btm-con {
  text-align: center;
  /*padding:0px 245px;*/
  width: 100%;
  word-wrap: break-word;
}

.proinfo .con .btm-con img {
  max-width: 970px;
  min-width: 200px;
}

.psl-info .btn1:hover {
  border: 1px solid #d7dde4;
}

.psl-info .btn2 {
  border: 1px solid #f54203;
  background: #f54203;
}

.psl-info .btn2:hover {
  background: #f54203;
  border: 1px solid #f54203;
}

.psl-info .copyBtn {
  padding: 0 2px;
  float: right;
}
</style>

<style>
.ckjl .ivu-btn {
  height: 45px;
  line-height: 45px;
  width: 170px;
  background: #f54203;
  color: #fff;
  border: 1px solid #f54203;
  font-size: 20px;
}

.ckjl .ivu-icon {
  line-height: inherit;
}

.proinfo .con .top .dropitem .ivu-dropdown-item:hover,
.dropitem .ivu-btn-ghost.active,
.ivu-btn-ghost:active,
.dropitem .ivu-btn-ghost:hover {
  color: #f54203;
}

.dropitem .ivu-btn:hover,
.dropitem .ivu-btn-ghost.active,
.dropitem .ivu-btn-ghost:active {
  border-color: #f54203;
}

.dropitem .ivu-select-dropdown {
  min-width: 160px;
  margin: 0;
}

.dropitem .ivu-dropdown-item {
  padding: 3px 4px;
  line-height: 20px;
}

.dropitem .ivu-dropdown-item:hover {
  background: #fff;
}
</style>
