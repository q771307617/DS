<template>
    <div class="loginandreg-page">
        <Banner></Banner>
        <RecommendDesigner :title="'推荐设计师'" :pageSize='8' :id='1' :changeShow="changeShow" v-show="isShow"></RecommendDesigner>
        <SearchDesigner v-if="isShow"></SearchDesigner>
        <GoodCase v-if="isShow"></GoodCase>

        <RecommendDesigner v-if="isShow" :title="'新晋设计师'" :pageSize='4' :id='2'></RecommendDesigner>
        <CooperationCase v-if="isShow"></CooperationCase>
    </div>
</template>

<script>
import login from '@/components/login.vue';
import register from '@/components/register.vue';
import Logout from '@/components/loginout.vue';
import Banner from '@/components/index_com/banner.vue';
import RecommendDesigner from '@/components/index_com/recommendDesigner.vue';
import GoodCase from '@/components/index_com/goodCase.vue';
import CooperationCase from '@/components/index_com/cooperationCustom.vue';
import SearchDesigner from '@/components/index_com/searchDesigner.vue';

export default {
  components: {
    login,
    register,
    Logout,
    Banner,
    RecommendDesigner,
    GoodCase,
    CooperationCase,
    SearchDesigner
  },
  data() {
    return {
      isShow: false
    };
  },
  methods: {
    changeShow() {
      this.isShow = true;
    }
  }
};
</script>
