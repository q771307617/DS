<template>
    <div class="main">
        <!--顶部-->
        <sixi-header></sixi-header>
        <!--头部-->
        <sixi-search></sixi-search>
        <!--页面-->
        <router-view></router-view>
        <!--底部-->
        <sixi-fotter></sixi-fotter>
    </div>
</template>

<script>
import sixiHeader from '@/components/header';
import sixiFotter from '@/components/fotter';
import sixiSearch from '@/components/search';
import router from '../router/index.js';
import { mapState, mapActions } from 'vuex';

const loginItem = [
  {
    lebal: '首页',
    id: 1,
    path: '/'
  },
  {
    lebal: '看作品',
    id: 2,
    path: '/prolist'
  },
  {
    lebal: '找设计师',
    id: 4,
    path: '/search/designer'
  },
  {
    lebal: '雇主后台',
    id: 3,
    path: '/emloyerBackstage'
  }
];
const notLoginItem = [
  {
    lebal: '首页',
    id: 1,
    path: '/'
  },
  {
    lebal: '看作品',
    id: 2,
    path: '/prolist'
  },
  {
    lebal: '找设计师',
    id: 4,
    path: '/search/designer'
  }
];
export default {
  components: { sixiHeader, sixiSearch, sixiFotter },
  data() {
    return {
      keyword: '',
      activeMenu: 1
    };
  },
  computed: {
    ...mapState({
      cates: state => state.pub.cates,
      info: state => state.User.info
    }),
    items() {
      if (this.info.id) {
        return loginItem;
      } else {
        return notLoginItem;
      }
    }
  },
  mounted() {
    if (!this.cates) {
      this.fetchCates();
    }
    // this.$root.$on("LOGIN_OK", () => {
    //     this.items = loginItem
    // });
    // this.$root.$on("LOGIN_OUT", () => {
    //     this.items = notLoginItem;
    // });
    this.queryAuthInfo();
  },
  methods: {
    ...mapActions(['fetchCates']),
    queryAuthInfo() {
      if (this.info.id) {
        this.$root.$emit('LOGIN_OK');
      } else {
        this.$root.$emit('LOGIN_OUT');
      }
    },
    menuSelect(item) {
      this.activeMenu = item.id;
      router.push({
        path: item.path
      });
    }
  }
};
</script>


<style scoped>
.active {
  background-color: #f54203;
  color: #fff;
}

.nav ul li {
  cursor: pointer;
}

.nav ul li a {
  color: #3c3c3c;
}
</style>

