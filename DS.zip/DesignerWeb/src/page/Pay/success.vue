<template>
    <div class="pay-box">
        <h2 style="color:red;">
            您的位置: 付款成功提示
        </h2>
        <p>
            订单号: {{orderid}}
        </p>
        <span>您已成功付款，我们将按要求完成您的需求！感谢您的支持！</span>
        <div style="margin-top:10px;">
            <Button type="warning" style="margin-right:10px;" @click="ok">确认</Button>
            <Button type="warning" @click="back">查看</Button>
        </div>
    </div>
</template>
<style scoped>
.pay-box {
  text-align: center;
  line-height: 2.5;
  padding-top: 100px;
  padding-bottom: 100px;
}
</style>

<script>
import router from '@/router';
export default {
  data() {
    return {
      orderid: {}
    };
  },
  mounted() {
    this.queryOrderInfo();
  },
  methods: {
    ok() {
      if (this.$route.query.type == 'BAIL') {
        router.push({ name: 'entryIntoSuccess' });
      } else {
        router.push({ name: 'EmloyerHome' });
      }
    },
    back() {
      if (this.$route.query.type == 'BAIL') {
        router.push({ name: 'entryIntoSuccess' });
      } else {
        router.push({ name: 'EmloyerHome' });
      }
    },
    queryOrderInfo() {
      this.orderid = this.$route.query.id;
    }
  }
};
</script>

