<template>
    <div class="pay-box">
        <h2 style="color:red;">
            您的位置: 请耐心等待支付结果
        </h2>
        <p>
            订单号: {{orderInfo.trade_record_order_no}}
        </p>
        <span>请耐心等待,系统正在确认支付结果。</span>
        <div style="margin-top:10px;">
            <Button type="warning" style="margin-right:10px;" @click="lookInfo">查看详情</Button>
            <Button type="warning" @click="backHome">返回首页</Button>
        </div>
    </div>
</template>
<style scoped>
.pay-box {
  text-align: center;
  line-height: 2.5;
  padding-top: 100px;
  padding-bottom: 100px;
}
</style>
<script>
import router from '@/router';
export default {
  data() {
    return {
      orderInfo: {}
    };
  },
  mounted() {
    this.queryOrderInfo();
  },
  methods: {
    backHome() {
      router.push({ name: 'home' });
    },
    lookInfo() {
      router.push({ name: 'employmentManagement' });
    },
    queryOrderInfo() {
      this.$ajax.get('hire/info', { hireId: this.$route.query.id }).then(e => {
        if (e.status == 200) {
          this.orderInfo = e.data;
        }
      });
    }
  }
};
</script>