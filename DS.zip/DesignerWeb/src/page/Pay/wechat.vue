<template>
  <div style="width: 1280px;margin: auto;">
    <div style="color: #000000;font-size: 26px;">
      <img src="http://3.img.dianjiangla.com/assets/icon/wechat-large.png" alt="" style="vertical-align: middle;"> 微信支付
    </div>
    <div style="margin-bottom: 123px;">
      <p style="margin: 37px 0;padding: 0 20px;color: #646464;font-size: 16px;">
        订单号：{{$route.query.orderId}}</p>
      <p style="color: #646464;font-size: 16px;text-align: center;">扫一扫付款（元）</p>
      <p style="text-align: center; color: #3b3b3b;font-size: 45px;font-weight: 600;margin-bottom: 20px;">
        {{orderInfo.amount}}</p>
      <div style="text-align: center;border: 1px solid #dddee1;width: 202px;margin: auto;">
        <vue-qrcode :value="orderInfo.url || ''" :options="{ size: 200 }" v-if="orderInfo.url"></vue-qrcode>
        <div v-else class="load">
          <p>二维码生成中......</p>
        </div>
        <div style="width: 200px;height: 40px;background-color: #495060;margin: auto;line-height: 40px;color: #ffffff;font-size: 20px;">
          扫码支付
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import VueQrcode from '@xkeshi/vue-qrcode';

export default {
  components: { VueQrcode },
  data() {
    return {
      orderInfo: {},
      update: null,
      frequency: 0
    };
  },
  destroyed() {
    clearInterval(this.update);
  },
  mounted() {
    this.getQS();
  },
  methods: {
    getQS() {
      if (!this.$route.query.orderId) return;
      const type = this.$route.query.type;
      let redirectUrl = '';
      if (type === 'demand') {
        redirectUrl = '/emloyerBackstage/demandManagent/index';
      } else if (type === 'hire') {
        redirectUrl = '/emloyerBackstage/employmentManagement';
      } else if (type === 'BAIL') {
        redirectUrl = '/join/entryIntoSuccess';
      } else {
        redirectUrl = '/emloyerBackstage/trading_record/index';
      }
      setTimeout(() => {
        clearInterval(this.update);
      }, 1000 * 60 * 5);
      this.refalshqs = this.$ajax
        .get('pay/wx', { id: this.$route.query.orderId })
        .then(e => {
          if (e.status !== 200) {
            this.getQS();
            this.$Message.error(e.msg);
            return;
          }
          this.orderInfo = e.data;
          //查询是否支付成功
          this.update = setInterval(() => {
            this.$ajax
              .get('pay/wx/query', { out_trade_no: this.$route.query.orderId })
              .then(e => {
                if (e.status !== 200) {
                  clearInterval(this.update);
                  this.$Message.error(e.msg);
                  return;
                }
                if (e.data === 'SUCCESS') {
                  clearInterval(this.update);
                  location.href = redirectUrl;
                }
              });
          }, 1500);
        })
        .catch(e => {
          this.frequency++;
          if (this.frequency < 50) {
            this.getQS();
          } else {
            this.$Message.error('网络异常！');
          }
        });
    }
  }
};
</script>
<style scoped>
.load {
  height: 200px;
  width: 200px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 18px;
}
</style>
