<template>
    <div class="fail-box">
        <h2 style="color:red;">
            您的位置: 付款失败提示
        </h2>
        <p>
            订单号: 2017052978321978
        </p>
        <span>您本次支付宝付款未成功，请尝试重新支付，或联系我们的客服人员</span>
        <div>
            <Button @ok="ok">重新支付</Button>
            <Button @click="back">查看</Button>
        </div>
    </div>
</template>
<style scoped>
.fail-box {
  text-align: center;
  line-height: 2.5;
  padding-top: 100px;
  padding-bottom: 100px;
}
</style>
<script>
import router from '@/router';
export default {
  data() {
    return {
      orderInfo: {}
    };
  },
  mounted() {
    this.queryOrderInfo();
  },
  methods: {
    ok() {
      router.push({
        name: 'payment',
        query: {
          hireId: router.query.hireId
        }
      });
    },
    back() {
      router.push({ name: 'employmentManagement' });
    },
    queryOrderInfo() {
      this.$ajax.get('hire/info', { hireId: this.$route.query.id }).then(e => {
        if (e.status == 200) {
          this.orderInfo = e.data;
        }
      });
    }
  }
};
</script>