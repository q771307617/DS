<template>
    <div class="information">
        <table width="100%" style="min-height:900px">
            <tr>
                <td valign="top">
                        <!--<Col span="5"><img :src="userInfo.image_url" alt="" class="user-avatar"></Col>-->
                    <div class="content">
                        <ul>
                            <li class="box-shadow font16">
                                <p class="clearfix height70">
                                    <span class="title float-left font-weight">尊敬的{{userInfo.nickname}}{{userInfo.gender==0?'先生':'女士'}} 下午好！</span>
                                    <a @click="selectActiveMenu()" class="link float-right">更改信息</a>
                                </p>
                                <p class="desc-color">手机号：{{userInfo.phone}}<span class="font14">（绑定后，可用于快速找回登录密码，接收账户余额变动提醒）</span></p>
                            </li>
                            <li class="box-shadow row" v-if="userInfo.type == 1">
                                <p class="clearfix height67">
                                    <span class="title float-left">支付宝绑定</span>
                                    <a @click="bindalipay()" class="link float-right" v-if="userInfo.alipay_account">修改绑定</a>
                                    <a @click="bindalipay()" class="link float-right" v-else>立即绑定</a>
                                </p>
                                <p class="desc-color"><span class="link" v-if="userInfo.alipay_account">支付宝已绑定</span>
                                <span class="link" v-else>暂未绑定</span>
                                （绑定后，可用于充值和提现，提升账户安全）</p>                           
                            </li>
                            <li class="box-shadow row" v-if="userInfo.type == 1">
                                <p class="clearfix height67">
                                    <span class="title float-left">公司信息</span>
                                    <a @click="selectActiveMenu()" class="link float-right">编辑</a>
                                </p>
                                <p class="desc-color">填写公司信息，可以方便我们更加了解您的公司！</p>
                            </li>
                            <li class="box-shadow row" v-if="userInfo.type == 1">
                                <p class="clearfix height67">
                                    <span class="title float-left">店铺信息</span>
                                    <a @click="selectActiveMenu()" class="link float-right">添加店铺</a>
                                </p>
                                <p class="desc-color">填写店铺信息，可以方便我们更加了解您的店铺！</p>
                            </li>
                        </ul>
                    </div>
                </td>
            </tr>
        </table>
    </div>
</template>

<script>
// import router from '../../../router/index.js';
import { mapState, mapActions } from 'vuex';
export default {
  data() {
    return {
      codeNum: '',
      userinfo: ''
    };
  },
  mounted() {
    this.fetchUserData();
  },
  computed: {
    ...mapState({ userInfo: state => state.User.info })
  },
  methods: {
    ...mapActions(['fetchUserData']),
    //修改个人信息
    selectActiveMenu() {
      this.$router.push({ name: 'editinfo' });
    },
    bindalipay() {
      this.$router.push({ name: 'bindalipay', params: { id: 1 } });
    }
  }
};
</script>
<style scoped>
.information {
  background: #fafafa;
}
.content ul li:first-child {
  height: 134px;
  padding: 15px 0 15px 37px;
  margin: 0;
}
.content ul li {
  height: 112px;
  margin-top: 15px;
  background: #fff;
}

.desc-color {
  color: #888888;
}
.height70 {
  height: 76px;
  line-height: 76px;
}
.height67 {
  height: 55px;
  line-height: 55px;
}
.row {
  padding-left: 37px;
  padding-top: 10px;
  font-size: 16px;
}
.title {
  font-size: 17px;
  color: #1a1a1a;
}
.font-weight {
  font-weight: bold;
}
.link {
  width: 140px;
  color: #f54203;
}
.link:hover {
  color: #f54203;
  text-decoration: underline;
}

/*.user-avatar {
    width:180px;
    border-radius: 3px;
    float: left;
    padding: 20px;
}*/
</style>
