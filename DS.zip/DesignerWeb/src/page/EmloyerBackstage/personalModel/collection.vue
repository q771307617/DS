<style>
.collection {
  padding-left: 10px;
}

.collection .con {
  margin-top: 5px;
  min-height: 500px;
  border: 1px solid #ccc;
  padding: 10px;
}

.collection .con .title {
  color: #39f;
  font-size: 26px;
  height: 50px;
}

.collection .con .img-box {
  margin-top: 20px;
  background: #fff;
  border: 1px solid #ccc;
  box-shadow: 1px 1px 5px #888888;
}

.collection .con .img-box:last-child {
  margin-right: 0;
}

.collection .con .img-box .btn-box {
  height: 25px;
}

.collection .con .img-box .li-btn {
  background: #fff;
  border: 1px solid #ccc;
  padding: 0 5px;
  margin-left: 5px;
}
</style>

<template>
    <div>
        <table width="100%" style="min-height:900px">
            <tr>
                <td width="820" valign="top">
                    <div class="collection">
                        <div class="con">
                            <p class="title">收藏的作品</p>
                            <Row :gutter="24">
                                <Col span="8" v-for="item in myfavItem" v-if="item.type == 1" :key="item.id">
                                    <div class="img-box">
                                        <img :src="item.p_image_url" width="100%" alt="">
                                        <p class="btn-box text-center">
                                            <input type="button" :value="'编号：' + item.id" class="li-btn" />
                                            <input type="button" value="立即使用" class="li-btn" />
                                        </p>
                                    </div>
                                </Col>
                            </Row>
                        </div>
                        <div class="con" style="min-height:380px;">
                            <p class="title">收藏的设计师</p>
                            <Row :gutter="24">
                                <Col span="6" v-for="item in myfavItem" v-if="item.type == 0" :key="item.id">
                                    <div class="img-box">
                                        <img :src="item.p_image_url" width="100%" alt="">
                                        <p class="btn-box text-center">
                                            <input type="button" :value=" '编号：' + item.id" class="li-btn"/>
                                            <input type="button" value="提前预约" class="li-btn" />
                                        </p>
                                    </div>
                                </Col>
                            </Row>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
    </div>
</template>

<script>
import { mapState, mapActions } from 'vuex';

export default {
  data() {
    return {
      userInfo: {},
      myfavItem: []
    };
  },
  mounted() {
    this.getInfo();
    this.getmyfav();
  },
  computed: {
    ...mapState({ userInfo: state => state.User.info })
  },
  methods: {
    //我的收藏
    getmyfav() {
      this.$ajax.get('user/getmyfav', {}).then(e => {
        this.myfavItem = e.data;
      });
    }
  }
};
</script>
