<template>
<div class="editinfo">
            <table width="100%" class="row height202 box-shadow">
                <tr>
                    <td width="820" valign="top">
                        <div>
                            <p class="title">个人信息</p>
                            <Form ref="formValidate" :model="userInfo" :rules="ruleValidate" :label-width="70">
                                <Form-item label="昵称：" prop="nickname">
                                    <Input v-model="userInfo.nickname" placeholder="请输入昵称"></Input>
                                </Form-item>
                                <Form-item label="性别：" prpo="gender">
                                    <Radio-group v-model="userInfo.gender">
                                        <Radio label="0">男</Radio>
                                        <Radio label="1">女</Radio>
                                    </Radio-group>
                                </Form-item>
                                <Form-item label="QQ：" prpo="wechat">
                                    <Input v-model="userInfo.wechat" placeholder="请输入QQ"></Input>
                                </Form-item>
                                <Form-item class="text-center" v-if="userInfo.type != 1">
                                    <Button type="primary" @click="subform('formValidate')" class="btn sub-btn">提交</Button>
                                    <Button type="ghost" @click="cancel" class="btn cel-btn">取消</Button>
                                </Form-item>
                            </Form>
                        </div>
                    </td>
                </tr>
            </table>

            <table width="100%" class="row box-shadow" v-if="userInfo.type == 1">
                <tr>
                    <td width="820" valign="top">
                        <div>
                            <p class="title">公司信息</p>
                            <Form :model="userInfo" :label-width="90">
                                <Form-item label="公司名称：" prpo="company">
                                    <Input v-model="userInfo.company" placeholder="请输入公司名称"></Input>
                                </Form-item>
                                <Form-item label="企业行业：" prpo="company_type">
                                    <Select v-model="userInfo.company_type" placeholder="电子商务">
                                        <Option v-for="(item,index) in companyItem" :value="item" :key="index">{{item}}</Option>
                                    </Select>
                                </Form-item>
                            </Form>
                        </div>
                    </td>
                </tr>
            </table>

            <table width="100%" class="row box-shadow" v-if="userInfo.type == 1">
                <tr>
                    <td width="820">
                        <div>
                            <p class="title">店铺信息</p>
                            <Form :model="userInfo" :label-width="90">
                                <Form-item label="店铺名称：" prpo="store_name">
                                    <Input v-model="userInfo.store_name" placeholder="请输入公司名称"></Input>
                                </Form-item>
                                <Form-item label="店铺地址：" prpo="store_url">
                                    <Input v-model="userInfo.store_url" placeholder="请输入店铺地址"></Input>
                                </Form-item>
                                <Form-item class="text-center">
                                    <Button type="primary" @click="subform('formValidate')" class="btn sub-btn">提交</Button>
                                    <Button type="ghost" @click="cancel" class="btn cel-btn">取消</Button>
                                </Form-item>
                            </Form>
                        </div>
                    </td>
                </tr>
            </table>

</div>
</template>

<script>
import { mapActions } from 'vuex';

export default {
  data() {
    return {
      companyItem: [],
      activeName: this.$route.query.activeName || '0',
      ruleValidate: {
        nickname: [{ required: true, message: '昵称不能为空', trigger: 'blur' }]
      },
      userInfo: {}
    };
  },
  mounted() {
    this.getcompany();
    this.getInfo();
  },
  methods: {
    ...mapActions(['fetchUserData']),
    cancel() {
      this.$router.push({ name: 'information' });
    },
    //获取公司行业
    getcompany() {
      this.$ajax.get('class/company', {}).then(e => {
        this.companyItem = e.data;
      });
    },
    getInfo() {
      this.$ajax.get('user/info', {}).then(e => {
        if (e.status !== 200) return;
        this.userInfo = e.data;
      });
    },
    // 修改雇主信息
    subform(name) {
      this.$refs[name].validate(valid => {
        if (!valid) {
          return;
        }
        this.$ajax
          .post('user/update', {
            nickname: this.userInfo.nickname || '',
            gender: this.userInfo.gender || 0,
            wechat: this.userInfo.wechat || '',
            qq: 0,
            company: this.userInfo.company || '',
            companyType: this.userInfo.company_type || '',
            storeName: this.userInfo.store_name || '',
            storeUrl: this.userInfo.store_url || ''
          })
          .then(e => {
            if (e.status == 200) {
              this.$Message.success('修改成功');
              this.$router.push({ name: 'information' });
              this.fetchUserData();
              return;
            }
            this.$Message.error(e.msg);
          });
      });
    }
  }
};
</script>

<style>
.editinfo .ivu-tabs.ivu-tabs-card > .ivu-tabs-bar .ivu-tabs-nav-container {
  height: 40px;
}
.editinfo .ivu-form .ivu-form-item-label {
  font-size: 14px;
}
.editinfo .ivu-input {
  display: block;
  width: 192px;
  height: 29px;
  line-height: 29px;
  border-radius: 0;
}
.editinfo .ivu-select-single .ivu-select-selection {
  width: 192px;
  border-radius: 0;
}
.editinfo .ivu-select-dropdown {
  width: 192px !important;
  left: 0 !important;
}
.editinfo .row .ivu-radio-inner:after {
  background: #666;
}
.editinfo .row .ivu-radio-checked .ivu-radio-inner {
  border-color: rgba(173, 173, 173, 1);
}
</style>
<style scoped>
.editinfo .row {
  background: #fff;
  margin-top: 15px;
  padding-left: 54px;
  padding-right: 20px;
}
.editinfo .row .title {
  height: 45px;
  line-height: 45px;
  border-bottom: 1px solid #e5e5e5;
  font-size: 16px;
  color: #888888;
}
.height202 {
  height: 202px;
}
.height154 {
  height: 154px;
}
.sub-btn {
  background: #f54203;
  border-color: #f54203;
}
.cel-btn {
  margin-left: 10px;
  background: #b3b3b3;
  border-color: #b3b3b3;
  color: #fff;
}
.btn {
  padding: 0;
  font-size: 18px;
  width: 91px;
  height: 30px;
  line-height: 30px;
}
.information-box {
  overflow: hidden;
  font-size: 14px;
}

.information-box .user-avatar {
  width: 180px;
  border-radius: 3px;
  float: left;
  padding: 20px;
}

.information-box .content {
  width: 100%;
  padding: 20px;
  padding-left: 0;
  float: left;
}

.information-box .content ul li {
  height: 130px;
  border-bottom: 1px dashed #ccc;
  width: 100%;
  line-height: 20px;
}

.information-box .content ul li:last-child {
  border-bottom: 0;
}

.information-box .content ul li .title {
  font-size: 20px;
  height: 35px;
}

.pwdservice {
  padding: 5px;
}

.pwdservice .con {
  padding: 25px;
  border: 1px solid #ccc;
  background: #eeeeee;
  height: 95px;
  margin-bottom: 5px;
}

.pwdservice .con span {
  float: left;
}

.pwdservice .con .con1 {
  font-size: 24px;
  color: #39f;
  margin-right: 20px;
}

.pwdservice .con .con2 {
  width: 430px;
  word-wrap: break-word;
  font-size: 14px;
}

.pwdservice .con .con3 {
  margin-top: 3px;
  float: right;
}

.collection {
  padding-left: 10px;
}

.collection .con {
  margin-top: 5px;
  min-height: 500px;
  border: 1px solid #ccc;
  padding: 10px;
}

.collection .con .title {
  color: #39f;
  font-size: 26px;
  height: 50px;
}

.collection .con .img-box {
  margin-top: 20px;
  background: #fff;
  border: 1px solid #ccc;
  box-shadow: 1px 1px 5px #888888;
}

.collection .con .img-box:last-child {
  margin-right: 0;
}

.collection .con .img-box .btn-box {
  height: 25px;
}

.collection .con .img-box .li-btn {
  background: #fff;
  border: 1px solid #ccc;
  padding: 0 5px;
  margin-left: 5px;
}

.left-menu li {
  height: 50px;
  line-height: 50px;
  border-top: 1px solid #d1d1d1;
}

.left-menu li:last-child {
  border-top: 1px solid #d1d1d1;
  border-bottom: 1px solid #d1d1d1;
}

.left-menu .active {
  background: #d7d7d7;
  color: #000;
  font-weight: 900;
}

.codebtn {
  height: 40px;
  font-size: 16px;
}
</style>

