<template>
  <div>
    <div class="nav">
       <ul v-if="userinfo.type==2">
        <li><router-link :to="{name:'favoriteDesigner'}" class="active">设计师</router-link></li>
        <li><router-link :to="{name:'favoritePro'}" >作品</router-link></li>
      </ul>
      <ul v-else>
        <li><router-link :to="{name:'favDesigner'}" class="active">设计师</router-link></li>
        <li><router-link :to="{name:'favPro'}" >作品</router-link></li>
      </ul>
    </div>
    <div class="content">
      <ul>
        <li v-for="item in list" :key="item.targetUserId">
          <div class="default">
            <a target="_blank" :href="'/designers/'+item.targetUserId">
              <div class="img">
                <p class="pic">
                  <!--'!216x255'-->
                  <img v-lazy="item.imageUrl+'!216x255'">
                </p>
                <p class="btn-del"><a @click="setDel(item.targetUserId)" href="javascript:;"><img :src="'icon/del_fav.png' | randomPath"></a></p>
              </div>
              <div class="info">
                <div class="txt">
                  <span class="name" style="max-width:55px;height: 20px;overflow: hidden;">{{item | getName}}</span>
                  <span class="icon">
                    <img :src="'icon/security.png' | randomPath" alt="平台保障">
                    <img :src="'icon/certification.png' | randomPath" alt="平台认证">
                    <img :src="'icon/'+item.rank+'.png' | randomPath">
                  </span>
                </div>
                <div class="money">
                  ￥<span style="color: #f54203;"> {{item.salary}}</span>/月
                </div>
              </div>
              <p class="hy">{{item.skilful | SKILLFULL_LIST_TEXT(childList4, ' | ')}}</p>
            </a>
          </div>
          <div class="del" :class="{'active':item.targetUserId == userId}">
            <div class="txt">
              <p>确定删除？</p>
              <div>
                <a class="qd" @click="favDel(item.targetUserId)" href="javascript:;">确定</a>
                <a class="qx" @click="setDel(0)" href="javascript:;">取消</a>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
    <div class="clearfix sx-page" v-if="params.count > 0">
      <Page :total="params.count" :current="params.pageNum" :page-size="params.pageSize"  show-elevator show-total @on-change="changePage" class="float-right page page-style"></Page>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex';

export default {
  data() {
    return {
      list: [],
      params: {
        pageNum: 1,
        pageSize: 24,
        count: 0
      },
      userId: 0
    };
  },
  mounted() {
    this.getList();
  },
  computed: {
    ...mapState({
      childList4: state => state.Lists.childList4, //子分类
      userinfo: state => state.User.info
    })
  },
  methods: {
    getList() {
      this.$ajax
        .get('fav/designer/list', {
          ...this.params
        })
        .then(e => {
          if (e.status != 200) {
            return;
          }
          this.list = e.data.list;
          this.params.count = e.data.count;
        });
    },
    favDel(userId) {
      this.$ajax
        .post('/fav/designer/del', {
          userId: userId
        })
        .then(e => {
          if (e.status != 200) {
            alert(e.msg);
            return;
          }
          this.getList();
        });
    },
    setDel(userId) {
      this.userId = userId;
    },
    changePage(p) {
      this.params.pageNum = p;
      this.getList();
    }
  },
  watch: {}
};
</script>
<style scoped>
.nav {
  background-color: #fff;
}

.nav ul {
  overflow: hidden;
}

.nav ul li {
  float: left;
  width: 181px;
  height: 110px;
  text-align: center;
}

.nav ul li a {
  display: block;
  border-right: 1px solid #ccc;
  height: 25px;
  line-height: 25px;
  margin-top: 40px;
  font-size: 20px;
  color: #888888;
}

.nav ul li a.active {
  color: #f54203;
}

.content {
  background-color: #fff;
  padding: 15px 6px;
  margin-top: 20px;
  min-height: 686px;
}

.content ul {
  overflow: hidden;
}

.content ul li {
  position: relative;
  float: left;
  width: 216px;
  height: 308px;
  margin: 10px 3px;
  overflow: hidden;
  border: 1px solid #efefef;
}

.content ul li .default a {
  display: block;
}

.content ul li .default a .img {
  overflow: hidden;
  position: relative;
  width: 216px;
  height: 255px;
}

.content ul li .default a .img .pic,
.content ul li .default a .img .pic img {
  width: 216px;
  height: 255px;
  overflow: hidden;
}

.content ul li .default a .img .btn-del {
  position: absolute;
  right: 0;
  top: 0;
  z-index: 99;
  display: none;
}
.content ul li .default a:hover .img .btn-del {
  display: block;
}
.content ul li .default a .img .btn-del a {
  color: #fff;
  font-size: 14px;
  font-weight: bold;
  padding: 10px;
  width: 70px;
  height: 30px;
  display: block;
}

.content ul li .default a .info {
  padding: 6px 10px 0 10px;
  color: #888888;
  font-size: 12px;
  overflow: hidden;
}

.content ul li .default a .info .txt {
  overflow: hidden;
  float: left;
}

.content ul li .default a .info .txt .name {
  float: left;
  margin-right: 6px;
}

.content ul li .default a .info .txt .icon {
  float: left;
  display: block;
  line-height: 19px;
  overflow: hidden;
}

.content ul li .default a .info .txt .icon img {
  width: 16px;
}

.content ul li .default a .info .money {
  float: right;
}

.content ul li .default a .hy {
  padding: 0 10px;
  text-overflow: ellipsis;
  white-space: nowrap;
  bottom: 0;
  overflow: hidden;
  color: #888;
  font-size: 12px;
}

.content ul li .del {
  display: none;
  position: absolute;
  top: 0;
  left: 0;
  background-color: rgba(0, 0, 0, 0.4);
  width: 216px;
  height: 308px;
  z-index: 999;
}
.content ul li .del.active {
  display: block;
}

.content ul li .del .txt {
  margin-top: 134px;
  font-size: 12px;
  text-align: center;
  color: #fff;
}

.content ul li .del .txt p {
  font-size: 16px;
}

.content ul li .del .txt div {
  width: 145px;
  margin: auto;
  margin-top: 20px;
}

.content ul li .del .txt a {
  display: block;
  width: 66px;
  height: 20px;
  line-height: 20px;
  float: left;
}

.content ul li .del .txt a.qd {
  background-color: #f54203;
  color: #fff;
  margin-right: 10px;
}

.content ul li .del .txt a.qx {
  background-color: #fff;
  color: #000;
}
</style>
