<template>
    <div style="background-color:#fff;padding:5px;">
        <div style="margin: 10px 0;font-size:20px;"> 任务详情
            <Button type="warning" style="padding: 3.5px 12px;margin-left:10px;width:50px;background-color:#f54203;" @click="backPageOne">返回</Button>
        </div>
        <div style="padding: 0 30px;">
            <Row class="row">
                <Col span="4" class="title">任务名称：</Col>
                <Col span="20" class="tit-con">{{data.title}}</Col>
            </Row>
            <Row class="row">
                <Col span="4" class="title">雇　　主：</Col>
                <Col span="8" class="tit-con">{{ data.employer_nickname || data.employer_phone || ''}}</Col>
                <Col span="4" class="title">联系方式：</Col>
                <Col span="8" class="tit-con">{{data.employer_phone}}</Col>
            </Row>
            <Row class="row">
                <Col span="4" class="title">平　　台：</Col>
                <Col span="8" class="tit-con">{{data.class_str && data.class_str.split(',')[0]}}</Col>
                 <Col span="4" class="title">类　　目：</Col>
                <Col span="8" class="tit-con">{{data.class_str && data.class_str.split(',')[1]}}</Col>
                
            </Row>
            <Row class="row">
                <Col span="4" class="title">设计类型：</Col>
                <Col span="20" class="tit-con">{{data.type_id && data.type_id.split(',') | toLabels(typeList)}}</Col>
            </Row>
            <Row class="row">
                <Col span="4" class="title">详细说明：</Col>
                <Col span="20" class="tit-con"><Input style="width:542px;" class="tit-con" v-model="data.details" type="textarea" readonly :autosize="{minRows: 2,maxRows: 5}"></Input></Col>
            </Row>
            <Row class="row">
                <Col span="4" class="title">期望风格：</Col>
                <Col span="12">
                    <span class="tit-con">{{data.style_id | toLabel1(styles)}}</span>
                    <br>
                    <div style="width:207px;overflow:hidden;margin-top:10px;">
                        <img :src="data.style_image_url+'!212x149'" width="100%" height="auto" alt="data.style_name">
                    </div>
                </Col>
            </Row>
            <Row class="row">
                <Col span="4" class="title">参考店铺：</Col>
                <Col span="20" class="tit-con">{{data.reference_store}}</Col>
            </Row>
            <Row class="row">
                <Col span="4" class="title">预　　算：</Col>
                <Col span="20" class="tit-con"><span>{{data.budget}}元</span><span v-if="data.budget_status == 1 ">( 已支付 )</span><span v-else >( 未支付 )</span></Col>
            </Row>
            <Row class="row">
                <Col span="4" class="title">分配设计师：</Col>
                <Col span="20" class="tit-con">{{data.department_name}} - - - - -{{data.designer_realname || data.designer_nickname || ''}}</Col>
            </Row>
            <Row class="row">
                <Col span="4" class="title">计划完成时间：</Col>
                <Col span="20" class="tit-con">{{getTimeStr}}</Col>
            </Row>
        </div>
    </div>
</template>
<script>
import moment from 'moment';
import { mapState } from 'vuex';
export default {
  data() {
    return {
      data: {},
      styleList: []
    };
  },
  computed: {
    getTimeStr: function() {
      return (
        (this.data.plan_complete_date &&
          moment(this.data.plan_complete_date).format('YYYY-MM-DD')) ||
        ''
      );
    },
    getStyleUrl: function(v) {
      let str = '';
      for (let item in this.styleList) {
        console.log(item);
        if (v == this.styleList[item].id) {
          str = this.styleList[item].imageUrl;
        }
      }
      return str;
    },
    ...mapState({
      typeList: state => state.Lists.typeList,
      styles: state => state.Lists.styles
    })
  },
  mounted() {
    const id = this.$route.params.id;
    this.$ajax
      .get('demand/get', {
        id
      })
      .then(e => {
        if (e.status != 200) {
          return;
        }
        this.data = e.data;
      });
  },
  methods: {
    backPageOne() {
      history.go(-1);
    },
    //获取风格类型
    getDesignTypeList() {
      this.$ajax.get('demand/style/list').then(e => {
        if (e.status == 200) {
          this.styleList = e.data;
        }
      });
    }
  }
};
</script>
<style scoped>
.row {
  margin-bottom: 10px;
  margin: 20px;
  font-size: 14px;
  /* font-family: 微软雅黑; */
}
.row span {
  display: block;
  float: left;
}
.title {
  /*width: 150px;*/
  font-size: 16px;
  font-weight: 100;
  text-align: right;
  color: #000;
  line-height: 30px;
}
.tit-con {
  line-height: 30px;
  font-size: 14px;
  /*text-align: left;*/
  color: #918f8f;
}
.ivu-input-wrapper {
  width: 50%;
}
</style>