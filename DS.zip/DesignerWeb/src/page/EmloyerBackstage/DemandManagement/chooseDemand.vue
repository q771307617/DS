<template>
    <div style="background-color:#fff;padding:5px;padding-top:20px;">
        <div>
            <div class="nav">
                <ul class="step">
                    <li class="active">01选择需求</li>
                    <li>02填写需求内容</li>
                    <li>03发布</li>
                </ul>
            </div>
            <Button type="warning" style="padding: 3.5px 12px;margin-left:10px;width:50px;background-color:#f54203;" @click="callback">返回</Button>
            <div class="wsl_select">
                <div class="tab hover">
                    <div>选择平台</div>
                    <ul>
                        <li :class="platform == item.id ? 'active':''" @click="selectPlatformid(item.id,item.name)" v-for="item in platformList" :key="item.id" :platformid="item.id">{{ item.name }}</li>
                    </ul>
                </div>
                <div class="tab hover">
                    <div>选择类目</div>
                    <ul>
                        <li :class="category == item.id ? 'active':''" @click="selectCategoryid(item.id,item.name)" v-for="item in categoryList" :categoryid="item.id" :key="item.id">{{ item.name }}</li>
                    </ul>
                </div>
                <div class="tab">
                    <div>选择设计类型<span style="color:#f54203;"> 可多选</span></div>
                    <ul>
                        <li v-for="item in designTypeList" :key="item.id">
                            <input v-model="designType" type="checkbox" :id="item.id" :value="item.id">
                            <label :for="item.id">{{ item.name }}</label>
                        </li>
                    </ul>
                </div>
            </div>
            <Row>
                <Col span="24" style="text-align:center;">
                <Button type="warning" @click="Next" style="width:112px;hegin:33px;background-color:#f54203;">下一步</Button>
                </Col>
            </Row>
        </div>
    </div>
</template>

<script>
// import * as types from '@/constant';
// const Tag = 'CHOISE_PAGE';
export default {
  data() {
    return {
      platform: '',
      category: '',
      platformName: '',
      categoryName: '',
      designType: [],
      platformList: [],
      categoryList: [],
      designTypeList: []
    };
  },
  mounted() {
    this.getPlatfromList();
    this.getCategoryList();
    this.getDesignTypeList();
  },
  methods: {
    //获取平台列表
    getPlatfromList() {
      this.$ajax.get('class/child').then(e => {
        if (e.status == 200) {
          this.platformList = e.data;
          this.platform = e.data[0].id;
          this.platformName = e.data[0].name;
          // this.getCategoryList();
        }
      });
    },
    //获取类目列表
    getCategoryList() {
      this.$ajax
        .get('class/child', {
          pid: 4
        })
        .then(e => {
          if (e.status == 200) {
            this.categoryList = e.data;
            this.category = e.data[0].id;
            this.categoryName = e.data[0].name;
          }
        });
    },
    //获取区域类型
    getDesignTypeList() {
      this.$ajax.get('type/list').then(e => {
        if (e.status == 200) {
          this.designTypeList = e.data;
        }
      });
    },
    selectPlatformid(id, name) {
      this.platform = id;
      this.platformName = name;
      console.log(this.platformName);
    },
    selectCategoryid(id, name) {
      this.category = id;
      this.categoryName = name;
      console.log(this.categoryName);
    },
    Next() {
      let classStr = this.platformName + ',' + this.categoryName;
      if (this.platform && this.category && this.designType.length) {
        this.$router.push({
          name: 'demandManagentWrite',
          query: {
            platform: this.platform,
            category: this.category,
            classStr: classStr,
            designType: this.designType.join()
          }
        });
      }
    },
    callback() {
      this.$router.push({
        name: 'demandManagentTable'
      });
    }
  }
};
</script>

<style scoped>
.wsl_select {
  overflow: hidden;
}
.wsl_select .tab {
  float: left;
  width: 256px;
  height: 590px;
  border: 1px solid #e5e5e5;
  margin: 20px 6px;
  text-indent: 30px;
  overflow: hidden;
}
.wsl_select .tab div {
  background-color: #eeeeee;
  height: 52px;
  line-height: 52px;
  font-size: 14px;
}
.wsl_select .tab ul {
  width: 100%;
  height: 100%;
  overflow-y: auto;
}
.wsl_select .tab ul li {
  height: 45px;
  line-height: 45px;
  border-bottom: 1px solid #eeeeee;
  cursor: pointer;
}
.wsl_select .hover ul li:hover,
.wsl_select .hover ul li.active {
  background-color: #f54203;
  color: #fff;
}
.wsl_select .tab ul li p {
  width: 20px;
  height: 30px;
  float: left;
}
.nav {
  display: inline-block;
}
.nav-btn button {
  font-weight: bold;
}
.step {
  display: flex;
}
.step > li {
  width: 152px;
  height: 31px;
  line-height: 31px;
  border: 1px solid #dddee1;
  border-right: none;
  width: 120px;
  text-align: center;
}
.step > li:last-child {
  border-right: 1px solid #dddee1;
}
.active {
  background-color: #f54203;
  color: #fff;
}
</style>


