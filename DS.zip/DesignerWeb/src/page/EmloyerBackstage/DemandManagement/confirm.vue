<template>
    <div style="background-color:#fff;padding:5px;padding-top:20px;" >
        <div class="nav">
            <ul class="step">
                <li>01选择需求</li>
                <li>02填写需求内容</li>
                <li class="active">03发布</li>
            </ul>
        </div>
        <Button type="warning" style="padding: 3.5px 12px;margin-left:10px;width:50px;background-color:#f54203;" @click="callback">返回</Button>
        <div class="row" style="margin:127px 0 93px 0;">
            <img :src="'icon/steps.png!653x142' | randomPath">
        </div>
        <div class="row">
            <Button type="error" style="width: 112px;height:33px;font-size:14px;" @click="handlePublish(true)">保存至草稿箱</Button>
        </div>
        <div class="row">
            <Button type="error" style="width: 112px;height:33px;font-size:14px;" @click="handlePublish(false)">确认发布</Button>
        </div>
        <div style="text-align:center;font-size:12px;color:#888;padding-top:15px;">
            <p>请确认步骤1、2内容，确认后发布，官方平台将在1小时内帮您匹配最优质</p>
            <p>的设计资源，请保持手机畅通，以便设计师向您沟通您的需求与想法。</p>
        </div>
    </div>
</template>
<script>
import { mapState } from 'vuex';

export default {
  data() {
    return {};
  },
  methods: {
    handlePublish(flag) {
      let data = sessionStorage.getItem('new-demand');
      if (!data) return;
      data = JSON.parse(data);
      data.temp = flag;
      let referenceStore = [];
      data.referenceStore.forEach(item => {
        referenceStore.push(item.value);
      });
      data.referenceStore = referenceStore.join();
      this.$ajax.post('demand/add', data).then(e => {
        if (e.status === 200) {
          this.$Message.success(e.msg);
          this.$store.commit('reflash', true);
          this.$router.push({
            name: 'demandManagentTable'
          });
          sessionStorage.removeItem('new-demand');
        }
      });
    },
    callback() {
      this.$router.push({
        name: 'demandManagentTable'
      });
    }
  },
  computed: {
    ...mapState({
      ftpPath: state => state.User.ftpPath
    })
  }
};
</script>
<style scoped>
.nav {
  display: inline-block;
}

.step {
  display: flex;
}

.step > li {
  border: 1px solid #dddee1;
  border-right: none;
  width: 152px;
  height: 33px;
  line-height: 33px;
  text-align: center;
}

.step > li:last-child {
  border-right: 1px solid #dddee1;
}

.active {
  background-color: #f54203;
  color: #fff;
}

.row {
  text-align: center;
  margin-top: 13px;
  margin-bottom: 13px;
}
</style>


