<template>
    <div>
        <demand-count></demand-count>
        <div style="background-color:#fff;padding:5px 0;">
            <Button type="warning" @click="demandAdd" class="btn-w btn-style">发布新需求</Button>
            <div class="clearfix" style="height:50px;line-height:32px;padding-top:15px;font-size:14px;">
                <span class="float-left">查询:　</span>
                <div class="float-left time-style" style="width:419px;">
                    <Row>
                        <Col span="11">
                        <Date-picker type="date" placeholder="选择日期" v-model="startTime"></Date-picker>
                        </Col>
                        <Col span="1" style="text-align:center;"> 至
                        </Col>
                        <Col span="11">
                        <Date-picker type="date" placeholder="选择日期" v-model="endTime"></Date-picker>
                        </Col>
                    </Row>
                </div>
                <Button class="float-left" type="warning" style="padding: 3.5px 12px;margin-left:10px;width:50px;background-color:#f54203;" @click="search">查询</Button>
                <span class="float-left" style="padding-left:10px;color: #888;">
                    最近
                </span>
                <span class="float-left sx-btn-link" 　style="display:block;margin:0 10px;" @click="limitDate(1, 'weeks')">
                    一周
                </span>
                <span class="float-left sx-btn-link" style="display:block;margin:0 10px;" @click="limitDate(1, 'months')">
                    1个月
                </span>
                <span class="float-left sx-btn-link" style="display:block;margin:0 10px;" @click="limitDate(3, 'months')">
                    3个月
                </span>
            </div>
            <Table :columns="columns" :data="datas" class="table-style" style="margin-top:20px;font-size:12px;"></Table>
            <Page :total="total" :current="pageNum" show-elevator show-total @on-change="changePage" class="float-right page page-style" style="padding-top:20px;"></Page>
            <pay-alert :id="id" v-on:parentHandle="setPayalert"></pay-alert>
            <accept-alert :id="id"></accept-alert>
        </div>
    </div>
</template>
<script>
import moment from 'moment';
import { mapState } from 'vuex';
import * as filter from '@/filter/index';
import payAlert from '@/page/EmloyerBackstage/Modal/payment';
import acceptAlert from '@/page/EmloyerBackstage/Modal/acceptance';
import demandCount from '@/components/demandCount';
const auditStatus = ['待审核', '已审核', '未通过'];
export default {
  components: {
    payAlert,
    acceptAlert,
    demandCount
  },
  data() {
    return {
      pay_alert_fresh: true, //默认刷新
      modal_b: false,
      id: '',
      startTime: '',
      endTime: '',
      total: 0,
      pageNum: 1,
      pageSize: 10,
      datas: [],
      columns: [
        {
          title: '序号',
          type: 'index',
          key: 'index',
          width: '30px',
          align: 'center'
        },
        {
          title: '需求名称',
          align: 'center',
          width: '150px',
          key: 'title'
        },
        {
          title: '需求发布日期',
          align: 'center',
          key: 'publish_time',
          render: (h, params) => {
            return h(
              'span',
              (params.row.publish_time &&
                moment(params.row.publish_time).format('YYYY-MM-DD HH:mm')) ||
                ''
            );
          }
        },
        {
          title: '预算',
          align: 'center',
          key: 'budget',
          //render: (h, params) => {
          //    return h('span', `${params.row.budget}元`);
          //}
          render: (h, params) => {
            if (params.row.budget_status == 0 && params.row.audit_status == 0) {
              return h(
                'Button',
                {
                  props: {
                    type: 'warning',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.id = params.row.id;
                      let bd = params.row.budget;
                      this.setBudget(this.id, bd);
                    }
                  }
                },
                params.row.budget + '元'
              );
            } else {
              return h('span', params.row.budget + '元');
            }
          }
        },
        {
          title: '平台审核',
          align: 'center',
          key: 'audit_status',
          render: (h, params) => {
            // eslint-disable-next-line
            let audit_status = params.row.audit_status;
            return h(
              'span',
              // eslint-disable-next-line
              audit_status > -1 ? auditStatus[audit_status] : '未通过'
            );
          }
        },
        {
          title: '保证金',
          align: 'center',
          // eslint-disable-next-line
          key: 'budget_status',
          render: (h, params) => {
            // eslint-disable-next-line
            let audit_status = params.row.audit_status;
            // eslint-disable-next-line
            let budget_status = params.row.budget_status;
            let strs = params.row;
            // eslint-disable-next-line
            if (strs.complete_status == -1) {
              return h('p', '--');
            }
            if (
            // eslint-disable-next-line
              audit_status == 1 &&
              // eslint-disable-next-line
              budget_status == 0 &&
              // eslint-disable-next-line
              strs.complete_status != -1
            ) {
              return h(
                'Button',
                {
                  props: {
                    type: 'warning',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.id = params.row.id;
                      this.$store.commit('SETTING_PAYMENT_VISIBLE', true);
                    }
                  }
                },
                '去支付'
              );
              // eslint-disable-next-line
            } else if (budget_status == 1) {
              return h('span', '已付保证金');
            } else {
              return h('span', '--');
            }
          }
        },
        {
          title: '设计师',
          align: 'center',
          key: 'designer',
          render: (h, params) => {
            let item = params.row;
            //console.log(filter);
            let name = filter.getNameDesigner(item);
            return h('span', {}, name || '--');
          }
        },
        {
          title: '预计完成时间',
          align: 'center',
          key: 'plan_complete_date',
          render: (h, params) => {
            return h(
              'span',
              (params.row.plan_complete_date &&
                moment(params.row.plan_complete_date).format('YYYY-MM-DD')) ||
                ''
            );
          }
        },
        {
          title: '完成状态',
          align: 'center',
          key: 'complete_status',
          render: (h, params) => {
            let strs = params.row;

            if (strs.budget_status == 9 || strs.budget_status == 12) {
              return h('p', '退款中');
            } else if (strs.budget_status == 15) {
              return h('p', '已退款');
            }

            if (strs.complete_status == -1) {
              return h('p', '已取消');
            }
            if (strs.budget_status == 1 && strs.complete_status != 1) {
              return h('p', '工作中');
            } else if (strs.budget_status == 1 && strs.accept_status == 1) {
              return h('p', '已完成');
            } else if (strs.budget_status == 1 && strs.complete_status == 1) {
              return h('p', '已交付');
            } else {
              if (strs.complete_status == 1) {
                return h('p', '已完成');
              } else if (strs.complete_status == 0) {
                return h('p', '未支付');
              } else if (strs.complete_status == -1) {
                return h('p', '已取消');
              } else {
                return h('p', '--');
              }
            }
          }
        },
        {
          title: '雇主验收',
          align: 'center',
          key: 'accept_status',
          render: (h, params) => {
            if (
              params.row.audit_status == 1 &&
              params.row.complete_status != -1
            ) {
              if (params.row.accept_status === 0) {
                if (params.row.complete_status == 0) {
                  return h('p', '--');
                }
                return h(
                  'Button',
                  {
                    props: {
                      type: 'warning',
                      size: 'small'
                    },
                    on: {
                      click: () => {
                        this.id = params.row.id;
                        this.$store.commit('SETTING_ACCT_VISIBLE', true);
                      }
                    }
                  },
                  '待验收'
                );
              } else if (params.row.accept_status === 1) {
                return h('span', '已验收');
              } else if (params.row.accept_status === -1) {
                return h(
                  'Button',
                  {
                    props: {
                      type: 'warning',
                      size: 'small'
                    },
                    on: {
                      click: () => {
                        this.id = params.row.id;
                        this.$store.commit('SETTING_ACCT_VISIBLE', true);
                      }
                    }
                  },
                  '未通过'
                );
                // return h('span', '未通过');
              }
            } else {
              return h('span', '--');
            }
          }
        },
        {
          title: '操作',
          key: 'key7',
          align: 'center',
          render: (h, params) => {
            let strs = params.row;
            let btnGroup = [];
            let that = this;
            btnGroup.push(
              h(
                'Button',
                {
                  props: {
                    type: 'text',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      if (strs.budget_status == 9 || strs.budget_status == 12) {
                        //退款中
                        that.$router.push({
                          name: 'check',
                          query: {
                            navType: '1',
                            id: strs.id,
                            type: 'DEMAND'
                          }
                        });
                      } else if (strs.budget_status == 15) {
                        //已退款
                        that.$router.push({
                          name: 'success',
                          query: {
                            navType: '1',
                            id: strs.id,
                            type: 'DEMAND'
                          }
                        });
                      } else {
                        that.$router.push({
                          name: 'demandManagentInfo',
                          params: {
                            id: params.row.id
                          }
                        });
                      }
                    }
                  }
                },
                '详情'
              )
            );
            if (strs.budget_status == 1 && strs.complete_status != 1) {
              //工作中
              btnGroup.push(
                h(
                  'Button',
                  {
                    props: {
                      type: 'text',
                      size: 'small'
                    },
                    style: {
                      color: '#0022f0',
                      border: 'none',
                      background: 'transparent'
                    },
                    on: {
                      click: () => {
                        // 根据状态判断路由跳转 退款中 已退款 工作中（申请退款
                        that.$ajax
                          .get('/orders/refund/apply', {
                            id: strs.id,
                            type: 'DEMAND'
                          })
                          .then(e => {
                            if (e.status == 200) {
                              that.$router.push({
                                name: 'commit',
                                query: {
                                  navType: '1', //需求 雇佣 交易
                                  id: strs.id,
                                  type: 'DEMAND' //需求 定制 包月
                                }
                              });
                            } else {
                              that.$Notice.error({
                                title: e.msg
                              });
                            }
                          });
                      }
                    }
                  },
                  '退款'
                )
              );
            }
            return h('div', btnGroup);
          }
        }
      ]
    };
  },
  methods: {
    setPayalert() {
      //设置弹窗
      this.pay_alert_fresh = false;
    },
    setBudget(ids, v) {
      this.value = v;
      this.$Modal.confirm({
        render: h => {
          return h('Input', {
            props: {
              value: v,
              autofocus: true,
              placeholder: '预算金额...'
            },
            on: {
              input: val => {
                this.value = val;
              }
            }
          });
        },
        onOk: () => {
          const budget = this.value;
          const id = ids;
          this.$ajax
            .get('demand/budget', {
              budget,
              id
            })
            .then(e => {
              location.href = location.href;
            });
        },
        onCancel: () => {
          this.value = '';
        }
      });
    },
    demandAdd() {
      this.$router.push({
        name: 'demandManagentChoose'
      });
    },
    changePage(p) {
      this.pageNum = p;
      this.fetchData();
    },
    limitDate(n, u) {
      this.startTime = moment()
        .subtract(n, u)
        .format();
      this.endTime = new Date();
      this.pageNum = 1;
      this.search();
    },
    search() {
      const startTime =
        (this.startTime &&
          moment(
            this.$utils.time.startTime(this.startTime, 'YYYY-MM-DD HH:mm:ss')
          ).format('x')) ||
        '';
      const endTime =
        (this.endTime &&
          moment(
            this.$utils.time.endTime(this.endTime, 'YYYY-MM-DD HH:mm:ss')
          ).format('x')) ||
        moment().format('x');
      this.$router.push({
        name: 'demandManagentTable',
        query: {
          startTime,
          endTime
        }
      });
    },
    fetchData() {
      const query = this.$route.query;
      const endTime = query.endTime;
      const startTime = query.startTime;
      const pageNum = this.pageNum;
      const pageSize = this.pageSize;
      const status = query.status;
      this.$ajax
        .get('demand/list', {
          endTime,
          startTime,
          pageNum,
          pageSize,
          status
        })
        .then(e => {
          if (e.status !== 200) {
            this.total = 0;
            this.datas = [];
            return;
          }
          this.total = e.data.count;
          this.datas = e.data.list;
        });
    }
  },
  mounted() {
    this.fetchData();
    this.limitDate(1, 'months');
  },
  watch: {
    $route: function() {
      this.fetchData();
    },
    payment_visible(val, oldVal) {
      if (!this.pay_alert_fresh) {
        this.pay_alert_fresh = true;
        return;
      }
      if (oldVal) this.$router.go(0);
    },
    acct_visible(val, oldVal) {
      if (oldVal) this.$router.go(0);
    }
  },
  computed: {
    ...mapState({
      payment_visible: state => state.Modal.payment_visible,
      acct_visible: state => state.Modal.acct_visible
    })
  }
};
</script>
<style>
.btn-style {
  width: 96px;
  font-size: 12px;
  background-color: #f54203;
}

.sx-btn-link:hover {
  text-decoration: underline;
}

.table-style .ivu-table-cell {
  padding: 3px;
}

.table-style .ivu-btn-text {
  color: #f54203;
}

.table-style .ivu-btn-warning {
  background-color: #f54203;
}

.table-style .ivu-btn-warning:hover {
  background-color: #f54203;
}

.ivu-btn-warning:hover {
  background-color: #f54203;
}
</style>
<style scoped>
.sx-btn-link {
  color: #f54203;
  cursor: pointer;
}

.sx-btn-link:hover {
  text-decoration: underline;
}
</style>