<template>
    <div style="padding: 5px;">
        <router-view></router-view>
    </div>
</template>

<script>
// import moment from 'moment';

export default {
  data() {
    return {};
  }
};
</script>
<style scoped>
.status li {
  border: 1px solid #ccc;
  border-right: 0;
  background: #f5f3f4;
  height: 75px;
  width: 150px;
  line-height: 32px;
  padding: 5px;
  margin-bottom: 25px;
}

.status li:last-child {
  border-right: 1px solid #ccc;
}

.sx-btn-link {
  /**color: #2d8cf0;*/
  color: RGB(246, 116, 4);
  cursor: pointer;
}

.btn-style {
  width: 96px;
  font-size: 12px;
  background-color: #f54203;
}

.sx-btn-link:hover {
  text-decoration: underline;
}
</style>
