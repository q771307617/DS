<template>
    <div style="background-color:#fff;padding:5px;">
        <Form ref="formValidate" :model="formValidate" :rules="ruleValidate">
            <div>
                <div style="padding:20px;">
                    <div class="nav">
                        <ul class="step">
                            <li>01选择需求</li>
                            <li class="active">02填写需求内容</li>
                            <li>03发布</li>
                        </ul>
                    </div>
                    <Button type="warning" style="padding: 3.5px 12px;margin-left:10px;width:50px;background-color:#f54203;" @click="callback">返回</Button>
                    <div class="row">
                        <div class="row-title">您的选择</div>
                        <Row>
                            <Col span="20" class="wsl_text"> {{query.platform | toLabel1(platformList)}} 、{{query.category | toLabel1(childList4)}}、{{query.designType.split(",") | toLabels(typeList)}}
                            </Col>
                            <Col span="4">
                            <Button type="warning" style="padding: 3.5px 12px;margin-left:10px;width:50px;background-color:#f54203;" @click="update">修改</Button>
                            </Col>
                        </Row>
                    </div>
                    <div class="row">
                        <div class="row-title">
                            <span class="require">*</span>简单描述您的需求(1-50个字符)</div>
                        <Row>
                            <Col span="24">
                            <Form-item prop="title" style="width:452px;height:33px;">
                                <Input :maxlength="50" v-model="formValidate.title" placeholder="一句话描述您的需求，例如 ：**旗舰店，首页设计等"></Input>
                            </Form-item>
                            </Col>
                        </Row>
                    </div>
                    <div class="row">
                        <div class="row-title">
                            <span class="require">*</span>详细说明(1-250个字符)
                        </div>
                        <Row :gutter="16">
                            <Col span="13">
                            <Form-item prop="details">
                                <Input v-model="formValidate.details" type="textarea" :rows="4" placeholder="请输入..."></Input>
                            </Form-item>
                            </Col>
                            <Col span="10" style="line-height:25px;">
                            <p style="color:#ccc;">模板参考</p>
                            <p style="color:#ccc;">1、设计风格尽量清新自然</p>
                            <p style="color:#ccc;">2、我们店铺的作品大部分是日韩风格</p>
                            <p style="color:#ccc;">3、希望设计师能够在2~3个工作日内完成工作</p>
                            </Col>
                        </Row>
                    </div>
                    <div style="clear:both;"></div>
                </div>
                <hr style="height:1px;border:none;border-top:1px solid #ccc;">
                <div style="padding:20px;">
                    <div class="row">
                        <div class="row-title"><span class="require">*</span>期望的风格</div>
                        <br>
                        <Radio-group v-model="styleId">
                            <Row :gutter="16">
                                <Col span="6" v-for="item in styles" :key="item.id">
                                <div style="width: 212px; height: 149px;text-align:center;overflow:hidden;">
                                    <img :src="item.imageUrl+'!212x149'">
                                </div>
                                <div class="text-center radio-style" style="width: 212px;">
                                    <Radio :label="item.id">
                                        <span>{{item.name}}</span>
                                    </Radio>
                                </div>
                                </Col>
                            </Row>
                        </Radio-group>
                    </div>
                    <div class="row">
                        <div class="row-title">参考店铺</div>
                        <Row>
                            <Col span="24">
                            <Form ref="formDynamic" :model="formDynamic">
                                <Form-item v-for="(item, index) in formDynamic.items" :key="index" :prop="'items.' + index + '.value'">
                                    <Row>
                                        <Col span="18">
                                        <Input style="width:452px;height:33px;" type="text" v-model="item.value" placeholder="输入店铺网址 http://xxx.com"></Input>
                                        <Button type="text" @click="handleRemove(index)">删除</Button>
                                        </Col>
                                    </Row>
                                </Form-item>
                                <Form-item v-if="!(formDynamic.items.length == 3)">
                                    <Row>
                                        <Col span="12">
                                        <Button style="width:206px;height:33px;" @click="handleAdd" icon="ios-plus-outline">点击添加参考店铺</Button>
                                        </Col>
                                    </Row>
                                </Form-item>
                            </Form>
                            </Col>
                        </Row>
                    </div>
                    <div class="row">
                        <div class="row-title">
                            <span class="require">*</span>您的预算</div>
                        <Row>
                            <Col span="24">
                            <Form-item prop="budget">
                                <Input-number :max="9999999999" :min="0.01" v-model="formValidate.budget" style="width:206px;height:33px;"></Input-number>&nbsp;元
                                <!--<Input  type="text" v-model="formValidate.budget" placeholder="请输入..." style="width:206px;height:33px;"></Input>-->
                            </Form-item>
                            </Col>
                        </Row>
                    </div>
                    <div>
                        <Button type="warning" style="width:112px;height:33px;background-color:#f54203;" @click="handleSubmit('formValidate')">提交需求</Button>
                    </div>
                </div>
            </div>
        </Form>
    </div>
</template>
<script>
import { mapState } from 'vuex';
export default {
  data() {
    const validateAge = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('不能为空'));
      } else {
        callback();
      }
    };
    return {
      formValidate: {
        title: '',
        details: '',
        budget: 0
      },
      ruleValidate: {
        title: [
          {
            required: true,
            message: '请填写标题',
            trigger: 'blur'
          }
        ],
        details: [
          {
            required: true,
            max: 250,
            message: '请简单描述您的需求',
            trigger: 'blur'
          }
        ],
        budget: [
          {
            validator: validateAge,
            trigger: 'blur'
          }
        ]
      },
      query: this.$route.query,
      styleLists: [],
      designTypeList: [],
      styleId: '',
      classStr: this.$route.classStr,
      id: '',
      platformList: [],
      categoryList: [],
      styles: [],
      formDynamic: {
        items: [
          {
            value: ''
          }
        ]
      }
    };
  },
  computed: {
    ...mapState({
      typeList: state => state.Lists.typeList,
      childList4: state => state.Lists.childList4
    })
  },
  mounted() {
    this.getPlatfromList();
    this.getDesignTypeList();
    let tempData = sessionStorage.getItem('TEMP_DEMAND');
    if (this.query.temp && tempData) {
      tempData = JSON.parse(tempData);
      this.formValidate.title = tempData.title || '';
      this.formValidate.details = tempData.details || '';
      this.formValidate.budget = tempData.budget || '';
      this.styleId = tempData.style_id;
      this.classStr = tempData.class_str;
      this.id = tempData.id;
      if (tempData.reference_store !== null) {
        let referenceStore = tempData.reference_store.split(',');
        this.formDynamic.items.splice(0, 1);
        for (let i of referenceStore) {
          this.formDynamic.items.push({
            value: i
          });
        }
      }
    } else {
      this.classStr = this.query.classStr;
    }
  },
  methods: {
    //获取平台列表
    getPlatfromList() {
      this.$ajax.get('class/child').then(e => {
        if (e.status == 200) {
          this.platformList = e.data;
        }
      });
    },
    //获取风格类型
    getDesignTypeList() {
      this.$ajax.get('demand/style/list').then(e => {
        if (e.status == 200) {
          this.styles = e.data;
          this.styleId = e.data[0].id;
        }
      });
    },
    update() {
      this.$router.push({
        name: 'demandManagentChoose'
      });
    },
    handleAdd() {
      this.formDynamic.items.push({
        value: ''
      });
    },
    handleRemove(index) {
      this.formDynamic.items.splice(index, 1);
    },
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          this.$Message.success('提交成功!');
          let data = {
            title: this.formValidate.title,
            details: this.formValidate.details,
            classStr: this.classStr,
            id: this.id,
            referenceStore: this.formDynamic.items,
            budget: this.formValidate.budget,
            platform: this.query.platform,
            classId: this.query.category,
            typeId: this.query.designType,
            styleId: this.styleId
          };
          sessionStorage.setItem('new-demand', JSON.stringify(data));
          this.$router.push({
            name: 'demandManagentConfirm'
          });
        } else {
          this.$Message.error('表单验证失败!');
        }
      });
    },
    callback() {
      this.$router.push({
        name: 'demandManagentTable'
      });
    }
  }
};
</script>
<style>
.radio-style .ivu-radio-checked .ivu-radio-inner {
  border-color: #f54203;
}
.radio-style .ivu-radio-inner:after {
  background-color: #f54203;
}
</style>
<style scoped>
.wsl_text {
  color: #f54203;
  text-indent: 30px;
  font-size: 12px;
  line-height: 30px;
  max-height: 60px;
  overflow: hidden;
}
.nav {
  display: inline-block;
}
.nav-btn button {
  font-weight: bold;
}
.step {
  display: flex;
}
.step > li {
  border: 1px solid #dddee1;
  border-right: none;
  width: 153px;
  height: 31px;
  line-height: 31px;
  text-align: center;
}
.step > li:last-child {
  border-right: 1px solid #dddee1;
}
.active {
  background-color: #f54203;
  color: #fff;
}
.row {
  margin-top: 20px;
  margin-bottom: 20px;
}
.row-title {
  font-size: 14px;
  color: #3b3b3b;
  margin: 10px 0;
}
.text-center {
  text-align: center;
}
.require {
  color: #f54203;
  margin-right: 10px;
}
.ivu-radio-group {
  display: block;
}
</style>

