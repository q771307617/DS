<template>
    <table width="100%" style="min-height:900px">
        <tr>
            <td width="138" valign="top" style="background-color:#f3f3f3;">
                <div class="font24 text-center" style="height:76px;line-height:76px;">
                    财务记录
                </div>
                <ul class="left-menu font20 text-center">
                    <li v-for="item in items" :key="item.id" v-bind:class="{active:(item.id == activeName)}" @click="()=>{selectActiveMenu(item)}">
                        {{item.lebal}}
                    </li>
                </ul>
            </td>
            <td width="820" valign="top">
                <div style="padding:5px;">
                    <div v-if="activeName == '1'">
                        <h4 style="padding:30px 10px;">财务信息 -> 财务记录 -> 我的钱包</h4>
                        <ul class="flex-box moneyinfolist">
                            <li class="flex-item2">
                                钱包总额
                                <br />
                                <em>{{info.totalAmount}}
                                </em>
                            </li>
                            <li class="flex-item2">
                                可用金额
                                <br />
                                <em>{{info.balance}}</em>
                            </li>
                            <li class="flex-item2">
                                平台监管金额
                                <br />
                                <em>{{info.deposit}}</em>
                            </li>
                            
                            <li class="flex-item">
                            <Row>
                                <Col>
                                    <Button type="warning" @click='recharge(3)' style="padding-top: 1.5px;padding-bottom: 1.5px;margin-top:20px;">充值</Button>
                                </Col>
                            </Row>

                            <!--暂时没有实现提现接口-->
                            <Row>
                                <Col>
                                     <Button type="primary" @click='getMoney' style="padding-top: 1.5px;padding-bottom: 1.5px;">提现</Button>
                                </Col>
                            </Row>
                               
                            </li>
                        </ul>
                    </div>
    
                    <div v-else-if="activeName == '2'">
                        <h4 style="padding:30px 10px;">财务信息 -> 财务记录 -> 交易记录</h4>
                        <div class="clearfix" style="height:50px;line-height:32px;padding-top:8px;">
                            <div class="float-left" style="width:300px;">
                                <Row>
                                    <Col span="11">
                                    <Date-picker type="date" v-model="queryInfo.beginTime" placeholder="选择日期"></Date-picker>
                                    </Col>
                                    <Col span="2" style="text-align:center;"> 至
                                    </Col>
                                    <Col span="11">
                                    <Date-picker type="date" v-model="queryInfo.endTime" placeholder="选择日期"></Date-picker>
                                    </Col>
                                </Row>
                            </div>
                            <Button class="float-left" type="primary" style="padding: 3.5px 12px;margin:5px 10px 0">查询</Button>
                            <span class="float-left">
                                最近 ｜
                            </span>
                            <span class="float-left sx-btn-link" 　style="display:block;margin:0 10px;" @click="limitDate(1, 'weeks')">
                                一周
                            </span>
                            <span class="float-left sx-btn-link" style="display:block;margin:0 10px;" @click="limitDate(1, 'months')">
                                1个月
                            </span>
                            <span class="float-left sx-btn-link" style="display:block;margin:0 10px;" @click="limitDate(3, 'months')">
                                3个月
                            </span>
                        </div>
                        <Table border :columns="records_columns" :data="records_data"></Table>
                        <Page :total="total" :current="queryInfo.pageNum" :page-size="queryInfo.pageSize" show-elevator class="float-right page page-style"></Page>
                    </div>
    
                    <div v-else-if="activeName == '3'">
                        <h4 style="padding:30px 10px;">财务信息 -> 财务记录 -> 账户充值</h4>
                        <Row>
                            <Col span="4" style="text-align: center;line-height:32px;font-size:18px;">充值金额(元)：</Col>
                            <Col span="20">
                                <Input-number :max="1000000000" :min="0.01" v-model="deposit" @on-change="changeDeposit" style="width: 100px" ></Input-number>
                            </Col>
                        </Row>
                        <Row>
                            <Col span="20" offset="4">（充值成功后，充值金额会在1分钟内到帐；如果遇到任何问题，请联系平台客服。）</Col>
                        </Row>
                        <Row v-if="error_despoit">
                            <Col span="20" offset="4" style="color:red;">
                                {{error_despoit}}
                            </Col>
                        </Row>
                        <Row>
                            <Col span="20" offset="4">
                                <Button type="warning" @click="handleRecharge">确认充值</Button>
                            </Col>
                        </Row>
                    </div>
                </div>
            </td>
        </tr>
    </table>
</template>

<script>
import Constant from '../../constant/index.js';
import moment from 'moment';
import router from '../../router/index.js';
import { mapState } from 'vuex';

export default {
  data() {
    return {
      code: '',
      error_despoit: '',
      queryInfo: {
        beginTime: moment()
          .subtract(1, 'weeks')
          .format(),
        endTime: new Date(),
        pageNum: 1,
        pageSize: 10
      },
      total: 0,
      activeName: this.$route.query.activeName || '1',
      items: [
        {
          lebal: '我的钱包',
          id: 1,
          path: ''
        },
        {
          lebal: '立即充值',
          id: 3,
          path: ''
        },
        {
          lebal: '交易记录',
          id: 2,
          path: ''
        }
      ],
      records_columns: [
        {
          width: 170,
          title: '时间',
          key: 'createTimeValue'
        },
        {
          width: 240,
          title: '流水号/订单号',
          key: 'orderNo'
        },
        {
          title: '交易类型',
          key: 'typeValue'
        },
        {
          title: '交易金额',
          key: 'amount'
        },
        {
          title: '交易状态',
          key: 'statusValue'
        },
        {
          title: '操作',
          key: 'key7',
          render: (h, params) => {
            if (params.row.statusValue == '成功') {
              return h('span', {}, '--');
            }
            if (
              params.row.statusValue == '等待付款' &&
              params.row.typeValue == '雇佣'
            ) {
              return h(
                'Button',
                {
                  props: { type: 'text', size: 'small' },
                  on: {
                    click: () => {
                      this.$router.push({
                        name: 'payment',
                        query: {
                          hireId: params.row.hireId
                        }
                      });
                    }
                  }
                },
                '去付款'
              );
            } else if (
              params.row.statusValue == '等待付款' &&
              params.row.typeValue == '充值'
            ) {
              return h(
                'Button',
                {
                  props: { type: 'text', size: 'small' },
                  on: {
                    click: () => {
                      this.$ajax.payMoney(params.row.amount);
                    }
                  }
                },
                '去充值'
              );
            } else {
              return h('span', {}, '--');
            }
          }
        }
      ],
      records_data: [],
      deposit: 10,
      balance: 0
    };
  },
  computed: {
    ...mapState({ info: state => state.User.info })
  },
  mounted() {
    this.setActiveMenu();
    this.getRecordList(this.queryInfo);
  },
  methods: {
    changeDeposit(num) {
      this.deposit = num.toFixed(2) * 1;
    },
    limitDate(n, u) {
      this.queryInfo.beginTime = moment()
        .subtract(n, u)
        .format();
      this.queryInfo.endTime = new Date();
    },
    //查询记录列表
    getRecordList(params) {
      params.beginTime = moment(
        this.$utils.time.startTime(params.beginTime, 'YYYY-MM-DD HH:mm:ss')
      ).format('x');
      params.endTime = moment(
        this.$utils.time.endTime(params.endTime, 'YYYY-MM-DD HH:mm:ss')
      ).format('x');
      this.$ajax.get('traderRecode/list', params).then(e => {
        for (var i in e.data.list) {
          e.data.list[i].createTimeValue = new Date(
            e.data.list[i].createTime * 1
          ).Format('yyyy-MM-dd hh:mm:ss');
          e.data.list[i].typeValue = Constant.TRADE_TYPE[e.data.list[i].type];
          e.data.list[i].statusValue =
            Constant.TRADE_STATUS[e.data.list[i].status];
        }
        this.records_data = e.data.list;
        this.total = e.data.total;
        this.queryInfo.pageNum = e.data.pageNum;
        this.queryInfo.pageSize = e.data.pageSize;
      });
    },
    recharge(p) {
      if (p) {
        this.activeName = p;
      }
    },
    handleRecharge() {
      if (this.error_despoit) {
        return;
      }
      this.$ajax.payMoney(this.deposit);
    },
    getMoney() {
      console.warn('提现功能还未完成');
    },
    selectActiveMenu(item) {
      this.activeName = item.id;
      router.push({
        path: '/emloyerBackstage/moneyCenter?activeName=' + item.id
      });
    },
    setActiveMenu() {
      for (let item of this.items) {
        if (this.$route.activeName === item.id) {
          this.activeName = item.id;
          break;
        }
      }
    }
  },
  watch: {
    $route: 'setActiveMenu'
  }
};
</script>

<style scoped>
.moneyinfolist li {
  padding: 25px 0;
  height: 110px;
  background-color: #f3f3f3;
  border: 1px solid #d1d1d1;
  border-right: 0;
  text-align: center;
  font-size: 20px;
}

.moneyinfolist li em {
  /**color: #2d8cf0;*/
  color: RGB(246, 116, 4);
  font-size: 28px;
  font-style: normal;
}

.moneyinfolist li:last-child {
  padding-top: 20px;
  border-right: 1px solid #d1d1d1;
}

.money-title {
  height: 60px;
  font-size: 20px;
  line-height: 60px;
  padding-left: 10px;
  margin: 20px 0 10px 0;
  background-color: #f3f3f3;
}

.page {
  margin: 20px 0;
}

.left-menu li {
  height: 50px;
  line-height: 50px;
  border-top: 1px solid #d1d1d1;
}

.left-menu li:last-child {
  border-top: 1px solid #d1d1d1;
  border-bottom: 1px solid #d1d1d1;
}

.left-menu .active {
  background: #d7d7d7;
  color: #000;
  font-weight: 900;
}

.sx-btn-link {
  /**color: #2d8cf0;*/
  color: RGB(246, 116, 4);
  cursor: pointer;
}

.sx-btn-link:hover {
  text-decoration: underline;
}
</style>
