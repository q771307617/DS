<style scoped>
.admin-index {
  padding-bottom: 30px;
  background: #fafafa;
}
.admin-index .bottom-con {
  padding: 5px;
  background: #fff;
  margin-top: 12px;
}
.top-con {
  background: #fafafa;
}
.titlespan {
  height: 152px;
  background: #fff;
  font-size: 22px;
  padding: 50px 120px 40px 30px;
}
.span-bor {
  background: #fff;
}
.span-bor:nth-child(2) {
  width: 305px;
  padding: 0px 35px;
  border-left: 1px solid #e5e5e5;
  border-right: 1px solid #e5e5e5;
}
.span-bor:last-child {
  padding-left: 35px;
}
.span-bor .red a {
  color: #f54203;
}

.account .name span {
  font-size: 20px;
}
.account .name {
  height: 42px;
  font-size: 14px;
  font-family: 'Arial Normal', 'Arial';
}
.height40 {
  height: 40px;
}

.tool {
  background: #fff;
}
.title {
  color: #646464;
  margin-left: 30px;
  font-size: 16px;
  height: 45px;
  line-height: 45px;
  border-bottom: 1px solid #e5e5e5;
}
.toolbox {
  padding: 15px 0;
  height: 90px;
  font-size: 14px;
  width: 610px;
}
.toolbox li {
  border-right: 1px solid #e5e5e5;
  width: 203px;
}
.tab-box {
  width: 290px;
  height: 80px;
  padding-top: 20px;
  padding-left: 30px;
  overflow: hidden;
}
.tab-box .list-btn {
  display: block;
  float: left;
  width: 130px;
  height: 35px;
  line-height: 35px;
  font-size: 16px;
  text-align: center;
  border: 1px solid #ccc;
  cursor: pointer;
}
.tab-box span:last-child {
  margin-left: -1px;
}
.tab-box span.active {
  /**background: #39f;*/
  background: #f54203;
  color: #fff;
  /**border: 1px solid #3091f2;*/
  border: 1px solid #f54203;
}
.list-con {
  padding-left: 30px;
}
.wsl-float-ul {
  overflow: hidden;
}
.wsl-float-ul li {
  float: left;
}
.wsl-top li {
  width: 215px;
}
</style>

<style>
.list-con .ivu-table {
  font-size: 14px;
}
.list-con .ivu-btn-text {
  color: #f54203;
}
</style>

<template>
    <div class="admin-index">
        <div class="top-con">
            <ul class="titlespan flex-box box-shadow wsl-float-ul wsl-top">
                <li class="span-bor account flex-item">
                    <p class="name" style="overflow: hidden;">
                        <span style="max-width:150px;height:40px;line-height:40px;display:block;overflow: hidden; float: left;">{{userInfo.nickname||userInfo.realname||userInfo.username ||userInfo.phone}}</span> &nbsp;&nbsp;
                      <span style="display: block;float: left;font-size: 14px;line-height: 45px;text-indent: 6px;">{{userInfo.gender ? '女士' : '先生'}}</span>
                    </p>
                    <p class="font14 red">
                        <router-link :to="{ name: 'editinfo' }">修改信息</router-link>&nbsp;&nbsp;
                        <!--<router-link to="./personalInfo">申请认证</router-link>-->
                    </p>
                </li>
                <li class="span-bor security flex-item">
                    <p class="font20 height40">账户安全</p>
                    <p class="font14 red">
                        <router-link :to="{ name:'pwdservice',params:{'active':'home'}}" v-if="!userInfo.pay_password">设置支付密码&nbsp;&nbsp;</router-link>
                        <!--<router-link to="./personalInfo">绑定支付宝</router-link>&nbsp;&nbsp;-->
                        <router-link :to="{ name: 'information'}">查看账户</router-link>
                    </p>
                </li>
                <li class="span-bor core flex-item">
                    <p class="font20 height40">账户中心</p>
                    <p class="font14 red">
                        <!--<router-link to="./moneyCenter?activeName=1">我的钱包</router-link>&nbsp;&nbsp;-->
                        <router-link to="./trading_record">交易记录</router-link>
                    </p>
                </li>
            </ul>
            <demand-count></demand-count>
            <div class="tool box-shadow">
                <p class="title">快捷工具</p>
                <ul class="toolbox flex-box wsl-float-ul">
                    <li class="text-center flex-item">
                        <router-link :to="{ name: 'demandManagentChoose'}">
                            <img :src="'icon/icon_wa.png' | randomPath" alt="">
                            <div style="color:#646464">发布需求</div>
                        </router-link>
                    </li>
                    <li class="text-center flex-item">
                        <router-link to="./trading_record">
                            <img :src="'icon/icon_jyjl.png' | randomPath" alt="">
                            <div style="color:#646464">交易记录</div>
                        </router-link>
                    </li>
                    <li class="text-center flex-item" v-if="userInfo.type == 1">
                        <router-link :to="{ name: 'editinfo'}">
                            <img :src="'icon/icon_dp.png' | randomPath" alt="">
                            <div style="color:#646464">店铺管理</div>
                        </router-link>
                    </li>
                    <li class="text-center flex-item last">
                        <router-link :to="{name:'pwdservice'}">
                            <img :src="'icon/icon_mm.png' | randomPath" alt="">
                            <div style="color:#646464">密码管理</div>
                        </router-link>
                    </li>
                </ul>
            </div>
        </div>
        <div class="bottom-con box-shadow">
            <div class="list-title">
                <p class="title font16">正在进行中的任务</p>
                <div class="tab-box">
                    <span class="list-btn" @click="chooseatab1" v-bind:class="{ active: isActive }">需求</span>
                    <span class="list-btn" @click="chooseatab2" v-bind:class="{ active: !isActive }">设计师</span>
                </div>
            </div>
            <div class="list-con">
                <Table border v-if="isActive" :columns="xq_columns" :data="xq_lists" height="400"></Table>
                <Table border v-else :columns="ry_columns" :data="ry_lists" height="400"></Table>
            </div>
        </div>
    </div>
</template>

<script>
// import * as filter from '@/filter';
import moment from 'moment';
import demandCount from '@/components/demandCount';
import { mapState } from 'vuex';

export default {
  components: { demandCount },
  data() {
    return {
      isActive: true,
      ry_lists: [],
      ry_columns: [
        {
          title: '序号',
          width: 70,
          type: 'index',
          align: 'center'
        },
        {
          title: '被雇佣设计师',
          key: 'designer_realname',
          align: 'center'
        },
        {
          title: '雇佣方式',
          width: 100,
          key: 'type',
          render: (h, params) => {
            let typeStr = '--';
            if (params.row.type == 0) {
              typeStr = '包月雇佣';
            } else if (params.row.type == 1) {
              typeStr = '定制雇佣';
            }
            return h('p', typeStr);
          },
          align: 'center'
        },
        {
          title: '开始时间',
          key: 'start_time_value',
          width: 150,
          align: 'center'
        },
        {
          title: '结束时间',
          key: 'end_time_value',
          width: 150,
          align: 'center'
        },
        {
          title: '雇佣进度',
          width: 100,
          key: 'status',
          render: (h, params) => {
            let statusStr = '已取消';
            let status = params.row.status;
            //-1已取消，0：未支付，1：已支付，2：工作中，3：已完结,4:已评价
            if (status == 0) {
              statusStr = '未支付';
            } else if (status == 1) {
              statusStr = '待开始';
            } else if (status == 2) {
              statusStr = '工作中';
            } else if (status == 3 && params.row.nopayPrice > 0) {
              statusStr = '已交付';
            } else if (status == 3 && params.row.nopayPrice <= 0) {
              statusStr = '已完成';
            } else if (status == 4) {
              statusStr = '已评价';
            }
            return h('p', statusStr);
          },
          align: 'center'
        },
        {
          title: '操作',
          width: 80,
          align: 'center',
          key: 'action',
          render: (h, params) => {
            return h(
              'Button',
              {
                props: {
                  type: 'text',
                  size: 'large',
                  color: '#f54203'
                },
                on: {
                  click: () => {
                    this.$router.push({
                      name: 'employmentManagement'
                    });
                  }
                }
              },
              '查看'
            );
          }
        }
      ],
      xq_lists: [],
      xq_columns: [
        {
          title: '序号',
          type: 'index',
          align: 'center',
          width: 70
        },
        {
          title: '需求名称',
          key: 'title',
          align: 'center'
        },
        {
          title: '平台受理时间',
          key: 'audit_time',
          align: 'center',
          width: 150,
          render: (h, params) => {
            return h(
              'span',
              (params.row.audit_time &&
                moment(params.row.audit_time).format('YYYY-MM-DD')) ||
                ''
            );
          }
        },
        {
          title: '设计师',
          key: 'designer_realname',
          align: 'center',
          width: 80
        },
        {
          title: '预计完成时间',
          key: 'plan_complete_date',
          align: 'center',
          width: 150,
          render: (h, params) => {
            return h(
              'span',
              (params.row.plan_complete_date &&
                moment(params.row.plan_complete_date).format('YYYY-MM-DD')) ||
                ''
            );
          }
        },
        {
          width: 100,
          title: '进度',
          key: 'complete_status',
          render: (h, params) => {
            let strs = params.row;
            if (strs.budget_status == 1 && strs.complete_status != 1) {
              return h('p', '工作中');
            } else if (strs.budget_status == 1 && strs.accept_status == 1) {
              return h('p', '已完成');
            } else if (strs.budget_status == 1 && strs.complete_status == 1) {
              return h('p', '已交付');
            } else {
              if (strs.complete_status == 1) {
                return h('p', '已完成');
              } else if (strs.complete_status == 0) {
                return h('p', '未支付');
              } else if (strs.complete_status == -1) {
                return h('p', '已取消');
              } else {
                return h('p', '--');
              }
            }
          },
          align: 'center'
        },
        {
          width: 100,
          align: 'center',
          title: '操作',
          key: 'action',
          render: (h, params) => {
            return h(
              'Button',
              {
                props: {
                  type: 'text',
                  size: 'large'
                },
                on: {
                  click: () => {
                    this.$router.push({
                      name: 'demandManagentInfo',
                      params: {
                        id: params.row.id
                      }
                    });
                  }
                }
              },
              '查看'
            );
          }
        }
      ]
    };
  },
  mounted() {
    this.getdemand();
    this.getdesigner();
  },
  computed: {
    ...mapState({
      userInfo: state => state.User.info,
      ftpPath: state => state.User.ftpPath
    })
  },
  methods: {
    //tab切换
    chooseatab1() {
      this.isActive = true;
      this.getdemand();
    },
    //tab切换
    chooseatab2() {
      this.isActive = false;
      this.getdesigner();
    },
    //获取需求列表
    getdemand() {
      this.$ajax
        .get('index/demand', {
          startTime: moment()
            .subtract(3, 'months')
            .format('x'),
          endTime: moment().format('x')
        })
        .then(e => {
          if (e.status !== 200) {
            this.xq_lists = [];
            return;
          }
          // for (let i in e.data) {
          //     e.data[i].publishTimeValue = !e.data[i].publishTime ? "--" : moment(e.data[i].publishTime).format("YYYY-MM-DD hh:mm");
          //     e.data[i].plan_complete_date_value = moment(e.data[i].plan_complete_date).format("YYYY-MM-DD hh:mm");
          // }
          this.xq_lists = e.data;
        });
    },
    //获取人员列表
    getdesigner() {
      this.$ajax
        .get('index/hire', {
          sDate: moment()
            .subtract(3, 'months')
            .format('x'),
          eDate: moment().format('x')
        })
        .then(e => {
          if (e.status !== 200) {
            this.ry_lists = [];
            return;
          }
          for (let i in e.data) {
            e.data[i].start_time_value = moment(e.data[i].start_time).format(
              'YYYY-MM-DD hh:mm'
            );
            e.data[i].end_time_value = moment(e.data[i].end_time).format(
              'YYYY-MM-DD hh:mm'
            );
          }
          this.ry_lists = e.data;
        });
    }
  }
};
</script>
