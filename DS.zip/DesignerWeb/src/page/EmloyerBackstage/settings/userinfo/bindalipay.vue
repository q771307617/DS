<template>
    <div >
        <div style="border-bottom: 10px solid #fafafa;padding: 40px 100px;background: #fff;">
            <ul class="bind-ul">
                <li class="is-32x32" :class="{active: current == 1}">
                    <img class="is-16x16" :src="'icon/user.png' | randomPath" alt="验证身份">
                </li>
                <li>
                    <div class="line"></div>
                </li>
                <li class="is-32x32" :class="{active: current == 2}">
                    <img class="is-16x16" :src="'icon/bind.png' | randomPath" alt="绑定支付宝">
                </li>
                <li>
                    <div class="line"></div>
                </li>
                <li class="is-32x32" :class="{active: current == 3}">
                    <img class="is-16x16" :src="'icon/ok.png' | randomPath" alt="完成">
                </li>
            </ul>
            <ul class="bind-text-ul">
                <li style="margin-left: -1em;" :class="{active: current == 1}">验证身份</li>
                <li style="margin-left: -1em;" :class="{active: current == 2}">
                    <span v-if="user.alipay_account">绑定新支付宝</span>
                    <span v-else>绑定支付宝</span>
                </li>
                <li :class="{active: current == 3}">完成</li>
            </ul>
        </div>
        <div  class="bind-content">
            <div v-if="current == 1">
                <div style="margin-bottom: 24px;">
                    <label class="input-label"  >您的手机号：<span style="color:#000;font:size:14px;margin-left: 24px;">{{userphone}}</span> </label>
                    <Button style="width:94px; margin-left: 23px;" @click="sendCode" v-if="codeIntervalTime===60">发送验证码</Button>
                    <Button style="width:94px; margin-left: 23px;" v-else disabled>{{codeIntervalTime}}s后再获取</Button>
                </div>
                <div style="margin-bottom: 24px;display:flex" v-if="needVerifycode">
                    <label class="input-label">图形验证码：
                        <Input v-model="imgcode" type="text" style="width: 104px;margin-left: 24px; " :maxlength="4"></Input>
                    </label>
                    <div @click="fetchCodeImg">
                        <img :src="verifycodeUrl" width="90px" height="32px" />
                    </div>
                </div>
                <div style="margin-bottom: 54px;">
                    <label class="input-label">手机验证码：
                        <Input v-model="params.code" type="text" style="width: 194px;margin-left: 24px;" :maxlength="6"></Input>
                    </label>
                </div>
                <div style="display: flex;justify-content: center;">
                    <div style="width: 212px;text-align: center;">
                        <Button type="error" style="width:90px;font-size:18px" @click="next1">确认</Button>
                        <!-- <a href="/api/oauth/alipay?return_url=/bindalipay/2" style="" target='_blank'>dsiplay:none;</a> -->
                    </div>
                </div>
            </div>
            <div v-if="current == 2">

            </div>
            <div v-if="current == 3" style="text-align: center;font-size: 18px;color: #888888;">
                <p style="font-size: 24px;color: #f54203;margin-bottom: 50px;">绑定成功！</p>
                <p style="margin: 0 -70px;">您将可以使用该支付宝进行提现</p>
                <p>3秒后自动跳转返回......
                    <Button type="text" style="color: #f54203;font-size: 18px;" @click="back">点击跳转</Button>
                </p>
            </div>
        </div>
       
    </div>
</template>
<script>
import { mapState } from 'vuex';
export default {
  data() {
    return {
      codeIntervalTime: 60,
      verifycodeUrl: '',
      needVerifycode: false,
      imgcode: '',
      current: 1,
      userphone: '',
      params: {
        alipay: '',
        code: '',
        realname: ''
      }
    };
  },
  computed: {
    ...mapState({
      user: state => state.User.info,
      ftpPath: state => state.User.ftpPath
    })
  },
  mounted() {
    this.getphone();
    this.fetchCodeImg();
  },
  methods: {
    getphone() {
      let phone = this.user.phone;
      this.userphone = phone.replace(phone.substr(3, 4), '****');
    },
    sendCode() {
      this.$ajax
        .post('auth/sendcode', {
          phone: this.user.phone,
          verifycode: this.imgcode
        })
        .then(e => {
          if (e.status === 200) {
            this.$Message.success(e.msg);
            this.codeIntervalTime--; //60秒倒计时
            this.update = setInterval(() => {
              this.codeIntervalTime--;
            }, 1000);
            this.params.code = e.data;
            // return;
          } else {
            this.needVerifycode = true;
            this.codeIntervalTime = 60;
            clearInterval(this.update);
            this.fetchCodeImg();
            if (!this.imgcode) {
              this.$Message.error('请输入验证码');
            } else if (this.imgcode.length < 4) {
              this.$Message.error('请输入四位验证码');
            } else {
              this.$Message.error(e.msg);
            }
          }
        });
    },
    fetchCodeImg() {
      this.current = this.$route.params.id;
      this.verifycodeUrl = this.$ajax.getVerifyCode();
    },
    next1() {
      if (!this.params.code) {
        this.$Message.error('请输入短信验证码');
        return;
      }
      if (this.params.code.length < 6) {
        this.$Message.error('请输入六位短信验证码');
        return;
      }
      this.$ajax
        .post('auth/verify/phone', {
          code: this.params.code
        })
        .then(e => {
          if (e.status == 200) {
            this.$router.push({
              name: 'bindalipay',
              params: { id: this.current }
            });
            let url = '/bindalipay/2';
            window.location.href = '/api/oauth/alipay?return_url=' + url;
            // window.open(`/api/oauth/alipay?return_url=${url}`);
            this.$Modal.confirm({
              title: '支付宝绑定',
              content: '支付宝绑定已完成？',
              onOk: () => {
                ++this.current;
              }
            });
          }
          this.$Message.error(e.msg);
        //   return;
        });
    },
    next2() {
      this.current = 3;
      let _this = this;
      setTimeout(() => {
        _this.back();
      }, 3000);
      //  if (!this.params.alipay) {
      //     this.$Message.error('请输入支付宝账号');
      //     return;
      // }
      // if (!this.params.realname) {
      //     this.$Message.error('请输入您的名字');
      //     return;
      // }
      // window.open(`/api/oauth/alipay`);
      // this.$Modal.confirm({
      //     title: '支付宝绑定',
      //     content: '支付宝绑定已完成？',
      //     onOk: () => {
      //         ++this.current;
      //             let _this = this;
      //         setTimeout(() => {
      //             _this.back();
      //         }, 3000)
      //     }
      // })
      //    this.$ajax.post('user/bind/alipay',{
      //          ...this.params
      //    }).then((e)=>{
      //        if(e.status===200){
      //            ++this.current;
      //     let _this = this;
      //     setTimeout(() => {
      //         _this.back();
      //     }, 3000)
      //        }else{
      //            this.$Message.error(e.msg);
      //        }
      //    })
    },
    back() {
      this.$router.push({
        path: '/emloyerBackstage/settings'
      });
    }
  },
  watch: {
    codeIntervalTime(val) {
      if (!val) {
        this.codeIntervalTime = 60;
        clearInterval(this.update);
      }
    },
    /** 监听返回数据如果返回2执行方法 */
    current(val) {
      if (val == 2) {
        this.next2();
      }
    }
  }
};
</script>
<style scoped>
.bind-ul {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}

.bind-ul li {
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #dfdede;
}

.bind-ul li.active {
  background-color: #f54203;
}
.bind-content {
  min-height: 750px;
  padding-top: 88px;
  background: #fff;
  display: flex;
  justify-content: center;
}
.is-32x32 {
  height: 32px;
  width: 32px;
}

.is-16x16 {
  height: 16px;
  width: 16px;
}

.line {
  height: 2px;
  background-color: #dfdede;
  width: 222px;
}

.bind-text-ul {
  display: flex;
  justify-content: space-between;
  font-size: 16px;
  color: #807f7f;
}

.bind-text-ul li.active {
  color: #f54203;
}

.input-label {
  font-size: 14px;
  color: #646464;
}
</style>