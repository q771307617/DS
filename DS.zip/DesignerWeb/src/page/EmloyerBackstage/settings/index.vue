<template>
    <div class="bgcolor">
        <ul class="settings-ul box-shadow">
            <li>
                <router-link :to="{ name: 'information'}" :class="{active: this.$route.name === 'information' || this.$route.name === 'editinfo' }">个人信息</router-link>
            </li>
            <li>
                <router-link :to="{ name: 'pwdservice'}" :class="{active: this.$route.name === 'pwdservice'}">密码服务</router-link>
            </li>
        </ul>
        <router-view>
        </router-view>
    </div>
</template>
<script>
export default {
  data() {
    return {};
  }
};
</script>

<style scoped>
.settings-ul {
  padding: 45px 0;
  background: #fff;
  margin-bottom: 15px;
}

.settings-ul li {
  display: inline-block;
  padding-left: 50px;
  padding-right: 50px;
  border-right: 1px solid #e9eaec;
}

.settings-ul li a {
  font-size: 20px;
  color: #646464;
}

.settings-ul li:last-child {
  border-right: none;
}

.settings-ul li a.active {
  color: #f54203;
}

.bgcolor {
  background: #fafafa;
}
</style>

