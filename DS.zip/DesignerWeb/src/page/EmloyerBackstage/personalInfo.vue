<template>
    <table width="100%" style="min-height:900px">
        <tr>
            <td width="138" valign="top" style="background-color:#f3f3f3;">
                <div class="font24 text-center" style="height:76px;line-height:76px;">
                    账户管理
                </div>
                <ul class="left-menu font20 text-center">
                    <li v-for="item in items" :key="item.id" v-bind:class="{active:(item.id == activeName)}" @click="()=>{selectActiveMenu(item)}">
                        {{item.lebal}}
                    </li>
                </ul>
            </td>
            <td width="820" valign="top">
                <div class="information-box">
                    <router-view></router-view>
                </div>
            </td>
        </tr>
    </table>
</template>

<script>
import router from '../../router/index.js';
import { mapState, mapActions } from 'vuex';

export default {
  data() {
    return {
      activeName: 1,
      items: [
        {
          lebal: '个人信息',
          id: 1,
          path: '/emloyerBackstage/personalInfo'
        },
        {
          lebal: '密码服务',
          id: 2,
          path: '/emloyerBackstage/personalInfo/pwdservice'
        }
      ]
    };
  },
  mounted() {
    this.setActiveMenu();
  },
  computed: {
    ...mapState({ userInfo: state => state.User.info })
  },
  methods: {
    setActiveMenu() {
      for (let item of this.items) {
        if (this.$route.path === item.path) {
          this.activeName = item.id;
          break;
        }
        if (this.$route.path === '/emloyerBackstage/personalInfo/editinfo') {
          this.activeName = 1;
          break;
        }
      }
    },
    // 切换页面
    selectActiveMenu(item) {
      this.activeName = item.id;
      router.push({ path: item.path });
    }
  },
  watch: {
    $route: 'setActiveMenu'
  }
};
</script>
<style scoped>
.information-box {
  overflow: hidden;
  font-size: 14px;
}

.information-box .user-avatar {
  width: 180px;
  border-radius: 3px;
  float: left;
  padding: 20px;
}

.information-box .content {
  width: 100%;
  padding: 20px;
  padding-left: 0;
  float: left;
}

.information-box .content ul li {
  height: 130px;
  border-bottom: 1px dashed #ccc;
  width: 100%;
  line-height: 20px;
}

.information-box .content ul li:last-child {
  border-bottom: 0;
}

.information-box .content ul li .title {
  font-size: 20px;
  height: 35px;
}

.pwdservice {
  padding: 5px;
}

.pwdservice .con {
  padding: 25px;
  border: 1px solid #ccc;
  background: #eeeeee;
  height: 95px;
  margin-bottom: 5px;
}

.pwdservice .con span {
  float: left;
}

.pwdservice .con .con1 {
  font-size: 24px;
  color: #39f;
  margin-right: 20px;
}

.pwdservice .con .con2 {
  width: 430px;
  word-wrap: break-word;
  font-size: 14px;
}

.pwdservice .con .con3 {
  margin-top: 3px;
  float: right;
}

.collection {
  padding-left: 10px;
}

.collection .con {
  margin-top: 5px;
  min-height: 500px;
  border: 1px solid #ccc;
  padding: 10px;
}

.collection .con .title {
  color: #39f;
  font-size: 26px;
  height: 50px;
}

.collection .con .img-box {
  margin-top: 20px;
  background: #fff;
  border: 1px solid #ccc;
  box-shadow: 1px 1px 5px #888888;
}

.collection .con .img-box:last-child {
  margin-right: 0;
}

.collection .con .img-box .btn-box {
  height: 25px;
}

.collection .con .img-box .li-btn {
  background: #fff;
  border: 1px solid #ccc;
  padding: 0 5px;
  margin-left: 5px;
}

.left-menu li {
  cursor: pointer;
  height: 50px;
  line-height: 50px;
  border-top: 1px solid #d1d1d1;
}

.left-menu li:last-child {
  border-top: 1px solid #d1d1d1;
  border-bottom: 1px solid #d1d1d1;
}

.left-menu .active {
  background: #d7d7d7;
  color: #000;
  font-weight: 900;
}

.codebtn {
  height: 40px;
  font-size: 16px;
}
.editinfo {
  min-height: 900px;
}
</style>
