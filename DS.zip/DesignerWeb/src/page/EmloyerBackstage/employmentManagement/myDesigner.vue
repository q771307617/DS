<template>
    <div>
        <div style="background-color:#fff;margin:10px 0;padding-left:20px;">
            <div class="clearfix" style="height:50px;line-height:32px;padding-top:15px;font-size:14px;padding-left:18px;">
                <span class="float-left">查询:　</span>
                <div class="float-left time-style" style="width:419px;">
                    <Row>
                        <Col span="11">
                        <Date-picker type="date" placeholder="选择日期" v-model="selectData.sDate"></Date-picker>
                        </Col>
                        <Col span="1" style="text-align:center;"> 至
                        </Col>
                        <Col span="11">
                        <Date-picker type="date" placeholder="选择日期" v-model="selectData.eDate"></Date-picker>
                        </Col>
                    </Row>
                </div>
                <span class="float-left" style="padding-left:10px;color: #888;">
                            最近
                        </span>
                <span class="float-left sx-btn-link" 　style="display:block;margin:0 10px;" @click="limitDate(1, 'weeks')">
                            一周
                        </span>
                <span class="float-left sx-btn-link" style="display:block;margin:0 10px;" @click="limitDate(1, 'months')">
                            1个月
                        </span>
                <span class="float-left sx-btn-link" style="display:block;margin:0 10px;" @click="limitDate(3, 'months')">
                            3个月
                        </span>
            </div>
            <div class="clearfix" style="height:50px;line-height:32px;padding-top:8px;">
                <span class="float-left">雇佣类型:　</span>
                <Select v-model="selectData.type" class="float-left" style="width:192px">
                        <Option v-for="item in typeList" :value="item.value" :key="item.value">{{ item.label }}</Option>
                    </Select>
                <span class="float-left">　雇佣状态:　</span>
                <Select v-model="selectData.status" class="float-left" style="width:192px;">
                        <Option v-for="item in statusList" :value="item.value" :key="item.value">{{ item.label }}</Option>
                    </Select>
                <div class="float-left" style="padding-left:10px;">
                    <Button class="float-left" type="warning" style="padding: 3.5px 12px;margin-left:10px;width:50px;background-color:#f54203;" @click="getdesignerpagelist">查询</Button>
                </div>
            </div>
        </div>
        <div style="background-color:#fff;padding:5px 0;">
            <Table :columns="designer_columns" :data="designer_data"></Table>
            <div class="clearfix sx-page page-style">
                <Page :total="selectData.count" :current="selectData.pageNum" :page-size="selectData.pageSize" show-elevator show-total class="float-right page" @on-change="changeDesignerPage"></Page>
            </div>
        </div>
        <Modal class="pj-modal" v-model="pj_modal" title="雇主评估" width="962" @on-ok="show_pj" @on-cancel="hide_pj" :closable="!pj_status" :mask-closable="false">
            <DesignerMess v-on:listenChildEvent="getChildData" v-bind:dataPj="designer_pj_data" v-bind:pjState="pj_status"></DesignerMess>
            <div slot="footer">
                <div class="pj-btn-group" v-if="pj_status">
                <Button class="pj-modal-btn pj-show" type="primary" size="large" @click="show_pj">确定</Button>
                <Button class="pj-modal-btn pj-hide" type="primary" size="large" @click="hide_pj">取消</Button>
                </div>
            </div>
        </Modal>
    </div>
</template>

<script>
import moment from 'moment';
import DesignerMess from './designerMess.vue';
export default {
  components: { DesignerMess },
  data() {
    return {
      pj_modal: false, //modal
      pj_status: true, //false 不可评价/查看 true 可评价
      pj_set_data: {
        //默认评价
        pjAttitude: 5,
        pjAbility: 5,
        pjSpeed: 5,
        pjDetails: ''
      },
      designer_columns: [
        {
          title: '设计师',
          align: 'center',
          key: 'designerName'
        },
        {
          title: '雇佣日期',
          align: 'center',
          key: 'emloymentDate',
          width: 200
        },
        {
          title: '雇佣类型',
          align: 'center',
          key: 'typeStr'
        },
        {
          title: '雇佣金额',
          align: 'center',
          key: 'price'
        },
        {
          title: '待发工资',
          align: 'center',
          key: 'nopayPrice'
        },
        {
          title: '保证金',
          align: 'center',
          key: 'statusValue',
          render: (h, params) => {
            if (params.row.status == 0) {
              return h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      window.location.href = '/payment?hireId=' + params.row.id;
                      // this.$router.push({
                      //     name: "payment",
                      //     query: {
                      //         hireId: params.row.id
                      //     }
                      // })
                    }
                  }
                },
                '去支付'
              );
            } else {
              return h('span', '已支付');
            }
          }
        },
        {
          title: '雇佣状态',
          align: 'center',
          key: 'status',
          render: (h, params) => {
            let item = params.row;
            if (item.status == 1) {
              return h('span', '待开始');
            } else if (item.status == -1) {
              return h('span', '已取消');
            } else if (
              item.type === 1 &&
              item.status == 3 &&
              item.nopayPrice > 0
            ) {
              return h('span', '已交付');
            } else if (item.status == 4) {
              return h('span', '已评价');
            } else if (item.status == 3 && item.nopayPrice <= 0) {
              return h('span', '已完成');
            } else if (item.status == 9 || item.status == 12) {
              return h('span', '退款中');
            } else if (item.status == 15) {
              return h('span', '已退款');
            } else {
              return h('span', item.statusValue);
            }
          }
        },
        {
          title: '操作',
          align: 'center',
          key: 'handle',
          render: (h, params) => {
            let pjObj = params.row;

            //退款
            //退款中 已退款
            let that = this;
            function getRefund(v, route) {
              let style = '';
              if (route == 'commit') {
                style = {
                  fontSize: '14px',
                  color: '#0022f0',
                  border: 'none',
                  background: 'transparent'
                };
              }
              return h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  style: style,
                  on: {
                    click: () => {
                      let type = '';
                      if (pjObj.type == 0) {
                        //包月
                        type = 'HIRE_MONTH';
                      } else if (pjObj.type == 1) {
                        //定制
                        type = 'HIRE_CUSTOM';
                      }

                      if (route == 'commit') {
                        that.$ajax
                          .get('/orders/refund/apply', {
                            id: pjObj.id,
                            type: type
                          })
                          .then(e => {
                            if (e.status == 200) {
                              that.$router.push({
                                name: route,
                                query: {
                                  navType: '2',
                                  id: pjObj.id,
                                  type: type
                                }
                              });
                            } else {
                              that.$Notice.error({
                                title: e.msg
                              });
                            }
                          });
                        return;
                      }
                      that.$router.push({
                        name: route,
                        query: {
                          navType: '2',
                          id: pjObj.id,
                          type: type
                        }
                      });
                    }
                  }
                },
                v
              );
            }
            if (pjObj.status == 1 || pjObj.status == 2) {
              //待开始 工作中(判断需要确认)
              const v = '退款';
              return getRefund(v, 'commit');
            } else if (pjObj.status == 9 || pjObj.status == 12) {
              //退款中
              const v = '详情';
              return getRefund(v, 'check');
            } else if (pjObj.status == 15) {
              //已退款
              const v = '详情';
              return getRefund(v, 'success');
            } else {
              //评价
              let txt;
              if (
                pjObj.status == 3 &&
                (pjObj.nopayPrice <= 0 && pjObj.nextPayTime == null)
              ) {
                //已完成
                txt = '评价';
              } else if (pjObj.status == 4) {
                //已评价
                txt = '详情';
              } else {
                return;
              }
              return h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      //拿到相应设计师的数据，ID唯一值，这条记录
                      if (pjObj.status == 3) {
                        //已完成 可以评估
                        this.pj_status = true;
                      } else if (pjObj.status == 4) {
                        //已评价 可以查看
                        this.pj_status = false;
                      }
                      this.designer_pj_data = pjObj;
                      this.pj_modal = true;
                    }
                  }
                },
                txt
              );
            }
          }
        }
      ],
      designer_pj_data: {},
      designer_data: [],
      statusList: [
        {
          value: '',
          label: '全部'
        },
        {
          value: '0',
          label: '未支付'
        },
        {
          value: '1',
          label: '待开始'
        },
        {
          value: '2',
          label: '工作中'
        },
        {
          value: '3',
          label: '已完成'
        },
        {
          value: '4',
          label: '已评价'
        },
        {
          value: '-1',
          label: '已取消'
        },
        {
          value: '9,12',
          label: '退款中'
        },
        {
          value: '15',
          label: '已退款'
        }
      ],
      typeList: [
        {
          value: '',
          label: '全部'
        },
        {
          value: '1',
          label: '定制'
        },
        {
          value: '0',
          label: '包月'
        }
      ],
      selectData: {
        type: '',
        status: '',
        pageNum: 1,
        pageSize: 10,
        count: 10,
        eDate: '',
        sDate: ''
      }
    };
  },
  mounted() {
    this.limitDate(1, 'months');
    this.getdesignerpagelist();
  },
  methods: {
    isNull(v) {
      if (v == null) {
        return true;
      }
      return false;
    },
    getChildData(v) {
      //保存评论数据 没有则用默认数据
      this.pj_set_data = { ...v };
    },
    show_pj() {
      this.pj_modal = false;
      if (this.pj_set_data.pjDetails.length < 5) {
        this.$Notice.error({
          title: '评价字数太少！'
        });
        // return;
      } else {
        //执行评价操作:1、评价；2、没评价、默认数据
        this.$ajax
          .post('hire/pj', {
            id: this.designer_pj_data.id,
            pjAbility: this.pj_set_data.pjAbility,
            pjAttitude: this.pj_set_data.pjAttitude,
            pjDetails: this.pj_set_data.pjDetails,
            pjSpeed: this.pj_set_data.pjSpeed
          })
          .then(e => {
            if (e.status == 200) {
              this.$Notice.success({
                title: '评价成功！'
              });
              this.getdesignerpagelist();
            } else {
              this.$Notice.error({
                title: '评价失败！'
              });
            }
          });
      }
    },
    hide_pj() {
      this.pj_modal = false;
    },
    getdesignerpagelist() {
      let obj = {
        ...this.selectData
      };
      obj.sDate = this.$utils.time.startTime(obj.sDate, 'YYYY-MM-DD HH:mm:ss');
      obj.eDate = this.$utils.time.endTime(obj.eDate, 'YYYY-MM-DD HH:mm:ss');
      obj.sDate = moment(obj.sDate).format('x');
      obj.eDate = moment(obj.eDate).format('x');
      this.$ajax.get('employ/getdesignerpagelist', obj).then(e => {
        for (let i in e.data.list) {
          e.data.list[i].emloymentDate =
            new Date(e.data.list[i].startTime).Format('yyyy/MM/dd') +
            '-' +
            new Date(e.data.list[i].endTime).Format('yyyy/MM/dd');
          e.data.list[i].typeStr = e.data.list[i].type == 0 ? '包月' : '定制';
        }
        this.designer_data = e.data.list;
        this.selectData.pageNum = e.data.num || 1;
        this.selectData.pageSize = e.data.size;
        this.selectData.count = e.data.count;
      });
    },
    limitDate(n, u) {
      this.selectData.sDate = moment()
        .subtract(n, u)
        .format();
      this.selectData.eDate = new Date();
      this.selectData.pageNum = 1;
      this.getdesignerpagelist();
    },
    changeDesignerPage(num) {
      this.selectData.pageNum = num;
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
      this.getdesignerpagelist();
    }
  }
};
</script>
<style scoped>
.wsl_tab_style {
  overflow: hidden;
  background-color: #fff;
}
.wsl_tab_style a {
  display: block;
  float: left;
  width: 180px;
  height: 126px;
  line-height: 126px;
  font-size: 20px;
  color: #888;
  text-align: center;
}
.wsl_tab_style a:hover,
.wsl_tab_style a.active {
  color: #f54203;
}
.ivu-select-dropdown {
  max-height: 500px;
}
.employ-p {
  padding-left: 20px;
  font-size: 18px;
  line-height: 1.5;
  padding-bottom: 20px;
}
.employ-p em {
  font-style: normal;
  /**color: #2d8cf0;*/
  color: RGB(246, 116, 4);
}
.sx-btn-link {
  color: RGB(246, 116, 4);
  cursor: pointer;
}
.sx-btn-link:hover {
  text-decoration: underline;
}
.page {
  margin: 20px 5px;
}

/* 雇主评价 */
.pj-modal-btn {
  padding-top: 3px;
  width: 91px;
  height: 30px;
  font-size: 17px;
  color: #fff;
  background: #f54203;
  border: none;
}
.pj-show {
}
.pj-hide {
  color: #fff;
  background: #b3b3b3;
  margin-left: 40px;
}
.pj-btn-group {
  padding-right: 80px;
}
</style>
<style scoped>
.pj-modal {
}
.ivu-modal-header {
  background: #f54203;
  padding: 11px 12px 8px;
}
.ivu-modal-body {
  padding-left: 0;
  padding-right: 0;
}
.ivu-modal-header-inner {
  color: #fff;
  font-size: 16px;
}
.ivu-modal-footer {
  border: none;
  padding-bottom: 36px;
}
.ivu-modal-close .ivu-icon-ios-close-empty {
  top: -3px;
  color: #fff;
}
</style>
