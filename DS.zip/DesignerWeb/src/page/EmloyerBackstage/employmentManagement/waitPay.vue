<template>
    <div>
        <p class="employ-p">
            <span style="color:#646464;">包月雇佣 ：</span>
            <span style="color:#888;">无需确认发放，月底自动扣减，平台负责与设计师结算。</span><br/>
            <span style="color:#646464;"> 定制雇佣 ：</span>
            <span style="color:#888;">状态为
                <em>已完成</em>后，10天内为雇主进行
                <em>确认发放</em>，超期自动发放，货申请延期确认（顺延5天）。</span>
        </p>
        <div style="background-color:#fff;padding:5px 0;">
            <Table class="table-style" :columns="waitPay_columns" :data="waitPay_data"></Table>
            <div class="clearfix sx-page page-style">
                <Page :total="selectData.count" :current="selectData.pageNum" :page-size="selectData.pageSize" show-elevator show-total class="float-right page" @on-change="changeDesignerPage"></Page>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment';
export default {
  data() {
    return {
      waitPay_columns: [
        {
          title: '设计师',
          align: 'center',
          key: 'designerName'
        },
        {
          title: '雇佣日期',
          align: 'center',
          key: 'emloymentDate',
          width: 200
        },
        {
          title: '雇佣类型',
          align: 'center',
          key: 'typeStr'
        },
        {
          title: '雇佣金额（元）',
          align: 'center',
          key: 'price'
        },
        {
          title: '待发工资（元）',
          align: 'center',
          key: 'salary'
        },
        {
          title: '雇佣状态',
          align: 'center',
          key: 'statusStr',
          render: (h, params) => {
            let item = params.row;
            if (item.type === 1 && item.status == 3 && item.nopayPrice > 0) {
              return h('span', '已交付');
            } else if (item.status == 3 && item.nopayPrice <= 0) {
              return h('span', '已完成');
            } else if (item.status == 4) {
              return h('span', '已评价');
            } else {
              return h('span', item.statusStr);
            }
          }
        },
        {
          title: '最迟确认发放剩余天数',
          align: 'center',
          key: 'lastday',
          className: 'ivu-btn-text'
        },
        {
          title: '操作',
          align: 'center',
          key: 'action',
          width: 180,
          render: (h, params) => {
            console.log(params.row.status);
            /** 定制才能发放 */
            if (params.row.type == 0) {
              return;
            }
            /** 未付款大于0才能发放 */
            if (params.row.nopayPrice <= 0) {
              return;
            }
            /** 雇佣状态为 已完成才能发放 */
            if (params.row.status != 3) {
              return;
            }
            let arr = [];
            arr.push(
              h(
                'Button',
                {
                  props: {
                    type: 'text',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.paySalary(params.row.id);
                    }
                  }
                },
                '确认发放'
              )
            );
            if (params.row.delayPaySalary != 1) {
              arr.push(
                h(
                  'Button',
                  {
                    props: {
                      type: 'text',
                      size: 'small'
                    },
                    on: {
                      click: () => {
                        this.delayPaySalary(params.row.id);
                      }
                    }
                  },
                  '延迟发放'
                )
              );
            }
            return h('Row', [h('Col', arr)]);
          }
        }
      ],
      waitPay_data: [],
      selectData: {
        pageNum: 1,
        pageSize: 10,
        count: 10
      }
    };
  },
  mounted() {
    this.getnopaypagelist();
  },
  methods: {
    // /hire/paySalary 发放薪水
    paySalary(hireId) {
      this.$ajax
        .post('hire/paySalary', {
          hireId: hireId
        })
        .then(e => {
          if (e.status == 200) {
            this.$Notice.success({
              title: '发放薪水成功'
            });
            this.getnopaypagelist();
          } else {
            this.$Notice.error({
              title: '发放薪水失败',
              desc: e.msg
            });
          }
        });
    },
    // /hire/delayPaySalary 延时发放薪水
    delayPaySalary(hireId) {
      this.$ajax
        .post('hire/delayPaySalary', {
          hireId: hireId
        })
        .then(e => {
          if (e.status == 200) {
            this.$Notice.success({
              title: '延时发放薪水成功'
            });
            this.getnopaypagelist();
          } else {
            this.$Notice.error({
              title: '延时发放薪水失败',
              desc: e.msg
            });
          }
        });
    },
    changeDesignerPage(num) {
      this.selectData.pageNum = num;
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
      this.getnopaypagelist();
    },
    getnopaypagelist() {
      let obj = {
        ...this.selectData
      };
      const nowDate = moment().format('YYYY-MM-DD');
      this.$ajax.get('employ/getnopaypagelist', obj).then(e => {
        for (let i in e.data.list) {
          e.data.list[i].emloymentDate =
            new Date(e.data.list[i].startTime).Format('yyyy/MM/dd') +
            '-' +
            new Date(e.data.list[i].endTime).Format('yyyy/MM/dd');
          e.data.list[i].typeStr = e.data.list[i].type == 0 ? '包月' : '定制';
          e.data.list[i].salary =
            e.data.list[i].type == 0
              ? e.data.list[i].salary
              : e.data.list[i].price;
          const startTime = new Date(e.data.list[i].startTime).Format(
            'yyyy/MM/dd'
          );
          const endTime = new Date(e.data.list[i].endTime).Format('yyyy/MM/dd');
          if (e.data.list[i].type == 0) {
            //包月雇佣
            let monthDate = this.getDateDiff(startTime, nowDate, 'month') + 1;
            let salaryday = moment(startTime)
              .add(monthDate, 'month')
              .format('YYYY-MM-DD');
            e.data.list[i].lastday =
              this.getDateDiff(nowDate, salaryday, 'day') + '天'; //这行代码不能省
          } else {
            //定制雇佣
            let salaryday = moment(endTime)
              .add(e.data.list[i].delayPaySalary == 1 ? 15 : 10, 'day')
              .format('YYYY-MM-DD');
            e.data.list[i].lastday =
              this.getDateDiff(nowDate, salaryday, 'day') + '天';
          }
        }
        this.waitPay_data = e.data.list;
        this.selectData.pageNum = e.data.num || 1;
        this.selectData.pageSize = e.data.size;
        this.selectData.count = e.data.count;
      });
    },
    getDateDiff(startTime, endTime, diffType) {
      //将xxxx-xx-xx的时间格式，转换为 xxxx/xx/xx的格式
      startTime = startTime.replace(/-/g, '/');
      endTime = endTime.replace(/-/g, '/');
      //将计算间隔类性字符转换为小写
      diffType = diffType.toLowerCase();
      var sTime = new Date(startTime); //开始时间
      var eTime = new Date(endTime); //结束时间
      //作为除数的数字
      var divNum = 1;
      switch (diffType) {
        case 'second':
          divNum = 1000;
          break;
        case 'minute':
          divNum = 1000 * 60;
          break;
        case 'hour':
          divNum = 1000 * 3600;
          break;
        case 'day':
          divNum = 1000 * 3600 * 24;
          break;
        case 'month':
          divNum = 1000 * 3600 * 24 * 30;
          break;
        default:
          break;
      }
      return (
        parseInt((eTime.getTime() - sTime.getTime()) / parseInt(divNum)) || 0
      );
    }
  }
};
</script>
<style>
.table-style {
  background-color: #fff;
}

.table-style .ivu-table-column-center {
  background-color: #fff;
}

.table-style .ivu-table-cell {
  padding: 3px;
}

.table-style .ivu-btn-text {
  color: #f54203;
}

.table-style .ivu-btn-warning {
  background-color: #f54203;
}
</style>
<style scoped>
.wsl_tab_style {
  overflow: hidden;
  background-color: #fff;
}

.wsl_tab_style a {
  display: block;
  float: left;
  width: 180px;
  height: 126px;
  line-height: 126px;
  font-size: 20px;
  color: #888;
  text-align: center;
}

.wsl_tab_style a:hover,
.wsl_tab_style a.active {
  color: #f54203;
}

.employ-p {
  background-color: #fff;
  margin: 10px 0;
  font-size: 16px;
  padding: 26px 49px;
  line-height: 30px;
}

.employ-p em {
  font-style: normal;
  /**color: #2d8cf0;*/
  color: RGB(246, 116, 4);
}

.sx-btn-link {
  color: RGB(246, 116, 4);
  cursor: pointer;
}

.sx-btn-link:hover {
  text-decoration: underline;
}

.page {
  margin: 20px 5px;
}
</style>
