<template>
    <div>
        <div style="background-color:#fff;padding:5px 0;margin-top:10px;">
            <Table class="table-style" :columns="records_columns" :data="records_data"></Table>
            <div class="clearfix sx-page page-style">
                <Page :total="selectData.count" :current="selectData.pageNum" :page-size="selectData.pageSize" show-elevator show-total class="float-right page" @on-change="changeDesignerPage"></Page>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment';
export default {
  data() {
    return {
      records_columns: [
        {
          title: '设计师',
          align: 'center',
          key: 'hire_designerName'
        },
        {
          title: '雇佣日期',
          align: 'center',
          key: 'emloymentDate',
          width: 200
        },
        {
          title: '雇佣类型',
          key: 'typeStr',
          align: 'center'
        },
        {
          title: '发放金额',
          align: 'center',
          key: 'price'
        },
        {
          title: '雇佣状态',
          align: 'center',
          key: 'statusStr',
          render: (h, params) => {
            let item = params.row;
            if (item.type === 1 && item.status == 3 && item.nopayPrice > 0) {
              return h('span', '已交付');
            } else if (item.status == 3 && item.nopayPrice <= 0) {
              return h('span', '已完成');
            } else if (item.status == 4) {
              return h('span', '已评价');
            } else if (item.status == 15) {
              return h('span', '已退款');
            } else {
              return h('span', item.statusStr);
            }
          }
        }
      ],
      records_data: [],
      selectData: {
        pageNum: 1,
        pageSize: 10,
        count: 10
      }
    };
  },
  mounted() {
    this.getpaylogpagelist();
  },
  methods: {
    changeDesignerPage(num) {
      this.selectData.pageNum = num;
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
      this.getpaylogpagelist();
    },
    getpaylogpagelist() {
      let obj = {
        pageNum: this.selectData.pageNum,
        pageSize: this.selectData.pageSize
      };
      this.$ajax.get('employ/getpaylogpagelist', obj).then(e => {
        let list = [];
        let arrayList = e.data.list;
        for (let i in arrayList) {
          list.push({
            hire_designerName: arrayList[i].designerName,
            emloymentDate:
              moment(arrayList[i].startTime).format('YYYY/MM/DD') +
              '-' +
              moment(arrayList[i].endTime).format('YYYY/MM/DD'),
            statusStr: arrayList[i].statusStr,
            typeStr: arrayList[i].type == 1 ? '定制' : '包月',
            price: arrayList[i].amount + '元'
          });
        }
        this.records_data = list;
        this.selectData.pageNum = e.data.num || 1;
        this.selectData.pageSize = e.data.size;
        this.selectData.count = e.data.count;
      });
    }
  }
};
</script>
<style>
.table-style {
  background-color: #fff;
}
.table-style .ivu-table-column-center {
  background-color: #fff;
}
.table-style .ivu-table-cell {
  padding: 3px;
}
.table-style .ivu-btn-text {
  color: #f54203;
}
.table-style .ivu-btn-warning {
  background-color: #f54203;
}
</style>
<style scoped>
.wsl_tab_style {
  overflow: hidden;
  background-color: #fff;
}
.wsl_tab_style a {
  display: block;
  float: left;
  width: 180px;
  height: 126px;
  line-height: 126px;
  font-size: 20px;
  color: #888;
  text-align: center;
}
.wsl_tab_style a:hover,
.wsl_tab_style a.active {
  color: #f54203;
}
.employ-p {
  background-color: #fff;
  margin: 10px 0;
  font-size: 16px;
  padding: 26px 49px;
  line-height: 30px;
}
.employ-p em {
  font-style: normal;
  /**color: #2d8cf0;*/
  color: RGB(246, 116, 4);
}
.sx-btn-link {
  color: RGB(246, 116, 4);
  cursor: pointer;
}
.sx-btn-link:hover {
  text-decoration: underline;
}
.page {
  margin: 20px 5px;
}
</style>
