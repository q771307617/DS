<template>
    <div>
        <div class="pj-designer">
            <div class="pj-designer-mess pj-designer-common">
                <p><label>设计师姓名：</label><span>{{getPjData.designerName}}</span></p>
                <p><label>设计师电话：</label><span>{{getPjData.designerPhone}}</span></p>
                <p><label>雇佣方式：</label><span>{{getPjData.typeStr}}</span></p>
            </div>
            <div class="pj-designer-hire pj-designer-common">
                <p><label>雇佣开始时间：</label><span>{{getPjData.startTime | format}}</span></p>
                <p><label>雇佣结束时间：</label><span>{{getPjData.endTime | format}}</span></p>
                <p><label>雇佣状态：</label><span>{{getPjData.status | status(getPjData.statusValue)}}</span></p>
            </div>
        </div>
        <div class="pj-handle">
            <div class="pj-handle-level pj-handle-common">
                <h3>评价：</h3>
                <ul class='pj-list'>
                    <li><!-- v-for="item in pjObj" -->
                        <p class="pj-list-lv">服务态度：</p><div class='pg-level'><span class='pg-level-bg'><i v-on:click="setStart1(i, pg_level.isPG)" v-for='i in 5'>★</i></span><span class='pg-level-handle'><i v-on:click="setStart1(i, pg_level.isPG)" v-for='i in pg_level.pjAttitude'>★</i></span></div>
                    </li>
                    <li>
                        <p class="pj-list-lv">设计能力：</p><div class='pg-level'><span class='pg-level-bg'><i v-on:click="setStart2(i, pg_level.isPG)" v-for='i in 5'>★</i></span><span class='pg-level-handle'><i v-on:click="setStart2(i, pg_level.isPG)" v-for='i in pg_level.pjAbility'>★</i></span></div>
                    </li>
                    <li>
                        <p class="pj-list-lv">响应速度：</p><div class='pg-level'><span class='pg-level-bg'><i v-on:click="setStart3(i, pg_level.isPG)" v-for='i in 5'>★</i></span><span class='pg-level-handle'><i v-on:click="setStart3(i, pg_level.isPG)" v-for='i in pg_level.pjSpeed'>★</i></span></div>
                    </li>
                </ul>
            </div>
            <div class="pj-handle-form pj-handle-common">
                <h3>评语：</h3>
                <textarea v-on:input="sendDataParent" v-model="pg_level.pjDetails" class="pj-textarea" v-bind:disabled="!pg_level.isPG" maxlength="250" ></textarea>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment';
export default {
  props: ['dataPj', 'pjState'], //数据
  data() {
    const state = this.pjState;
    return {
      pg_level: {
        //评估等级
        pjAttitude: 5,
        pjAbility: 5,
        pjSpeed: 5,
        pjDetails: '', //评语
        isPG: state //是否可评估
      }
    };
  },
  watch: {
    dataPj: function() {
      //监听 清空数据/读取新数据
      this.pg_level.pjAttitude = this.dataPj.pjAttitude || 5;
      this.pg_level.pjAbility = this.dataPj.pjAbility || 5;
      this.pg_level.pjSpeed = this.dataPj.pjSpeed || 5;
      this.pg_level.pjDetails = this.dataPj.pjDetails || '';
      this.sendDataParent();
    },
    pjState: function() {
      this.pg_level.isPG = this.pjState;
    }
  },
  filters: {
    status: function(v, s) {
      if (v == 1) {
        return '待开始';
      } else if (v == 0 || v == undefined) {
        return '--';
      } else {
        return s;
      }
    },
    format: function(v) {
      return moment(v).format('YYYY/MM/DD');
    }
  },
  computed: {
    getPjData: function() {
      //接收展示数据
      return this.dataPj;
    }
  },
  methods: {
    setStart1: function(v, pd) {
      if (!pd) return;
      this.pg_level.pjAttitude = v;
      this.sendDataParent();
    },
    setStart2: function(v, pd) {
      if (!pd) return;
      this.pg_level.pjAbility = v;
      this.sendDataParent();
    },
    setStart3: function(v, pd) {
      if (!pd) return;
      this.pg_level.pjSpeed = v;
      this.sendDataParent();
    },
    sendDataParent: function() {
      //数据传回父级
      const v = { ...this.pg_level };
      this.$emit('listenChildEvent', v);
    }
  }
};
</script>

<style scoped>
.pj-designer {
  padding-top: 4px;
  border-bottom: 1px solid #e9eaec;
}
.pj-designer-common {
  font-size: 14px;
  overflow: hidden;
}
.pj-designer-common p {
  width: 50%;
  float: left;
  padding-bottom: 20px;
}
.pj-designer-common label {
  width: 130px;
  display: inline-block;
  color: #373737;
  text-align: right;
}
.pj-designer-common span {
  color: #686868;
  opacity: 0.77;
}

.pj-handle {
  overflow: hidden;
}
.pj-handle-common {
  margin-top: 20px;
}
.pj-handle-common h3 {
  float: left;
  width: 80px;
  font-size: 14px;
  color: #373737;
  padding-left: 36px;
}
.pj-list {
  overflow: hidden;
}
.pj-list li {
  float: left;
  margin-right: 50px;
}
.pj-list-lv {
  display: inline-block;
  padding-right: 1px;
  font-size: 14px;
  color: #7b7b7b;
}
.pj-textarea {
  width: 787px;
  height: 153px;
  font-family: '微软雅黑';
  font-size: 14px;
  font-weight: normal;
  padding: 0 5px;
}

.pg-level {
  position: relative;
  display: inline-block;
  -webkit-user-select: none;
  user-select: none;
}
.pg-level-bg {
  cursor: pointer;
}
.pg-level-bg i {
  font-style: normal;
  font-size: 15px;
  padding-right: 1px;
}
.pg-level-handle {
  position: absolute;
  top: 0;
  left: 0;
  color: #ffb309;
  cursor: pointer;
}
.pg-level-handle i {
  font-style: normal;
  font-size: 15px;
  padding-right: 1px;
  display: inline-block;
}
</style>