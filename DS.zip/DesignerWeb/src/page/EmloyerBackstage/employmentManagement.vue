<template>
    <div>
        <div class="wsl_tab_style">
            <a :class="isShowType == 1 ?'active':''" @click="setIsShowType(1)" href="javascript:;">我的设计师</a>
            <p>|</p>
            <a :class="isShowType == 2 ?'active':''" @click="setIsShowType(2)" href="javascript:;">待付工资</a>
            <p>|</p>
            <a :class="isShowType == 3 ?'active':''" @click="setIsShowType(3)" href="javascript:;">发放记录</a>
        </div>
        <!--发放纪录-->
        <div v-if="isShowType == 3">
            <records></records>
        </div>
        <!--代付工资-->
        <div v-else-if ="isShowType == 2">
            <waitPay></waitPay>
        </div>
        <!--我的设计师-->
        <div v-else>
            <myDesigner></myDesigner>
        </div>
    </div>
</template>

<script>
import myDesigner from './employmentManagement/myDesigner.vue';
import waitPay from './employmentManagement/waitPay.vue';
import records from './employmentManagement/records.vue';
export default {
  data() {
    return {
      isShowType: '1'
    };
  },
  mounted() {},
  methods: {
    setIsShowType(type) {
      if (type == 3) {
        this.isShowType = 3;
        return;
      }
      if (type == 2) {
        this.isShowType = 2;
        return;
      }
      this.isShowType = 1;
    }
  },
  components: {
    myDesigner,
    waitPay,
    records
  }
};
</script>
<style scoped>
.wsl_tab_style {
  overflow: hidden;
  background-color: #fff;
}
.wsl_tab_style a {
  display: block;
  float: left;
  width: 180px;
  height: 126px;
  line-height: 126px;
  font-size: 20px;
  color: #888;
  text-align: center;
}
.wsl_tab_style a:hover,
.wsl_tab_style a.active {
  color: #f54203;
}

.wsl_tab_style p {
  float: left;
  line-height: 126px;
}
.employ-p {
  padding-left: 20px;
  font-size: 18px;
  line-height: 1.5;
  padding-bottom: 20px;
}
.employ-p em {
  font-style: normal;
  /**color: #2d8cf0;*/
  color: RGB(246, 116, 4);
}
.sx-btn-link {
  color: RGB(246, 116, 4);
  cursor: pointer;
}
.sx-btn-link:hover {
  text-decoration: underline;
}
.page {
  margin: 20px 5px;
}
</style>
