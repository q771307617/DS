<template>
    <div>
        <div style="margin-bottom: 10px;border-bottom: 10px solid #fafafa;padding: 20px;background-color: #fff;">
            <ul class="statistics-ul">
                <li>
                    <span class="font20 color646464">钱包总额</span>
                    <br>
                    <span class="font20 f54203">{{info.totalAmount}}元</span>
                </li>
                <li>
                    <span class="font20 color646464">平台监管金额</span>
                    <br>
                    <span class="font20 f54203">{{info.deposit}}元</span>
                </li>
                <li>
                    <span class="font20 color646464">账户余额</span>
                    <br>
                    <span class="font20 f54203">{{info.balance}}元</span>
                </li>
                <div style="display: inline-block">
                    <div>
                        <Button style="margin-bottom: 10px;background-color: #ed3f14;color: #fff;" @click="recharge">充值</Button>
                        <Button style="margin-bottom: 10px;background-color: #9e9e9e;color: #fff;margin-left: 6px;" @click="cash">提现</Button>
                    </div>
                </div>
            </ul>
        </div>
        <div style="padding: 10px 20px;background-color: #fff;">
            <div style="border-bottom: 1px solid #e9eaec;margin-bottom: 10px;padding-bottom: 10px;" class="font16 color646464">
                <a class="f54203" >交易记录</a>
                <a  class="color646464 link" @click="cashRecord">提现记录</a>
                <a  class="color646464 link" @click="refundLog">退款记录</a>
                </div>
            <div style="margin-bottom: 20px;">
                <span>查询</span>
                <Date-picker v-model="beginTime" @on-change="handleBeginPicker" :editable="false" :clearable="false" type="date" placeholder="开始日期" style="width: 200px;display: inline-block;"></Date-picker>
                <span>至</span>
                <Date-picker v-model="endTime" :options="options" :editable="false" :clearable="false" type="date" placeholder="结束日期" style="width: 200px;display: inline-block;"></Date-picker>
                <Button type="error" @click="search">查询</Button>
                <ul class="time-link-ul">
                    <li>最近</li>
                    <li>
                        <a href="javascript:;" @click="limitDate(1,'weeks')">一周</a>
                    </li>
                    <li>
                        <a href="javascript:;" @click="limitDate(1,'months')">1个月</a>
                    </li>
                    <li>
                        <a href="javascript:;" @click="limitDate(3,'months')">3个月</a>
                    </li>
                    <li>
                        <a href="javascript:;" @click="limitDate(1,'years')">1年</a>
                    </li>
                </ul>
            </div>
            <div style="min-height:400px">
            <Table border :columns="records_columns" :data="records_data"></Table>
            </div>
            <Page :total="total" :current="pageNum" :page-size="pageSize" @on-change="paging" show-total show-elevator class="float-right page page-style" style="margin-top: 20px;"></Page>
        </div>
        <pay-alert :id="id"></pay-alert>
        <pay-charge :id="id"></pay-charge>
    </div>
</template>

<script>
import { mapState } from 'vuex';
import moment from 'moment';
import Constant from '@/constant/index';
import payAlert from '@/page/EmloyerBackstage/Modal/payment';
import payCharge from '@/page/EmloyerBackstage/Modal/recharge';

const channel = ['账户余额', '支付宝', '微信', '支付宝', '微信'];
export default {
  components: {
    payAlert,
    payCharge
  },
  computed: {
    ...mapState({
      info: state => state.User.info
    })
  },
  methods: {
    handleBeginPicker(date) {
      this.endTime = date;
    },
    recharge() {
      this.$router.push({ name: 'recharge' });
    },
    cash() {
      this.$router.push({ name: 'cash' });
    },
    cashRecord() {
      this.$router.push({ name: 'cashRecord' });
    },
    refundLog() {
      this.$router.push({ name: 'refundLog' });
    },
    limitDate(n, u) {
      this.beginTime = moment().subtract(n, u);
      this.endTime = moment();
    },
    paging(pageNum) {
      this.pageNum = pageNum;
      this.fetchData();
    },
    search() {
      this.pageNum = 1;
      this.fetchData();
    },
    fetchData() {
      const params = {
        beginTime:
          (this.beginTime &&
            moment(
              this.$utils.time.startTime(this.beginTime, 'YYYY-MM-DD HH:mm:ss')
            ).format('x')) ||
          0,
        endTime:
          (this.endTime &&
            moment(
              this.$utils.time.endTime(this.endTime, 'YYYY-MM-DD HH:mm:ss')
            ).format('x')) ||
          moment().format('x'),
        pageNum: this.pageNum,
        pageSize: this.pageSize
      };
      this.$ajax.get('traderRecode/list', params).then(e => {
        if (e.status !== 200) {
          this.records_data = [];
          this.total = 0;
          return;
        }
        this.records_data = e.data.list;
        this.total = e.data.count;
      });
    }
  },
  mounted() {
    this.fetchData();
  },
  data() {
    return {
      id: '',
      beginTime: moment().subtract(1, 'weeks'),
      endTime: moment(),
      total: 0,
      pageNum: 1,
      pageSize: 10,
      options: {
        disabledDate: date => {
          return date && date.valueOf() < this.beginTime.valueOf() - 86400000;
        }
      },
      records_data: [],
      records_columns: [
        {
          width: 140,
          title: '时间',
          align: 'center',
          key: 'createTime',
          render: (h, params) => {
            return h(
              'span',
              `${moment(params.row.createTime).format('YYYY/M/DD HH:mm')}`
            );
          }
        },
        {
          width: 220,
          title: '流水号/订单号',
          align: 'center',
          key: 'orderId'
        },
        {
          title: '交易类型',
          key: 'type',
          width: 140,
          align: 'center',
          render: (h, params) => {
            return h('span', `${Constant.TRADE_TYPE[params.row.type]}`);
          }
        },
        {
          title: '交易金额',
          key: 'amount',
          align: 'center',
          render: (h, params) => {
            return h('span', `${params.row.amount}元`);
          }
        },
        {
          title: '交易渠道',
          key: 'channel',
          align: 'center',
          render: (h, params) => {
            if (params.row.status === 'WAIT_BUYER_PAY') {
              return h('span', '');
            }
            return h('span', channel[params.row.channel]);
          }
        },
        {
          title: '交易状态',
          key: 'status',
          align: 'center',
          render: (h, params) => {
            const obj = params.row;

            const that = this;
            function getRefund(route) {
              return h(
                'Button',
                {
                  props: { type: 'error', size: 'small' },
                  on: {
                    click: () => {
                      that.$router.push({
                        name: route,
                        query: {
                          orderType: '3',
                          id: obj.orderId,
                          type: obj.type
                        }
                      });
                    }
                  }
                },
                '详情'
              );
            }
            if (obj.status) {
              //审核中
              getRefund('check');
            } else if (obj.status) {
              //已退款
              getRefund('success');
            } else if (obj.status) {
              //已取消
              // getRefund('check');
            }
            if (
              params.row.status === 'WAIT_BUYER_PAY' &&
              params.row.type === 'HIRE_DEPOSIT'
            ) {
              return h(
                'Button',
                {
                  props: { type: 'error', size: 'small' },
                  on: {
                    click: () => {
                      this.$router.push({
                        name: 'payment',
                        query: {
                          hireId: params.row.hireId
                        }
                      });
                    }
                  }
                },
                '去支付'
              );
            } else if (
              params.row.status === 'WAIT_BUYER_PAY' &&
              params.row.type === 'DEMAND_DEPOSIT'
            ) {
              return h(
                'Button',
                {
                  props: { type: 'error', size: 'small' },
                  on: {
                    click: () => {
                      this.id = params.row.demandId;
                      this.$store.commit('SETTING_PAYMENT_VISIBLE', true);
                    }
                  }
                },
                '去支付'
              );
            } else if (
              params.row.status === 'WAIT_BUYER_PAY' &&
              params.row.type === 'DEPOSIT'
            ) {
              return h(
                'Button',
                {
                  props: { type: 'error', size: 'small' },
                  on: {
                    click: () => {
                      // this.$ajax.payMoney(params.row.orderId);
                      this.id = params.row.orderId;
                      this.$store.commit('SETTING_RECHARGE_VISIBLE', true);
                    }
                  }
                },
                '去充值'
              );
            } else if (
              params.row.status == 'TRADE_SUCCESS' &&
              params.row.type === 'DEPOSIT'
            ) {
              return h('span', '已充值');
            } else {
              return h('span', Constant.TRADE_STATUS[params.row.status]);
            }
          }
        },
        {
          title: '备注',
          key: 'comment',
          align: 'center'
        }
      ]
    };
  }
};
</script>
<style scoped>
.statistics-ul {
  display: inline-block;
}

.statistics-ul li {
  width: 212px;
  border-left: 1px solid #e5e5e5;
  padding: 10px 20px;
  display: inline-block;
}

.statistics-ul li:first-child {
  padding-left: 0;
  border-left: none;
}

.time-link-ul {
  display: inline-block;
}

.time-link-ul li {
  padding: 0 10px;
  border-right: 1px solid #e9eaec;
  display: inline-block;
}

.time-link-ul li:last-child {
  border-right: none;
}

.time-link-ul li a {
  color: #f54203;
}
.link {
  margin-left: 10px;
}
.link:hover {
  color: #f54203;
}
.color646464 {
  color: #646464;
}

.f54203 {
  color: #f54203;
}
</style>
