<template>
  <div style="padding: 36px 50px;height:593px; background-color: #fff;">
    <div class="breadcrumb color646464">
      <span>
        <a href="/emloyerBackstage/trading_record" class="font16 color646464">交易记录</a>
      </span>
      <span class="font16">>申请提现</span>
    </div>
    <h1 class="font16 borderline">申请提现 </h1>
    <Form style="margin-top: 70px;font-size: 14px;">
      <FormItem label="提现到：">
        <RadioGroup v-model="params.remittanceChannel" :vertical="true">
          <Radio label="ALI" class="font16 breadcrumb1">
            <img :src="'icon/tx-zfb.png' | randomPath" alt="支付宝支付" class="vertical-middle"> 支付宝钱包
          </Radio>
          <!-- <Radio label="WX" class="font16">
              <img :src="'icon/tx-wechat.png' | randomPath" alt="微信支付" class="vertical-middle"> 微信钱包
            </Radio> -->
        </RadioGroup>
      </FormItem>
    </Form>
    <div class=" submit selectSubmit">
      <Button type="error" @click="selectSubmit" size="large" style="width:125px;height:40px">确认</Button>
    </div>
    <Modal v-model="needmodal" class="wsl_model" width="940">
      <p slot="header" >
        <span v-if="this.params.remittanceChannel=='ALI'">提现到支付宝</span>
        <!--  <span v-else>提现到微信</span> -->
      </p>
      <Row>
        <Col span="6" class="pic">
        <img :src="'icon/tx-zfb-big.png' | randomPath" alt="支付宝支付" class="vertical-middle" v-if="this.params.remittanceChannel=='ALI'">
        <img :src="'icon/tx-wechat-big.png' | randomPath" alt="微信支付" class="vertical-middle" v-else>
        </Col>
        <Col span="17" class="con">
        <Form ref="formInline" :model="formValidate" :rules="ruleValidate" :label-width="110">
          <!-- <FormItem label="账户名称：" prop="name">
            {{userinfo.realname}}
          </FormItem>
          <FormItem label="支付宝账号：" prop="alipay">
            {{userinfo.alipay_account}}
          </FormItem> -->
          <FormItem label="本次提现金额：" prop="cashNum">
            <Row>
              <Col span="11">
              <InputNumber v-model="formValidate.cashNum" :max="userinfo.balance"  style="width:290px" number="true"></InputNumber>
              </Col>
              <Col span="10" offset="3">
              <p style="color:#bcbcbc">可提现金额
                <span style="color:#f54203">{{userinfo.balance}}</span>元&nbsp&nbsp
                <span @click="getallmoney" style="color:#f54203">提现全部</span>
              </p>
              <!-- <Button type="error" @click="getallmoney" style="text-align: center;">提现全部</Button> -->
              </Col>
            </Row>
          </FormItem>
          <FormItem label="交易密码：" prop="payPassword">
                       <Input v-model="formValidate.payPassword" placeholder="请输入交易密码" type="password" style="width:290px" :maxlength="6"></Input>
                    </FormItem>
                    <p style="color:#f54203">温馨提示：提现金额将于48小时提现到您指定账户，请注意查收！ </p>
          <!-- <FormItem label="图片验证码：" prop="imgcode" v-if="needVerifycode">
            <Row>
              <Col span="11">
              <Input v-model="formValidate.imgcode" placeholder="请输入验证码" type="text" style="width:290px" :maxlength="4"></Input>
              </Col>
              <Col span="10" offset="3">
              <img :src="verifycodeUrl" alt="" class="verifycode" @click="fetchCodeImg" style="height:32px">
              </Col>
            </Row>
          </FormItem>
          <FormItem label="手机号码：" prop="phone">
            <p>{{formValidate.phone}}
              <Button type="ghost" @click="sendCode" style="margin-left: 8px" v-if="codeIntervalTime === 60">发送验证码</Button>
              <Button type="ghost" @click="sendCode" style="margin-left: 8px" disabled v-else>{{codeIntervalTime}}s后再获取</Button>
            </p>
          </FormItem>
          <FormItem label="验证码：" prop="verifycode">
            <Input v-model="formValidate.verifycode" placeholder="请输入验证码" type="text" style="width:290px" :maxlength="6"></Input>
          </FormItem> -->
        </Form>
        </Col>
        <Col span="1">
        </Col>
      </Row>
      <Row>
        <Col class="submit">
        <!-- <p style="color:#f54203">温馨提示：提现金额将于48小时提现到您指定账户，请注意查收！
        </p> -->
        </Col>
      </Row>
      <div slot="footer" class=" submit cashSubmit">
        <Button type="error" size="large" style="width:125px;height:40px" @click="handleSubmit('formInline')">确认</Button>
      </div>
    </Modal>
    <Modal v-model="needbind" class="wsl_model" width="900" :styles="{top: '360px'}" >
       <div slot="header" style="font-size:18px;">支付宝提现</div>
        <Row  class="submit font18">
        <div style="width:100px;height:130px;line-height:170px;text-aligin:right;margin-right:15px;"><img :src="'icon2/payError.png' | randomPath" style="display:inline-block;"></div>
        <Col v-if="this.userinfo.alipay_account == null" style="height:130px;line-height:130px;color:#646464">您尚未绑定支付宝，请先绑定支付宝！</Col>
        <Col v-else-if="this.userinfo.pay_password == null" style="height:148px;line-height:130px;color:#646464">您尚未设置交易密码，需设置交易密码！</Col>
      </Row>
      <div slot="footer" class="submit" >
        <Button type="ghost" size="large" style="width:125px;height:40px;border:1px solid #f54203;color:#f54203;"  @click="needbind=false">取消</Button>
         <Button v-if="this.userinfo.alipay_account == null" type="error" size="large" style="width:125px;height:40px" @click="alipaybind">立即绑定</Button>
         <Button v-else-if="this.userinfo.pay_password == null" type="error" size="large" style="width:125px;height:40px;" @click="pay_password">立即设置</Button>
      </div>
    </Modal>
  </div>
</template>
<script>
import { mapState } from 'vuex';
export default {
  data() {
    const validatecash = (rule, value, callback) => {
      if (value < 0.1) {
        callback(new Error('请输入不小于0.1元的提现金额'));
      } else {
        callback();
      }
    };
    const validatecode = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入短信验证码'));
      } else if (value.length < 6) {
        callback(new Error('请输入六位短信验证码'));
      } else {
        callback();
      }
    };
    const validateimg = (rule, value, callback) => {
      if (!value) {
        callback(new Error('请输入图片验证码'));
      } else if (value.length < 4) {
        callback(new Error('请输入四位图片验证码'));
      } else {
        callback();
      }
    };
    return {
      codeIntervalTime: 60,
      verifycodeUrl: '',
      needVerifycode: false,
      params: {
        fee: '',
        payPassword: '',
        remittanceChannel: 'ALI'
      },
      needmodal: false,
      needbind: false,
      formValidate: {
        name: '',
        alipay: '',
        wechat: '',
        cashNum: 0,
        phone: '',
        verifycode: '',
        imgcode: ''
      },
      ruleValidate: {
        cashNum: [
          {
            validator: validatecash,
            required: true,
            trigger: 'blur'
          }
        ],
        verifycode: [
          {
            validator: validatecode,
            required: true,
            trigger: 'blur'
          }
        ],
        imgcode: [
          {
            validator: validateimg,
            trigger: 'blur'
          }
        ]
      }
    };
  },
  computed: {
    ...mapState({
      ftpPath: state => state.User.ftpPath,
      userinfo: state => state.User.info
    })
  },
  mounted() {
    this.getphone();
  },
  methods: {
    /** 判断是否需要去绑定支付宝 */
    selectSubmit() {
      if (!this.userinfo.alipay_account) {
        this.needbind = true;
      } else if (this.userinfo.pay_password == null) {
        this.needbind = true;
      } else {
        this.needmodal = true;
      }
    },
    /** 提现表单验证 */
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          this.params.fee = this.formValidate.cashNum;
          this.params.payPassword = this.formValidate.payPassword;
          this.$ajax.post('withdraw/add', { ...this.params }).then(e => {
            if (e.status === 200) {
              this.$Notice.success({
                title: '提现申请已提交',
                desc: '您的提现申请已提交成功，我们将立即为您处理！',
                duration: 2
              });
              this.$router.push({ name: 'cashRecord' });
            } else {
              this.$Notice.error({
                title: e.msg,
                duration: 1
              });
            }
          });
        } else {
        }
      });
    },
    /*** 全部提现 */
    getallmoney() {
      this.formValidate.cashNum = this.userinfo.balance;
    },
    /** 图片验证码 */
    fetchCodeImg() {
      this.verifycodeUrl = this.$ajax.getVerifyCode();
    },
    getphone() {
      this.formValidate.phone = this.userinfo.phone.replace(
        this.userinfo.phone.substr(3, 4),
        '****'
      );
    },
    alipaybind() {
      this.$router.push({ name: 'bindalipay', params: { id: 1 } });
    },
    pay_password() {
      this.$router.push({
        name: 'pwdservice'
      });
    },
    /** 获取短信验证码 */
    sendCode() {
      this.$ajax
        .post('auth/sendcode', {
          phone: this.userinfo.phone,
          verifycode: this.formValidate.imgcode
        })
        .then(e => {
          if (e.status !== 200) {
            this.needVerifycode = true;
            this.codeIntervalTime = 60;
            clearInterval(this.update);
            this.fetchCodeImg();
            this.$Message.error('请输入正确的验证码');
          } else {
            this.codeIntervalTime--; //60秒倒计时
            this.update = setInterval(() => {
              this.codeIntervalTime--;
            }, 1000);
            this.formValidate.verifycode = e.data;
          }
        });
    },
    cancelcash() {
      this.needmodal = false;
    }
  },
  watch: {
    codeIntervalTime(val) {
      if (!val) {
        this.codeIntervalTime = 60;
        clearInterval(this.update);
      }
    }
  }
};
</script>

<style scoped>
.breadcrumb {
  margin-bottom: 36px;
}

.breadcrumb1 {
  margin-bottom: 20px;
}

.color646464 {
  color: #646464;
}

.borderline {
  padding-bottom: 18px;
  border-bottom: 1px solid #e5e5e5;
}

.header {
  color: #fff;
  display: flex;
  align-items: center;
}
.vertical-center-modal {
  display: flex;
  align-items: center;
  justify-content: center;
}
.submit {
  text-align: center;
  display: flex;
  justify-content: center;
}
.wsl_model .ivu-modal-footer {
  border-top: 0px solid #e9eaec;
  padding: 12px 18px 12px 18px;
  text-align: right;
}
.cashSubmit {
  padding: 15px;
}

.selectSubmit {
  padding: 70px;
  border-bottom: 1px solid #e5e5e5;
}
/* .wsl_model .ivu-modal-header {
  background-color: #f54203;
  color: #fff;
  border-bottom: 1px solid #e9eaec;
  line-height: 1;
}

.ivu-modal-header {
  background-color: #f54203;
  color: #fff;
  border-bottom: 1px solid #e9eaec;
  
  line-height: 1;
} */
.ivu-modal-content .ivu-modal-header {
  background: #f54203;
}
.f54203 {
  color: #f54203;
}

.font25 {
  font-size: 25px;
}

.font16 {
  font-size: 16px;
}

.font14 {
  font-size: 14px;
}

.pic {
  display: flex;
  justify-content: center;
  margin-top: 50px;
}
.con {
  margin-top: 30px;
}
.vertical-middle {
  vertical-align: middle;
}

.font30 {
  font-size: 30px;
}

.vertical-bottom {
  vertical-align: text-bottom;
}
</style>


