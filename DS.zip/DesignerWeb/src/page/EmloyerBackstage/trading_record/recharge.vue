<template>
    <div style="padding: 36px 50px; background-color: #fff;">
        <div class="breadcrumb color646464">
            <span>
                <a href="/emloyerBackstage/trading_record" class="font14 color646464">交易记录</a>
            </span>
            <span class="font14">-></span>
            <span class="font14">账户充值</span>
        </div>
        <div class="font14 color646464" style="padding-bottom: 10px;border-bottom: 1px solid #e9eaec;margin-bottom: 25px;">交易记录</div>
        <Form :label-width="80" label-position="left">
            <Form-item label="充值金额：" style="margin-bottom: 4px;">
                <Input-number :max="99999" :min="0.01" v-model="totalFee" style="margin-right: 10px;width: 206px;"></Input-number>
                <span>元</span>
            </Form-item>
            <Form-item>
                <p class="font14" style="color: #888888;margin-bottom: 19px;">（充值成功后，充值金额会在1分钟内到帐；如果遇到任何问题，请联系平台客服）</p>
                <Button type="error" style="width: 100px;" @click="ok">确认金额</Button>
            </Form-item>
        </Form>
        <Modal v-model="modal" width="962" @on-cancel="cancelPay" style="background: #fff;">
            <div  style="margin-top: 6px;margin-left: 30px;background: #fff;">
                <div class="font20 color646464" style="margin-bottom: 11px;">订单提交成功，请您尽快付款！订单号：
                    <span class="font20" style="">{{orderId}}</span>
                </div>
                <div style="color: #888888;margin-bottom: 31px;background: #fff;">
                    <div class="font16" style="width: 710px;display: inline-block;">请在您提交订单后
                        <span class="font16 f54203">24小时内</span>完成支付，否则订单会自动取消</div>
                    <div class="font20" style="display: inline-block;">充值金额
                        <span class="font25 f54203">{{totalFee.toFixed(2)}}</span>元</div>
                </div>
            </div>
            <div style="padding: 20px 85px;height: 130px;">;
                <div>
                    <div>
                        <label>
                            <input type="radio" value="2" v-model="picked" v-if="picked != '2'" style="margin-right: 30px;margin-left: 11px;">
                            <img :src="'icon/passlog.png' | randomPath" v-if="picked == '2'" alt="支付宝支付" style="margin-right: 20px;">
                            <img :src="'icon/zfb.png' | randomPath" alt="支付宝支付" :class="{'vertical-middle':picked != '2'}">
                        </label>
                        <div class="font16" style="float: right;" v-if="picked == '2'">支付
                            <span class="font25 f54203">{{totalFee.toFixed(2)}}</span>元</div>
                    </div>
                </div>
                <div style="padding-left: 64px;margin-top: 17px;" v-if="picked == '2'">
                    <Button type="error" style="width: 156px;" @click="alipay">立即跳转支付</Button>
                </div>
            </div>
            <div style="padding: 20px 85px;height: 130px;">
                <div>
                    <div>
                        <label>
                            <p style="display: inline-block;width: 230px;">
                                <input type="radio" value="3" v-model="picked" v-if="picked != '3'" style="margin: 10px 11px 0 10px;float: left;">
                                <img :src="'icon/passlog.png' | randomPath" v-if="picked == '3'" alt="微信支付">
                                <img :src="'icon/wechat.png' | randomPath" alt="微信支付" style="margin-left: 23px;">
                                <span class="font30 color646464" style="float: right;margin-top: -6px;">微信支付</span>
                            </p>
                        </label>
                        <div class="font16" style="float: right;" v-if="picked == '3'">支付
                            <span class="font25 f54203">{{totalFee.toFixed(2)}}</span>元</div>
                    </div>
                </div>
                <div style="padding-left: 64px;margin-top: 17px;">
                    <Button type="error" style="width: 156px;" v-if="picked == '3'" @click="wxpay">立即跳转支付</Button>
                </div>
            </div>
            <div slot="footer" style="text-align: center;">
                <Button size="large" style="width: 134px;background-color: #888888;color: #fff" @click="cancelPay">取消</Button>
            </div>
        </Modal>
    </div>
</template>
<script>
import { mapState } from 'vuex';
export default {
  data() {
    return {
      totalFee: 1,
      modal: false,
      orderId: '',
      picked: '2'
    };
  },
  computed: {
    ...mapState({
      ftpPath: state => state.User.ftpPath
    })
  },
  methods: {
    ok() {
      if (this.totalFee) {
        this.$ajax
          .get('pay/account/create', {
            amount: this.totalFee
          })
          .then(e => {
            if (e.status === 200) {
              this.modal = true;
              this.orderId = e.data;
            }
          });
      }
    },
    alipay() {
      this.$ajax.payAli(this.orderId);
    },
    wxpay() {
      window.open(`/wechat/orderId?orderId=${this.orderId}&type=recharge`);
      this.$Modal.confirm({
        title: '微信支付',
        content: '微信支付已完成？',
        onOk: () => {
          this.$router.push('/emloyerBackstage/trading_record');
        }
      });
    },
    cancelPay() {
      this.$router.push('/emloyerBackstage/trading_record');
    }
  }
};
</script>

<style scoped>
.breadcrumb {
  margin-bottom: 36px;
}
.color646464 {
  color: #646464;
}

.f54203 {
  color: #f54203;
}

.font25 {
  font-size: 25px;
}

.vertical-middle {
  vertical-align: middle;
}

.font30 {
  font-size: 30px;
}

.vertical-bottom {
  vertical-align: text-bottom;
}
</style>


