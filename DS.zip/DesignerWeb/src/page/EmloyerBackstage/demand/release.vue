<template>
    <div>
        <div class="row">
            <img :src="'icon/steps.png!653x142' | randomPath">
        </div>
        <div class="row">
            <Button type="error" style="width: 100px;" @click="handlePublish(true)">保存至草稿箱</Button>
        </div>
        <div class="row">
            <Button type="error" style="width: 100px;" @click="handlePublish(false)">确认发布</Button>
        </div>
    </div>
</template>
<script>
import { mapState } from 'vuex';
export default {
  data() {
    return {};
  },
  methods: {
    handlePublish(flag) {
      let data = sessionStorage.getItem('new-demand');
      if (!data) return;
      data = JSON.parse(data);
      data.temp = flag;
      let referenceStore = [];
      data.referenceStore.forEach(item => {
        referenceStore.push(item.value);
      });
      data.referenceStore = referenceStore.join();
      this.$ajax.post('demand/add', data).then(e => {
        this.$store.commit('SETTING_DEMAND_VISIBLE', false);
        this.$Message.info(e.msg);
      });
    }
  },
  computed: {
    ...mapState({
      ftpPath: state => state.User.ftpPath
    })
  }
};
</script>
<style scoped>
.row {
  text-align: center;
  margin-top: 20px;
  margin-bottom: 20px;
}
</style>


