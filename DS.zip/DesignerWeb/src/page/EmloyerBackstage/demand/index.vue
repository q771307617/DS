<template>
    <div>
        <Row style="margin: 10px auto;">
            <Col span="16">
            <Steps :current="current">
                <Step title="选择需求"></Step>
                <Step title="填写需求内容"></Step>
                <Step title="发布"></Step>
            </Steps>
            </Col>
            <Col span="8">
            <Button type="text" size="large" @click="Return">返回</Button>
            </Col>
        </Row>
        <div style="padding: 10px;">
            <choice v-if="current === 0" v-on:Next="Next"></choice>
            <fill-in v-if="current === 1" :data="data" v-on:Next="Next"></fill-in>
            <release v-if="current === 2"></release>
        </div>
    </div>
</template>
<script>
import choice from './choice';
import fillIn from './fill-in';
import release from './release';
export default {
  components: { choice, fillIn, release },
  data() {
    return {
      current: 0,
      data: ''
    };
  },
  methods: {
    Return() {
      if (this.current) {
        --this.current;
        return;
      }
      this.$store.commit('SETTING_DEMAND_VISIBLE', false);
    },
    Next(data) {
      ++this.current;
      if (data) {
        this.data = data;
      }
    }
  }
};
</script>

<style>

</style>

