<template>
    <div>
        <Row :gutter="16">
            <Col span="8">选择平台</Col>
            <Col span="8">选择类目</Col>
            <Col span="8">选择设计类型（可多选）</Col>
        </Row>
        <Row :gutter="16">
            <Col span="8">
            <Select v-model="platform" @on-change="getCategoryList">
                <Option v-for="item in platformList" :value="item.id" :key="item">{{ item.name }}</Option>
            </Select>
            </Col>
            <Col span="8">
            <Select v-model="category">
                <Option v-for="item in categoryList" :value="item.id" :key="item">{{ item.name }}</Option>
            </Select>
            </Col>
            <Col span="8">
            <Select v-model="designType" multiple>
                <Option v-for="item in designTypeList" :value="item.id" :key="item">{{ item.name }}</Option>
            </Select>
            </Col>
        </Row>
        <Row>
            <Col span="24">
            <Button type="error" size="large" @click="Next">下一步</Button>
            </Col>
        </Row>
    </div>
</template>
<script>
const Tag = 'CHOISE_PAGE';

export default {
  data() {
    return {
      platform: '',
      category: '',
      designType: [],
      platformList: [],
      categoryList: [],
      designTypeList: []
    };
  },
  mounted() {
    this.getPlatfromList();
    this.getCategoryList();
    this.getDesignTypeList();
  },
  methods: {
    //获取平台列表
    getPlatfromList() {
      this.$ajax.get('class/child').then(e => {
        console.log(Tag, '平台', e);
        if (e.status == 200) {
          this.platformList = e.data;
          this.getCategoryList();
        }
      });
    },
    //获取类目列表
    getCategoryList() {
      this.$ajax.get('class/child', { pid: this.platform }).then(e => {
        console.log(Tag, '类目', e);
        if (e.status == 200) {
          this.categoryList = e.data;
        }
      });
    },
    //获取设计类型
    getDesignTypeList() {
      this.$ajax.get('demand/style/list').then(e => {
        console.log(Tag, '设计类型', e);
        if (e.status == 200) {
          this.designTypeList = e.data;

          // this.platformList = e.data;
        }
      });
    },
    Next() {
      if (this.platform && this.category && this.designType.length) {
        let data = {
          platform: this.platform,
          category: this.category,
          designType: this.designType,
          platformList: this.platformList,
          categoryList: this.categoryList,
          designTypeList: this.designTypeList
        };
        // this.$root.$emit("DEMAND_PUBLISH_FIRST",data);
        this.$emit('Next', data);
      }
    }
  }
};
</script>

<style scoped>
.ivu-row {
  margin-bottom: 10px;
  margin-top: 10px;
}
</style>

