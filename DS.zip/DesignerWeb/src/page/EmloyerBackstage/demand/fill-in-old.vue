<template>
    <div>
        <div class="row">
            <div class="row-title">您的选择</div>
            <Row>
                <Col span="24"> {{data.platform | toLabel1(platformList)}} 、{{data.category | toLabel1(categoryList)}} 、{{data.designType | toLabel1(designTypeList)}}
                </Col>
            </Row>
        </div>
        <div class="row">
            <div class="row-title">*简单描述您的需求</div>
            <Row>
                <Col span="24">
                <Input v-model="title" placeholder="请输入..."></Input>
                </Col>
            </Row>
        </div>
        <div class="row">
            <div class="row-title">*详细说明</div>
            <Row :gutter="16">
                <Col span="12">
                <Input v-model="details" type="textarea" :rows="4" placeholder="请输入..."></Input>
                </Col>
                <Col span="12">
                <h5>模板参考</h5>
                <p>1、设计风格尽量清新自然</p>
                <p>2、我们店铺的作品大部分是日韩风格</p>
                <p>3、希望设计师能够在2~3个工作日内完成工作</p>
                </Col>
            </Row>
        </div>
        <div class="row">
            <div class="row-title">期望的风格</div>
            <Radio-group v-model="styleId">
                <Row :gutter="16" v-for="item in styleLists" :key="item.id">
                    <Col span="6" >
                        <div>
                            <img :src="item.imageUrl+'!212x149'" width="100%" />
                        </div>
                        <div class="text-center">
                            <Radio label="2">
                                <span>{{item.name}}</span>
                            </Radio>
                        </div>
                    </Col>
                   
                </Row>
            </Radio-group>
        </div>
        <div class="row">
            <div class="row-title">参考店铺</div>
            <Row>
                <Col span="24">
                <Form ref="formDynamic" :model="formDynamic" :label-width="80">
                    <Form-item v-for="(item, index) in formDynamic.items" :key="item" :label="'参考' + (index + 1)" :prop="'items.' + index + '.value'">
                        <Row>
                            <Col span="18">
                            <Input type="text" v-model="item.value" placeholder="请输入..."></Input>
                            </Col>
                            <Col span="4" offset="1">
                            <Button type="ghost" @click="handleRemove(index)">删除</Button>
                            </Col>
                        </Row>
                    </Form-item>
                    <Form-item v-if="!(formDynamic.items.length == 3)">
                        <Row>
                            <Col span="12">
                            <Button type="dashed" long @click="handleAdd" icon="plus-round">点击添加参考店铺</Button>
                            </Col>
                        </Row>
                    </Form-item>
                </Form>
                </Col>
            </Row>
        </div>
        <div class="row">
            <div class="row-title">*您的预算</div>
            <Row>
                <Col span="24">
                <Input v-model="budget" placeholder="请输入..." style="width: 200px"></Input>&nbsp;元
                </Col>
            </Row>
        </div>
        <div style="text-align: center">
            <Button type="error" style="width: 50%;" @click="handleSubmit">提交需求</Button>
        </div>
    </div>
</template>
<script>
import types from '@/constant';

export default {
  props: ['data'],
  data() {
    return {
      styleLists: this.data.designTypeList,
      title: '',
      budget: '',
      details: '',
      styleId: '1',
      platformList: this.data.platformList,
      categoryList: this.data.categoryList,
      designTypeList: this.data.designTypeList,
      formDynamic: { items: [{ value: '' }] }
    };
  },
  mounted() {},
  methods: {
    Return() {},
    handleAdd() {
      this.formDynamic.items.push({
        value: ''
      });
    },
    handleRemove(index) {
      this.formDynamic.items.splice(index, 1);
    },
    handleSubmit() {
      //提交数据
      if (!this.title) {
        return;
      }
      if (!this.details) {
        return;
      }
      if (!this.budget) {
        return;
      }
      let data = {
        title: this.title,
        details: this.details,
        referenceStore: this.formDynamic.items,
        budget: this.budget,
        platform: this.data.platform,
        classId: this.data.category,
        designType: this.data.designType,
        styleId: this.styleId
      };

      sessionStorage.setItem('new-demand', JSON.stringify(data));
      this.$emit('Next');
    }
  }
};
</script>

<style scoped>
.row {
  margin-top: 20px;
  margin-bottom: 20px;
}

.row-title {
  font-size: 14px;
  font-weight: bold;
  color: #464c5b;
}

.text-center {
  text-align: center;
}

img {
  border-radius: 4px;
}
</style>

