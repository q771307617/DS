<template>
    <div>
        <Modal v-model="recharge_visible" class="wsl_model" @on-cancel="cancel">
            <p slot="header" >
                <span>充值</span>
            </p>
            <Row>
                <Col span="20" offset="4" style="margin-top:10px;">订单编号：{{data.orderId}}</Col>
            </Row>
            <Row>
               <Col span="20" offset="4" style="margin-top:10px;">充值金额：{{data.amount}}元</Col>
            </Row>          
            <Row>
                <Col span="5" offset="4" style="margin-top:10px;">充值方式：</Col>  
                <Col span="15" style="margin-top:10px;">
                    <Row>
                        <Radio-group v-model="vertical">
                            <Radio label="alipay" class="radio-style">
                                <span>支付宝支付</span>
                            </Radio>
                        </Radio-group>
                    </Row>
                    <Row>
                        <Radio-group v-model="vertical">
                            <Radio label="wechat" class="radio-style">
                                <span>微信支付</span>
                            </Radio>
                        </Radio-group>
                    </Row>
                </Col>
            </Row>
            <div slot="footer">
                <Button size="large" @click="cancel">取消</Button>
                <Button type="primary" style="background-color:#f54203;border-color:#f54203;" size="large" @click="ok">确认</Button>
            </div>
        </Modal>
    </div>
</template>
<script>
import { mapState } from 'vuex';
import router from '@/router';
export default {
  props: ['id'],
  data() {
    return {
      data: {},
      vertical: 'alipay',
      referralCode: ''
    };
  },
  computed: {
    ...mapState({
      recharge_visible: state => state.Modal.recharge_visible,
      info: state => state.User.info
    })
  },
  mounted() {
    this.payPassword = '';
  },
  methods: {
    ok() {
      if (this.vertical === 'alipay') {
        //支付宝支付
        if (!this.data.orderId) return;
        this.$ajax.payAli(this.data.orderId);
        this.$Modal.confirm({
          title: '支付宝支付',
          content: '支付宝支付已完成？',
          onOk: () => {
            this.cancel();
          }
        });
        return;
      }

      if (this.vertical === 'wechat') {
        // 微信支付
        if (!this.data.orderId) return;
        window.open(
          `/wechat/orderId?orderId=${this.data.orderId}&type=recharge`
        );
        this.$Modal.confirm({
          title: '微信支付',
          content: '微信支付已完成？',
          onOk: () => {
            this.cancel();
          }
        });
      }
    },
    cancel() {
      this.$store.commit('SETTING_RECHARGE_VISIBLE', false);
    },
    jumPage() {
      router.push({
        path: '/emloyerBackstage/demandManagent/index'
      });
    }
  },
  watch: {
    recharge_visible(val) {
      if (val && this.id) {
        this.$ajax
          .get('order/get', {
            id: this.id
          })
          .then(e => {
            this.data = e.data || {};
          });
      }
    }
  }
};
</script>
<style scoped>
.wsl_model .ivu-modal-header {
  padding: 9px 16px;
}
.ivu-row {
  margin-bottom: 10px;
}
</style>

