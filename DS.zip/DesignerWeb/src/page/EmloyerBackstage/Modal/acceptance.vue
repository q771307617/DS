<template>
    <div>
        <Modal v-model="acct_visible" style="font-size:14px;"   title="雇主需求验收" @on-ok="ok" @on-cancel="cancel" width=800>
            <p slot="header" >
                <span>雇主验收</span>
            </p>
            <Row :gutter="16">
                <Col span="24" style="line-height:30px;"><div class="wsl_title">需求名称：</div>{{data.title}}</Col>
            </Row>
            <Row :gutter="16">
                <Col span="12" style="line-height:30px;"><div class="wsl_title">预算金额：</div>{{data.budget}}元</Col>
            </Row>
            <Row :gutter="16">
                <Col span="12" style="line-height:30px;"><div class="wsl_title">设计师：</div>{{data.designer_realname}}</Col>
                <Col span="12" style="line-height:30px;"><div class="wsl_title">设计师电话：</div>{{data.designer_phone}}</Col>
            </Row>
            <Row :gutter="16">
                <Col span="12" style="line-height:30px;"><div class="wsl_title">计划完成时间：</div>{{data.plan_complete_date | format('YYYY-MM-DD')}}</Col>
                <Col span="12" style="line-height:30px;"><div class="wsl_title">实际交付时间：</div>{{data.publish_time | format('YYYY-MM-DD')}}</Col>
            </Row>
            <Row :gutter="16">
                <Col span="12"><div class="wsl_title">雇主验收结果：</div>
                <Select v-model="accept_status" style="width:200px">
                    <Option v-for="item in accept_status_list" :value="item.value" :key="item.value">{{ item.label }}</Option>
                </Select>
                </Col>
            </Row>
            <Row :gutter="16" style="width:600px;margin-left:45px;">
                <Col span="24">评语:
                <Input v-model="view" type="textarea" :rows="8" placeholder="请输入..."></Input>
                </Col>
            </Row>
            <div slot="footer">
                <Button size="large" @click="cancel">取消</Button>
                <Button type="primary" style="background-color:#f54203;border-color:#f54203;" size="large" @click="ok">确认</Button>
            </div>
        </Modal>
    </div>
</template>
<script>
import { mapState } from 'vuex';
import types from '@/constant';
export default {
  props: ['id'],
  data() {
    return {
      data: '',
      accept_status: '',
      view: '',
      accept_status_list: types.acceptStatus
    };
  },
  computed: mapState({
    acct_visible: state => state.Modal.acct_visible
  }),
  methods: {
    ok() {
      if (this.accept_status === '') {
        this.$Message.info('请选择验收结果');
        this.cancel();
        return;
      }

      this.$ajax
        .post('demand/accept', {
          id: this.id,
          accept: this.accept_status,
          view: this.view
        })
        .then(e => {
          this.$Message.info(e.msg);
          // 执行完成后
          this.cancel();
        });
    },
    cancel() {
      this.$store.commit('SETTING_ACCT_VISIBLE', false);
    }
  },
  watch: {
    acct_visible(val) {
      if (val && this.id) {
        this.$ajax.get('demand/get', { id: this.id }).then(e => {
          this.data = e.data;
        });
      }
    }
  }
};
</script>
<style scoped>
.wsl_model .ivu-modal-header {
  background-color: #f54203;
  padding: 9px 16px;
}
.ivu-modal-body {
  font-size: 14px;
}
.wsl_title {
  float: left;
  width: 150px;
  text-align: right;
  height: 30px;
  line-height: 30px;
}
</style>
<style scoped>
.ivu-row {
  margin-bottom: 10px;
}
</style>

