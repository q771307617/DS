<template>
    <div>
        <Modal v-model="payment_visible"  @on-cancel="cancel">
            <p slot="header" >
                <span>支付保证金</span>
            </p>
            <Row>
                <Col span="20" style="margin:23px 0 10px 47px;">需求名称：{{data.title}}</Col>
            </Row>
            <Row>
                <Col span="20" style="margin:0 0 10px 47px;">预算金额：{{data.budget}}元</Col>
            </Row>
            <!-- <Row>
                                    <Col span="20" style="margin:0 0 10px 57px;">
                                    <div class="font14 c888888">
                                        邀请码：
                                        <Input v-model="referralCode" placeholder="请输入..." style="width: 150px"></Input>
                                        <Alert type="error" style="display: inline-block;" v-if="msg">{{msg}}</Alert>
                                    </div>
                                    </Col>
                                </Row> -->
            <Row>
                <Col span="20" style="margin:0 0 10px 47px;">支付方式：
                <Radio-group v-model="vertical">
                    <Radio label="balance" class="radio-style">
                        <span>账户余额(目前账户余额有{{info.balance}}元)</span>
                    </Radio>
                </Radio-group>
                </Col>
            </Row>
            <Row v-if="!info.pay_password && vertical=='balance'" style="margin:0 0 10px 120px;">
                <Col span="20">
                <Button style="background-color:#f54203;border-color:#f54203;" type="primary" @click="gotoSetPwd">去设置支付密码</Button>
                </Col>
            </Row>
            <Row v-if="info.pay_password && vertical=='balance'" style="margin:0 0 10px 120px;">
                <Col span="20">
                <Input style="width:195px;height:33px;" type="password" v-model="payPassword" placeholder="请输入支付密码"></Input>
                </Col>
            </Row>
            <Row>
                <Col span="20" style="margin:0 0 10px 120px;">
                <Radio-group v-model="vertical">
                    <Radio label="alipay" class="radio-style">
                        <span>支付宝支付</span>
                    </Radio>
                </Radio-group>
                </Col>
            </Row>
             <Row>
                <Col span="20" style="margin:0 0 10px 120px;">
                <Radio-group v-model="vertical">
                    <Radio label="wechat" class="radio-style">
                        <span>微信支付</span>
                    </Radio>
                </Radio-group>
                </Col>
            </Row>
            <div slot="footer">
                <Button size="large" @click="cancel">取消</Button>
                <Button type="primary" style="background-color:#f54203;border-color:#f54203;" size="large" @click="ok">确认</Button>
            </div>
        </Modal>
    </div>
</template>
<script>
import { mapState, mapActions } from 'vuex';
import router from '@/router';
export default {
  props: ['id'],
  data() {
    return {
      data: {},
      payPassword: '',
      vertical: 'balance',
      referralCode: '',
      msg: ''
    };
  },
  computed: {
    ...mapState({
      payment_visible: state => state.Modal.payment_visible,
      info: state => state.User.info
    })
  },
  methods: {
    ...mapActions(['fetchUserData']),
    ok() {
      if (this.vertical === 'balance') {
        if (this.data.budget > this.info.balance) {
          this.$Notice.error({
            title: '余额不足，请充值'
          });
          return;
        }

        // 余额支付
        if (!this.payPassword) return;
        this.$ajax
          .get('pay/account', {
            id: this.data.order_id,
            password: this.payPassword
          })
          .then(e => {
            if (e.status === 200) {
              this.$Notice.success({
                title: '支付成功'
              });
              this.payPassword = '';
              this.jumPage();
              // 执行完成后
              this.cancel();
              return;
            }
            this.$Notice.error({
              title: '支付失败',
              desc: e.msg
            });
            this.payPassword = '';
            this.msg = e.msg;
          });
      }

      if (this.vertical === 'alipay') {
        // 支付宝支付
        if (!this.data.order_id) return;
        this.$ajax.payAli(this.data.order_id);
        this.$Modal.confirm({
          title: '支付宝支付',
          content: '支付宝支付已完成？',
          onOk: () => {
            this.cancel();
          }
        });
        return;
      }

      if (this.vertical === 'wechat') {
        // 微信支付
        if (!this.data.order_id) return;
        window.open(
          `/wechat/orderId?orderId=${this.data.order_id}&type=demand`
        );
        this.$Modal.confirm({
          title: '微信支付',
          content: '微信支付已完成？',
          onOk: () => {
            this.cancel();
          }
        });
      }
    },
    cancel() {
      this.$store.commit('SETTING_PAYMENT_VISIBLE', false);
    },
    jumPage() {
      router.push({
        path: '/emloyerBackstage/demandManagent/index'
      });
    },
    gotoSetPwd() {
      this.cancel();
      this.$emit('parentHandle', this.currentPage);
      router.push({ name: 'pwdservice' });
    }
  },
  mounted() {
    this.payPassword = '';
    this.fetchUserData();
  },
  watch: {
    payment_visible(val) {
      if (val && this.id) {
        this.$ajax
          .get('demand/get', {
            id: this.id
          })
          .then(e => {
            this.data = e.data || {};
            this.fetchUserData();
          });
      }
    }
  }
};
</script>
<style scoped>
.wsl_model .ivu-modal-header {
  background-color: #f54203;
  padding: 9px 16px;
}
</style>


<style scoped>
.ivu-row {
  margin-bottom: 10px;
}
</style>

