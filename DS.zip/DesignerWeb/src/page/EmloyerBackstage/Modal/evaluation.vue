<template>
    <div>
        <Modal v-model="eval_visible" title="评价" @on-ok="ok" @on-cancel="cancel" width=800>
            <Row :gutter="16">
                <Col span="12">需求名称：{{data.title}}</Col>
                <Col span="12">预算金额：{{data.budget}}元</Col>
            </Row>
            <Row :gutter="16">
                <Col span="12">设计师：{{data.realname}}</Col>
                <Col span="12">设计师电话：{{data.phone}}</Col>
            </Row>
            <Row :gutter="16">
                <Col span="12">计划完成时间：{{data.plan_complete_date | format('YYYY-MM-DD')}}</Col>
                <Col span="12">实际交付时间：{{data.publish_time | format('YYYY-MM-DD')}}</Col>
            </Row>
            <Row :gutter="16">
                <Col span="24">雇主验收结果：{{data.accept_status | toLabel(accept_status_list)}}</Col>
            </Row>
            <Row :gutter="16">
                <Col span="8">服务态度：
                <Rate v-model="value"></Rate>
                </Col>
                <Col span="8">设计能力：
                <Rate v-model="value"></Rate>
                </Col>
                <Col span="8">响应速度：
                <Rate v-model="value"></Rate>
                </Col>
            </Row>
            <Row :gutter="16">
                <Col span="24">评语：
                <Input v-model="view" type="textarea" :rows="4" placeholder="请输入..."></Input>
                </Col>
            </Row>
        </Modal>
    </div>
</template>
<script>
import { mapState } from 'vuex';
import moment from 'moment';
import types from '@/constant';

export default {
  props: ['id'],
  data() {
    return {
      data: '',
      view: '',
      value: 0,
      accept_status_list: types.acceptStatus
    };
  },
  computed: mapState({
    eval_visible: state => state.Modal.eval_visible
  }),
  methods: {
    ok() {
      this.cancel();
      // this.$ajax.post('demand/accept', { id: this.id, accept: this.accept_status, view: this.view }).then((e) => {
      //     this.$Message.info(e.msg);
      //     // 执行完成后
      //     this.cancel();
      // });
    },
    cancel() {
      this.$store.commit('SETTING_EVAL_VISIBLE', false);
    }
  },
  watch: {
    eval_visible(val) {
      if (val && this.id) {
        this.$ajax.get('demand/get', { id: this.id }).then(e => {
          this.data = e.data;
        });
      }
    }
  }
};
</script>

<style scoped>
.ivu-row {
  margin-bottom: 10px;
}
</style>

