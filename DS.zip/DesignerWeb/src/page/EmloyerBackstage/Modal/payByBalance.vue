<template>
    <div>
        <Modal v-model="payment_visible" title="请输入支付密码">
            <Row>
                <Col span="24">
                    <Input type="text" v-model="payPassword" placeholder="请输入支付密码"></Input>
                </Col>
            </Row>
        </Modal>
    </div>
</template>
<script>
import { mapState } from 'vuex';
import moment from 'moment';
import router from '@/router';
export default {
  props: ['id'],
  data() {
    return {
      data: '',
      payPassword: '',
      vertical: 'balance'
    };
  },
  computed: mapState({
    payment_visible: state => state.Modal.payment_visible,
    info: state => state.User.info
  }),
  mounted() {},
  methods: {
    ok() {
      if (this.vertical === 'balance') {
        // 余额支付
        this.$ajax
          .post('finance/demandPay/deposit', {
            demandId: this.id,
            payPassword: this.payPassword
          })
          .then(e => {
            if (e.status != 200) {
              this.$Notice.error({
                title: '支付失败',
                desc: e.msg
              });
            } else {
              this.$Notice.success({
                title: '支付成功'
              });

              // 执行完成后
              this.cancel();
            }
          });
      }
    },
    cancel() {
      this.$store.commit('SETTING_PAYMENT_VISIBLE', false);
    },
    gotoSetPwd() {
      router.push({
        path: '/emloyerBackstage/personalInfo/pwdservice'
      });
      this.cancel();
    }
  },
  watch: {
    payment_visible(val) {
      if (val && this.id) {
        this.$ajax.get('demand/get', { id: this.id }).then(e => {
          this.data = e.data;
        });
      }
    }
  }
};
</script>

<style scoped>
.ivu-row {
  margin-bottom: 10px;
}
</style>

