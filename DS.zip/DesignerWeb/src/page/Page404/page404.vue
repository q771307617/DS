<template>
  <div class="page404">
    <h1><span>404</span></h1>
    <div class="content">
      <div class="img">
        <img src="../../assets/images/404logo.png" alt="点将啦" />
      </div>
      <p>抱歉，您所访问的页面不存在！</p>
      <div class="btn-group">
        <Button class='backOne' type="primary" v-on:click="back('prev')">返回上一页</Button>
        <Button class="backIndex" type="default" v-on:click="back">返回首页</Button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'page404',
  methods: {
    back: function(v = '') {
      if (v == 'prev') {
        this.$router.go(-1);
        return;
      }
      window.location.href = '/';
    }
  }
};
</script>
<style scoped>
.page404 {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: #f5f5f5;
  font-family: '微软雅黑';
}
.page404 .content {
  position: absolute;
  top: -152px;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  height: 227px;
}
.page404 h1 {
  position: absolute;
  top: -50px;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  height: 468px;
  font-size: 468px;
  font-weight: bolder;
  color: #ededed;
  text-align: center;
  line-height: 1;
}
.page404 h1 span {
  display: inline-block;
  -webkit-transform-origin: center;
  -webkit-transform: scaleX(1.05);
  transform-origin: center;
  transform: scaleX(1.05);
}
.page404 .img {
  margin: auto;
  width: 117px;
}
.page404 .img img {
  display: block;
  max-width: 100%;
}
.page404 p {
  text-align: center;
  font-weight: 400;
  font-size: 40px;
  padding: 20px 0 25px;
}
.page404 .btn-group {
  text-align: center;
}
.page404 .btn-group button {
  font-weight: 400;
  font-size: 28px;
  width: 218px;
  padding: 2px 0 4px;
}
.backOne {
  margin-right: 40px;
  color: #fff;
  background: #ff7646;
  border-color: #ff7646;
}
.backIndex {
  color: #000;
  border-color: #000;
  background: transparent;
}
</style>
