<template>
<div style="width:1200px;margin:0 auto;">
  <step :step='step_status' /> 

    <div class="main font16 box-shadow">
      <p ><img :src="'../../assets/join/finish.png' | randomPath" alt="入驻成功"></p>
      <p>恭喜您，入驻成功，点将啦为您开启职业新篇章！
        <br />立即完善 <a href="/personalCenter/resume" class="active">个人简历</a> ，接单啦！
      </p>
    </div>   
  </div>
</template>

<style lang="scss" scoped>
.active {
  color: #f54203;
}
.main {
  height: 500px;
  background-color: #fff;
  margin: 20px auto;
  padding: 142px 300px;
  p {
    height: 50px;
    line-height: 25px;
    margin: 21px auto;
    text-align: center;
    margin-right: 30px;
    img {
      height: 50px;
      width: 50px;
      border-radius: 25px;
    }
  }
}
</style>


<script>
import step from '@/join/components/public/step';
export default {
  data() {
    return {
      designer: '',
      step_status: 14
    };
  },
  components: { step },
  mounted() {
    this.$ajax.get('registerdesigner/querycount').then(e => {
      if (e.status == 200) {
        this.designer = e.data.allCount;
      } else {
        this.$Message.error(e.msg);
      }
    });
    this.$ajax.get('registerdesigner/queryenteruserinfo').then(e => {
      if (e.status == 200) {
        this.step_status = e.data.status;
      } else {
        this.$Message.error(e.msg);
      }
    });
  }
  // methods(){

  // },
};
</script>