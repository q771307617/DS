<template>
  <div style="width:1200px;margin:0 auto;background:#f5f5f5">
    <step :step='step_status'  />  
    <div style="margin-top: 20px;">
        <div  style="height:354px;background: #fff; padding-top:114px;" class="box-shadow">
                <div style="width:70px;height:70px;display:inline-block;margin:0 20px 0 40px;">
                    <img :src="'../../assets/join/finish.png' | randomPath" style="max-width:70px;margin-bottom:-15px;" alt="">
                </div>
                <div style="margin-bottom:20px;background: #fff;display:inline-block;padding-bottom:50px;">
                    <div class="font20 color646464" style="margin-bottom: 11px;">
                        您的订单已提交成功，请尽快付款！
                        <p class="font16 " style="color:#888888;">订单号： <span class="font16" style="">{{orderId}}</span></p>                   
                    </div>
                    <!-- <div class="font14" style="width: 710px;display: inline-block;color:#bababa;">请在您提交订单后
                        <span class="font16 f54203">24小时内</span>完成支付，否则订单会自动取消
                    </div>                   -->
                </div>
                <div class="font16" style="border-top:1px dashed #ccc;height:60px;line-height:60px;text-align:right;padding:20px 60px 0px 0;" >应付金额：￥
                        <span class="font20 theme">{{payBail}}</span>元
                </div>
            </div>
            <div class="box-shadow" style="margin-top:14px;background:#fff;">
                <div style="padding: 34px 79px 34px 85px;height: 142px;background: #fff;border-top:1px dashed #e7e7e7;" >
                    <div style="float:left;">
                        <div style="display: inline-block;width: 240px;margin-top: 16px;">
                            <label>
                                <input type="radio" value="2" v-model="picked" v-if="picked != '2'" style="margin-right: 30px;margin-left: 11px;">
                                <img :src="'../../assets/join/checked.png' | randomPath" v-if="picked == '2'" alt="支付宝支付" style="margin-right: 20px;">
                                <img :src="'../../assets/join/zfb.png' | randomPath" alt="支付宝支付" :class="{'vertical-middle':picked != '2'}">
                            </label>
                            
                        </div>
                    </div>
                    <div  style="float:left;margin-top: 20px;" v-if="picked == '2'">
                        <Button type="error" style="width: 106px;float:left;" @click="alipay">立即支付</Button>
                        <div class="font16" style="float:right;margin:0px 0 0 527px;" v-if="picked == '2'">金额：￥
                                <span class="font20 theme">{{payBail}} </span>元
                        </div>
                    </div>
                </div>
                <div style="padding: 34px 79px 34px 85px;height: 142px;background: #fff;margin-bottom: 20px;border-top:1px dashed #e7e7e7;">
                    <div style="float:left;">
                        <div style="display: inline-block;width: 240px;margin-top: 16px;">
                            <label>
                                <p style="display: inline-block;">
                                    <input type="radio" value="3" v-model="picked" v-if="picked != '3'" style="margin-right: 30px;margin-left: 11px;" >
                                    <img :src="'../../assets/join/checked.png' | randomPath" v-if="picked == '3'" alt="微信支付" style="margin-right: 20px;"  />
                                    <img :src="'../../assets/join/wx.png' | randomPath" alt="微信支付" >
                                </p>
                            </label>                         
                        </div>
                    </div>
                    <div style="float:left;margin-top: 20px;">
                        <Button type="error" style="width: 106px;float:left;" v-if="picked == '3'" @click="wxpay">立即支付</Button>
                        <div class="font16" style="float:right;margin:0px 0 0 527px;  " v-if="picked == '3'">金额：￥
                                <span class="font20 theme">{{payBail}} </span>元
                        </div>
                    </div>
                </div>
            </div>
            
    </div>    
  </div>
</template>

<style lang="scss" scoped>
.theme {
  color: #f54203;
}
</style>
 
<script>
// /join/joinProcess/securityDeposit
import step from '@/join/components/public/step';
import { mapState } from 'vuex';
export default {
  components: { step },
  data() {
    return {
      step_status: '',
      totalFee: 1,
      modal: false,
      orderId: '',
      picked: '2',
      payBail: '',
      payParams: {
        toPay: false
      }
    };
  },
  computed: {
    ...mapState({
      ftpPath: state => state.User.ftpPath
    })
  },
  methods: {
    toPay() {
      this.payParams.toPay = true;
    },
    alipay() {
      this.$ajax.payAli(this.orderId);
    },
    wxpay() {
      window.open(`/wechat/orderId?orderId=${this.orderId}&type=BAIL`);
      this.$Modal.confirm({
        title: '微信支付',
        content: '微信支付已完成？',
        onOk: () => {
          this.$ajax
            .get('pay/wx/query', { out_trade_no: this.orderId })
            .then(e => {
              if (e.data === 'SUCCESS') {
                this.$router.push('/join/entryIntoSuccess');
              } else {
                this.$router.push('/join/securityDeposit');
                this.$Message.error(e.msg);
              }
            });
        }
      });
    },
    cancelPay() {
      this.$router.push('/join/securityDeposit');
    }
  },
  mounted() {
    this.$ajax.get('registerdesigner/queryenteruserinfo').then(e => {
      if (e.status == 200) {
        if (e.data.orderId == null) {
          this.$Message.error('订单号为空');
          this.step_status = 13;
          this.payBail = e.data.payBail;
        } else {
          this.orderId = e.data.orderId;
          this.payBail = e.data.payBail;
          this.step_status = e.data.status;
        }
        return;
      }
      this.$Message.error(e.msg);
    });
  }
};
</script>