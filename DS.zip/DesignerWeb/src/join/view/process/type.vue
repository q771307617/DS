<template>
  <div>
    <step :step='1'/>
    <p class="p font16">您选择的入驻类型：<span class="active">在家办公</span></p>
    <div class="settedIn">
      <a href="javascript:"><img src="http://3.img.dianjiangla.com/uploads/1499138106106_E9BE9AE9BE99E8BE89.jpg!288x339" alt="封面"></a>
      <div >
        <p><span>缴纳会员费</span><span>全职入驻</span></p>
        <p>设计师需要保证每天至少8小时的工时，较强的自制能力，平衡您的工作和生活。咨询客服，协助您完成入驻。</p>       
      </div>
    </div>
  </div>  
</template>

<script>
import step from '@/join/components/public/step';
export default {
  data() {
    return {};
  },
  components: { step }
};
</script>
<style scoped>
.active {
  color: #c20c0c;
}
.bz {
  height: 150px;
  background: #f2f2f2;
  margin: auto;
  border: 1px solid #000;
}
.bz li {
  text-align: center;
  padding: 30px;
}
.bz li .num {
  height: 50px;
  width: 50px;
  line-height: 50px;
  font-size: 30px;
  border: 1px solid #000;
  border-radius: 40px;
  margin: auto;
}
.bz li .num_bz {
  height: 30px;
  line-height: 30px;
  font-size: 16px;
  text-align: center;
}
.p {
  height: 20px;
  line-height: 20px;
  margin: 50px 0;
}
.settedIn div {
  display: inline-block;
  height: 340px;
  width: 850px;
  border: 1px solid #000;
  margin-left: 100px;
}
</style>
