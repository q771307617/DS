<template>
  <div class="working" >
    <step :step='step_status' />   
     <div v-if="this.$route.query.workPlace=='1'" class="box-shadow" style="margin:20px auto;height:777px;border:1px solid #FFF;background:#FFF;">
        <div  style="width:1130px;margin:20px auto; height:681px;">
          <img style="max-width:1130px; " :src="'../../assets/icon2/zckj.png' | randomPath" alt="众创空间">
          <p style="margin:20px 0;height:40px;"><input type="checkbox" v-model="checked" > 我已阅读并了解众创空间和相关规则  <br>
              <span  v-if="!this.checked" ><img style="margin-bottom:-5px;" :src="'../../assets/join/err.png' | randomPath" alt="">  </span>
              <span class="err" v-if="!this.checked" style="display:inline-block;margin-top:-5px;"> 请勾选  [ 我已阅读并了解众创空间和相关规则 ] </span>
          </p>

          <p style="padding:20px 0 80px 470px">
            <a href="/join/designerJoin" style="display:inline-block;width:90px;height:26px;line-height:26px;border:1px solid #f54203;text-align:center;border-radius:5px;color:#f54203;margin-right:30px;">上一步</a>
            <a @click="next(1)" style="display:inline-block;width:90px;height:26px;line-height:26px;border:1px solid #f54203;text-align:center;border-radius:5px;background:#f54203;color:#fff;">下一步</a>
          </p>
        </div>
    </div>
    <div v-else class="home box-shadow">
         <p class="p font16">您选择的入驻类型：<span class="active">在家办公</span></p>
        <div class="settedIn">
          <a class="img" href="javascript:"><img :src="'../../assets/join/at_home.jpg' | randomPath" alt="封面"></a>
          <div class="block box-shadow">
            <p><span>缴纳会员费</span><span>全职入驻</span></p>
            <p>设计师需要保证每天至少8小时的工时，较强的自制能力，平衡您的工作和生活。
              咨询客服，协助您完成入驻。
            </p>
            <a href="/join/designerJoin" style="display:inline-block;width:90px;height:26px;line-height:26px;border:1px solid #f54203;text-align:center;border-radius:5px;color:#f54203;margin-right:30px;">返回首页</a> 
            <p> 
                <a @click="next(0)"  style="color:#fff;">立即入驻</a>
            </p>
            <p>还有疑问, 请戳
              <a target="_blank" :href="`http://wpa.qq.com/msgrd?v=3&uin=${customServiceinfo.QQ}&site=qq&menu=yes`">
                <img style="margin-bottom:-3px;" :src="ftpPath+'icon/icon_qq2.png'"  alt="联系我" />
              </a>
            </p>
          </div>
        </div>
    </div>
  </div>  
</template>

<style lang="scss" scoped>
.active {
  color: #f54203;
}
.err {
  color: #f54102;
}
.working {
  width: 1200px;
  margin: 0 auto;
  .home {
    padding: 22px 65px 60px;
    background: #fff;
    margin-bottom: 20px;
    .p {
      height: 20px;
      line-height: 20px;
      margin: 22px 0 12px 0;
    }
    .settedIn {
      .img {
        float: left;
        margin-right: 5px;
        height: 284px;
        img {
          height: 284px;
        }
      }
      .block {
        display: inline-block;
        height: 284px;
        width: 770px;
        text-align: center;
        border: 1px solid #ccc;
        p {
          width: 505px;
          margin: 0 auto;
        }
        p:nth-of-type(1) {
          font-size: 18px;
          line-height: 36px;
          margin: 42px auto 20px;
          color: #646464;
        }
        p:nth-of-type(2) {
          font-size: 14px;
          line-height: 23px;
          color: #888888;
        }
        p:nth-of-type(3) {
          margin: 47px 0 14px;
          display: inline-block;
          width: 100px;
          height: 26px;
          line-height: 26px;
          border: 1px solid #f54203;
          text-align: center;
          border-radius: 5px;
          background: #f54203;
          color: #fff !important;
        }
        p:nth-of-type(4) {
          color: #f54203;
          img {
            display: inline-block;
          }
        }
      }
    }
  }
}
</style>



<script>
import step from '@/join/components/public/step';
import { mapState } from 'vuex';
export default {
  data() {
    return {
      checked: true,
      step_status: 0
    };
  },
  components: { step },
  computed: {
    ...mapState({
      // info: state => state.User.info,
      ftpPath: state => state.User.ftpPath,
      customServiceinfo: state => state.User.customServiceinfo
    })
  },
  mounted() {
    this.$ajax.get('registerdesigner/queryenteruserinfo').then(e => {
      if (e.status == 200) {
        this.step_status = e.data.status;
      } else {
        this.$Message.error(e.msg);
      }
    });
  },
  methods: {
    next(num) {
      if (num == 0) {
        this.$router.push({
          name: 'idCertification',
          query: { workPlace: this.$route.query.workPlace }
        });
      } else {
        if (this.checked) {
          this.$router.push({
            name: 'idCertification',
            query: { workPlace: this.$route.query.workPlace }
          });
        } else {
          this.$Message.error('请勾选相关规则');
        }
      }
    }
  }
};
</script>