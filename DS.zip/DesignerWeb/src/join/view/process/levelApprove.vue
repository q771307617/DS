<template>
    <div>
        <step :step="status"/>
        <div class="level-approve">
            <div class="section">
                <h1 class='title'>工作经验及作品</h1>
                <div class='form-group'>
                    <div class='form-item'>
                        <label class='label'>从业时间：</label>
                        <RadioGroup v-model="employTime" class="radio-group">
                            <Radio ref='radio' class="radio" v-for="(item, i) in employTimeData" :key="i" :label="item.label"><span>{{item.name}}</span></Radio>
                        </RadioGroup>
                        <span v-if="verifyType == 1" class="verify">请选择从业时间</span>
                    </div>
                    <div class='form-item'>
                        <label class='label'>擅长类目：</label>
                        <div class="form-checkbox">
                            <p class='amount'>（可选择1-3种）<span  v-if="verifyType == 2" class="verify">请选择擅长类目</span></p>
                            <CheckboxGroup v-model="adeptType">
                                <Checkbox ref='checkbox1' class='checkbox' v-for="(item, i) in adeptTypeData" :label="item.id" :key="i"><span>{{item.name}}</span></Checkbox>
                            </CheckboxGroup>
                        </div>
                    </div>
                    <div class='form-item'>
                        <label class='label'>设计风格：</label>
                        <div class="form-checkbox">
                            <p class='amount'>（可选择1-3种）<span  v-if="verifyType == 3" class="verify">请选择设计风格</span></p>
                            <CheckboxGroup v-model="designStyle">
                                <Checkbox ref='checkbox2' class='checkbox' v-for="(item, i) in designStyleData" :label="item.id" :key="i">
                                    <span>{{item.name}}</span>
                                    <p class='content ellipsis'>{{item.description}}</p>
                                </Checkbox>
                            </CheckboxGroup>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section">
                <h1 class="title">
                    上传作品
                    <span class="tip">（掌门将根据您上传的作品水平，制定专属培训计划）</span>
                    <span v-if="verifyType == 4" class="verify">请选择上传作品</span>
                </h1>
                <div class="product-list">
                    <!-- 添加 -->
                    <div class="product-item pro-default" v-on:click="updateProduct" v-if="productList.length < 3">
                        <div class="img">
                            <img src='../../../assets/images/designer_product_add.png' alt='作品封面' />
                        </div>
                        <p class='tip'>作品上传</p>
                        <p class='tip-txt'>支持jpg/gif/png格式RGB模式，不超过5M</p>
                    </div>
                    <!-- 修改 删除 -->
                    <div class="product-item" v-for="(p, i) in productList" :key="i">
                        <div class='product-img'>
                            <div class="img">
                                <img :src="p.image_url" alt='作品封面' />
                            </div>
                            <div class="img-bg">
                                <a class="delete" v-on:click="productBG = i">删除</a>
                            </div>
                        </div>
                        <div class="product-inform">
                            <h2 class='title'>{{p.name}}</h2>
                            <p class='label'>类目：{{p.class_id | formatTag(adeptTypeData)}}</p>
                            <a class='edit' v-on:click="updateProduct(p)">修改</a>
                        </div>
                        <div class="product-bg" v-show="i == productBG">
                            <div class="txt">
                                <p>确定删除</p>
                                <div class="btn-group">
                                    <a class="btn-confirm" v-on:click="deleteProduct(p.id);productBG = '-1'">确定</a>
                                    <a class="btn-cancle" v-on:click="productBG = '-1'">取消</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section special-btn">
                <div class="btn-group">
                    <Button class="btn-cancle" v-on:click="prevHandle">回到首页</Button>
                    <Button class="bnt-confirm" type="error" v-on:click="verify">提交审核</Button>
                </div>
            </div>

            <productUpload :data="productData" :modal="uploadShow" v-show="uploadShow" v-on:emitHandle="childProductMess" />

            <Modal class-name="level-approve-modal" width="680" v-model="modalHint" title=" " @on-ok="submit" :transfer="false" :mask-closable="false">
                <p>鉴定审核最长时间不超过1~3个工作日，审核期间您的作品</p>
                <p>无法修改，是否确认提交？</p>
            </Modal>
        </div>
    </div>
</template>

<script>
import step from '@/join/components/public/step';
import productUpload from '@/join/view/process/productUpload.vue';
import { mapState } from 'vuex';

export default {
  components: { productUpload, step },
  data() {
    return {
      productBG: '-1',
      verifyType: '0', //验证提示
      status: '', //状态

      modalHint: false, //提示弹窗
      uploadShow: false, //作品上传
      productData: {
        //作品数据
        //封面图
        //作品图
        proTitle: '', //作品标题
        adeptType: '', //行业类目
        designStyle: '', //设计风格
        proLabel: '', //作品标签
        proExplain: '' //作品说明
      },
      productList: [], //作品列表

      employTime: '', //从业时间
      employTimeData: [
        { label: '1', name: '1年以内' },
        { label: '2', name: '1-2年' },
        { label: '3', name: '2-3年' },
        { label: '4', name: '3-5年' },
        { label: '5', name: '5年以上' }
      ],
      adeptType: [], //擅长类目
      adeptTypeData: [
        // { label: '1', name: '机电机械'},
        // { label: '2', name: '数码电子'},
        // { label: '3', name: '家电办公'},
        // { label: '4', name: '五金配件'},
        // { label: '5', name: '化工原料'},
        // { label: '6', name: '家居卫浴'},
        // { label: '7', name: '家装建材'},
        // { label: '8', name: '户外运动'},
        // { label: '9', name: '情趣用品'},
        // { label: '10', name: '珠宝饰品'},
        // { label: '11', name: '美容化妆'},
        // { label: '12', name: '食品饮料'},
        // { label: '13', name: '图书音像'},
        // { label: '14', name: '宠物用品'},
        // { label: '15', name: '医药保健'},
        // { label: '16', name: '日用百货'},
        // { label: '17', name: '婚庆礼品'},
      ],
      designStyle: [], //设计风格
      designStyleData: [
        // { label: '1', name: '质感酷炫', content: '光效、纹理、渐变、色彩酷炫，光感强烈'},
        // { label: '2', name: '日韩小清', content: '颜色清晰淡雅，饱和度较低'},
        // { label: '3', name: '扁平化', content: '纯色块，无渐变'},
        // { label: '4', name: '中国风', content: '人物、花鸟、山水画，色调高雅，颜色淡雅清新'},
        // { label: '5', name: '古典欧美', content: '复古纹理，欧美特色服饰、人物、建筑等'},
        // { label: '6', name: '时尚简约', content: '画面、色彩简洁，颜色数量一般不超过3种'},
        // { label: '7', name: '卡通风', content: '萌萌哒、可爱、梦幻，以粉色系为主'},
        // { label: '8', name: '科技风', content: '色彩炫酷、二进制展示，以冷色调为主'}
      ]
    };
  },
  computed: {
    ...mapState({
      info: state => state.User.info,
      childList4: state => state.Lists.childList4,
      styles: state => state.Lists.styles
    })
  },
  filters: {
    formatTag(v, arr) {
      // return v.replace(/\,/g, "/");
      let n = '';
      arr.forEach(function(item) {
        if (item.id == v) {
          n = item.name;
        }
      });
      return n;
    }
  },
  methods: {
    ajaxUpdateState(flag) {
      //更新状态
      this.$ajax
        .post('/registerdesigner/updatedesignerstatus', { flag: flag })
        .then(e => {
          if (e.status == 200) {
            this.jumpPage('idCertification');
          } else {
            this.$Notice.error({ title: e.msg });
          }
        });
    },
    prevHandle() {
      //回到首页
      this.jumpPage('designerJoin');
    },
    verify() {
      //验证
      if (this.isNull(this.employTime)) {
        this.verifyType = 1;
        this.$refs.radio[0].$el.focus();
        return;
      }
      if (this.adeptType.length <= 0 || this.adeptType.length > 3) {
        //擅长类目
        this.verifyType = 2;
        this.$refs.checkbox1[0].$el.focus();
        return;
      }
      if (this.designStyle.length <= 0 || this.designStyle.length > 3) {
        //设计风格
        this.verifyType = 3;
        this.$refs.checkbox2[0].$el.focus();
        return;
      }
      if (this.productList.length <= 0) {
        this.verifyType = 4;
        return;
      }
      this.verifyType = '';

      this.modalHint = true;
    },
    submit() {
      //提交审核
      let params = {
        designStyle: this.designStyle.join(','),
        workYear: this.employTime,
        skillful: this.adeptType.join(','),
        skilful: this.adeptType.join(',')
        // userId: this.info.user_id
      };
      console.log(params);
      this.$ajax
        .post('/registerdesigner/updatedesignerinfo', params)
        .then(e => {
          if (e.status == 200) {
            this.jumpPage('levelApproveCheck');
          } else {
            this.$Notice.error({ title: e.msg });
          }
        });
    },
    productShow(v) {
      //显隐作品信息
      this.uploadShow = v;
    },
    childProductMess(o) {
      //接收子数据
      if (o.isFresh) {
        this.getInfo();
      }
      this.productShow(o.modal);
    },
    updateProduct(obj) {
      //更新作品信息
      if (obj) {
        this.productData = obj;
      } else {
        this.productData = [];
      }
      this.productShow(true);
    },
    deleteProduct(id) {
      //删除作品
      // this.productList.splice(index, 1);
      console.log(id);
      this.$ajax
        .post('/registerdesigner/deleteproduct', { id: id, status: 0 })
        .then(e => {
          if (e.status == 200) {
            this.getInfo();
          } else {
            this.$Notice.error({ title: e.msg });
          }
        });
    },

    getInfo() {
      //获取信息
      this.$ajax.get('/registerdesigner/queryenteruserinfo').then(e => {
        if (e.status == 200) {
          let data = e.data;
          if (data.style) {
            this.designStyle = data.style.split(',');
          }
          if (data.skilful) {
            this.adeptType = data.skilful.split(',');
          }
          if (data.workYear) {
            this.employTime = data.workYear;
          }

          //作品信息
          this.productList = data.products || [];
          //状态
          this.status = data.status;
        } else {
          this.$Notice.error({ title: e.msg });
        }
      });
    },

    jumpPage(name) {
      //路由跳转
      this.$router.push({
        name: name
      });
    },
    isNull(v) {
      if (v == '' || v == null || v == undefined) {
        return true;
      }
      return false;
    },
    lenAstrict(arr) {
      //长度限制
      let len = arr.length;
      if (len > 3) {
        return 3;
      }
      return len;
    }
  },
  mounted() {
    //请求 信息
    this.getInfo();
    this.childList4.forEach(function(item) {
      item.id = item.id.toString();
    });
    this.adeptTypeData = this.childList4;

    this.styles.forEach(function(item) {
      item.id = item.id.toString();
    });
    this.designStyleData = this.styles;
  },
  watch: {
    adeptType() {
      this.adeptType.length = this.lenAstrict(this.adeptType);
    },
    designStyle() {
      this.designStyle.length = this.lenAstrict(this.designStyle);
    },
    childList4() {
      this.childList4.forEach(function(item) {
        item.id = item.id.toString();
      });
      this.adeptTypeData = this.childList4;
    },
    styles() {
      this.styles.forEach(function(item) {
        item.id = item.id.toString();
      });
      this.designStyleData = this.styles;
    }
  }
};
</script>

<style>
.level-approve-modal .ivu-modal-close {
  top: 3px;
}
.level-approve-modal .ivu-modal-header {
  padding: 8px 16px;
  border: none;
}
.level-approve-modal .ivu-modal-body {
  padding: 15px 25px 20px;
  text-align: center;
  font-size: 20px;
  color: #646464;
}
.level-approve-modal .ivu-modal-footer {
  border: none;
  text-align: center;
  padding-bottom: 56px;
}
.level-approve-modal .ivu-modal-footer button {
  width: 116px;
  height: 28px;
  line-height: 28px;
  font-size: 14px;
  padding: 0;
  color: #f54102;
  border-color: #f54102;
  background-color: transparent;
}
.level-approve-modal .ivu-modal-footer .ivu-btn-primary {
  color: #fff;
  background-color: #f54102;
  margin-left: 25px;
}
</style>
<style lang="scss" scoped>
.level-approve {
  // 公共
  // 省略号
  .ellipsis {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  //验证
  .verify {
    font-size: 14px;
    color: #f54102;
    padding-left: 20px;
    background: url('../../../assets/images/icon_verify.png') no-repeat center
      left;
    background-size: 20px;
  }
  .section {
    width: 1200px;
    margin: auto;
    margin-bottom: 20px;
    padding: 0 70px;
    box-shadow: 0 4px 11px rgba(0, 0, 0, 0.3);
    background: #fff;

    &:first-child {
      margin-top: 15px;
    }

    & > .title {
      width: 100%;
      height: (27 + 21 + 11px);
      line-height: 27px;
      padding: 21px 0 11px;
      font-size: 18px;
      color: #f54102;
      border-bottom: 1px solid #d4d0c8;
    }
    // 单选/多选
    .form-group {
      .form-item {
        margin-top: 18px;

        &:after {
          content: '';
          display: table;
          clear: both;
        }
        &:last-child {
          padding-bottom: 18px;
        }

        .label {
          float: left;
          width: 87px;
          height: 28px;
          line-height: 28px;
          font-size: 16px;
          color: #646464;
        }
        .radio {
          width: 87px;
          height: 28px;
          line-height: 28px;
          font-size: 14px;
          color: #888888;
        }
        .checkbox {
          height: 28px;
          line-height: 28px;
          font-size: 14px;
          color: #888888;
          margin: 5px 40px 5px 0;
        }

        .form-checkbox {
          float: left;
          width: (1060 - 87px);

          .amount {
            font-size: 14px;
            color: #888888;
            height: 28px;
            line-height: 28px;
            border-bottom: 1px solid #d4d0c8;
          }
          .content {
            font-size: 12px;
            color: #bababa;
            width: 265px;
            height: 16px;
            line-height: 16px;
          }
        }
      }
    }
    // 上传作品
    .product-list {
      padding: 26px -0 28px;

      &:after {
        content: '';
        display: table;
        clear: both;
      }

      .product-item {
        width: 338px;
        height: 408px;
        float: left;
        margin-left: 20px;
        border: 1px solid #d4d0c8;
        position: relative;

        &:first-child {
          margin: 0;
        }

        &.pro-default {
          background: #f2f2f2;
          cursor: pointer;

          .img {
            margin-top: 165px;
            margin-bottom: 15px;

            img {
              display: block;
              max-width: 100%;
              margin: auto;
            }
          }
        }

        .tip {
          font-size: 14px;
          color: #646464;
          width: 151px;
          text-align: center;
          margin: auto;
        }
        .tip-txt {
          font-size: 12px;
          color: #888;
          width: 130px;
          text-align: center;
          margin: auto;
        }
        .product-img {
          position: relative;

          .img {
            width: 336px;
            height: 336px;
            overflow: hidden;
            display: block;
            position: relative;

            img {
              display: block;
              max-width: 100%;
              margin: auto;
              position: absolute;
              top: 50%;
              left: 50%;
              transform: translateX(-50%) translateY(-50%);
            }
          }
          .img-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;

            .delete {
              float: right;
              font-size: 14px;
              color: #646464;
              margin: 3px 4px 0 0;
              padding-left: 20px;
              background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAAQCAYAAAAbBi9cAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAEQSURBVHja7NI9SkNBFIbhJ/EGJSpCQEihgmInRHAJFi5EcgsLsbSwUyxtbAcX4ALERSi4B39QhBgkiDEQtZlivFyNhaVfM+edc+bMN4eptNttI3SPGhbRKyZDCCDDDpbxgCpmY80HltCMfIarGFfQxSDP8yZuM2yiVeLkDS94jLyCNUyW1F5nWMU4+riJ7ipxP8NlLG5hAhfR7TnW0QghdLPkdhhiEONTNDAT+SS6+nImhNAVZ5Iq5anCM+oYS7gGeZ7Xyxql6uO1MLNvVfVH+m80WlmB35N4rpBbKPDwp0apw11MJ7yH+YQr6ZqV3HqMZzyhg8OY6+AOB/FzbqTO0kZb2Mf2L8fSw1EIoQ+fAwDsWDhnxPKjtwAAAABJRU5ErkJggg==')
                no-repeat center left;
              background-size: 18px;
            }
          }
        }
        .product-inform {
          position: relative;

          .title {
            height: 23px;
            line-height: 23px;
            font-size: 16px;
            color: #646464;
            margin-top: 12px;
            padding-left: 9px;
          }
          .label {
            height: 18px;
            line-height: 18px;
            font-size: 14px;
            color: #888;
            padding-left: 9px;
          }
          .edit {
            position: absolute;
            top: 0;
            right: 4px;
            font-size: 14px;
            color: #f54102;
          }
        }
        .product-bg {
          position: absolute;
          top: 0;
          left: 0;
          background-color: rgba(0, 0, 0, 0.4);
          width: 100%;
          height: 100%;
          z-index: 999;
          .txt {
            margin-top: 135px;
            font-size: 12px;
            text-align: center;
            color: #fff;
            p {
              font-size: 16px;
            }
            .btn-group {
              width: 145px;
              margin: auto;
              margin-top: 20px;
              a {
                display: block;
                width: 66px;
                height: 20px;
                line-height: 20px;
                float: left;
              }
              .btn-confirm {
                background-color: #f54203;
                color: #fff;
                margin-right: 10px;
              }
              .btn-cancle {
                background-color: #fff;
                color: #000;
              }
            }
          }
        }
      }
    }
    &.special-btn {
      box-shadow: none;
      background-color: transparent;
    }
    .btn-group {
      text-align: center;
      padding: 10px 0;

      button {
        width: 116px;
        height: 28px;
        line-height: 28px;
        font-size: 14px;
        padding: 0;
        color: #f54102;
        border-color: #f54102;
        background-color: transparent;
      }
      .btn-cancle {
      }
      .bnt-confirm {
        color: #fff;
        background-color: #f54102;
        margin-left: 25px;
      }
    }
  }
}
</style>
