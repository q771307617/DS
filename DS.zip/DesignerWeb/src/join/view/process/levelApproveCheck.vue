<template>
    <div>
    <step :step="state"/>
    <div class="level-approve-check">
        <!-- 等待审核 -->
        <div v-if="state == 3 || state == 6" class="check-waiting">
            <div class="img">
                <img src="../../../assets/images/icon_check.png" alt="等待审核图标" />
            </div>
            <div class="mess">
                <h1>你的身份认证与作品已提交，请耐心等待平台审核</h1>
                <p>温馨提示：身份认证需要1个工作日，作品审核需要1-3个工作日</p>
                <p class='tip'>
                    若超时未收到审核结果，请戳这里联系我们
                    <a target="_blank" :href="'http://wpa.qq.com/msgrd?V=3&uin='+QQ+'&Site=QQ客服&Menu=yes'">qq交谈</a>
                </p>
            </div>
            <div class='btn-group'>
                <Button class="bnt-confirm" type="error" @click="modalWaive = true">放弃提交</Button>
            </div>
        </div>

        <!-- 众创空间的流程 -->
        <!-- 通过审核，线下面试 这个状态再改 -->
        <div v-if="state == 8 && info.workPlace == 1" class="level-check-pass">
            <h1>恭喜您！已通过平台审核，邀请您参与众创空间线下面试</h1>
            <div class="inform">
                <div class='cover-img'>
                    <img :src='info.photoImg' alt='设计师封面图' />
                </div>
                <div class='text'>
                    <p>真实姓名：<span>{{ info.realname }}</span></p>
                    <p>入驻类型：<span>{{ getName(info.workPlace) }}</span></p>
                    <p>身份证号：<span>{{ info.idCard }}</span></p>
                    <p>Q&nbsp;Q&nbsp;号码：<span>{{ info.qq }}</span></p>
                </div>
            </div>
            <div class='btn-group'>
                <Button class="btn-confirm" type="error" @click="ajaxUpdateState(1, 'add')">接受邀请</Button>
                <p>因个人原因无法线下面试，可<a @click="modalFace = true">取消面试邀请</a></p>
            </div>
        </div>
        <!-- 面试后，等待认证 -->
        <div v-if="state == 10" class="check-waiting">
            <div class="img">
                <img src="../../../assets/images/icon_check.png" alt="等待审核图标" />
            </div>
            <div class="mess">
                <h1>等级认证中，请耐心等待....</h1>
                <p>温馨提示：面试后1-2个工作日公布评定结果</p>
                <p class='tip'>
                    若超时未收到审核结果，请戳这里联系我们
                    <a target="_blank" :href="'http://wpa.qq.com/msgrd?V=3&uin='+QQ+'&Site=QQ客服&Menu=yes'">qq交谈</a>
                </p>
            </div>
        </div>
        <!-- 众创空间的流程 -->


        <!-- 通过审核 -->
        <div v-if="pageState == 0 &&((state == 8 && info.workPlace == 0) || (state == 12))" class="check-pass">
            <div class="img">
                <img src="../../../assets/images/icon_check.png" alt="通过审核图标" />
                <p>认证通过</p>
            </div>
            <div class="mess">
                <p>您的信息已通过审核，能力鉴定为<span class="level">{{ designerElect | getLevel(designerData)}}</span></p>
                <p class='txt'>您的薪资可设置区间<span class="money">{{ designerElect | getMoney(salary) }}</span>元/月 <span class="hint">如未达到您预期的评定结果，可重新上传作品</span></p>
            </div>
            <div class="btn-group">
                <Button class="btn-afresh" @click="modalAfresh = true">重新认证</Button>
                <Button class="bnt-confirm" type="error" @click="pageState = 1">确定入驻</Button>
            </div>
        </div>
        <!-- 未通过审核 未通过面试 -->
        <div v-if="state == 4 || state == 5 || state == 7 || state == 11" class="check-pass">
            <div class="img">
                <img src="../../../assets/images/icon_fail.png" alt="通过审核图标" />
                <p style="color: #f54102;">认证不通过</p>
            </div>
            <div class="mess">
                <p>很抱歉！您的等级认证不通过，请重新认证或联系平台客服</p>
            </div>
            <div class="btn-group">
                <Button class="btn-afresh" @click="modalAfreshNo = true">重新认证</Button>
                <Button class="bnt-confirm" type="error" @click="jumpPage('designerJoin')">返回首页大厅</Button>
            </div>
        </div>
        <!-- 等级信息 -->
        <div v-if="pageState == 1" class="level-inform">
            <ul class='nav'>
                <li v-for="(v, k) in designerData" :class="designerElect == k ? 'ac' : ''" :key="k" @click="tabHandle(k)"><a>{{v.level}}设计师</a></li>
            </ul>
            <div class='content'>
                <div v-for="(v, k) in designerData" :class="designerElect == k ? 'ac mess-item' : 'mess-item'" :key="k">
                    <h1 v-if="info.rank == k">您的能力间鉴定为<span>{{v.level}}</span></h1>
                    <h1 v-else>{{v.level}}设计师等级需求</h1>
                    <div class="text">
                        <img :src="'http://1.img.dianjiangla.com'+v.imgUrl" alt="文案" />
                    </div>
                </div>
            </div>
            <div class="btn-group">
                <Button class="btn-afresh" @click="modalAfresh = true">重新认证</Button>
                <Button class="bnt-confirm" type="error" @click="modalIn = true">确定入驻</Button>
            </div>
        </div>
        <!-- 等级认证通过 -->
        <div v-if="pageState == 2" class="level-check-pass">
            <h1>恭喜您！认证等级已通过，还差最后一步就可以加入点将啦！</h1>
            <div class="inform">
                <div class='cover-img'>
                    <img :src='info.photoImg' alt='设计师封面图' />
                </div>
                <div class='text'>
                    <p>真实姓名：<span>{{ info.realname }}</span></p>
                    <p>入驻类型：<span>{{ getName(info.workPlace) }}</span></p>
                    <p>等级认证：<span>{{ info.rank | getLevel(designerData)}}</span></p>
                    <p>保&nbsp;&nbsp;证&nbsp;&nbsp;金：<span>{{ info.payBail }} 元</span></p>
                </div>
            </div>
            <div class="btn-group">
                <Button class="btn-confirm" type="error" @click="payMoney">缴纳保证金</Button>
            </div>
        </div>


        <Modal class-name="level-approve-check" width="680" v-model="modalWaive" title=" " @on-ok="confirmWaive" :mask-closable="false">
            <p>您是否确定放弃本次个人信息审核？</p>
        </Modal>
        <Modal class-name="level-approve-check" width="680" v-model="modalIn" title=" " @on-ok="confirmIn" :mask-closable="false">
            <p>您是否确认以{{ info.rank | getLevel(designerData)}}设计师的身份入驻点将啦</p>
        </Modal>
        <Modal class-name="level-approve-check" width="680" v-model="modalAfresh" title=" " @on-ok="confirmAfresh" :mask-closable="false">
            <p>您是否确认继续重新认证等级？</p>
        </Modal>
        <!-- 未通过 -->
        <Modal class-name="level-approve-check" width="680" v-model="modalAfreshNo" title=" " @on-ok="jumpPage('designerJoin')" :mask-closable="false">
            <p>您是否确认继续重新认证等级？</p>
        </Modal>
        <Modal class-name="level-approve-check" width="680" v-model="modalFace" title=" " @on-ok="confirmFace" :mask-closable="false">
            <p>放弃面试您将重新选择入驻类型，是否继续？</p>
        </Modal>
    </div>
    </div>
</template>

<script>
import step from '@/join/components/public/step';
import { mapState } from 'vuex';

export default {
  components: { step },
  data() {
    return {
      info: {
        //用户信息
        rank: '0',
        workPlace: '1',
        idCard: '',
        qq: '',
        realname: '',
        photoImg: '',
        status: '',
        payBail: ''
      },
      salary: [], //薪资
      state: '', //审核状态
      pageState: 0, //当前页面状态切换
      modalWaive: false, //放弃
      modalIn: false, //入驻
      modalAfresh: false, //重新认证
      modalAfreshNo: false, //未通过 重新认证
      modalFace: false, //放弃面试
      designerElect: 0, //选中设计师等级 0 1 2 3 4
      designerData: [
        //设计师数据
        {
          level: '助理',
          imgUrl: '/assets/icon2/designer_rank_0.png'
        },
        {
          level: '初级',
          imgUrl: '/assets/icon2/designer_rank_1.png'
        },
        {
          level: '中级',
          imgUrl: '/assets/icon2/designer_rank_2.png'
        },
        {
          level: '高级',
          imgUrl: '/assets/icon2/designer_rank_3.png'
        },
        {
          level: '专家',
          imgUrl: '/assets/icon2/designer_rank_4.png'
        }
      ]
    };
  },
  computed: {
    ...mapState({
      QQ: state => state.User.customServiceinfo.QQ
    })
  },
  filters: {
    getJoinType(i) {
      if (i == 0) {
        return '在家';
      } else if (i == 1) {
        return '众创空间';
      }
    },
    getLevel(i, data) {
      return data[i].level;
    },
    getMoney(i, salary) {
      if (salary.length == 0) return '暂定';
      return salary[i].start + '~' + salary[i].end;
    }
  },
  methods: {
    getName(type) {
      return this.$utils.pub.getDesignerWorkPlaceName(type);
    },
    tabHandle(i) {
      //tab 切换
      this.designerElect = i;
    },

    confirmWaive() {
      //放弃提交
      //跳转
      this.ajaxUpdateState(0);
    },
    confirmIn() {
      //确定入驻
      this.pageState = 2;
    },
    confirmAfresh() {
      //重新认证
      //跳转
      this.ajaxUpdateState(0);
    },
    payMoney() {
      //缴纳保证金
      //跳转 页面
      this.$ajax.post('/order/createbail').then(e => {
        if (e.status == 200) {
          this.jumpPage('securityDeposit');
        } else {
          this.$Notice.error({ title: e.msg });
        }
      });
    },
    confirmFace() {
      //放弃面试
      //跳转 选择入驻类型
      this.ajaxUpdateState(0);
    },

    jumpPage(name) {
      //路由跳转
      this.$router.push({
        name: name
      });
    },
    ajaxUpdateState(flag, type) {
      //更新状态
      this.$ajax
        .post('/registerdesigner/updatedesignerstatus', { flag: flag })
        .then(e => {
          if (e.status == 200) {
            if (type == 'add') {
              this.getInfo();
              return;
            }
            this.jumpPage('designerJoin');
          } else {
            this.$Notice.error({ title: e.msg });
          }
        });
    },

    getInfo() {
      //获取信息
      this.$ajax.get('/registerdesigner/queryenteruserinfo').then(e => {
        if (e.status == 200) {
          let data = e.data;
          this.designerElect = data.rank || 0;
          this.info = data;
          this.state = data.status;
        } else {
          this.$Notice.error({ title: e.msg });
        }
      });
    },
    getTeamInfo() {
      this.$ajax.get('/common/config/get', { key: 'salary' }).then(e => {
        if (e.status == 200) {
          const data = JSON.parse(e.data) || [];
          this.salary = data;
        } else {
          this.$Notice.error({ title: e.msg });
        }
      });
    }
  },
  mounted() {
    //初始化数据
    this.getInfo();
    this.getTeamInfo();
  }
};
</script>

<style>
.level-approve-check {
  display: flex;
  align-items: center;
  justify-content: center;
}
.level-approve-check .ivu-modal {
  top: 0;
  margin: inherit;
}
.level-approve-check .ivu-modal-close {
  top: 3px;
}
.level-approve-check .ivu-modal-header {
  padding: 8px 16px;
  border: none;
}
.level-approve-check .ivu-modal-body {
  padding: 15px 25px 20px;
  text-align: center;
  font-size: 20px;
  color: #646464;
}
.level-approve-check .ivu-modal-footer {
  border: none;
  text-align: center;
  padding-bottom: 56px;
}
.level-approve-check .ivu-modal-footer button {
  width: 116px;
  height: 28px;
  line-height: 28px;
  font-size: 14px;
  padding: 0;
  color: #f54102;
  border-color: #f54102;
  background-color: transparent;
}
.level-approve-check .ivu-modal-footer .ivu-btn-primary {
  color: #fff;
  background-color: #f54102;
  margin-left: 25px;
}
</style>
<style lang="scss" scoped>
.level-approve-check .ivu-modal-footer {
}

.mess-item {
  display: none;
}
.ac {
  display: block;
}

.level-approve-check {
  width: 1200px;
  margin: 20px auto;
  box-shadow: 0 4px 11px rgba(0, 0, 0, 0.3);
  background: #fff;

  // 公共
  .img {
    img {
      display: block;
      max-width: 100%;
      margin: auto;
    }
  }
  .btn-group {
    text-align: center;

    button {
      width: 116px;
      height: 28px;
      line-height: 28px;
      font-size: 14px;
      padding: 0;
      color: #f54102;
      border-color: #f54102;
      background-color: transparent;
    }
  }
  // 等待审核
  .check-waiting {
    height: 538px;
    width: 100%;

    .img {
      margin-top: 100px;
      margin-bottom: 26px;
    }
    .mess {
      text-align: center;

      > h1 {
        font-size: 16px;
        color: #646464;
        margin-bottom: 12px;
        height: 23px;
        line-height: 23px;
      }
      > p {
        font-size: 14px;
        color: #bababa;
        margin-bottom: 8px;
        height: 22px;
        line-height: 22px;
      }
      .tip {
        font-size: 14px;
        color: #f54102;
        margin-bottom: 73px;

        a {
          display: inline-block;
          text-indent: 999999px;
          width: 20px;
          height: 20px;
          overflow: hidden;
          background: url('../../../assets/images/icon_qq.png') no-repeat center;
          background-size: 100%;
          margin-bottom: -4px;
        }
      }
    }
    .btn-group {
      .bnt-confirm {
      }
    }
  }

  // 通过审核
  .check-pass {
    height: 540px;
    width: 100%;
    text-align: center;

    .img {
      margin-top: 96px;
      margin-bottom: 36px;

      p {
        font-size: 18px;
        color: #76c61d;
        margin-top: 9px;
      }
    }
    .mess {
      margin-bottom: 82px;

      p {
        font-size: 16px;
        color: #646464;
      }
      .level {
        font-size: 24px;
        color: #f54102;
      }
      .money {
        color: #f54102;
      }
      .hint {
        color: #bababa;
      }
      .txt {
        font-size: 14px;
      }
    }
    .btn-group {
      .btn-afresh {
      }
      .bnt-confirm {
        color: #fff;
        background-color: #f54102;
        margin-left: 25px;
      }
    }
  }

  // 等级信息
  .level-inform {
    width: 100%;
    padding: 40px;

    .nav {
      float: left;
      width: 127px;
      height: 361px;

      li {
        &:first-child a {
          border: none;
        }
        a {
          display: block;
          width: 127px;
          height: 60px;
          line-height: 60px;
          text-align: center;
          font-size: 14px;
          color: #646464;
          border-top: 1px dashed #e6e6e6;
        }
        &.ac a {
          color: #fff;
          background: #f54102;
          border: 1px solid #f54102;
        }
      }
    }
    .content {
      float: left;
      width: 993px;
      height: 361px;
      background: #fafafa;

      .mess-item {
        > h1 {
          font-size: 18px;
          color: #646464;
          margin-left: 41px;
          margin-top: 28px;
          height: 36px;
          line-height: 36px;

          span {
            font-size: 24px;
            color: #f54102;
          }
        }
        p {
          font-size: 14px;
          color: #888;
          margin-left: 71px;
        }
        .tip {
          color: #f54102;
        }
        .text {
          padding: 26px 0 36px;

          p {
            margin-top: 5px;

            &:first-child {
              margin-top: 0;
            }
          }
          img {
            max-width: 100%;
          }
        }
      }
    }
    .btn-group {
      padding: 53px 0 8px;
      clear: both;

      .btn-afresh {
      }
      .bnt-confirm {
        color: #fff;
        background-color: #f54102;
        margin-left: 25px;
      }
    }
  }

  // 等级认证通过
  .level-check-pass {
    height: 545px;
    width: 100%;
    text-align: center;

    h1 {
      font-size: 22px;
      color: #646464;
      padding-left: 54px;
      background: url('../../../assets/images/icon_check_pass.png') no-repeat
        left center;
      margin: 99px 0 73px;
      display: inline-block;
    }
    .inform {
      &:after {
        content: '';
        display: table;
        clear: both;
      }

      .cover-img {
        float: left;
        width: 131px;
        height: 155px;
        background: #f2f2f2;
        margin-left: 363px;
        margin-right: 34px;
        overflow: hidden;
        position: relative;

        img {
          display: block;
          max-width: 100%;
          margin: auto;
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translateX(-50%) translateY(-50%);
        }
      }
      .text {
        float: left;
        text-align: left;

        p {
          font-size: 14px;
          color: #646464;
          height: 33px;
          line-height: 33px;
          margin-bottom: 6px;

          &:last-child {
            margin: 0;
          }

          span {
            color: #f54102;
            margin-left: 20px;
          }
        }
      }
    }
    .btn-group {
      margin-top: 87px;

      p {
        margin-top: 5px;
      }
      .btn-confirm {
      }
    }
  }
}
</style>
