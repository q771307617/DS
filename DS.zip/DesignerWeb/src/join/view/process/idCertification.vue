<template>
<div >
    <step :step="step"/>
    <div class="main" v-if="status">
        <div class="title"><p><span class="red">填写个人信息</span>点将啦运用先进的加密技术，保障您的个人信息安全</p></div>
      <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="106" :show-message="false" class="form">
        <FormItem  prop="realname" :show-message="false">
             <div class="label">真实姓名</div>
            <Input v-model="formValidate.realname" placeholder="请输入真实姓名" class="input-width" type="text" :maxlength="5" ></Input>
            <div class="error ivu-form-item-error-tip" v-if="error.realname">
              <span><img  :src="'join/err.png' | randomPath" ></span>{{error.realname}}
              </div>
        </FormItem>
        <FormItem  prop="gender" >
          <div class="label">性<span style="margin-left: 30px;"></span>别</div>
            <RadioGroup v-model="formValidate.gender" :show-message="false">
                <Radio label="0">男</Radio>
                <Radio style="margin-left: 30px;"label="1">女</Radio>
            </RadioGroup>
            <div class="error ivu-form-item-error-tip" v-if="error.gender" style="margin-left: 252px;">
              <span><img  :src="'join/err.png' | randomPath" ></span>{{error.gender}}
              </div>          
        </FormItem>
        <FormItem  prop="nickname">
          <div class="label">花<span style="margin-left: 30px;"></span>名</div>
            <Input v-model="formValidate.nickname" placeholder="花名" class="input-width" type="text" :maxlength="5"></Input>
           <div class="error ivu-form-item-error-tip" v-if="error.nickname">
              <span><img  :src="'join/err.png' | randomPath" ></span>{{error.nickname}}
              </div> 
               <div v-if="this.error.nicksuccess" class="error"><span><img  :src="'join/finish.png' | randomPath" ></span></div>
        </FormItem>
        <FormItem  prop="birthday">
          <div class="label" style="margin-right: 72px;">出生日期</div>
            <DatePicker type="date" v-model="formValidate.birthday" placeholder="选择出生日期" :options="optionsdata" format="yyyy/MM/dd" style="width: 216px"></DatePicker>
            <div class="error ivu-form-item-error-tip" v-if="error.birthday" style="margin-left: 143px;">
              <span><img  :src="'join/err.png' | randomPath" ></span>{{error.birthday}}
              </div> 
        </FormItem>
        <FormItem  prop="idCard">
          <div class="label" style="margin-right: 56px;">身份证号码</div>
            <Input v-model="formValidate.idCard" placeholder="请输入身份证" class="input-width" type="text" :maxlength="18"></Input>
            <div class="error ivu-form-item-error-tip" v-if="error.idCard">
              <span><img  :src="'join/err.png' | randomPath" ></span>{{error.idCard}}
              </div> 
              <div v-if="this.error.idCardsuccess" class="error "><span><img  :src="'join/finish.png' | randomPath" ></span></div>            
        </FormItem>
       <FormItem  prop="idCardImg" class="card-img">
            <Row>
              <Col span="4">
             <div class="label idcard" >上传身份照</div>
              </Col>
              <Col span="5" >
             <Upload :multiple="true"
              :on-error="handleError" 
              :show-upload-list="false" 
              :format="['jpg','jpeg','png']"
              action="/api/upload" 
              class="idcard" 
              :on-success="handleSuccess">
                  <Button type="error" class="button" >点击上传</Button>
                </Upload>
              </Col>
              <Col span="8" >
            <div style="height:200px;">
            <div style="width:310px;height:180px;overflow: hidden;" class="inline">
              <img :src="'join/IDcard.jpg' | randomPath" style="max-width: 100%;" alt=""  v-if="!formValidate.idCardImg"> 
              <img :src="formValidate.idCardImg" alt="" style="max-width: 100%;" v-else> 
             </div>
               <p class="error" v-if="error.idCardImg" style="margin-left: 0px;"><span><img  :src="'join/err.png' | randomPath" ></span>{{error.photoImg}}</p>
             </div>
              </Col>
              <Col span="5" >
            <div class="inline detail">
              <p>上传规范：</p>
               <p>1、彩色正面手持身份证照一张，JPG格式，大小不超过5M；</p>
              <p>2、五官可见</p>
               <p>3、证件信息完整清晰无遮挡</p>
            </div>
              </Col>
            </Row>                       
        </FormItem>
        <FormItem  prop="photoImg" class="photo-img">
          <Row>
              <Col span="4">
             <div class="label idcard" style="margin-right: 24px;">上传电子封面照</div>
              </Col>
              <Col span="5" >
             <Upload :multiple="true"
              :on-error="handleErrorPhoto" 
              :show-upload-list="false" 
              :format="['jpg','jpeg','png']"
              action="/api/upload" 
              class="idcard" 
              :on-success="handleSuccessPhoto">
                  <Button type="error" class="button" >点击上传</Button>
                </Upload>
              </Col>
              <Col span="5" >
              <div style="height:200px;">
            <div style="width:154px;height:180px;overflow: hidden;" class="inline">
              <img :src="'join/photoImg.jpg' | randomPath" alt="" style="max-width: 100%;" v-if="!formValidate.photoImg"> 
              <img :src="formValidate.photoImg" alt="" style="max-width: 100%;" v-else> 
             </div>
              <p class="error" v-if="error.photoImg" style="margin-left: 0px;"><span><img  :src="'join/err.png' | randomPath" ></span>{{error.photoImg}}</p>
             </div>
              </Col>
              <Col span="7" >
            <div class="inline detail">
              <p>1、照片清晰无码</p>
               <p>2、背景颜色统一，为能在页面中充分展现您的个人形象提高浏览量，建议上传以灰色调为背景的个人封面图</p>
              <p>3、杀马特一律不予通过</p>
            </div>
              </Col>
            </Row>                        
        </FormItem>
          <FormItem  prop="phone" class="phone">
            <div class="label" style="margin-right: 70px;">手机号码</div>
           <Input v-model="formValidate.phone" placeholder="请输入手机号" class="input-width" type="text" :maxlength="11"></Input>
              <div class="error ivu-form-item-error-tip" v-if="error.phone">
              <span><img  :src="'join/err.png' | randomPath" ></span>{{error.phone}}
              </div> 
              <div v-if="this.error.phonesuccess" class="error "><span><img  :src="'join/finish.png' | randomPath" ></span></div> 
          </FormItem>
           <FormItem  prop="imgcode" v-if="needVerifycode">
            <Row>
              <Col span="7">
              <Input v-model="formValidate.imgcode" placeholder="请输入验证码" type="text" style="width:164px;margin-left: 138px;" :maxlength="4"></Input>
              </Col>
              <Col span="14" >
              <img :src="verifycodeUrl" alt="" class="verifycode" @click="fetchCodeImg" style="height:32px;line-height: 32px;">
              </Col>
            </Row>
            <div class="error ivu-form-item-error-tip">{{error.imgcode}}</div>
          </FormItem>
          <FormItem  prop="code">
              <Input v-model="formValidate.code" placeholder="请输入验证码" type="text" style="width:164px;margin-left: 138px;" :maxlength="6"></Input>
              <Button type="error" @click="sendCode" style="margin-left: 16px" v-if="codeIntervalTime === 60" class="button">发送验证码</Button>
              <Button type="error" @click="sendCode" style="margin-left: 16px" disabled v-else class="button">{{codeIntervalTime}}s后再获取</Button>
            <div class="error ivu-form-item-error-tip" v-if="error.code">
              <span><img  :src="'join/err.png' | randomPath" ></span>{{error.code}}
              </div>
          </FormItem>
          <FormItem  prop="qq">
            <div class="label" style="margin-right: 77px;">QQ号码</div>
            <Input v-model="formValidate.qq" placeholder="请输入QQ号码" type="text" class="input-width" :maxlength="20"></Input>
             <div class="error ivu-form-item-error-tip" v-if="error.qq">
              <span><img  :src="'join/err.png' | randomPath" ></span>{{error.qq}}
              </div>
          </FormItem>
          <FormItem  prop="read">
            <Checkbox v-model="formValidate.read" class="read">我已打开QQ临时会话（雇主无需添加好友即可聊天），设置方法详见：<a @click="setqq" target="_Blank">戳这里</a></Checkbox>
             <div class="error ivu-form-item-error-tip" v-if="error.read" style="line-height: 14px;">
              <span><img  :src="'join/err.png' | randomPath" ></span>{{error.read}}
              </div>
          </FormItem>
           <div class="submit">
             <Button class="empty tong" @click="handleCannel" >返回上一步</Button>
             <Button  @click="handleSubmit('formValidate')" class="fill tong" >保存资料，下一步</Button>
        </div>
    </Form>
    </div>
    <div v-else class="success">
      <div class="content">
        <div class="left">
          <img :src="'../../assets/join/finish.png' | randomPath" alt="入驻成功">
        </div>
        <div class="right">
          <ul>
            <li><p>真实姓名：<span>{{formValidate.realname}}</span></p></li>
            <li><p>身份证号：<span>{{formValidate.idCard}}</span></p></li>
            <li><p>手机号码：<span>{{formValidate.phone}}</span></p></li>
            <li><p>QQ&nbsp号码：<span>{{formValidate.qq}}</span></p></li>
          </ul>
        </div>
      </div>
        <div class="footer">
           <Button class="empty tong" @click="successCannel" >返回上页修改</Button>
             <Button  @click="successSure" class="fill tong" >确认信息，下一步</Button>
          </div>      
    </div>
</div>
    
</template>
<script>
import step from '@/join/components/public/step';
export default {
  data() {
    const realname = (rule, value, callback) => {
      if (value == null) {
        this.error.realname = '请输入真实姓名';
        callback(new Error());
      } else if (!/^[\u4E00-\u9FA5A-Za-z]+$/.test(value)) {
        this.error.realname = '请输入真实姓名';
        callback(new Error());
      } else {
        this.error.realname = '';
        callback();
      }
    };
    const gender = (rule, value, callback) => {
      if (value === '') {
        this.error.gender = '请选择性别';
        callback(new Error());
      } else {
        this.error.gender = '';
        callback();
      }
    };
    const nickname = (rule, value, callback) => {
      if (value == null) {
        this.error.nickname = '请输入花名';
        this.error.nicksuccess = false;
        callback(new Error());
      } else if (value) {
        this.$ajax
          .post('registerdesigner/checknickname', { nickname: value })
          .then(e => {
            if (e.status == 200) {
              this.error.nicksuccess = true;
              this.error.nickname = false;
              callback();
            } else {
              this.error.nicksuccess = false;
              this.error.nickname = e.msg;
              callback(new Error());
            }
          });
      }
    };
    const birthday = (rule, value, callback) => {
      if (value == null) {
        this.error.birthday = '请输入出生日期';
        callback(new Error());
      } else {
        this.error.birthday = '';
        callback();
      }
    };
    const idCard = (rule, value, callback) => {
      if (
        !/^[1-9]\d{5}(((18|19|([2][0-1]))\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx])|(\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{2}))$/.test(
          value
        )
      ) {
        this.error.idCard = '请输入正确的身份证号码';
        this.error.idCardsuccess = false;
        callback(new Error());
      } else if (value) {
        this.$ajax
          .post('registerdesigner/checkidcard', { idCard: value })
          .then(e => {
            if (e.status == 200) {
              this.error.idCardsuccess = true;
              this.error.idCard = false;
              callback();
            } else {
              this.error.idCardsuccess = false;
              this.error.idCard = e.msg;
              callback(new Error());
            }
          });
      }
    };
    const idCardImg = (rule, value, callback) => {
      if (value === '') {
        this.error.idCardImg = '请上传身份证照';
        callback(new Error());
      } else {
        this.error.idCardImg = '';
        callback();
      }
    };
    const photoImg = (rule, value, callback) => {
      if (value === '') {
        this.error.photoImg = '请上传电子封面照';
        callback(new Error());
      } else {
        this.error.photoImg = '';
        callback();
      }
    };
    const phone = (rule, value, callback) => {
      if (!/^1[34578]\d{9}$/.test(value)) {
        this.error.phone = '请输入11位正确的手机号码';
        this.error.phonesuccess = false;
        callback(new Error());
      } else if (value) {
        this.$ajax
          .post('registerdesigner/checkphone', { phone: value })
          .then(e => {
            if (e.status == 200) {
              this.error.phonesuccess = true;
              this.error.phone = false;
              callback();
            } else {
              this.error.phonesuccess = false;
              this.error.phone = e.msg;
              callback(new Error());
            }
          });
      } else {
        this.error.phone = '';
        callback();
      }
    };
    const code = (rule, value, callback) => {
      if (value === '') {
        this.error.code = '请输入六位短信验证码';
        callback(new Error());
      } else if (!/^\d{6}$/.test(value)) {
        this.error.code = '请输入六位正确的短信验证码';
        callback(new Error());
      } else {
        this.error.code = '';
        callback();
      }
    };
    const qq = (rule, value, callback) => {
      if (!/^[0-9]*$/.test(value) || value === '') {
        this.error.qq = '请输入QQ号码';
        callback(new Error());
      } else {
        this.error.qq = '';
        callback();
      }
    };
    const read = (rule, value, callback) => {
      if (value == false) {
        this.error.read = '您还未勾选（我已打开QQ临时会话）';
        callback(new Error());
      } else {
        this.error.read = '';
        callback();
      }
    };
    return {
      step: 1,
      status: true,
      needVerifycode: false,
      verifycodeUrl: '',
      codeIntervalTime: 60,
      formValidate: {
        birthday: '', //出生日期
        gender: '', //性别
        idCard: '', //身份证号码
        idCardImg: '', //身份证照片地址
        photoImg: '', //多张照片地址，逗号隔开
        nickname: '', //昵称
        phone: '',
        code: '', //验证码
        qq: '',
        realname: '', //真实姓名
        // userId: "965",
        // workPlace: '',
        imgcode: '',
        workPlace: 0,
        read: true
      },
      error: {
        birthday: '', //出生日期
        gender: '', //性别
        idCard: '', //身份证号码
        idCardImg: '', //身份证照片地址
        photoImg: '', //多张照片地址，逗号隔开
        nickname: '', //昵称
        phone: '',
        code: '', //验证码
        qq: '',
        realname: '', //真实姓名
        userId: '',
        imgcode: '',
        read: '',
        nicksuccess: false, //时时验证花名
        idCardsuccess: false, //时时验证idcard
        phonesuccess: false //时时验证花名手机
      },
      ruleValidate: {
        birthday: [{ required: true, validator: birthday, trigger: 'blur' }],
        gender: [{ required: true, validator: gender, trigger: 'blur' }],
        idCard: [{ required: true, validator: idCard, trigger: 'blur' }],
        nickname: [{ required: true, validator: nickname, trigger: 'blur' }],
        phone: [{ required: true, validator: phone, trigger: 'blur' }],
        // photoImg: [{ required: true, validator: photoImg, trigger: 'blur' }],
        qq: [{ required: true, validator: qq, trigger: 'blur' }],
        realname: [{ required: true, validator: realname, trigger: 'blur' }],
        idCardImg: [{ required: true, validator: idCardImg, trigger: 'blur' }],
        photoImg: [{ required: true, validator: photoImg, trigger: 'blur' }],
        code: [{ validator: code, required: true, trigger: 'blur' }],
        read: [{ validator: read, required: true, trigger: 'blur' }]
      },
      optionsdata: {
        disabledDate(date) {
          return date && date.valueOf() > Date.now() - 86400000;
        }
      }
    };
  },
  components: { step },
  mounted() {
    this.fetchCodeImg();
    this.getdesigner();
  },
  methods: {
    handleSubmit(name) {
      this.formValidate.workPlace = this.$route.query.workPlace;
      this.$refs[name].validate(valid => {
        if (valid) {
          this.$ajax
            .post('registerdesigner/updateinfo', this.formValidate)
            .then(e => {
              if (e.status == 200) {
                this.status = false;
              } else {
                this.$Notice.error({
                  title: e.msg
                });
              }
            });
        } else {
        }
      });
    },
    handleReset(name) {
      this.$refs[name].resetFields();
    },
    handleCannel() {
      this.$router.push({
        name: 'working',
        query: { workPlace: this.$route.query.workPlace }
      });
    },
    /**上传图片 */
    /**上传身份照 */
    handleSuccess(res, file) {
      if (res.status == 200) {
        this.formValidate.idCardImg = res.data;
      } else {
        this.$Message.error(res.msg);
      }
    },
    handleError(res, file) {
      this.$Notice.error({
        title: '请上传5M以内正确格式身份证照'
      });
    },
    /**上传电子封面照 */
    handleSuccessPhoto(res, file) {
      if (res.status == 200) {
        this.formValidate.photoImg = res.data;
      } else {
        this.$Message.error(res.msg);
      }
    },
    handleErrorPhoto(res, file) {
      this.$Notice.error({
        title: '请上传5M以内正确格式电子封面照'
      });
    },
    /**获取设计师信息 */
    getdesigner() {
      this.$ajax.get('registerdesigner/queryenteruserinfo').then(e => {
        if (e.status == 200) {
          this.formValidate = e.data;
          this.step = e.data.status;
          this.formValidate.read = true;
        } else {
        }
      });
    },
    /** 图片验证码 */
    fetchCodeImg() {
      this.verifycodeUrl = this.$ajax.getVerifyCode();
    },
    /** 获取短信验证码 */
    sendCode() {
      if (this.formValidate.phone && this.error.phone == '') {
        this.$ajax
          .post('auth/sendcode', {
            phone: this.formValidate.phone,
            verifycode: this.formValidate.imgcode
          })
          .then(e => {
            if (e.status !== 200) {
              if (this.needVerifycode == true) {
                this.$Notice.error({
                  title: '请输入正确的验证码'
                });
              }
              this.needVerifycode = true;
              this.codeIntervalTime = 60;
              clearInterval(this.update);
              this.fetchCodeImg();
            } else {
              this.codeIntervalTime--; //60秒倒计时
              this.update = setInterval(() => {
                this.codeIntervalTime--;
              }, 1000);
              this.formValidate.code = e.data;
            }
          });
      }
    },
    /** success页面
     * 取消按钮
     * 确认按钮
     */
    successCannel() {
      this.status = true;
      this.fetchCodeImg();
      this.formValidate.code = '';
    },
    successSure() {
      this.$ajax
        .post('registerdesigner/updatedesignerstatus', { flag: 1 })
        .then(e => {
          if (e.status == 200) {
            this.$router.push({ name: 'levelApprove' });
          } else {
            this.$Message.error(e.msg);
          }
        });
    },
    setqq() {
      window.open(`/join/setqq`);
    }
  },
  watch: {
    codeIntervalTime(val) {
      if (!val) {
        this.codeIntervalTime = 60;
        clearInterval(this.update);
      }
    }
  }
};
</script>
<style scoped lang="scss">
.main {
  width: 1200px;
  // background-color: #ccc5c5;
  margin: 0 auto;
  overflow: hidden;
  _zoom: 1;
  .title {
    margin-top: 22px;
    font-size: 14px;
    color: #cccccc;
    line-height: 26px;
    .red {
      margin: 22px 27px 11px 26px;
      font-size: 18px;
      color: #f54102;
    }
  }
  .form {
    padding-top: 22px;
    margin: 0px 20px;
    border-top: 1px solid #ebebeb;
    .ivu-form-item {
      margin-bottom: 7px;
      vertical-align: top;
      zoom: 1;
    }
    .label {
      display: inline-block;
      line-height: 34px;
      font-size: 16px;
      color: #646464;
      margin-right: 74px;
    }
    .input-width {
      width: 300px;
    }
    .button {
      width: 114px;
      height: 34px;
    }
    .card-img {
      margin-top: 40px;
      border-top: 1px solid #ebebeb;
      padding-top: 26px;
      .idcard {
        line-height: 200px;
      }
    }
    .photo-img {
      padding-bottom: 40px;
      border-bottom: 1px solid #ebebeb;
      .idcard {
        line-height: 200px;
      }
      // .button{
      //   width: 114px;
      //   height:34px;
      // }
    }
    .detail {
      font-size: 12px;
      color: #bababa;
    }
    .phone {
      margin-top: 15px;
    }
    .submit {
      width: 304px;
      margin: 0 auto;
      margin-top: 61px;
      margin-bottom: 40px;
      .tong {
        height: 28px;
        width: 140px;
        border: 1px solid #f54102;
        border-radius: 5px;
        margin: 0 auto;
      }
      .empty {
        color: #f54102;
      }
      .fill {
        margin-left: 20px;
        background-color: #f54102;
        color: #fff;
      }
    }
    .read {
      color: #f54102;
      font-size: 14px;
      a {
        color: #f54102;
      }
    }
    .error {
      color: #f54102;
      display: inline-block;
      margin-left: 60px;
      line-height: 34px;
      top: auto;
      left: auto;
      span {
        line-height: 34px;
        img {
          height: 20px;
          width: 20px;
          margin-bottom: -5px;
        }
      }
    }
  }
}
.success {
  width: 1200px;
  height: 533px;
  background-color: #fff;
  margin: 0 auto;
  overflow: hidden;
  _zoom: 1;
  .content {
    width: 420px;
    margin: 0 auto;
    overflow: hidden;
    margin-top: 142px;
    .left {
      float: left;
      margin-top: 21px;
    }
    .right {
      margin-left: 136px;
      font-size: 14px;
      p {
        margin-bottom: 19px;
        span {
          color: #f54102;
          margin-left: 10px;
        }
      }
    }
  }
  .footer {
    width: 304px;
    margin: 0 auto;
    margin-top: 75px;
    margin-bottom: 40px;
    .tong {
      height: 28px;
      width: 140px;
      border: 1px solid #f54102;
      border-radius: 5px;
      margin: 0 auto;
    }
    .empty {
      color: #f54102;
    }
    .fill {
      margin-left: 20px;
      background-color: #f54102;
      color: #fff;
    }
  }
}
</style>
