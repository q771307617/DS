<template>
  <div class="main">
    <a href="http://shang.qq.com/v3/widget.html" target="_Blank">
      <img :src="'join/SETQQ.jpg' | randomPath" alt=""></a>
  </div>  
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>
<style scoped>
.main {
  width: 1200px;
  margin: 0 auto;
  background-color: #ffffff;
}
</style>
