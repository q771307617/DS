<template>
  <div class="content">
    <div class="banner">
      <div class="img">
        <img src="http://3.img.dianjiangla.com/uploads/d7d5213be2d5cb4af06adbb4a36d4d4e457967.jpg!1920">
      </div>
      <div class="txt">
        <span v-if="designerNumCount.allCount > 0">目前入驻{{designerNumCount.allCount}}位设计师</span>
        <span v-if="designerNumCount.newCount > 0"> 昨日新增{{designerNumCount.newCount}}位设计师入驻</span>
      </div>
    </div>

    <div class="explain">
      <img :src="ftpPath+'join/explain.png'">
    </div>

    <div class="by">
      <img :src="ftpPath+'join/by.png'" alt="改变您的工作方式  从点将啦开始！">
    </div>

    <!--设计师入驻-->
    <div class="join-index-title">
      <div class="left"><p>设计师入驻</p></div>
    </div>

    <div class="join-cart">
      <a @click="jumJion(0)" class="left">
        <p class="title">在家办公</p>
        <p class="txt">基于互联网+的新型用人模式，设计师 在家即可使用点将啦平台接单，实现全职在线</p>
        <p class="yq">入驻要求：热爱设计，缴纳点将啦创客会员费</p>
        <div class="pic">
          <img :src="ftpPath+'/join/join-home.jpg'" alt="在家办公">
        </div>
        <div class="join-btn">申请入驻</div>
      </a>

      <a @click="jumJion(1)" class="left right">
        <p class="title">加入众创空间</p>
        <p class="txt">由众创空间提供办公场地、设备，可通过门派的师徒体系得到快速成长</p>
        <p class="yq">入驻要求：热爱设计，能够到门派所在地办公。</p>
        <div class="pic">
          <img :src="ftpPath+'/join/join-work.jpg'" alt="加入众创空间">
        </div>
        <div class="join-btn">申请入驻</div>
        <!--<router-link class="join-btn" to=""></router-link>-->
      </a>
    </div>
    <!--入驻指南-->
    <div style="display: none;" class="join-index-title">
      <div class="left"><p>入驻指南</p></div>
      <div class="right"><a href="">查看更多 ></a></div>
    </div>

    <div style="display: none;" class="jion-manual">
      <div class="j-content">
        <div class="list">
          <div class="item" v-for="item in copyWriterList" :key="item.id">
            <div class="title">{{item.title}}</div>
            <div class="round"></div>
            <div class="item-list">
              <ul>
                <li v-for="write in item.list" :key="write.id">
                  <a v-if="write.type == '1'" href="javascript:;">{{write.title}}</a>
                  <a v-else target="_blank" href="#">{{write.title}}</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="hr"></div>
      </div>
    </div>

    <div class="excellent-designer">
      <div class="title">优秀设计师展示墙</div>
      <ul>
        <li v-for="item in designerBest" :key="item.userId">
          <a target="_blank" :href="'/designers/'+item.userId">
            <div class="designer">
              <div class="pic"><img :src="item.imageUrl+'!288x339'"></div>
              <div class="info">
                <div class="name">
                  <div class="txt">{{item | getName}}</div>
                  <div class="user-icon">
                    <img :src="ftpPath+'/icon/security.png'" alt="保障">
                    <img :src="ftpPath+'/icon/certification.png'" alt="平台认证">
                    <img :src="ftpPath+'/icon/'+item.rank+'.png'">
                  </div>
                </div>
                <p class="bt">设计宣言:</p>
                <p class="designer-explain">{{item.description}}</p>
              </div>
            </div>
            <p class="speciality">擅长类目：{{item.skilful | SKILLFULL_LIST_TEXT(childList4, ' | ')}}</p>
          </a>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex';

export default {
  data() {
    return {
      copyWriterList: [] /** 入驻指南 */,
      designerBest: [] /** 优秀设计师 */,
      enterInfo: [] /** 设计师入驻信息 */,
      /** 设计师数量统计 */
      designerNumCount: {
        allCount: 0 /** 全部设计师数量 */,
        newCount: 0 /** 新入驻设计师数量 */
      },
      status: {
        joinType: 0
      }
    };
  },
  computed: {
    ...mapState({
      childList4: state => state.Lists.childList4, //子分类
      ftpPath: state => state.User.ftpPath,
      info: state => state.User.info
    })
  },
  mounted() {
    this.getCopyWriter(); // 获取入驻指南
    this.getDesignerBest(); // 获取优秀设计师
    this.getDesignerNumCount(); // 获取设计师数量统计
  },
  methods: {
    /** 获取入驻指南 */
    getCopyWriter() {
      this.$ajax.get('/copywriter/getallcw', { num: 4 }).then(e => {
        if (e.status != 200) {
          this.copyWriterList = [];
          return;
        }
        this.copyWriterList = e.data;
      });
    },
    /** 获取优秀设计师 */
    getDesignerBest() {
      this.$ajax.get('/registerdesigner/getbestresigners').then(e => {
        if (e.status != 200) {
          this.designerBest = [];
          return;
        }
        this.designerBest = e.data;
      });
    },
    /** 获取设计师数量统计 */
    getDesignerNumCount() {
      this.$ajax.get('/registerdesigner/querycount').then(e => {
        if (e.status != 200) {
          this.designerNumCount.allCount = 0;
          this.designerNumCount.newCount = 0;
          return;
        }
        let { allCount, newCount } = e.data;
        this.designerNumCount.allCount = allCount || 0;
        this.designerNumCount.newCount = newCount || 0;
      });
    },
    /** 登录后跳转到入驻页面 */
    jumJion(type) {
      if (this.info.id <= 0 || this.info.id == undefined) {
        location.href =
          '/common/userjump?url=/join/designerJoin&nourl=/user/login&&redirect=/join/designerJoin';
        return;
      }
      this.status.joinType = type;
      /** 按钮点击的入驻类型 */
      this.getEnterInfo();
      /** 获取设计师入驻信息 */
    },
    /**
       *
       * 根据当前流程进度，当前流程类型，点击按钮类型
       * 判断是同类型流程，还是不同类型流程
       *
       */
    determine(status, type) {
      if (this.status.joinType == type) {
        this.equal_determine(status, type);
      } else {
        this.inequality_determine(status);
      }
    },
    /**
       * 根据是否可以修改，提示对应内容。
       */
    alertMessage(result) {
      let message = this.status.joinType == '1' ? '在家办公' : '加入众创空间';
      if (result) {
        //提示是否更换入驻方式
        this.$Modal.confirm({
          title: '申请入驻',
          content: '<p>您已申请' + message + '，是否更换入驻方式？</p>',
          onOk: () => {
            this.postDesignerUpdatestatus();
          },
          onCancel: () => {
            this.$Modal.remove();
          }
        });
      } else {
        //提示不能修改入驻方式
        this.$Modal.error({
          title: '申请入驻',
          content: '您已申请' + message + '，不能更改入驻方式。'
        });
      }
    },
    /** 将当前入驻流程重置到 放弃状态 */
    postDesignerUpdatestatus() {
      this.$ajax
        .post('registerdesigner/updatedesignerstatus', { flag: 2 })
        .then(e => {
          if (e.status != 200) {
            this.$Notice.error({
              title: '申请入驻',
              desc: e.msg
            });
            return;
          }
          this.$router.push({
            name: 'working',
            query: { workPlace: this.status.joinType }
          });
        });
    },
    /**
       *
       * 根据入驻状态跳转页面 同种流程
       *
       * 入驻状态：
       *  0默认状态；
       *  1待入驻；
       *  2个人资料提交完毕；
       *  3作品提交完毕，认证中；
       *  4放弃提交；
       *  5个人信息审核失败；
       *  6个人信息认证成功等级认证中；
       *  7等级认证失败；
       *  8等级认证完毕（面试邀请）；
       *  9认证成功后重新认证（重新上传，放弃面试）；
       *  10接受面试；
       *  11面试失败；
       *  12面试成功；
       *  13:缴纳保证金中；
       *  14缴纳保证金成功，入驻成功
       */
    equal_determine(status, type) {
      switch (status) {
        case 0:
          this.$Notice.error({ title: '设计师入驻', desc: '账号入驻状态异常，请联系管理员！' });
          break;
        case 1:
        case 4:
        case 5:
        case 7:
        case 9:
        case 11:
          this.$router.push({ name: 'working', query: { workPlace: type } });
          break;
        case 2:
          this.$router.push({ name: 'levelApprove' });
          break;
        case 3:
        case 6:
        case 8:
        case 10:
        case 12:
          this.$router.push({ name: 'levelApproveCheck' });
          break;
        case 13:
          this.$router.push({ name: 'securityDeposit' });
          break;
        case 14:
          this.$router.push({ name: 'entryIntoSuccess' });
          break;
        default:
          this.$router.push({ name: 'working', query: { workPlace: type } });
      }
    },
    /**
       *
       * 根据入驻状态判断是否可重新选择入驻类型 不同种流程
       *
       * 入驻状态：
       *  0默认状态；
       *  1待入驻；
       *  2个人资料提交完毕；
       *  3作品提交完毕，认证中；
       *  4放弃提交；
       *  5个人信息审核失败；
       *  6个人信息认证成功等级认证中；
       *  7等级认证失败；
       *  8等级认证完毕（面试邀请）；
       *  9认证成功后重新认证（重新上传，放弃面试）；
       *  10接受面试；
       *  11面试失败；
       *  12面试成功；
       *  13:缴纳保证金中；
       *  14缴纳保证金成功，入驻成功
       */
    inequality_determine(status) {
      let result = true;
      switch (status) {
        case 0:
          this.$Notice.error({ title: '设计师入驻', desc: '账号入驻状态异常，请联系管理员！' });
          return;
          // break;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 9:
        case 11:
          result = true;
          break;
        case 8:
        case 10:
        case 12:
        case 13:
        case 14:
          result = false;
          break;
        default:
          result = true;
      }

      this.alertMessage(result);
    },
    /** 获取设计师入驻信息 */
    getEnterInfo() {
      this.$ajax.get('/registerdesigner/queryenteruserinfo').then(e => {
        if (e.status != 200) {
          this.$Notice.error({
            title: '申请入驻',
            desc: e.msg
          });
          return;
        }
        this.enterInfo = e.data;
        if (e.data.status == 1) {
          this.$router.push({
            name: 'working',
            query: { workPlace: this.status.joinType }
          });
          return;
        }
        this.determine(e.data.status, e.data.workPlace);
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.content {
  width: 1200px;
  overflow: hidden;
  margin: auto;
  .banner {
    height: auto;
    position: relative;
    .img {
      width: 1200px;
      img {
        max-width: 1200px;
      }
    }
    .txt {
      position: absolute;
      bottom: 4px;
      left: 0px;
      z-index: 99;
      width: 100%;
      min-width: 1200px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      background: rgba(0, 0, 0, 0.2);
      color: #fff;
      font-size: 12px;
      span {
        margin: 0 10px;
      }
    }
  }
  .explain {
    text-align: center;
    height: 128px;
    line-height: 128px;
    background-color: #fff;
    img {
      margin-top: 30px;
    }
  }
  .by {
    background-color: #5cbcff;
    height: 50px;
    line-height: 50px;
    text-align: center;
    color: #fff;
    font-size: 18px;
    margin-top: 16px;
    img {
      margin-top: 7px;
    }
  }
  .join-index-title {
    overflow: hidden;
    border-bottom: 1px solid #ebebeb;
    height: 40px;
    margin-top: 22px;
    .left {
      float: left;
      font-size: 18px;
      color: #646464;
      height: 26px;
      line-height: 26px;
      p {
        border-left: 3px solid #ff5f5f;
        text-indent: 5px;
        height: 15px;
        line-height: 15px;
        margin-top: 10px;
      }
    }
    .right {
      float: right;
      a {
        display: inline-block;
        color: #646464;
        font-size: 14px;
        height: 26px;
        line-height: 26px;
      }
    }
  }
  .join-cart {
    overflow: hidden;
    margin-top: 25px;
    .left {
      display: block;
      float: left;
      width: 570px;
      height: 516px;
      background-color: #fff;
      position: relative;
      .title {
        margin-top: 27px;
        height: 42px;
        line-height: 42px;
        font-size: 30px;
        text-align: center;
        font-weight: bold;
        color: #ff5f5f;
      }
      .txt {
        width: 400px;
        height: 48px;
        line-height: 24px;
        margin: auto;
        margin-top: 20px;
        font-size: 14px;
        color: #646464;
        text-align: center;
      }
      .yq {
        width: 426px;
        height: 66px;
        line-height: 60px;
        margin: auto;
        margin-top: 8px;
        border-top: 1px solid #ebebeb;
        text-align: center;
        font-size: 12px;
        color: #646464;
      }
      .pic {
        width: 426px;
        height: 242px;
        line-height: 242px;
        overflow: hidden;
        text-align: center;
        overflow: hidden;
        margin: auto;
        img {
          max-width: 426px;
        }
      }
      .join-btn {
        position: absolute;
        bottom: 0px;
        left: 0px;
        width: 100%;
        height: 44px;
        line-height: 44px;
        background-color: #ff5f5f;
        color: #fff;
        font-size: 20px;
        text-align: center;
        /*border-bottom-left-radius: 20px;*/
        /*border-bottom-right-radius: 20px;*/
        display: none;
      }
    }
    .left:hover {
      .join-btn {
        display: block;
      }
    }
    .right {
      float: right;
      .title {
        color: #5cbcff;
      }
      .join-btn {
        background-color: #5cbcff;
        display: none;
      }
    }
  }
  .jion-manual {
    background-color: #ff5f5f;
    border-radius: 5px;
    font-size: 14px;
    color: #fff;
    text-align: center;
    height: 212px;
    margin-top: 25px;
    a {
      color: rgba(255, 255, 255, 0.6);
    }
    .j-content {
      width: 1081px;
      overflow: hidden;
      position: relative;
      margin: auto;
      padding-top: 32px;
      .list {
        overflow: hidden;
        width: 1600px;
        .item {
          width: 200px;
          height: 170px;
          float: left;
          margin-right: 96px;
          .title {
            font-weight: bold;
            height: 30px;
            line-height: 30px;
          }
          .round {
            background-color: #fff;
            width: 11px;
            height: 11px;
            margin: 8px auto;
            border-radius: 10px;
          }
          .item-list {
            ul {
              overflow: hidden;
              width: 220px;
              height: 116px;
              li {
                float: left;
                width: 93px;
                height: 23px;
                line-height: 23px;
                overflow: hidden;
                margin-right: 10px;
              }
            }
          }
        }
        .item:hover {
          a {
            color: #fff;
          }
          .round {
            width: 15px;
            height: 15px;
            margin: 6px auto;
            border-radius: 10px;
          }
        }
      }
      .hr {
        height: 76px;
        width: 1081px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.6);
        position: absolute;
        top: 0px;
      }
    }
  }
  .excellent-designer {
    margin-bottom: 35px;
    .title {
      font-size: 18px;
      color: #646464;
      font-weight: bold;
      height: 30px;
      line-height: 30px;
      text-align: center;
      margin-top: 40px;
      margin-bottom: 25px;
    }
    ul {
      overflow: hidden;
      width: 1300px;
      li {
        width: 388px;
        height: 192px;
        overflow: hidden;
        border-radius: 6px;
        float: left;
        margin-right: 18px;
        margin-bottom: 18px;
        background-color: #fff;
        border: 1px solid #dedede;
        a {
          display: block;
          padding: 14px 10px;
          .designer {
            overflow: hidden;
            .pic {
              width: 144px;
              height: 144px;
              overflow: hidden;
              border-radius: 80px;
              float: left;
              img {
                max-width: 144px;
              }
            }
            .info {
              float: right;
              width: 203px;
              color: #646464;
              font-size: 16px;
              .name {
                height: 22px;
                line-height: 22px;
                margin-top: 10px;
                overflow: hidden;
                .txt {
                  float: left;
                  max-width: 120px;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                  margin-right: 7px;
                }
                .user-icon {
                  float: left;
                }
              }
              .bt {
                height: 22px;
                line-height: 22px;
                margin-top: 14px;
              }
              .designer-explain {
                width: 203px;
                height: 46px;
                line-height: 15px;
                overflow: hidden;
                margin-top: 12px;
                font-size: 12px;
                color: #bababa;
              }
            }
          }
          .speciality {
            text-align: right;
            font-size: 12px;
            color: #646464;
          }
        }
      }
    }
  }
}
</style>
