<template>
    <div class="bz clearboth">
      <ul class="clearboth ul1" >
        <li  :class="now_step<=0?'b1':'a1'"   ></li>
        <li  :class="now_step<=1?'b2':'a2'"   ></li>
        <li  :class="now_step<=2?'b3':'a3'"   ></li>
        <li  :class="now_step<=3?'b4':'a4'"   ></li>
        <li  :class="now_step<=4?'b5':'a5'"   ></li>
        <li  :class="now_step<=5?'b6':'a6'"   ></li>
      </ul> 
    </div>
</template>

<style lang="scss" scoped>
.active {
  color: #000;
}
.normal {
  color: #ccc;
}
$a0: 30px;
$a1: 55px;
$a2: -145px;
$a3: -345px;
$a4: -545px;
$a5: -745px;
$a6: -945px;
$b0: -110px;
.a1 {
  background: url('http://3.img.dianjiangla.com/assets/../../assets/join/step.png')
    no-repeat $a1 $a0;
}
.a2 {
  background: url('http://3.img.dianjiangla.com/assets/../../assets/join/step.png')
    no-repeat $a2 $a0;
}
.a3 {
  background: url('http://3.img.dianjiangla.com/assets/../../assets/join/step.png')
    no-repeat $a3 $a0;
}
.a4 {
  background: url('http://3.img.dianjiangla.com/assets/../../assets/join/step.png')
    no-repeat $a4 $a0;
}
.a5 {
  background: url('http://3.img.dianjiangla.com/assets/../../assets/join/step.png')
    no-repeat $a5 $a0;
}
.a6 {
  background: url('http://3.img.dianjiangla.com/assets/../../assets/join/step.png')
    no-repeat $a6 $a0;
}
.b1 {
  background: url('http://3.img.dianjiangla.com/assets/../../assets/join/step.png')
    no-repeat $a1 $b0;
}
.b2 {
  background: url('http://3.img.dianjiangla.com/assets/../../assets/join/step.png')
    no-repeat $a2 $b0;
}
.b3 {
  background: url('http://3.img.dianjiangla.com/assets/../../assets/join/step.png')
    no-repeat $a3 $b0;
}
.b4 {
  background: url('http://3.img.dianjiangla.com/assets/../../assets/join/step.png')
    no-repeat $a4 $b0;
}
.b5 {
  background: url('http://3.img.dianjiangla.com/assets/../../assets/join/step.png')
    no-repeat $a5 $b0;
}
.b6 {
  background: url('http://3.img.dianjiangla.com/assets/../../assets/join/step.png')
    no-repeat $a6 $b0;
}
.bz {
  height: 150px;
  background: #fff;
  margin: 20px auto;
  box-shadow: 0 0 10px #eee;
  width: 1200px;
  li {
    text-align: center;
    padding: 30px;
    float: left;
    width: 200px;
    height: 150px;
  }
}
</style>

<script>
export default {
  props: ['step'],
  data() {
    return {
      now_step: ''
    };
  },
  watch: {
    step: function(val) {
      this.step = val;
      switch (this.step) {
        case 0:
          this.$Notice.error({ title: '设计师入驻', desc: '账号入驻状态异常，请联系管理员！' });
          this.$router.replace('/join');
          break;
        case 1:
          switch (this.$route.name) {
            // case 'designerJoin':
            //   this.$router.replace('/join');
            //   break;
            // case 'working':
            //   if(this.$route.query.workPlace=="0"){
            //       this.$router.replace('/join/working?workPlace=0');
            //   }else if(this.$route.query.workPlace=="1"){
            //       this.$router.replace('/join/working?workPlace=1');
            //   }else{
            //       this.$router.replace('/join/working?workPlace=0');
            //   }
            //   break;
            // case 'idCertification':
            //    if(this.$route.query.workPlace=="0"){
            //       this.$router.replace('/join/idCertification?workPlace=0');
            //   }
            //   if(this.$route.query.workPlace=="1"){
            //       this.$router.replace('/join/idCertification?workPlace=1');
            //   }
            //   break;
            case 'levelApprove':
            case 'levelApproveCheck':
            case 'securityDeposit':
            case 'entryIntoSuccess':
              this.$router.replace('/join');
              break;
            default:
              break;
          }
          break;
        case 2:
          this.$router.replace('/join/levelApprove');
          break;

        case 4:
        case 5:
        case 7:
        case 9:
        case 11:
          switch (this.$route.name) {
            case 'securityDeposit':
            case 'entryIntoSuccess':
              this.$router.replace('/join/levelApproveCheck');
              break;
            default:
              break;
          }
          break;
        case 3:
        case 6:
        case 8:
        case 10:
        case 12:
          this.$router.replace('/join/levelApproveCheck');
          break;
        case 13:
          this.$router.replace('/join/securityDeposit');
          break;
        case 14:
          this.$router.replace('/join/entryIntoSuccess');
          break;
        default:
          break;
      }
    }
  },
  mounted() {
    switch (this.$route.name) {
      case 'designerJoin':
        this.now_step = 1;
        break;
      case 'working':
        this.now_step = 2;
        break;
      case 'idCertification':
        this.now_step = 3;
        break;
      case 'levelApprove':
      case 'levelApproveCheck':
        this.now_step = 4;
        break;
      case 'securityDeposit':
        this.now_step = 5;
        break;
      case 'entryIntoSuccess':
        this.now_step = 6;
        break;
      default:
        break;
    }
  },
  methods: {}
};
</script>


