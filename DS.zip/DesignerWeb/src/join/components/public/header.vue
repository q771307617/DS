<template>
  <div>
    <div class="min-nav-bg">
      <div class="content">您好，欢迎来到点将啦！</div>
    </div>
    <div class="nav">
      <div class="left">
        <a href="/">
          <img src="http://5.img.dianjiangla.com/assets/icon/logo-2.png" height="73">
        </a>
        <ul>
          <li>设计师中心</li>
        </ul>
      </div>
      <div class="right">
        <router-link :to="{name:'designerJoin'}" >设计师入驻</router-link>
        <a style="display: none;" href="#">入驻指南</a>
        <a href="/">点将啦首页</a>
      </div>
    </div>
  </div>
</template>
<style lang="scss" scoped>
.min-nav-bg {
  background-color: #f54203;
  width: 100%;
  min-width: 1200px;
  .content {
    width: 1200px;
    height: 24px;
    line-height: 24px;
    color: #fff;
    font-size: 12px;
    margin: auto;
  }
}

.nav {
  width: 1200px;
  height: 80px;
  margin: auto;
  overflow: hidden;
  font-size: 14px;
  line-height: 80px;
  .left {
    float: left;
    overflow: hidden;
    a {
      display: block;
      float: left;
      width: 160px;
      height: 73px;
      overflow: hidden;
      margin-top: 5px;
    }
    ul {
      float: right;
      li {
        list-style: disc;
      }
    }
  }
  .right {
    float: right;
    a {
      display: inline-block;
      width: 90px;
      text-align: center;
      color: #646464;
    }
    .router-link-active {
      color: #f54203;
    }
  }
}
</style>
