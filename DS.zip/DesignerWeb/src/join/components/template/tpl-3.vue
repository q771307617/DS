<template>
  <div style="background-color: #f7f7f7;min-height: 800px;">
    <top/>
    <router-view></router-view>
    <fotter/>
  </div>
</template>

<script>
import top from '@/join/components/public/header';
import fotter from '@/components/fotter';
import { mapActions } from 'vuex';
export default {
  components: { top, fotter },
  methods: {
    ...mapActions(['designerIsType'])
  },
  mounted() {
    this.designerIsType();
  }
};
</script>
