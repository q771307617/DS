import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router);

/** ---------------home模块--------------------- */
const Home = r => require.ensure([], () => r(require('@/page/index')), 'home');

/** ---------------home模块--------------------- */

/** ---------------designerCenter 模块--------------------- */

const personalCenterTpl1 = r => require.ensure([], () => r(require('@/personalCenter/components/template/tpl-1')), 'personalCenterTpl1'); // 模板1 带头部和左侧  设计师个人中心
const manageHall = r => require.ensure([], () => r(require('@/personalCenter/view/manageHall')), 'manageHall'); // 管理大厅
const myWorks = r => require.ensure([], () => r(require('@/personalCenter/view/myWorks')), 'myWorks'); // 我的作品
const resume = r => require.ensure([], () => r(require('@/personalCenter/view/resume')), 'resume'); // 我的简历
const collection = r => require.ensure([], () => r(require('@/personalCenter/view/collection')), 'collection'); // 我的收藏
const personalCenter = r => require.ensure([], () => r(require('@/personalCenter/view/personalCenter')), 'personalCenter'); // 个人中心
const bindPay = r => require.ensure([], () => r(require('@/personalCenter/view/personalCenter/bindPay')), 'bindPay');// 个人中心
const financial = r => require.ensure([], () => r(require('@/personalCenter/view/financial/index')), 'financial');//财务中心 
const financialCash = r => require.ensure([], () => r(require('@/personalCenter/view/financial/cash')), 'financialCash');//财务中心-提现 
const financialSalary = r => require.ensure([], () => r(require('@/personalCenter/view/financial/salary')), 'financialSalary');// 财务中心-提现
const alipayBind = r => require.ensure([], () => r(require('@/personalCenter/view/financial/alipaybind')), 'alipayBind'); // 财务中心-提现
const orders = r => require.ensure([], () => r(require('@/personalCenter/view/orders')), 'orders'); // 订单中心
const ordersinfo = r => require.ensure([], () => r(require('@/personalCenter/view/orders/info')), 'ordersinfo'); // 订单中心
const myEmployer = r => require.ensure([], () => r(require('@/personalCenter/view/myEmployer')), 'myEmployer'); // 我的雇主


const personalCenterTpl2 = r => require.ensure([], () => r(require('@/personalCenter/components/template/tpl-2')), 'personalCenterTpl2'); // 模板1 带头部,不带左侧  设计师个人中心
/** ---------------designerCenter 模块---------------------  */

/** ---------------join模块--------------------- */
const joinTpl3 = r => require.ensure([], () => r(require('@/join/components/template/tpl-3')), 'joinTpl3'); // 模板 设计师中心-设计师入驻

const designerJoin = r => require.ensure([], () => r(require('@/join/view/designer')), 'designerJoin'); // 首页
const type = r => require.ensure([], () => r(require('@/join/view/process/type')), 'type'); // 入驻类型
const working = r => require.ensure([], () => r(require('@/join/view/process/working')), 'working'); // 工作方式
const idCertification = r => require.ensure([], () => r(require('@/join/view/process/idCertification')), 'idCertification'); // 身份认证
const levelApprove = r => require.ensure([], () => r(require('@/join/view/process/levelApprove')), 'levelApprove'); // 等级认证
const levelApproveCheck = r => require.ensure([], () => r(require('@/join/view/process/levelApproveCheck')), 'levelApproveCheck'); // 等级认证
const securityDeposit = r => require.ensure([], () => r(require('@/join/view/process/securityDeposit')), 'securityDeposit'); // 缴纳保证金
const entryIntoSuccess = r => require.ensure([], () => r(require('@/join/view/process/entryIntoSuccess')), 'entryIntoSuccess'); // 入驻成功
const NewsSetQQ = r => require.ensure([], () => r(require('@/join/view/news/setQQ')), 'NewsSetQQ'); // 新闻

/** ---------------join模块--------------------- */

/** ---------------employer模块--------------------- */
const employerTpl1 = r => require.ensure([], () => r(require('@/employer/components/template/tpl-1')), 'employerTpl1'); // 模板1 带头部和左侧
const cashRecord = r => require.ensure([], () => r(require('@/employer/view/cash/cashRecord')), 'cashRecord'); // 提现记录
const refundLog = r => require.ensure([], () => r(require('@/employer/view/refund/refundLog')), 'refundLog'); // 退款记录


const employerTpl2 = r => require.ensure([], () => r(require('@/employer/components/template/tpl-2')), 'employerTpl2'); // 模板2 带头部没有左侧
const refund = r => require.ensure([], () => r(require('@/employer/view/refund')), 'refund');// 退款流程
const commit = r => require.ensure([], () => r(require('@/employer/view/refund/commit')), 'commit');// 设计师检查
const check = r => require.ensure([], () => r(require('@/employer/view/refund/check')), 'check');// 设计师检查
const fail = r => require.ensure([], () => r(require('@/employer/view/refund/fail')), 'fail');// 审核中、失败、关闭
const success = r => require.ensure([], () => r(require('@/employer/view/refund/success')), 'success');// 审核完成

/** ---------------employer模块---------------------  */

/** ---------------未整理 模块---------------------  */

const EmployerBackstage = r => require.ensure([], () => r(require('@/page/EmloyerBackstage/emloyerBackstage')), 'emloyerBackstage');
const Page404 = r => require.ensure([], () => r(require('@/page/Page404/page404')), 'page404');
const login = r => require.ensure([], () => r(require('@/page/h5/login')), 'user');
const register = r => require.ensure([], () => r(require('@/page/h5/register')), 'user');

/**  前台路由配置 old */
const IndexPage = r => require.ensure([], () => r(require('@/page/Front/indexPage')), 'indexPage');
const PayFail = r => require.ensure([], () => r(require('@/page/Pay/fail')), 'payfail');
const PaySuccess = r => require.ensure([], () => r(require('@/page/Pay/success')), 'paysuccess');
const PayWait = r => require.ensure([], () => r(require('@/page/Pay/wait')), 'paywait');
const wechat = r => require.ensure([], () => r(require('@/page/Pay/wechat')), 'wechat'); // 微信支付单独页面
const ProList = r => require.ensure([], () => r(require('@/page/Front/proList')), 'proList');// 作品搜索
const Rules = r => require.ensure([], () => r(require('@/page/Front/rules')), 'rules'); // 平台规则
const ProInfo = r => require.ensure([], () => r(require('@/page/Front/proInfo')), 'proInfo'); // 作品详情
const Hire = r => require.ensure([], () => r(require('@/page/Front/hire')), 'hire'); // 立即雇佣
const Payment = r => require.ensure([], () => r(require('@/page/Front/payment')), 'payment');
const Designer = r => require.ensure([], () => r(require('@/page/Front/designer')), 'designer'); // 设计师搜索
const OneDesigner = r => require.ensure([], () => r(require('@/page/Front/oneDesigner')), 'oneDesigner'); // 设计师作品列表
const DetailForDesigner = r => require.ensure([], () => r(require('@/page/Front/detail-for-designer')), 'detailForDesigner'); // 设计师简历/设计师详情
/**  前台路由配置 old */

/** 雇主后台路由配置 old*/
const EmloyerHome = r => require.ensure([], () => (require('@/page/EmloyerBackstage/emloyerHome')), "emloyerHome");
const EmploymentManagement = r => require.ensure([], () => (require('@/page/EmloyerBackstage/employmentManagement')), 'employmentManagement');
const MoneyCenter = r => require.ensure([], () => (require('@/page/EmloyerBackstage/moneyCenter')), "moneycenter");

/** 交易记录页面路由配置 */
const trading_record = r => require.ensure([], () => (require('@/page/EmloyerBackstage/trading_record/index')), "trading_record");
/** 交易记录页面开始 */
const trading_record_table = r => require.ensure([], () => (require('@/page/EmloyerBackstage/trading_record/table')), "trading_record");
const recharge = r => require.ensure([], () => (require('@/page/EmloyerBackstage/trading_record/recharge')), "trading_record");
const cash = r => require.ensure([], () => (require('@/page/EmloyerBackstage/trading_record/cash')), "trading_record");
/** 交易记录页面路由配置 */

/** 雇主后台个人设置  */
const settings = r => require.ensure([], () => (require('@/page/EmloyerBackstage/settings/index')), "settings");
/** 雇主后台个人设置 */
const settings_userinfo = r => require.ensure([], () => (require('@/page/EmloyerBackstage/settings/userinfo/index')), "settings");
const SettingsUserinfoInformation = r => require.ensure([], () => (require('@/page/EmloyerBackstage/personalModel/information.vue')));
const SettingsUserinfoEditinfo = r => require.ensure([], () => (require('@/page/EmloyerBackstage/personalModel/editinfo.vue')));
const SettingsUserinfoPwdservice = r => require.ensure([], () => (require('@/page/EmloyerBackstage/personalModel/pwdservice.vue')));
const settings_user_bindalipay = r => require.ensure([], () => (require('@/page/EmloyerBackstage/settings/userinfo/bindalipay')), "settings");
/** 雇主后台个人设置  */

/** 需求管理路由配置 */
const DemandManagent = r => require.ensure([], () => (require('@/page/EmloyerBackstage/DemandManagement/index')), "demandManagent");
/** 需求管理 */
const DemandManagentTable = r => require.ensure([], () => (require('@/page/EmloyerBackstage/DemandManagement/table')), "demandManagentTable");
const DemandManagentChoose = r => require.ensure([], () => (require('@/page/EmloyerBackstage/DemandManagement/chooseDemand')), "demandManagentChoose");
const DemandManagentWrite = r => require.ensure([], () => (require('@/page/EmloyerBackstage/DemandManagement/writeContent')), "demandManagentWrite");
const DemandManagentConfirm = r => require.ensure([], () => (require('@/page/EmloyerBackstage/DemandManagement/confirm')), "demandManagentConfirm");
const DemandManagentInfo = r => require.ensure([], () => (require('@/page/EmloyerBackstage/DemandManagement/info')), "demandManagentInfo");
/** 需求管理路由配置 */

/** 我的收藏路由配置 */
const favDesigner = r => require.ensure([], () => (require('@/page/EmloyerBackstage/favDesigner')), "favDesigner");
/** 我的收藏--设计师收藏 */
const favPro = r => require.ensure([], () => (require('@/page/EmloyerBackstage/favPro')), "favPro");
/** 我的收藏--作品收藏 */
/** 我的收藏路由配置 */

/** 雇主后台路由配置 old*/

/** ---------------未整理 模块---------------------  */

const RouterConfig = {
    mode: 'history',
    routes: [
        /*****  PC路径重定向  *****/
        { path: '/bindalipay/:id', redirect: { name: 'bindalipay' } },//绑定支付宝
        {
            path: '/', component: Home,
            children: [
                { path: "", name: "indexPage", component: IndexPage, meta: { title: '点将啦' } },
                { path: "payFail", component: PayFail, name: "payfail" },
                { path: "paySuccess", component: PaySuccess, name: "paysuccess" },
                { path: "payWait", component: PayWait, name: "payWait" },
                { path: "wechat/:id", component: wechat, name: "wechat" },
                { path: "proList", component: ProList, name: "proList", meta: { title: '看作品 - 点将啦' } },
                { path: "rules", component: Rules, name: "rules", meta: { title: '平台规则-点将啦' } },
                { path: "proInfo/:id", component: ProInfo, name: "proInfo", meta: { title: '作品详情 - 点将啦' } },
                { path: "proInfoList/:designerWorkId", component: ProInfo, name: "proInfoList", meta: { title: '作品详情 - 点将啦' } },
                { path: "hire/:id", component: Hire, name: "hire", meta: { title: '立即雇佣 - 点将啦' } },
                { path: "payment", component: Payment, name: "payment", meta: { title: '确认付款 - 点将啦' } },
                { path: 'search/designer', name: 'designer', component: Designer, meta: { title: '搜索设计师 - 点将啦' } },
                { path: 'designer/:id', name: 'oneDesigner', component: OneDesigner, meta: { title: '搜索设计师 - 点将啦' } },
                { path: 'designers/:id', name: 'detailForDesigner', component: DetailForDesigner, meta: { title: '查看设计师 - 点将啦' } }
            ]
        },
        {
            path: '/employer', component: employerTpl1, // 模板1 带头部和左侧
            children: []
        },
        {
            path: '/employer', component: employerTpl2, // 模板2 带头部没有左侧
            children: [
                {
                    path: 'refund', component: refund,
                    children: [
                        { path: '1', name: 'commit', component: commit }, // 退款
                        { path: '2', name: 'check', component: check }, // 设计师检查
                        { path: '3', name: 'fail', component: fail }, // 审核中、失败、关闭
                        { path: '4', name: 'success', component: success }, // 审核完成
                        { path: '/', redirect: 'commit' }
                    ]
                },
            ]
        },
        {
            path: '/personalCenter', component: personalCenterTpl1, // 模板1 带头部和左侧  设计师个人中心
            children: [
                { path: 'manageHall', name: 'manageHall', component: manageHall }, // 管理大厅
                { path: 'myWorks', name: 'myWorks', component: myWorks }, // 我的作品
                { path: 'resume', name: 'resume', component: resume }, // 我的简历
                { path: 'collection', name: "collection", component: collection, }, // 我的收藏
                { path: 'favoriteDesigner', component: favDesigner, name: "favoriteDesigner" }, // 我的收藏--设计师收藏
                { path: 'favoritePro', component: favPro, name: "favoritePro" }, // 我的收藏--作品收藏
                { path: 'financial', title: '财务中心', component: financial,  
                children: [    
                    { path: '/',  redirect: { name: 'financialSalary' }},               
                    { path: 'cash', name: 'financialCash', title: '财务中心-提现 ', component: financialCash },
                    { path: 'salary', name: 'financialSalary', title: '财务中心-薪资', component: financialSalary },
                ] },
                { path: 'alipayBind/:id', name: 'alipayBind', title: '设计师绑定支付宝', component: alipayBind }, // 设计师绑定支付宝
                { path: 'orders', name: 'orders', title: '订单中心', component: orders }, // 订单中心
                { path: 'myEmployer', name: 'myEmployer', title: '我的雇主', component: myEmployer }, // 我的雇主
                { path: 'personalCenter', name: 'personalCenter', component: personalCenter }, // 个人中心
                { path: 'personalCenter/:id',    name: 'bindPay',    component: bindPay },                               /** 绑定支付宝 */
                { path: '/', redirect: 'manageHall' },
            ]
        },
      {
        path: '/personalCenter', component: personalCenterTpl2, // 模板1 带头部,不带左侧  设计师个人中心
        children: [
          { path: 'orders/info', name: 'ordersinfo', title: '订单中心', component: ordersinfo }, // 订单中心--订单详情
        ]
      },
        {
            path: '/join', component: joinTpl3, // 模板 设计师中心-设计师入驻
            children: [
                { path: '/', redirect: { name: 'designerJoin' } }, // 默认打开页面
                { path: 'designerJoin', name: 'designerJoin', component: designerJoin }, // 首页
                { path: 'working', name: 'working', component: working }, // 工作方式
                { path: 'idCertification', name: 'idCertification', component: idCertification }, // 身份认证
                { path: 'levelApprove', name: 'levelApprove', component: levelApprove }, // 等级认证-- 作品上传
                { path: 'levelApproveCheck', name: 'levelApproveCheck', component: levelApproveCheck }, // 等级认证 -- 审核中
                { path: 'securityDeposit', name: 'securityDeposit', component: securityDeposit }, // 缴纳保证金
                { path: 'type', name: 'type', component: type }, // 入驻类型
                { path: 'setqq', name: 'setqq', component: NewsSetQQ }, // 设置QQ
                { path: 'entryIntoSuccess', name: 'entryIntoSuccess', component: entryIntoSuccess }, // 入驻成功
            ]
        },
        {
            path: '/emloyerBackstage', component: EmployerBackstage, // 雇主后台路由配置 old
            children: [
                { path: '/', redirect: { name: 'EmloyerHome' } }, // 默认打开页面
                { path: 'home', component: EmloyerHome, name: "EmloyerHome" },
                { path: 'employmentManagement', component: EmploymentManagement, name: "employmentManagement" },
                { path: 'moneyCenter', component: MoneyCenter, name: "moneyCenter" },
                {
                    path: 'trading_record', component: trading_record, // 交易记录页面路由配置
                    children: [
                        { path: '', redirect: 'index' },
                        { path: 'index', name: 'trading_record_table', component: trading_record_table },
                        { path: 'recharge', component: recharge, name: 'recharge' },
                        { path: 'cash', component: cash, name: 'cash' },
                        { path: 'cashRecord', name: 'cashRecord', component: cashRecord },
                        { path: 'refundLog', name: 'refundLog', component: refundLog }, // 退款记录
                    ]
                },
                {
                    path: 'settings', component: settings, // 雇主后台个人设置
                    children: [
                        { path: '', redirect: 'userinfo' },
                        {
                            path: 'userinfo', component: settings_userinfo,
                            children: [
                                { path: '', name: 'information', component: SettingsUserinfoInformation },
                                { path: 'editinfo', name: 'editinfo', component: SettingsUserinfoEditinfo },
                                { path: 'pwdservice', name: 'pwdservice', component: SettingsUserinfoPwdservice },
                                { path: 'bindalipay/:id', component: settings_user_bindalipay, name: 'bindalipay' },
                            ]
                        }
                    ]
                },
                {
                    path: 'demandManagent', component: DemandManagent, // 需求管理
                    children: [
                        { path: '', redirect: 'index' },
                        { path: 'index', component: DemandManagentTable, name: 'demandManagentTable' },
                        { path: 'create/1', component: DemandManagentChoose, name: 'demandManagentChoose' },
                        { path: 'create/2', component: DemandManagentWrite, name: 'demandManagentWrite' },
                        { path: 'create/3', component: DemandManagentConfirm, name: 'demandManagentConfirm' },
                        { path: 'info/:id', component: DemandManagentInfo, name: 'demandManagentInfo' },
                    ]
                },
                { path: 'favDesigner', component: favDesigner, name: "favDesigner" }, // 我的收藏--设计师收藏
                { path: 'favPro', component: favPro, name: "favPro" }, // 我的收藏--作品收藏
            ]
        },
        { path: '/user/login', name: 'login', component: login },
        { path: '/user/register', name: 'register', component: register },
        { path: '*', name: '404', component: Page404 }
    ],
    scrollBehavior(to, from, savedPosition) {
        return { x: 0, y: 0 }
    }
};

let router = new Router(RouterConfig);

router.beforeEach((to, from, next) => {
    document.title = to.meta && to.meta.title || '杭州四喜';
    if (to.path.indexOf('emloyerBackstage') > -1) {
        document.title = '雇主后台';
    }
    next();
})
export default router;
