<template>
    <div class="layout-ceiling" v-lazy:background-image="`${ftpPath}images/ht_headbg.png`">
        <div class="layout-ceiling-main">
            <Row>
                <Col span="18">
                    <ul class="nav clearfix">
                        <li class="font20 title">工作管理系统</li>
                        <li class="font16"  @mouseenter="()=>{showClosePlaneHover(true)}" @mouseleave="()=>{showClosePlaneHover(false)}" style="position: relative;">
                            {{info.username}}
                            <div v-if="showClosePlane" class="user-exit" @click="exitUser">
                                退出
                            </div>
                        </li>
                        <li class="font16">
                            <a href="/" style="color:#fff;" class="font16">首页</a>
                            <!-- <router-link to="/" style="color:#fff;" class="font16">首页</router-link> -->
                        </li>
                    </ul>
                </Col>
                <Col span="6" class="layout-ceiling-right font16"> {{this.time}}
                </Col>
            </Row>
        </div>
    </div>
</template>

<script>
import { mapState, mapActions } from 'vuex';
let weekName = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];

export default {
  data() {
    return {
      showClosePlane: false,
      time:
        new Date().Format('yyyy-MM-dd') +
        '　' +
        weekName[new Date().getDay()] +
        '　' +
        new Date().Format('hh:mm:ss')
    };
  },
  computed: {
    ...mapState({
      info: state => state.User.info,
      ftpPath: state => state.User.ftpPath
    })
  },
  methods: {
    ...mapActions(['exitUser']),
    showClosePlaneHover(boolean) {
      this.showClosePlane = boolean;
    }
  },
  mounted() {
    this.timer = setInterval(() => {
      this.time =
        new Date().Format('yyyy-MM-dd') +
        '　' +
        weekName[new Date().getDay()] +
        '　' +
        new Date().Format('hh:mm:ss');
    }, 1000);
  },
  destroyed() {
    clearInterval(this.timer);
  }
};
</script>

<style>
body {
  color: #646464;
  background-color: #fafafa;
  /* font-family:微软雅黑; */
}
.kf-font .ivu-tooltip-inner {
  color: #888888;
  background-color: rgb(249, 249, 249);
  border-radius: 0;
  box-shadow: inherit;
  border: 1px solid #eaeaea;
}
.kf-font .ivu-tooltip-popper .ivu-tooltip-arrow {
  border-bottom-color: rgba(226, 227, 230, 0.9);
}
</style>
<style scoped>
.nav {
  height: 73px;
}
.nav li {
  height: 73px;
  line-height: 73px;
  min-width: 100px;
  cursor: pointer;
  float: left;
  padding: 0 10px;
  text-align: center;
}
.nav li:first-child {
  font-size: 30px;
  width: 292px;
  font-weight: bold;
}
.layout {
  position: relative;
}
.layout .main {
  width: 1200px;
  margin: 0 auto;
}
.layout-ceiling-main {
  width: 1200px;
  margin: 0 auto;
  color: #fff;
}
.layout-ceiling-main .title {
  text-align: left;
  color: #fff;
}
.layout-ceiling-right {
  height: 73px;
  line-height: 73px;
  text-align: right;
}
.layout-ceiling-main a {
  color: #9ba7b5;
}
.user-exit {
  cursor: pointer;
  position: absolute;
  height: 50px;
  line-height: 50px;
  width: 100%;
  background-color: #f54000;
  left: 0;
  z-index: 200;
  text-align: center;
}
</style>
