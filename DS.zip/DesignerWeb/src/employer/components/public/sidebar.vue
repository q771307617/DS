<style scoped>
.nav {
  height: 73px;
}
.nav li {
  height: 73px;
  line-height: 73px;
  min-width: 100px;
  cursor: pointer;
  float: left;
  padding: 0 10px;
  text-align: center;
}
.nav li:first-child {
  font-size: 30px;
  width: 292px;
  font-weight: bold;
}
.layout {
  position: relative;
}
.layout .main {
  width: 1200px;
  margin: 0 auto;
}
.layout-ceiling-main {
  width: 1200px;
  margin: 0 auto;
  color: #fff;
}
.layout-ceiling-main .title {
  text-align: left;
  color: #fff;
}
.layout-ceiling-right {
  height: 73px;
  line-height: 73px;
  text-align: right;
}
.layout-ceiling-main a {
  color: #9ba7b5;
}
.layout-content-main {
  min-height: 900px;
}
.layout-menu-right,
.layout-menu-left {
  position: relative;
  margin-top: 15px;
}
.layout-menu-left {
  background-color: #fff;
  width: 283px;
}
.layout-menu-left .kf {
  padding: 58px;
  text-align: center;
}
.layout-menu-left .kf .kf-font {
  color: #818181;
  display: inline-flex;
}
.layout-menu-left .kf .kf-font img {
  width: 22px;
}
.layout-menu-right {
  width: 902px;
}
.left-menu {
  text-align: center;
}
.left-menu li {
  cursor: pointer;
  height: 55px;
  line-height: 55px;
  font-size: 16px;
}
.left-menu .active {
  background: #d7d7d7;
  color: #000;
  font-weight: 900;
}
.left-menu li.active:first-child div {
  border: 0;
}
.left-menu li div {
  width: 219px;
  margin: 0 auto;
  border-bottom: 1px solid #eee;
}
.left-menu li:first-child div {
  border-top: 1px solid #eee;
}
.user-info-list li {
  line-height: 30px;
  cursor: pointer;
  text-align: center;
}
.user-info-list li:first-child {
  padding: 25px 30px;
  border-top: 0;
}
.user-info-list li .user_img {
  width: 218px;
  height: 218px;
  border-radius: 110px;
}
.user-exit {
  cursor: pointer;
  position: absolute;
  height: 50px;
  line-height: 50px;
  width: 100%;
  background-color: #f54000;
  left: 0;
  z-index: 200;
  text-align: center;
}
.cz-btn {
  border-radius: 0;
  padding: 0;
  width: 218px;
  height: 25px;
  line-height: 25px;
  margin: 20px 0 57px 0;
  color: #646464;
  background-color: #eeeeee;
  border-color: #dadada;
}
.cz-btn:hover {
  color: #fff;
  background: #f54203;
}
</style>
<template>
    <div class="layout-menu-left float-left box-shadow">
        <ul class="user-info-list">
            <li class="font20">
                <img :src="info.image_url" width="100%;" alt="" class="user_img">
                <span class="font20">{{info.nickname || info.username}}</span>
            </li>
            <li class="font16">
                账户余额：{{info.balance}}元
            </li>
            <li class="font16">
                平台监管金额：{{info.deposit}}元
            </li>
            <li>
                <Button type="warning" @click='recharge' class="cz-btn">立即充值</Button>
            </li>
        </ul>
        <ul class="left-menu font20">
            <li v-for="item in items" :key="item.id" v-bind:class="{active:(item.id == activeMenu)}" @click="()=>{menuSelect(item)}">
                <div>{{item.lebal}}</div>
            </li>
        </ul>
        <div class="kf">
            <div style="height:90px;width:90px;display: inline-block;">
                <img :src="ftpPath+'icon/icon_kf.png'" width="100%" alt="联系我">
            </div>
            <p class="kf-font font14 margintop10">
                专属客服
                <span v-on:mouseenter="()=>{enter(1)}" v-on:mouseleave="()=>{leave(1)}">

                    <img :src="ftpPath+'icon/icon_phone.png'" width="100%" alt="联系我" v-if="!phone_hover">
                    <!--<img :src="ftpPath+'icon/icon_phone.png" width="100%" alt="联系我" v-if="hover">-->
                    <Tooltip :content="'手机号码：'+customServiceinfo.phone" placement="bottom" v-if="phone_hover">
                        <img :src="ftpPath+'icon/icon_phone2.png'" width="100%" alt="联系我">
                    </Tooltip>
                </span>

                <span v-on:mouseenter="()=>{enter(2)}" v-on:mouseleave="()=>{leave(2)}">
                        <img :src="ftpPath+'icon/icon_qq.png'" width="100%" alt="联系我" v-if="!qq_hover">
                    <!--<img :src="ftpPath+'icon/icon_phone.png" width="100%" alt="联系我" v-if="hover">-->
                    <Tooltip :content="'QQ号码：'+customServiceinfo.QQ" placement="bottom" v-if="qq_hover">
                        <img :src="ftpPath+'icon/icon_qq2.png'" width="100%" alt="联系我">
                    </Tooltip>
                </span>

                <span v-on:mouseenter="()=>{enter(3)}" v-on:mouseleave="()=>{leave(3)}">
                    <img :src="ftpPath+'icon/icon_weixin.png'" width="100%" alt="联系我" v-if="!weixin_hover">
                    <!--<img :src="ftpPath+'icon/icon_phone.png" width="100%" alt="联系我" v-if="hover">-->
                    <Tooltip :content="'微信号码：'+customServiceinfo.weChat" placement="bottom" v-if="weixin_hover">
                        <img :src="ftpPath+'icon/icon_weixin2.png'" width="100%" alt="联系我">
                    </Tooltip>
                </span>
            </p>
        </div>
    </div>
</template>

<script>
import { mapState } from 'vuex';

export default {
  data() {
    return {
      activeMenu: 1,
      items: [
        {
          lebal: '工作台首页',
          id: 1,
          path: '/emloyerBackstage/home'
        },
        {
          lebal: '需求管理',
          id: 2,
          path: '/emloyerBackstage/demandManagent'
        },
        {
          lebal: '雇佣管理',
          id: 3,
          path: '/emloyerBackstage/employmentManagement'
        },
        {
          lebal: '交易记录',
          id: 4,
          path: '/emloyerBackstage/trading_record'
        },
        {
          lebal: '个人信息',
          id: 5,
          path: '/emloyerBackstage/settings'
        },
        {
          lebal: '收藏夹',
          id: 6,
          path: '/emloyerBackstage/favDesigner'
        }
      ],
      phone_hover: false,
      qq_hover: false,
      weixin_hover: false
    };
  },
  computed: {
    ...mapState({
      info: state => state.User.info,
      ftpPath: state => state.User.ftpPath,
      customServiceinfo: state => state.User.customServiceinfo
    })
  },
  methods: {
    enter(k) {
      if (k == 1) {
        this.phone_hover = true;
      }
      if (k == 2) {
        this.qq_hover = true;
      }
      if (k == 3) {
        this.weixin_hover = true;
      }
    },
    leave(k) {
      if (k == 1) {
        this.phone_hover = false;
      }
      if (k == 2) {
        this.qq_hover = false;
      }
      if (k == 3) {
        this.weixin_hover = false;
      }
    },
    recharge() {
      this.$router.push({ name: 'recharge' });
    },
    menuSelect(item) {
      this.activeMenu = item.id;
      this.$router.push({
        path: item.path
      });
    },
    setActiveMenu() {
      for (let item of this.items) {
        if (this.$route.path === item.path) {
          this.activeMenu = item.id;
          break;
        }
        // 二级tab
        if (this.$route.matched[1].path == item.path) {
          this.activeMenu = item.id;
          break;
        }
      }
    }
  },
  mounted() {
    this.setActiveMenu();
  },
  watch: {
    $route: 'setActiveMenu'
  }
};
</script>
