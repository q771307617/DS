<template>
    <div class='handling-side box-shadow'>
        <h1 v-if="page == 1">
            <span v-if="info.orderType == 'DEMAND'">需求详情</span>
            <span v-if="info.orderType == 'HIRE_CUSTOM'">定制详情</span>
            <span v-if="info.orderType == 'HIRE_MONTH'">包月详情</span>
        </h1>
        <h1 v-if="page != 1">退款详情</h1>
        <div class='text'>
            <p v-if="info.title">
                <label>需求名称：</label>
                <span class='value'>{{info.title}}</span>
            </p>
            <p v-if="info.orderType == 'DEMAND'">
                <label>预计完成时间：</label>
                <span class='value'>{{info.planCompleteDate | getTime}}</span>
            </p>
            <p v-if="info.orderType == 'HIRE_CUSTOM'">
                <label>定制时间：</label>
                <span class='value'>{{info.startTime | getTime}}-{{info.endTime | getTime}}</span>
            </p>
            <p v-if="info.orderType == 'HIRE_MONTH'">
                <label>包月时间：</label>
                <span class='value'>{{info.startTime | getTime}}-{{info.endTime | getTime}}</span>
            </p>
            <p>
                <label>预算金额：</label>
                <span v-if="info.orderType == 'DEMAND'" class='red value'>{{info.budget | getMoney}} </span>
                <span v-else class='red value'>{{info.price | getMoney}} </span>
            </p>
            <p>
                <label>订单状态：</label>
                <span class='red value'>{{info | getState}}</span>
            </p>
            <p>
                <label>退款路径：</label>
                <span class='value'>{{info.channel | getPath}}</span>
            </p>
            <!--<p>-->
                <!--沟通设计师：-->
                <!--<span></span>-->
            <!--</p>-->
        </div>
        <div v-if="page != 1" class='text'>
            <p>
                <label>退款编号：</label>
                <span class='value'>{{info.refundNo}}</span>
            </p>
            <p>
                <label>退款金额：</label>
                <span class='value'>{{info.refundFee | getMoney}} </span>
            </p>
            <p>
                <label>退款原因：</label>
                <span class='value'>{{info.refundMemo}}</span>
            </p>
        </div>
    </div>
</template>
<script>
import moment from 'moment';

export default {
  props: ['info', 'page'],
  data() {
    return {
      // page: ''
    };
  },
  filters: {
    getMoney(v) {
      if (v == '' || v == null || v == undefined) {
        return 0;
      }
      return '￥' + v;
    },
    getTime(v) {
      return moment(v).format('YYYY/MM/DD');
    },
    getState(info) {
      const v = info.status;
      if (!info) return;
      if (info.orderType == 'DEMAND') {
        if (info.budgetStatus == 9 || info.budgetStatus == 12) {
          return '退款中';
        } else if (info.budgetStatus == 15) {
          return '已退款';
        }
        if (info.budgetStatus == 1 && info.completeStatus != 1) {
          return '工作中';
        }
      }
      if (info.orderType == 'HIRE_CUSTOM' || info.orderType == 'HIRE_MONTH') {
        if (v == 1) {
          return '待开始';
        } else if (v == 2) {
          return '工作中';
        } else if (v == 9 || v == 12) {
          return '退款中';
        } else if (v == 15) {
          return '已退款';
        }
      }
    },
    getPath(v) {
      if (v == 0) {
        return '账户余额';
      } else if (v == 1) {
        return '支付宝';
      } else if (v == 2) {
        return '微信';
      }
    }
  }
};
</script>


<style scoped>
/* 侧栏 */
.red {
  color: #f54203 !important;
}
.handling-side {
  float: right;
  width: 376px;
  background: #fff;
  min-height: 775px;
  padding: 26px 30px 0;
}

.handling-side h1 {
  font-size: 20px;
  font-weight: 400;
  color: #575757;
  padding-bottom: 15px;
}

.handling-side .text {
  font-size: 16px;
  color: #8c8c8c;
  padding-top: 31px;
  padding-bottom: 47px;
  border-top: 1px solid #d4d0c8;
}

.handling-side .text p {
  margin-bottom: 20px;
}

.handling-side .text .value {
  line-height: 1.2;
  word-break: break-all;
}

.handling-side .text span {
  color: #393939;
}
</style>
