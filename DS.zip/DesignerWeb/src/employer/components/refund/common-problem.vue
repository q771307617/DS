<template>
    <div class='question box-shadow'>
        <h1>常见问题：</h1>
        <div class='text'>
            <h2>1、申请退款后多长时间完成退款？</h2>
            <p>提交申请后，我们将在3个工作日内完成审核，审核通过后，将在4个工作日内完成退款，请关注退款结果。</p>
            <h2>2、申请退款后，交易退款成功，钱退到哪里？</h2>
            <p>要先查看退款状态哦，只有当订单的退款状态显示【退款成功】时，钱款才会退回原先的支付渠道。</p>
        </div>
    </div>
</template>

<style scoped>
/* 问题 */

.question {
  background: #fff;
  margin-top: 18px;
  padding: 35px 72px;
  overflow-y: auto;
  flex-shrink: 1;
  flex-grow: 1;
}

.question h1 {
  font-size: 20px;
  font-weight: 400;
  color: #575757;
  margin-bottom: 25px;
}

.question .text {
  font-size: 14px;
  color: #8c8c8c;
}

.question .text h2 {
  font-size: 14px;
  font-weight: 400;
  margin-bottom: 10px;
}

.question .text p {
  text-indent: 1.5em;
  margin-bottom: 21px;
  line-height: 1.2;
}
</style>
