<template>
  <div class='record box-shadow'>
    <h1>处理记录：</h1>
    <div v-if="log.length <= 0">
      <p style="text-align: center;">暂无记录</p>
    </div>
    <div v-else v-for="item in log" :key="item.id" class='record-item'>
      <img class='img' :src='item.imageUrl' alt='头像'/>
      <div class='text'>
        <p class='t1'>{{item.nickname || item.username}}</p>
        <p class='t2'>{{item.optDesc}}</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ['log']
};
</script>

<style scoped>
/* 记录 */
.record {
  background: #fff;
  margin-top: 18px;
  padding: 35px 72px;
  overflow-y: auto;
  /* height: 486px; */
  /* height: 326px; */
  flex-shrink: 1;
  flex-grow: 1;
}

.record h1 {
  font-weight: 400;
  font-size: 18px;
  color: #575757;
  margin-bottom: 10px;
}

.record .record-item {
  padding: 20px 0;
  border-bottom: 1px solid #ddd;
}

.record-item:after {
  content: '';
  display: table;
  clear: both;
}

.record-item img {
  width: 55px;
  height: 55px;
  float: left;
}

.record-item .text {
  float: left;
  margin-left: 23px;
}

.record-item .t1 {
  font-size: 16px;
  color: #9c9c9c;

  margin: 3px 0 15px;
}

.record-item .t2 {
  font-size: 18px;
  color: #787878;
}
</style>
