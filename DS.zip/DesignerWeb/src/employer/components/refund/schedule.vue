<template>
    <div class='refund-step box-shadow'>
        <ul>
            <li :class="active == '1' ? 'acitve' : ''">
                <p class='order'>1</p>
                <p class='tip'>退款申请</p>
            </li>
            <li :class="active == '2' ? 'acitve' : ''">
                <p class='order'>2</p>
                <p class='tip'>设计师处理退款申请</p>
            </li>
            <li :class="active == '3' ? 'acitve' : ''">
                <p class='order'>3</p>
                <p class='tip'>退款</p>
            </li>
            <li :class="active == '4' ? 'acitve' : ''">
                <p class='order'>4</p>
                <p class='tip'>退款完成</p>
            </li>
        </ul>
    </div>
</template>
<script>
export default {
  props: {
    active: {
      type: String,
      default: '1'
    }
  }
};
</script>


<style scoped>
.refund-step {
  background: #fff;
  line-height: 1;
  font-size: 16px;
  font-family: '微软雅黑';
  -ms-user-select: none;
  -moz-user-select: none;
  -webkit-user-select: none;
  user-select: none;
  cursor: default;
  margin-bottom: 18px;
}

.refund-step ul:after {
  content: '';
  display: table;
  clear: both;
}

.refund-step li {
  width: 25%;
  float: left;
  text-align: center;
  padding: 33px 0 29px;
  position: relative;
}

.refund-step li:first-child:before,
.refund-step li:last-child:after {
  display: none;
}

.refund-step li:before,
.refund-step li:after {
  content: '';
  position: absolute;
  top: 58px;
  width: 84px;
  height: 1px;
  background: #d3d3d3;
}

.refund-step li:before {
  left: 0;
}

.refund-step li:after {
  right: 0;
}

.refund-step li.acitve .order {
  background: #f54203;
}

.refund-step .order {
  width: 50px;
  height: 50px;
  line-height: 50px;
  margin: auto;
  background: #bfbfbf;
  border-radius: 50%;
  font-size: 24px;
  color: #fff;
}

.refund-step li.acitve .tip {
  color: #f54203;
}

.refund-step .tip {
  font-size: 18px;
  color: #bfbfbf;
  margin-top: 21px;
}
</style>
