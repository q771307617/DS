<template>
  <div class="layout">
    <publicHeader/>
    <router-view></router-view>
  </div>
</template>

<script>
import publicHeader from '@/employer/components/public/header';
import { mapActions } from 'vuex';
export default {
  components: { publicHeader },
  methods: {
    ...mapActions(['employerIslogin'])
  },
  mounted() {
    this.employerIslogin();
  }
};
</script>
