<template>
  <div class="layout">
    <publicHeader/>
    <div class="main">
      <div class="clearfix" style="position: relative;background: #fafafa;">
        <sidebar/>
        <div class="layout-menu-right float-right">
          <div class="layout-content">
            <div class="layout-content-main">
              <router-view></router-view>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import publicHeader from '@/employer/components/public/header.vue';
import sidebar from '@/employer/components/public/sidebar.vue';
import { mapActions } from 'vuex';

export default {
  components: { publicHeader, sidebar },
  methods: {
    ...mapActions(['employerIslogin'])
  },
  mounted() {
    this.employerIslogin();
  }
};
</script>

<style scoped>
.layout {
  position: relative;
}

.layout .main {
  width: 1200px;
  margin: 0 auto;
}

.layout-ceiling-right {
  height: 73px;
  line-height: 73px;
  text-align: right;
}

.layout-content-main {
  min-height: 900px;
}

.layout-menu-right,
.layout-menu-left {
  position: relative;
  margin-top: 15px;
}

.layout-menu-right {
  width: 902px;
}
</style>

