<template>
  <div class='handlingCheck box-shadow'>
    <div v-if="status.refundStatus" class='status'>
      <h1>设计师已处理，退款中....
        <!-- <span class='time'>还剩 {{auditStartDate | getDateDiff(auditEndDate, 'dhm')}}</span> -->
      </h1>
      <p>设计师已同意您的退款，我们正在马不停蹄的处理中，请耐心等待</p>
    </div>
    <div v-else class='status'>
      <h1>等待设计师处理
        <span class='time'><i></i>还剩 {{auditStartDate | getDateDiff(auditEndDate, 'dhm')}}</span>
      </h1>
      <p>您已发起退款申请，请耐心等待设计师处理</p>
    </div>
    <div class='handle'>
      <ul class='text'>
        <li>设计师同意后，退款金额将于原路退回您的打款账户中，请及时关注退款进度。</li>
        <li>如果设计师拒绝，您可以修改申请后再次发起，设计师会重新处理</li>
        <li>如果设计师超时未处理，退款申请将达成，系统将按照订单金额自动退款</li>
      </ul>
      <div v-if="status.refundStatus">
        <Button class='alter-btn' type="error" @click="status.modal1 = true">撤销申请</Button>
      </div>
      <div v-else>
        <Button class='alter-btn' type="error" @click="edit" v-if="progress == 'PENDING_DESIGNER_AUDIT'">修改申请</Button>
        <Button class='alter-btn' type="error" @click="status.modal1 = true" v-else>撤销申请</Button>
        <p class='other' v-if="progress == 'PENDING_DESIGNER_AUDIT'">您还可以：
          <a class='backout' @click="status.modal1 = true">撤销申请</a>
        </p>
      </div>
    </div>

    <Modal v-model="status.modal1" width="769" :closable="false" class-name='refund-vertical-center'>
      <p slot="header"></p>
      <p style="font-size: 20px;color: #575757;text-align: center;">撤销本次申请，如果问题未解决，您还可再次申请。确定继续吗？</p>
      <div class="btn-group">
        <a @click="revocation" href="javascript:;" style="background-color: #f54203;border: 1px solid #f54203;color: #fff;">确认</a>
        <a @click="status.modal1 = false" href="javascript:;" style="color: #6a6a6a;border: 1px solid #afafaf;margin-left: 38px;">取消</a>
      </div>
      <div slot="footer"></div>
    </Modal>
  </div>
</template>

<script>
export default {
  data() {
    return {
      auditEndDate: '',
      auditStartDate: '',
      status: {
        modal1: false,
        refundStatus: false
      },
      params: {
        id: '' /** 订单号 */,
        type:
          '' /** 订单类型: DEMAND(需求订单)，HIRE_CUSTOM(定制雇佣订单)，HIRE_MONTH(包月雇佣订单) */,
        /**
         * 等待设计师处理            等待设计师审核 PENDING_DESIGNER_AUDIT(3, "等待设计师审核"), 等待总监审核 PENDING_MANAGER_AUDIT(6, "等待总监审核"),
         * 设计师已处理，退款中....  等待财务审核 PENDING_FINANCE_AUDIT(9, "等待财务审核"), 退款处理中  PROCESSING(18, "退款处理中"),
         * 退款审核未通过            退款单已关闭 CLOSED(27, "退款单已关闭"); 退款失败 FAIL(24, "退款失败");APPLY_FAIL(15, "申请失败")
         * 退款完成                  退款成功 SUCCESS(21, "退款成功")
         */
        ordersRefundId: '',
        navType: ''
      },
      progress: '' //退款进度
    };
  },
  mounted() {
    this.params.id = this.$route.query.id || '';
    this.params.type = this.$route.query.type || '';
    this.params.navType = this.$route.query.navType || '';
    this.params.ordersRefundId = this.$route.query.ordersRefundId || '';
    this.getInfo();
  },
  methods: {
    edit() {
      /** 修改申请，调到第一步 */
      this.$router.replace({ name: 'commit', query: { ...this.params } });
    },
    getInfo() {
      this.$ajax.get('/orders/refund/detail', { ...this.params }).then(e => {
        if (e.status != 200) {
          return;
        }
        this.auditStartDate = this.$moment().format('YYYY-MM-DD HH:mm:ss');
        this.auditEndDate = this.$moment(
          e.data.auditEndDate || this.$moment()
        ).format('YYYY-MM-DD HH:mm:ss');
        this.params.ordersRefundId =
          this.params.ordersRefundId || e.data.ordersRefundId;
        this.progress = e.data.refundStatus;
        this.setRefundStatus(e.data.refundStatus);
      });
    },
    revocation() {
      this.$ajax
        .get('/orders/refund/revocation', { ...this.params })
        .then(e => {
          if (e.status != 200) {
            this.$Notice.error({
              title: '撤销失败',
              desc: e.msg
            });
            return;
          }
          this.status.modal1 = false;
          this.jumpPage('fail');
        });
    },
    jumpPage(name) {
      this.$router.replace({
        name: name,
        query: { ...this.params }
      });
    },
    setRefundStatus(refundStatus) {
      /** 等待设计师处理            等待设计师审核 PENDING_DESIGNER_AUDIT(3, "等待设计师审核"), 等待总监审核 PENDING_MANAGER_AUDIT(6, "等待总监审核") */
      if (
        refundStatus == 'PENDING_DESIGNER_AUDIT' ||
        refundStatus == 'PENDING_MANAGER_AUDIT'
      ) {
        this.status.refundStatus = false;
        return;
      }
      /** 设计师已处理，退款中....  等待财务审核 PENDING_FINANCE_AUDIT(9, "等待财务审核"), 退款处理中  PROCESSING(18, "退款处理中") APPLY_SUCCESS(12) 申请成功 */
      if (
        refundStatus == 'PENDING_FINANCE_AUDIT' ||
        refundStatus == 'PROCESSING' ||
        refundStatus == 'APPLY_SUCCESS'
      ) {
        this.status.refundStatus = true;
        return;
      }
      /** 退款审核未通过            退款单已关闭 CLOSED(27, "退款单已关闭"); 退款失败 FAIL(24, "退款失败");APPLY_FAIL(15, "申请失败") */
      if (
        refundStatus == 'CLOSED' ||
        refundStatus == 'APPLY_FAIL' ||
        refundStatus == 'FAIL'
      ) {
        this.jumpPage('fail');
      }
      /** 退款完成                  退款成功 SUCCESS(21, "退款成功") */
      if (refundStatus == 'SUCCESS') {
        this.jumpPage('success');
      }
    }
  }
};
</script>


<style scoped>
.handlingCheck {
  background: #fff;
  padding: 36px 72px 42px;
  min-height: 431px;
}

.handlingCheck .status {
  padding-bottom: 12px;
  border-bottom: 1px solid #ddd;
}

.handlingCheck .status h1 {
  font-weight: 400;
  font-size: 24px;
  color: #434343;
  margin-bottom: 23px;
}

.handlingCheck .status p {
  font-size: 14px;
  color: #9b9b9b;
}

.handlingCheck .status .time {
  margin-left: 19px;
  padding-left: 24px;
  font-size: 14px;
  color: #f54203;
  position: relative;
}

.handlingCheck .status .time:before {
  content: '';
  position: absolute;
  top: 2px;
  left: 0;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  border: 1px solid #f88258;
}
.handlingCheck .status .time:after {
  content: '';
  position: absolute;
  top: 11px;
  left: 8px;
  width: 4px;
  height: 1px;
  background: #f88258;
}
.handlingCheck .status .time i {
  position: absolute;
  top: 6px;
  left: 8px;
  width: 1px;
  height: 5px;
  background: #f88258;
}

.handlingCheck .handle {
  margin-top: 31px;
}

.handlingCheck .handle .text {
  margin-bottom: 76px;
}

.handle .text li {
  font-size: 16px;
  color: #545454;
  margin-bottom: 24px;
  padding-left: 8px;
  position: relative;
}

.handle .text li::before {
  content: '';
  position: absolute;
  top: 8px;
  left: 0;
  width: 2px;
  height: 2px;
  background: #000;
}

.handle .text li:last-child {
  margin: 0;
}

.handlingCheck .handle .alter-btn {
  width: 191px;
  height: 35px;
  line-height: 35px;
  color: #fff;
  font-size: 18px;
  background: #f54203;
  padding: 0;
  margin-bottom: 23px;
}

.handlingCheck .handle .other {
  font-size: 18px;
  color: #757575;
}

.handlingCheck .handle .backout {
  margin-left: 10px;
  color: #0066ff;
}

.btn-group {
  font-size: 18px;
  overflow: hidden;
  margin: auto;
  width: 372px;
  margin-top: 38px;
}

.btn-group a {
  display: block;
  width: 166px;
  height: 42px;
  line-height: 42px;
  text-align: center;
  float: left;
  border-radius: 5px;
}
</style>
<style>
/* reund 垂直居中 */
.refund-vertical-center {
  display: flex;
  align-items: center;
  justify-content: center;
}
.refund-vertical-center .ivu-modal {
  top: 0;
}
.refund-vertical-center .ivu-modal-header {
  padding: 10px 0 0 0;
  border: none;
}
.refund-vertical-center .ivu-modal-footer {
  border: none;
}
.ivu-btn-primary {
  background-color: #f54203;
  border-color: #f54203;
}

.ivu-btn-primary:hover {
  background-color: #f54203;
  border-color: #f54203;
}
</style>
