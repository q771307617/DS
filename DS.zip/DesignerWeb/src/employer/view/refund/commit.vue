<template>
    <div class='commit-main box-shadow'>
        <div class='form'>
            <Row class="form-group">
                <Col span="3" class='label'>退款金额：</Col>
                <Col span="8" class='control input-money'>
                    <Input v-if="orderType !='HIRE_MONTH'" :number="true" ref='inputMoney' v-model="refundFee" placeholder="请输入退款金额" :disabled="editAble == '0' && orderType=='HIRE_CUSTOM'"></Input>
                </Col>
                <span v-if="editAble == '0' && orderType =='HIRE_MONTH'" class="red refundFee">{{refundFee}}元</span>
                <span v-if="orderType !='HIRE_MONTH'" class='remark'>(请与设计师沟通可退款金额)</span>
                <span v-if="editAble == '0' && orderType =='HIRE_MONTH' && remainDay" class='remark'>({{dayPrice}}元/天*{{remainDay}}天={{refundFee}}元，金额不能修改)</span>
            </Row>
            <Row class="form-group">
                <Col span="3" class='label'>退款原因：</Col>
                <Col span="12" class='control input-cause'>
                    <Input ref='inputIdea' v-model="refundMemo" :maxlength="250" type="textarea" :rows="8" placeholder="请输入退款原因"></Input>
                    <span class='tip'>250个汉字</span>
                </Col>
            </Row>
            <Row class="form-group">
                <p class="addInfo">温馨提醒：退款订单完成，即默认雇佣关系终止！</p>
                <Button class='sumit-btn' type="error" v-on:click="sumitHandle">提交</Button>
            </Row>
        </div>
    </div>
</template>

<script>
export default {
  data: function() {
    return {
      // price: '100',               //订单金额
      id: '', //订单编号
      type: '', //订单类型
      ordersRefundId: '', //退款单编号
      refundAll: '', //退款状态
      refundFee: '', //退款金额
      refundMemo: '', //退款原因
      dayPrice: '', //日薪
      remainDay: '', //天数
      orderFee: '', //订单总额、判断金额限制
      editAble: '', //是否可编辑
      orderType: '',
      refundStatus: '', //退款状态
      navType: '' //导航nav
    };
  },
  mounted() {
    let that = this;
    let type = this.$route.query.type; //订单类型
    const id = this.$route.query.id; //订单id
    this.navType = this.$route.query.navType;
    //status 订单状态
    //1 判断订单——需求 雇佣-定制 雇佣-包月
    //2 三天内退全款 不可更改 直接塞入值
    //3 包月，则显示退款金额
    this.id = id;
    this.type = type;
    const params = {
      id: id,
      type: type
    };

    //请求详情 金额+理由  //修改过来的页面
    this.$ajax.get('/orders/refund/detail', params).then(e => {
      if (e.status == 200) {
        this.refundFee = e.data.refundFee;
        this.refundMemo = e.data.refundMemo;
        this.ordersRefundId = e.data.ordersRefundId;
        this.refundStatus = e.data.refundStatus;
        that.orderFee = e.data.orderFee; //订单总额

        //判断需要调整
        this.editAble = e.data.editAble;
        this.orderType = e.data.orderType;
        if (this.editAble) {
          //可编辑 申请
        } else if (this.orderType == 'HIRE_MONTH') {
          //不可编辑 包月

          that.dayPrice = e.data.dayPrice; //日薪
          that.remainDay = e.data.remainDay; //天数
        } else if (this.orderType == 'HIRE_CUSTOM') {
          //退全款
        }

        //重定向&&清数据
        this.setRefundStatus(this.refundStatus);
      }
    });
  },
  methods: {
    //定向到相应页面
    setRefundStatus(refundStatus) {
      /** 等待设计师处理            等待设计师审核 PENDING_DESIGNER_AUDIT(3, "等待设计师审核"), 等待总监审核 PENDING_MANAGER_AUDIT(6, "等待总监审核") */
      if (refundStatus == 'PENDING_MANAGER_AUDIT') {
        this.routerJump('check');
        return;
      }
      if (refundStatus == 'PENDING_DESIGNER_AUDIT') {
        //修改
      }

      /** 设计师已处理，退款中....  等待财务审核 PENDING_FINANCE_AUDIT(9, "等待财务审核"), 退款处理中  PROCESSING(18, "退款处理中") APPLY_SUCCESS(12) 申请成功 */
      if (
        refundStatus == 'PENDING_FINANCE_AUDIT' ||
        refundStatus == 'PROCESSING' ||
        refundStatus == 'APPLY_SUCCESS'
      ) {
        this.routerJump('check');
        return;
      }
      /** 退款审核未通过            退款单已关闭 CLOSED(27, "退款单已关闭"); 退款失败 FAIL(24, "退款失败");APPLY_FAIL(15, "申请失败") */
      if (
        refundStatus == 'CLOSED' ||
        refundStatus == 'APPLY_FAIL' ||
        refundStatus == 'FAIL'
      ) {
        //清数据
        if (this.editAble) {
          this.refundFee = '';
        } else {
        }
        this.refundMemo = '';
        this.ordersRefundId = null;
      }
      /** 退款完成                  退款成功 SUCCESS(21, "退款成功") */
      if (refundStatus == 'SUCCESS') {
        this.routerJump('success');
      }
    },
    //提交申请
    sumitHandle() {
      const that = this;
      this.getNumber();

      if (this.isNull(this.refundFee)) {
        this.$Notice.error({
          title: '退款金额不能为空！'
        });
        this.$refs.inputMoney.focus();
        return;
      }
      if (isNaN(this.refundFee)) {
        this.$Notice.error({
          title: '请输入数值！'
        });
        this.refundFee = 0;
        return;
      }
      if (this.refundFee < 0.01) {
        this.$Notice.error({
          title: '最小退款金额0.01元！'
        });
        this.refundFee = 0.01;
        return;
      }
      if (this.refundFee > this.orderFee) {
        this.$Notice.error({
          title: '退款金额不能大于订单金额！'
        });
        this.$refs.inputMoney.focus();
        return;
      }
      if (this.isNull(this.refundMemo)) {
        this.$Notice.error({
          title: '退款理由不能为空！'
        });
        this.$refs.inputIdea.focus();
        return;
      }

      if (this.ordersRefundId) {
        //修改申请
        const params = {
          ordersRefundId: this.ordersRefundId,
          refundFee: this.refundFee,
          refundMemo: this.refundMemo,
          refundReason: 0
        };
        this.$ajax.post('/orders/refund/update', params).then(e => {
          if (e.status == 200) {
            that.routerJump('check');
          } else {
            this.$Notice.error({
              title: '修改失败，请刷新页面或者重新登录！'
            });
          }
        });
        return;
      }
      //第一次申请
      const params = {
        id: this.id,
        refundFee: this.refundFee,
        refundMemo: this.refundMemo,
        refundReason: 0,
        type: this.type
      };
      //提交接口
      this.$ajax.post('/orders/refund/add', params).then(e => {
        if (e.status == 200) {
          that.routerJump('check');
        } else {
          this.$Notice.error({
            title: '提交失败，请刷新页面或者重新登录！'
          });
        }
      });
    },
    routerJump(route) {
      this.$router.replace({
        name: route,
        query: {
          id: this.id,
          type: this.type,
          navType: this.navType //导航nav
        }
      });
    },
    getNumber() {
      this.orderFee = Number(this.orderFee);
      this.refundFee = Number(this.refundFee);
    },
    isNull(v) {
      if (v == '' || v == undefined || v == null) {
        return true;
      }
      return false;
    }
  }
};
</script>

<style>
.commit .input-money .ivu-input {
  line-height: 26px;
  height: 26px;
}
.commit .input-cause .ivu-input {
  height: 245px;
}
</style>
<style scoped>
.red {
  color: #f54203 !important;
}
.commit {
  line-height: 1;
  font-size: 16px;
  font-family: '微软雅黑';
  margin-bottom: 5px;
}
.commit:after {
  content: '';
  display: table;
  clear: both;
}
/* 主栏 */
.commit-main {
  float: left;
  width: 802px;
  background: #fff;
  /* min-height: 775px; */
}
/* 表单 */
.commit-main .form {
  padding-top: 50px;
  padding-bottom: 32px;
}
.commit-main .form .form-group {
  margin-bottom: 18px;
  padding-left: 72px;
}
.commit-main .form .form-group:last-child {
  margin: 0;
}
.refundFee {
  line-height: 26px;
  height: 26px;
}
.form-group .label {
  text-align: right;
  line-height: 26px;
  padding-right: 35px;
  width: auto;
  position: relative;
  color: #575757;
}
.form-group .label:after {
  content: '*';
  color: red;
  position: absolute;
  right: 6px;
  top: 0;
}
.form-group .control {
  position: relative;
}
.form-group .input-money {
  width: 200px;
}
.form-group .input-cause {
  width: 544px;
}
.form-group .remark {
  text-align: right;
  line-height: 26px;
  font-size: 14px;
  color: #8c8c8c;
  margin-left: 14px;
}
.form-group .tip {
  position: absolute;
  right: 10px;
  bottom: 9px;
  font-size: 14px;
  color: #8c8c8c;
}
.form-group .sumit-btn {
  width: 191px;
  height: 35px;
  line-height: 35px;
  color: #fff;
  font-size: 18px;
  background: #f54203;
  padding: 0;
  margin-left: 115px;
}
.form-group .addInfo {
  margin: 0 0 30px 115px;
  color: #575757;
}
</style>
