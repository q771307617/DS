<template>
    <div class='handlingSucess box-shadow'>
        <div class='title'>
            <h1>退款完成</h1>
            <p class='tip'>温馨提醒：由于第三方平台原因，可能出现退款延时到账的情况。请耐心等待！</p>
        </div>
        <p>退款已完成，退款金额已打入您的账号，请及时查收</p>
        <p class='time'>处理时间：{{ gmtModified }}</p>
    </div>
</template>

<script>
export default {
  data: function() {
    return {
      gmtModified: '',
      params: {
        id: '' /** 订单号 */,
        type:
          '' /** 订单类型: DEMAND(需求订单)，HIRE_CUSTOM(定制雇佣订单)，HIRE_MONTH(包月雇佣订单) */
        /**
                 * 等待设计师处理            等待设计师审核 PENDING_DESIGNER_AUDIT(3, "等待设计师审核"), 等待总监审核 PENDING_MANAGER_AUDIT(6, "等待总监审核"),
                 * 设计师已处理，退款中....  等待财务审核 PENDING_FINANCE_AUDIT(9, "等待财务审核"), 退款处理中  PROCESSING(18, "退款处理中"),
                 * 退款审核未通过            退款单已关闭 CLOSED(27, "退款单已关闭"); 退款失败 FAIL(24, "退款失败"),
                 * 退款完成                  退款成功 SUCCESS(21, "退款成功")
                 */
      }
    };
  },
  mounted() {
    this.params.id = this.$route.query.id || '';
    this.params.type = this.$route.query.type || '';
    this.getInfo();
  },
  methods: {
    getInfo() {
      this.$ajax.get('/orders/refund/detail', { ...this.params }).then(e => {
        if (e.status != 200) {
          return;
        }
        this.gmtModified = this.$moment(
          e.data.gmtModified || this.$moment()
        ).format('YYYY-MM-DD HH:mm:ss');
      });
    }
  }
};
</script>


<style scoped>
.handlingSucess {
  background: #fff;
  height: 271px;
  padding: 36px 72px 37px;
}
.handlingSucess .title {
  padding-bottom: 12px;
  border-bottom: 1px solid #ddd;
  margin-bottom: 30px;
}
.handlingSucess h1 {
  font-size: 24px;
  color: #575757;
  margin-bottom: 22px;
}
.handlingSucess .tip {
  font-size: 14px;
  color: #9b9b9b;
}
.handlingSucess p {
  font-size: 16px;
  color: #575757;
}
.handlingSucess .time {
  font-size: 14px;
  color: #8c8c8c;
  margin-top: 80px;
}
</style>
