<template>

        <div class="main">
            <div class="clearfix" style="position: relative;background: #fafafa;">
                <div class='refund-nav'>
                    <span>您的位置:</span>
                    <ul>
                        <li><a href="/">首页</a>></li>
                        <li><router-link :to="{ name: 'EmloyerHome' }">雇主平台</router-link>></li>
                        <li><router-link class='ac' :to="{name: navInfo.path}">{{navInfo.name}}</router-link></li>
                    </ul>
                </div>
                <schedule :active="active"></schedule>
                <div class='handling'>
                    <div class='handling-main'>
                        <router-view></router-view>
                      <log :log="log"   v-if="active != 1" />

                        <commonProblem v-else />

                    </div>
                    <orderInfo :info="info" :page="active" />
                </div>
            </div>
        </div>
</template>

<script>
import schedule from '@/employer/components/refund/schedule';
import orderInfo from '@/employer/components/refund/order-info';
import commonProblem from '@/employer/components/refund/common-problem';
import log from '@/employer/components/refund/log';

export default {
  data() {
    return {
      active: '', //1 2 3:1 3:2 4    退款状态
      order: [
        {
          id: '1',
          name: '需求管理',
          path: 'demandManagentTable'
        },
        {
          id: '2',
          name: '雇佣管理',
          path: 'employmentManagement'
        },
        {
          id: '3',
          name: '交易记录',
          path: 'refundLog'
        }
      ],
      navInfo: {}, //导航
      info: {}, //详情
      log: {} /** 日志 */
    };
  },
  components: {
    schedule,
    orderInfo,
    commonProblem,
    log
  },
  methods: {
    setActive() {
      let state = this.$route.fullPath.match(/\/(\d+)/g);
      this.active = state[0].match(/\d+/g)[0];

      let that = this;
      const index = this.$route.query.navType;
      this.order.forEach(function(elem) {
        if (elem.id == index) {
          that.navInfo = { ...elem };
        }
      });
    },
    getOrdersRefundId(ordersRefundId) {
      this.$ajax
        .get('/orders/refund/opt/list', { ordersRefundId: ordersRefundId })
        .then(e => {
          if (e.status != 200) {
            return;
          }
          this.log = e.data;
        });
    },
    getData() {
      const that = this;
      const type = this.$route.query.type; //订单类型
      const id = this.$route.query.id; //订单id
      const ordersRefundId = this.$route.query.ordersRefundId || ''; //订单id
      this.$ajax
        .get('/orders/refund/detail', {
          type: type,
          id: id,
          ordersRefundId: ordersRefundId
        })
        .then(e => {
          if (e.status == 200) {
            that.info = e.data;
            that.getOrdersRefundId(e.data.ordersRefundId);
          }
        });
    }
  },
  mounted() {
    this.setActive();

    this.getData();
  },
  watch: {
    $route: function() {
      this.setActive();

      this.getData();
    }
  }
};
</script>

<style scoped>
.nav {
  height: 73px;
}
.nav li {
  height: 73px;
  line-height: 73px;
  min-width: 100px;
  cursor: pointer;
  float: left;
  padding: 0 10px;
  text-align: center;
}
.nav li:first-child {
  font-size: 30px;
  width: 292px;
  font-weight: bold;
}
.layout {
  position: relative;
}
.layout .main {
  width: 1200px;
  margin: 0 auto;
}
.layout-ceiling-main {
  width: 1200px;
  margin: 0 auto;
  color: #fff;
}
.layout-ceiling-main .title {
  text-align: left;
  color: #fff;
}
.layout-ceiling-right {
  height: 73px;
  line-height: 73px;
  text-align: right;
}
.layout-ceiling-main a {
  color: #9ba7b5;
}
.layout-menu-left {
  position: relative;
  margin-top: 15px;
}
.layout-menu-left {
  background-color: #fff;
  width: 283px;
}
.layout-menu-left .kf {
  padding: 58px;
  text-align: center;
}
.layout-menu-left .kf .kf-font {
  color: #818181;
  display: inline-flex;
}
.layout-menu-left .kf .kf-font img {
  width: 22px;
}
.user-exit {
  cursor: pointer;
  position: absolute;
  height: 50px;
  line-height: 50px;
  width: 100%;
  background-color: #f54000;
  left: 0;
  z-index: 200;
  text-align: center;
}

/* 公共 */
.refund-nav {
  line-height: 1;
  font-size: 16px;
  font-family: '微软雅黑';
  margin: 33px 0 15px;
}
.refund-nav:after {
  content: '';
  display: table;
  clear: both;
}
.refund-nav span {
  float: left;
  margin-right: 5px;
  color: rgba(75, 75, 75, 0.8);
}
.refund-nav ul {
  float: left;
}
.refund-nav ul:after {
  content: '';
  display: table;
  clear: both;
}
.refund-nav li {
  float: left;
  color: rgba(123, 123, 123, 0.8);
}
.refund-nav li a {
  color: rgba(123, 123, 123, 0.8);
}
.refund-nav li a.ac {
  color: rgba(245, 66, 3, 0.8);
}

.handling {
  line-height: 1;
  font-size: 16px;
  font-family: '微软雅黑';
  margin-bottom: 5px;
}
.handling:after {
  content: '';
  display: table;
  clear: both;
}
/* 主栏 */
.handling-main {
  float: left;
  width: 802px;
  min-height: 775px;
  display: flex;
  flex-direction: column;
}
</style>
