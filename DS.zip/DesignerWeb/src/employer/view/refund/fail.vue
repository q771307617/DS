<template>
    <div>
      <div v-if="status.refundStatus" class="handlingFail box-shadow">
        <div class='status'>
          <h1>退款审核未通过</h1>
          <p>设计师拒绝了您的退款申请，您可在时限内重新申请退款。</p>
        </div>
        <div class='handle'>
          <div class='text'>
            <p>驳回原因：{{params.auditMsg}}</p>
          </div>
          <p class='time'>处理时间：{{gmtModified}}</p>
          <Button class='afresh-btn' type="error" @click="add">重新申请</Button>
          <p class='other'>您还可以：<a @click="status.modal1 = true" href="javascript:;">撤销申请</a></p>
        </div>
      </div>
      <div v-else class='handlingFail box-shadow close'>
        <h1>退款关闭</h1>
        <p>因您撤销退款申请，退款已关闭，交易正常进行，请及时关注。</p>
        <p class='time'>处理时间：{{gmtModified}}</p>
      </div>

      <Modal v-model="status.modal1" width="769">
        <p slot="header"></p>
        <p style="font-size: 20px;color: #575757;text-align: center;">撤销本次申请，如果问题未解决，您还可再次申请。确定继续吗？</p>
        <div class="btn-group">
          <a @click="revocation" href="javascript:;" style="background-color: #f54203;border: 1px solid #f54203;color: #fff;">确认</a>
          <a @click="status.modal1 = false" href="javascript:;" style="color: #6a6a6a;border: 1px solid #afafaf;margin-left: 38px;">取消</a>
        </div>
        <div slot="footer"></div>
      </Modal>
    </div>
</template>

<script>
export default {
  data: function() {
    return {
      gmtModified: '',
      status: {
        modal1: false,
        refundStatus: true
      },
      params: {
        id: '' /** 订单号 */,
        type:
          '' /** 订单类型: DEMAND(需求订单)，HIRE_CUSTOM(定制雇佣订单)，HIRE_MONTH(包月雇佣订单) */,
        /**
                 * 等待设计师处理            等待设计师审核 PENDING_DESIGNER_AUDIT(3, "等待设计师审核"), 等待总监审核 PENDING_MANAGER_AUDIT(6, "等待总监审核"),
                 * 设计师已处理，退款中....  等待财务审核 PENDING_FINANCE_AUDIT(9, "等待财务审核"), 退款处理中  PROCESSING(18, "退款处理中"), APPLY_SUCCESS(12) 申请成功
                 * 退款审核未通过            退款单已关闭 CLOSED(27, "退款单已关闭"); 退款失败 FAIL(24, "退款失败"),
                 * 退款完成                  退款成功 SUCCESS(21, "退款成功")
                 */
        refundMemo: '',
        ordersRefundId: '',
        navType: ''
      }
    };
  },
  mounted() {
    this.params.id = this.$route.query.id || '';
    this.params.type = this.$route.query.type || '';
    this.params.navType = this.$route.query.navType || '';
    this.params.ordersRefundId = this.$route.query.ordersRefundId || '';
    this.getInfo();
  },
  methods: {
    getInfo() {
      this.$ajax.get('/orders/refund/detail', { ...this.params }).then(e => {
        if (e.status != 200) {
          return;
        }
        this.gmtModified = this.$moment(
          e.data.gmtModified || this.$moment()
        ).format('YYYY-MM-DD HH:mm:ss');
        this.params.refundMemo = e.data.refundMemo;
        this.params.ordersRefundId =
          this.params.ordersRefundId || e.data.ordersRefundId;
        this.params.auditMsg = e.data.auditMsg;
        this.setRefundStatus(e.data.refundStatus);
      });
    },
    revocation() {
      this.$ajax
        .get('/orders/refund/revocation', { ...this.params })
        .then(e => {
          if (e.status != 200) {
            this.$Notice.error({
              title: '撤销失败',
              desc: e.msg
            });
            return;
          }
          this.status.modal1 = false;
          this.getInfo();
        });
    },
    setRefundStatus(refundStatus) {
      /** 等待设计师处理            等待设计师审核 PENDING_DESIGNER_AUDIT(3, "等待设计师审核"), 等待总监审核 PENDING_MANAGER_AUDIT(6, "等待总监审核") */
      if (
        refundStatus == 'PENDING_DESIGNER_AUDIT' ||
        refundStatus == 'PENDING_MANAGER_AUDIT'
      ) {
        this.jumpPage('check');
        return;
      }
      /** 设计师已处理，退款中....  等待财务审核 PENDING_FINANCE_AUDIT(9, "等待财务审核"), 退款处理中  PROCESSING(18, "退款处理中")  APPLY_SUCCESS(12) 申请成功 */
      if (
        refundStatus == 'PENDING_FINANCE_AUDIT' ||
        refundStatus == 'PROCESSING' ||
        refundStatus == 'APPLY_SUCCESS'
      ) {
        this.jumpPage('check');
        return;
      }
      /** 退款审核未通过            退款单已关闭 CLOSED(27, "退款单已关闭"); 退款失败 FAIL(24, "退款失败");APPLY_FAIL(15, "申请失败") */
      if (refundStatus == 'CLOSED') {
        this.status.refundStatus = false;
        return;
      }
      /** 退款审核未通过            退款单已关闭 CLOSED(27, "退款单已关闭"); 退款失败 FAIL(24, "退款失败");APPLY_FAIL(15, "申请失败") */
      if (refundStatus == 'APPLY_FAIL' || refundStatus == 'FAIL') {
        this.status.refundStatus = true;
        return;
      }
      /** 退款完成                  退款成功 SUCCESS(21, "退款成功") */
      if (refundStatus == 'SUCCESS') {
        this.jumpPage('success');
      }
    },
    jumpPage(name) {
      this.$router.replace({
        name: name,
        query: { ...this.params }
      });
    },
    add() {
      let params = { ...this.params };
      params.refundMemo = '';
      this.$router.replace({
        name: 'commit',
        query: params
      });
    }
  }
};
</script>


<style scoped>
.handlingFail {
  background: #fff;
  padding: 36px 72px 37px;
  min-height: 429px;
}
.handlingFail.close {
  min-height: auto;
  height: 271px;
  padding: 36px 72px 37px;
}
.handlingFail.close h1 {
  font-size: 24px;
  color: #575757;
  margin-bottom: 22px;
}
.handlingFail.close p {
  font-size: 16px;
  color: #575757;
  margin-bottom: 102px;
}
.handlingFail.close .time {
  font-size: 14px;
  color: #8c8c8c;
}

.handlingFail .status {
  padding-bottom: 12px;
  border-bottom: 1px solid #ddd;
}
.handlingFail .status h1 {
  font-weight: 400;
  font-size: 24px;
  color: #434343;
  margin-bottom: 23px;
}
.handlingFail .status p {
  font-size: 14px;
  color: #9b9b9b;
}

.handlingFail .handle {
  margin-top: 18px;
}
.handlingFail .handle .text {
  /* margin-bottom: 76px; */
}
.handle .text p {
  font-size: 16px;
  color: #545454;
  margin-bottom: 24px;
}
.handlingFail .handle .time {
  font-size: 14px;
  color: #8c8c8c;
  margin-bottom: 48px;
}
.handlingFail .handle .afresh-btn {
  width: 191px;
  height: 35px;
  line-height: 35px;
  color: #fff;
  font-size: 18px;
  background: #f54203;
  padding: 0;
  margin-bottom: 23px;
}
.handlingFail .handle .other {
  font-size: 18px;
  color: #757575;
}
.handlingFail .handle .backout {
  margin-left: 10px;
  color: #0066ff;
}
.btn-group {
  font-size: 18px;
  overflow: hidden;
  margin: auto;
  width: 372px;
  margin-top: 38px;
}

.btn-group a {
  display: block;
  width: 166px;
  height: 42px;
  line-height: 42px;
  text-align: center;
  float: left;
  border-radius: 5px;
}
</style>
