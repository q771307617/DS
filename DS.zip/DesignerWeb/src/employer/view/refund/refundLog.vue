<template>
  <div>
    <div style="margin-bottom: 10px;border-bottom: 10px solid #fafafa;padding: 20px;background-color: #fff;">
      <ul class="statistics-ul">
        <li>
          <span class="font20 color646464">钱包总额</span>
          <br>
          <span class="font20 f54203">{{info.totalAmount}}元</span>
        </li>
        <li>
          <span class="font20 color646464">平台监管金额</span>
          <br>
          <span class="font20 f54203">{{info.deposit}}元</span>
        </li>
        <li>
          <span class="font20 color646464">账户余额</span>
          <br>
          <span class="font20 f54203">{{info.balance}}元</span>
        </li>
        <div style="display: inline-block">
          <div>
            <Button style="margin-bottom: 10px;background-color: #ed3f14;color: #fff;" @click="recharge">充值</Button>
            <Button style="margin-bottom: 10px;background-color: #9e9e9e;color: #fff;margin-left: 6px;" @click="cash">
              提现
            </Button>
          </div>
        </div>
      </ul>
    </div>
    <div style="padding: 10px 20px;background-color: #fff;">
      <div style="border-bottom: 1px solid #e9eaec;margin-bottom: 10px;padding-bottom: 10px;"
           class="font16 color646464">
        <a class="color646464 link" @click="tradingRecord">交易记录</a>
        <a class="color646464 link" @click="cashRecord">提现记录</a>
        <a class="f54203">退款记录</a>
      </div>
      <div style="margin-bottom: 20px;">
        <span>查询</span>
        <Date-picker v-model="params.startTime" @on-change="handleBeginPicker" :editable="false" :clearable="false"
                     type="date" placeholder="开始日期" style="width: 200px;display: inline-block;"></Date-picker>
        <span>至</span>
        <Date-picker v-model="params.endTime" :options="options" :editable="false" :clearable="false" type="date"
                     placeholder="结束日期" style="width: 200px;display: inline-block;"></Date-picker>
        <Button type="error" @click="search">查询</Button>
        <ul class="time-link-ul">
          <li>最近</li>
          <li>
            <a href="javascript:;" @click="limitDate(1,'weeks')">一周</a>
          </li>
          <li>
            <a href="javascript:;" @click="limitDate(1,'months')">1个月</a>
          </li>
          <li>
            <a href="javascript:;" @click="limitDate(3,'months')">3个月</a>
          </li>
          <li>
            <a href="javascript:;" @click="limitDate(1,'years')">1年</a>
          </li>
        </ul>
      </div>
      <div style="min-height:400px">
        <Table border :columns="columns" :data="data"></Table>
      </div>
      <Page :total="params.total"
            :current="params.pageNum"
            :page-size="params.pageSize"
            @on-change="paging"
            show-total
            show-elevator
            class="float-right page page-style" style="margin-top: 20px;"></Page>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex';
import moment from 'moment';
// import Constant from '@/constant/index';
export default {
  data() {
    return {
      orderTypeList: {
        DEMAND: '需求',
        HIRE_CUSTOM: '定制雇佣',
        HIRE_MONTH: '包月雇佣'
      },
      refundStatusList: {
        PENDING_DESIGNER_AUDIT:
          '审核中' /** PENDING_DESIGNER_AUDIT(3, "等待设计师审核") */,
        PENDING_MANAGER_AUDIT: '审核中' /** PENDING_MANAGER_AUDIT(6, "等待总监审核") */,
        PENDING_FINANCE_AUDIT: '审核中' /** PENDING_FINANCE_AUDIT(9, "等待财务审核") */,
        PROCESSING: '审核中' /** PROCESSING(18, "退款处理中") */,
        APPLY_SUCCESS: '审核中' /** APPLY_SUCCESS(12) 申请成功 */,
        CLOSED: '已取消' /** CLOSED(27, "退款单已关闭") */,
        FAIL: '已取消' /** FAIL(24, "退款失败") */,
        APPLY_FAIL: '已取消' /** APPLY_FAIL(15, "申请失败") */,
        SUCCESS: '已完成' /** SUCCESS(21, "退款成功") */
      },
      payTypeList: ['账户余额', '支付宝', '微信'],
      id: '',
      params: {
        startTime: moment().subtract(1, 'weeks'),
        endTime: moment(),
        total: 0,
        pageNum: 1,
        pageSize: 10
      },
      options: {
        disabledDate: date => {
          return (
            date && date.valueOf() < this.params.startTime.valueOf() - 86400000
          );
        }
      },
      data: [],
      columns: [
        {
          width: 140,
          title: '时间',
          align: 'center',
          key: 'refundCreate',
          render: (h, params) => {
            return h(
              'span',
              `${moment(params.row.refundCreate).format('YYYY/M/DD HH:mm')}`
            );
          }
        },
        {
          width: 220,
          title: '流水号/订单号',
          align: 'center',
          key: 'refundNo'
        },
        {
          width: 140,
          title: '交易类型',
          key: 'orderType',
          align: 'center',
          render: (h, params) => {
            return h('span', this.orderTypeList[params.row.orderType] + '退款');
          }
        },
        {
          title: '退款金额',
          key: 'refundFee',
          align: 'center',
          render: (h, params) => {
            return h('span', params.row.refundFee + '元');
          }
        },
        {
          title: '交易渠道',
          key: 'refundChannel',
          align: 'center',
          render: (h, params) => {
            return h('span', this.payTypeList[params.row.refundChannel]);
          }
        },
        {
          title: '交易状态',
          key: 'refundStatus',
          align: 'center',
          render: (h, params) => {
            return h('span', this.refundStatusList[params.row.refundStatus]);
          }
        },
        {
          title: '备注',
          key: 'refundStatus',
          align: 'center',
          render: (h, params) => {
            return h(
              'Button',
              {
                props: { size: 'small' },
                on: {
                  click: () => {
                    this.goInfo(params.row);
                  }
                }
              },
              '详情'
            );
          }
        }
      ]
    };
  },
  computed: {
    ...mapState({
      info: state => state.User.info
    })
  },
  methods: {
    goInfo(info) {
      let refundStatus = info.refundStatus;
      let params = {
        navType: 3,
        id: info.id,
        type: info.orderType,
        ordersRefundId: info.ordersRefundId
      };

      /** 等待设计师处理            等待设计师审核 PENDING_DESIGNER_AUDIT(3, "等待设计师审核"), 等待总监审核 PENDING_MANAGER_AUDIT(6, "等待总监审核") */
      if (
        refundStatus == 'PENDING_DESIGNER_AUDIT' ||
        refundStatus == 'PENDING_MANAGER_AUDIT'
      ) {
        this.jumpPage('check', params);
        return;
      }
      /** 设计师已处理，退款中....  等待财务审核 PENDING_FINANCE_AUDIT(9, "等待财务审核"), 退款处理中  PROCESSING(18, "退款处理中") || APPLY_SUCCESS(12) 申请成功  */
      if (
        refundStatus == 'PENDING_FINANCE_AUDIT' ||
        refundStatus == 'PROCESSING' ||
        refundStatus == 'APPLY_SUCCESS'
      ) {
        this.jumpPage('check', params);
        return;
      }
      /** 退款审核未通过            退款单已关闭 CLOSED(27, "退款单已关闭"); 退款失败 FAIL(24, "退款失败");APPLY_FAIL(15, "申请失败") */
      if (
        refundStatus == 'CLOSED' ||
        refundStatus == 'APPLY_FAIL' ||
        refundStatus == 'FAIL'
      ) {
        this.jumpPage('fail', params);
      }
      /** 退款完成                  退款成功 SUCCESS(21, "退款成功") */
      if (refundStatus == 'SUCCESS') {
        this.jumpPage('success', params);
      }
    },
    jumpPage(name, params) {
      this.$router.push({
        name: name,
        query: params
      });
    },
    handleBeginPicker(date) {
      this.params.endTime = date;
    },
    recharge() {
      this.$router.push({ name: 'recharge' });
    },
    cash() {
      this.$router.push({ name: 'cash' });
    },
    cashRecord() {
      this.$router.push({ name: 'cashRecord' });
    },
    tradingRecord() {
      this.$router.push({ name: 'trading_record_table' });
    },
    limitDate(n, u) {
      this.params.startTime = moment().subtract(n, u);
      this.params.endTime = moment();
      this.fetchData();
    },
    paging(pageNum) {
      this.params.pageNum = pageNum;
      this.fetchData();
    },
    search() {
      this.params.pageNum = 1;
      this.fetchData();
    },
    fetchData() {
      let params = { ...this.params };
      params.startTime = this.$utils.time.startTime(
        this.params.startTime,
        'YYYY-MM-DD HH:mm:ss'
      );
      params.endTime = this.$utils.time.endTime(
        this.params.endTime,
        'YYYY-MM-DD HH:mm:ss'
      );
      this.$ajax.get('/orders/refund/list', params).then(e => {
        if (e.status !== 200) {
          this.data = [];
          this.params.total = 0;
          return;
        }
        this.data = e.data.list;
        this.params.total = e.data.count;
      });
    }
  },
  mounted() {
    this.fetchData();
  }
};
</script>
<style scoped>
.statistics-ul {
  display: inline-block;
}

.statistics-ul li {
  width: 212px;
  border-left: 1px solid #e5e5e5;
  padding: 10px 20px;
  display: inline-block;
}

.statistics-ul li:first-child {
  padding-left: 0;
  border-left: none;
}

.time-link-ul {
  display: inline-block;
}

.time-link-ul li {
  padding: 0 10px;
  border-right: 1px solid #e9eaec;
  display: inline-block;
}

.time-link-ul li:last-child {
  border-right: none;
}

.time-link-ul li a {
  color: #f54203;
}

.link {
  margin-right: 10px;
}

.link:hover {
  color: #f54203;
}

.color646464 {
  color: #646464;
}

.f54203 {
  color: #f54203;
}
</style>
