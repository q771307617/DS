<template>
    <div>
        <div style="margin-bottom: 10px;border-bottom: 10px solid #fafafa;padding: 20px;background-color: #fff;">
            <ul class="statistics-ul">
                <li>
                    <span class="font20 color646464">钱包总额</span>
                    <br>
                    <span class="font20 f54203">{{info.totalAmount}}元</span>
                </li>
                <li>
                    <span class="font20 color646464">平台监管金额</span>
                    <br>
                    <span class="font20 f54203">{{info.deposit}}元</span>
                </li>
                <li>
                    <span class="font20 color646464">账户余额</span>
                    <br>
                    <span class="font20 f54203">{{info.balance}}元</span>
                </li>
                <div style="display: inline-block">
                    <div>
                        <Button style="margin-bottom: 10px;background-color: #ed3f14;color: #fff;" @click="recharge">充值</Button>
                        <Button style="margin-bottom: 10px;background-color: #9e9e9e;color: #fff;margin-left: 6px;" @click="cash">提现</Button>
                    </div>
                </div>
            </ul>
        </div>
        <div style="padding: 10px 20px;background-color: #fff;">
            <div style="border-bottom: 1px solid #e9eaec;margin-bottom: 10px;padding-bottom: 10px;" class="font16 color646464">
              <a class="color646464 link" @click="tradingRecord">交易记录</a>
              <a class="f54203 " >提现记录</a>
              <a class="color646464 link" style="margin-left: 10px;" @click="refundLog">退款记录</a>
            </div>
            <div style="margin-bottom: 20px;">
                <span>查询</span>
                <Date-picker v-model="startTime" @on-change="handleBeginPicker" :editable="false" :clearable="false" type="date" placeholder="开始日期" style="width: 200px;display: inline-block;"></Date-picker>
                <span>至</span>
                <Date-picker v-model="endTime" :options="options" :editable="false" :clearable="false" type="date" placeholder="结束日期" style="width: 200px;display: inline-block;"></Date-picker>
                <Button type="error" @click="search">查询</Button>
                <ul class="time-link-ul">
                    <li>最近</li>
                    <li>
                        <a href="javascript:;" @click="limitDate(1,'weeks')">一周</a>
                    </li>
                    <li>
                        <a href="javascript:;" @click="limitDate(1,'months')">1个月</a>
                    </li>
                    <li>
                        <a href="javascript:;" @click="limitDate(3,'months')">3个月</a>
                    </li>
                    <li>
                        <a href="javascript:;" @click="limitDate(1,'years')">1年</a>
                    </li>
                </ul>
            </div>
            <div style="min-height:400px">
            <Table border :columns="cash_columns" :data="cash_data"></Table>
            </div>
            <Page :total="total" :current="pageNum" :page-size="pageSize" @on-change="paging" show-total show-elevator class="float-right page page-style" style="margin-top: 20px;"></Page>
        </div>
    </div>
</template>

<script>
import { mapState } from 'vuex';
import moment from 'moment';
// import Constant from '@/constant/index';
export default {
  computed: {
    ...mapState({
      info: state => state.User.info
    })
  },
  methods: {
    handleBeginPicker(date) {
      this.endTime = date;
    },
    recharge() {
      this.$router.push({ name: 'recharge' });
    },
    cash() {
      this.$router.push({ name: 'cash' });
    },
    refundLog() {
      this.$router.push({ name: 'refundLog' });
    },
    tradingRecord() {
      this.$router.push({ name: 'trading_record_table' });
    },
    limitDate(n, u) {
      this.startTime = moment().subtract(n, u);
      this.endTime = moment();
    },
    paging(pageNum) {
      this.pageNum = pageNum;
      this.fetchData();
    },
    search() {
      this.pageNum = 1;
      this.fetchData();
    },
    fetchData() {
      const params = {
        startTime:
          (this.startTime &&
            moment(
              this.$utils.time.startTime(this.startTime, 'YYYY-MM-DD HH:mm:ss')
            ).format('x')) ||
          0,
        endTime:
          (this.endTime &&
            moment(
              this.$utils.time.endTime(this.endTime, 'YYYY-MM-DD HH:mm:ss')
            ).format('x')) ||
          moment().format('x'),
        pageNum: this.pageNum,
        pageSize: this.pageSize
      };
      this.$ajax.get('withdraw/list', params).then(e => {
        if (e.status !== 200) {
          this.cash_data = [];
          this.total = 0;
          return;
        }
        this.cash_data = e.data.list;
        this.total = e.data.count;
      });
    }
  },
  mounted() {
    this.fetchData();
  },
  data() {
    return {
      remittance: {
        //提现交易状态
        3: '审核中',
        6: '申请成功',
        9: '申请失败',
        12: '处理中',
        15: '提现成功',
        18: '提现失败'
      },
      id: '',
      startTime: moment().subtract(1, 'weeks'),
      endTime: moment(),
      total: 0,
      pageNum: 1,
      pageSize: 10,
      options: {
        disabledDate: date => {
          return date && date.valueOf() < this.startTime.valueOf() - 86400000;
        }
      },
      cash_data: [],
      cash_columns: [
        {
          width: 140,
          title: '时间',
          align: 'center',
          key: 'gmtCreate',
          render: (h, params) => {
            return h(
              'span',
              `${moment(params.row.gmtCreate).format('YYYY/M/DD HH:mm')}`
            );
          }
        },
        {
          width: 220,
          title: '流水号/订单号',
          align: 'center',
          key: 'remittanceNo'
        },
        {
          width: 140,
          title: '交易类型',
          key: 'type',
          align: 'center',
          render: (h, params) => {
            return h('span', '提现');
          }
        },
        {
          title: '提现金额',
          key: 'fee',
          align: 'center',
          render: (h, params) => {
            return h('span', `${params.row.fee}元`);
          }
        },
        {
          title: '交易渠道',
          key: 'channel',
          align: 'center',
          render: (h, params) => {
            if (params.row.remittanceType == 1) {
              return h('span', '支付宝');
            }
            if (params.row.remittanceType == 2) {
              return h('span', '微信');
            }
          }
        },
        {
          title: '交易状态',
          key: 'remittanceStatus',
          align: 'center',
          render: (h, params) => {
            let num = params.row.remittanceStatus;
            return h('span', this.remittance[num]);
          }
        },
        {
          title: '备注',
          key: 'remittanceMemo',
          align: 'center',
          render: (h, params) => {}
        }
      ]
    };
  }
};
</script>
<style scoped>
.statistics-ul {
  display: inline-block;
}

.statistics-ul li {
  width: 212px;
  border-left: 1px solid #e5e5e5;
  padding: 10px 20px;
  display: inline-block;
}

.statistics-ul li:first-child {
  padding-left: 0;
  border-left: none;
}

.time-link-ul {
  display: inline-block;
}

.time-link-ul li {
  padding: 0 10px;
  border-right: 1px solid #e9eaec;
  display: inline-block;
}

.time-link-ul li:last-child {
  border-right: none;
}

.time-link-ul li a {
  color: #f54203;
}
.link {
  margin-right: 10px;
}
.link:hover {
  color: #f54203;
}

.color646464 {
  color: #646464;
}

.f54203 {
  color: #f54203;
}
</style>
