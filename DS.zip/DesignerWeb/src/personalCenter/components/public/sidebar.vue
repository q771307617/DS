<template>
    <div class="layout-menu-left float-left box-shadow">
        <ul class="user-info-list">
            <li class="font20">
                <a class="user_img"><img :src="info.image_url" alt=""></a>
                <span v-if="info.status == 14" style="color: #646464;" class="font20">花名：{{info.nickname}}</span>
            </li>
        </ul>
        <Menu class="siderbar-menu" width="100%" ref="leftMenu" theme="light" @on-select="menuSelect" :active-name="activeMenu" :open-names="activeOpen" accordion>
            <div v-for="item in menus" :key="item.routerName">
            <MenuItem v-if="item.children.length == 1" :name="item.children[0].routerName">
                <Icon :type="item.icon"></Icon>
                {{item.title}}
            </MenuItem>
            <Submenu v-if="item.children.length > 1" :name="item.routerName">
                <template slot="title">
                    <Icon :type="item.icon"></Icon>
                    {{item.title}}
                </template>
                <MenuItem v-for="c in item.children" :key="c.routerName" :name="c.routerName"><Icon :type="c.icon"></Icon>{{c.title}}</MenuItem>
            </Submenu>
            </div>
        </Menu>
    </div>
</template>

<script>
import { mapState } from 'vuex';

export default {
  data() {
    return {
      activeMenu: '',
      activeOpen: [],
      menus: []
    };
  },
  computed: {
    ...mapState({
      info: state => state.User.info,
      status: state => state.User.info.status
    })
  },
  methods: {
    menuSelect(name) {
      if (
        (name == 'DEMAND') |
        (name == 'HIRE_CUSTOM') |
        (name == 'HIRE_MONTH')
      ) {
        // 订单中心
        this.$router.push({ name: 'orders', query: { orderType: name } });
      } else {
        this.$router.push({
          name: name
        });
      }
    },
    setActiveMenu() {
      let name = this.$route.query.orderType;
      if (
        (name == 'DEMAND') |
        (name == 'HIRE_CUSTOM') |
        (name == 'HIRE_MONTH')
      ) {
        // 订单中心
        this.activeMenu = name;
      } else if (this.$route.name == 'favoritePro') {
        this.activeMenu = 'favoriteDesigner';
      } else {
        this.activeMenu = this.$route.name;
      }
      let activeOpen = '';
      this.menus.forEach(item => {
        if (item.children.length > 1) {
          item.children.forEach(c => {
            if (c.routerName == this.activeMenu) {
              activeOpen = item.routerName;
            }
          });
        }
      });
      this.activeOpen = [activeOpen];
    },
    joinStatus() {
      //入驻状态
      let menus = [
        {
          routerName: '管理大厅',
          title: '管理大厅',
          icon: 'home',
          children: [{ routerName: 'manageHall', title: '管理大厅' }]
        },
        {
          routerName: '个人中心',
          title: '个人中心',
          icon: 'person',
          children: [{ routerName: 'personalCenter', title: '个人中心' }]
        },
        {
          routerName: '我的收藏',
          title: '我的收藏',
          icon: 'ios-heart-outline',
          children: [{ routerName: 'favoriteDesigner', title: '我的收藏' }]
        }
      ];
      if (this.info.status == 14) {
        //入驻成功
        menus.splice(
          2,
          0,
          {
            routerName: '我的雇主',
            title: '我的雇主',
            icon: 'person-stalker',
            children: [{ routerName: 'myEmployer', title: '我的雇主' }]
          },
          {
            routerName: '订单中心',
            title: '订单中心',
            icon: 'clipboard',
            children: [
              { routerName: 'DEMAND', title: '需求订单' },
              { routerName: 'HIRE_CUSTOM', title: '定制订单' },
              { routerName: 'HIRE_MONTH', title: '包月订单' }
            ]
          },
          {
            routerName: '财务中心',
            title: '财务中心',
            icon: 'social-yen',
            children: [
              { routerName: 'financialSalary', title: '薪资', icon: 'card' },
              {
                routerName: 'financialCash',
                title: '提现',
                icon: 'social-buffer'
              }
            ]
          },
          {
            routerName: '我的作品',
            title: '我的作品',
            icon: 'android-image',
            children: [{ routerName: 'myWorks', title: '我的作品' }]
          },
          {
            routerName: '我的简历',
            title: '我的简历',
            icon: 'android-mail',
            children: [{ routerName: 'resume', title: '我的简历' }]
          }
        );
      }
      this.menus = menus;
    },
    intercept() {
      // eslint-disable-next-line
      let array = {},
        name = this.$route.name;
      if (this.info.status != 14) {
        this.menus.forEach(item => {
          item.children.forEach(cItem => {
            if (!array[cItem.routerName]) {
              array[cItem.routerName] = cItem.routerName;
            }
          });
        });
        array['favoritePro'] = 'favoritePro';
        if (!array[name]) {
          this.menuSelect('manageHall');
        }
      }
    }
  },
  mounted() {
    this.joinStatus();
    this.setActiveMenu();
    this.$nextTick(function() {
      this.$refs.leftMenu.updateOpened();
      this.$refs.leftMenu.updateActiveName();
    });
    this.intercept();
  },
  watch: {
    $route: 'setActiveMenu',
    status() {
      this.joinStatus();
      this.intercept();
    }
  }
};
</script>

<style lang="scss" scoped>
.layout-menu-left {
  position: relative;
  margin-top: 15px;
  background-color: #fff;
  width: 283px;
  height: 1000px;
}

.left-menu {
  text-align: center;
}
.left-menu li {
  cursor: pointer;
  height: 55px;
  line-height: 55px;
  font-size: 16px;
}
.left-menu .active {
  background: #d7d7d7;
  color: #000;
  font-weight: 900;
}
.left-menu li.active:first-child div {
  border: 0;
}
.left-menu li div {
  width: 219px;
  margin: 0 auto;
  border-bottom: 1px solid #eee;
}
.left-menu li:first-child div {
  border-top: 1px solid #eee;
}
.user-info-list li {
  line-height: 30px;
  cursor: pointer;
  text-align: center;
}
.user-info-list li:first-child {
  padding: 25px 30px;
  border-top: 0;
}
.user-info-list li .user_img {
  width: 218px;
  height: 218px;
  border-radius: 5px;
  overflow: hidden;
  display: block;

  img {
    max-width: 100%;
    margin: auto;
    display: block;
  }
}

// 侧栏
.siderbar-menu {
  &.ivu-menu-vertical .ivu-menu-item,
  .ivu-menu-vertical .ivu-menu-submenu-title {
    padding: 14px 24px;
    position: relative;
    cursor: pointer;
    z-index: 1;
    transition: all 0.2s ease-in-out;
    text-align: center;
    border: none;
    font-size: 16px;
    color: #646464;
  }
  &.ivu-menu-light.ivu-menu-vertical
    .ivu-menu-item-active:not(.ivu-menu-submenu) {
    background: #f3f3f3;
    color: #50A4F8;
    border: none;

    .ivu-icon {
      color: #50A4F8;
    }
  }
  .ivu-menu-submenu {
    text-align: center;
    border: none;
    margin-left: 20px;
    font-size: 16px;
    color: #646464;
    .ivu-icon {
      color: #646464;
    }
    .ivu-menu-item {
      font-size: 14px;
    }
  }
  .ivu-menu-item {
    text-align: center;
    border: none;
    font-size: 16px;
    color: #646464;

    .ivu-icon {
      color: #646464;
    }
  }

  &.ivu-menu-vertical.ivu-menu-light:after {
    display: none;
  }
}
</style>
