<template>
    <div class="layout-ceiling">
        <div class="layout-ceiling-main">
            <Row>
                <Col span="18" class="font16 layout-ceiling-left">
                    欢迎您，<span class='name'>{{info.username}}</span> 登录设计师个人中心
                    <a class="out" @click=" exitUser"><img :src="'icon2/icon_loginOut.png' | randomPath" class="logout">退出</a>
                </Col>
                <Col span="6" class="layout-ceiling-right">
                    <ul class="nav">
                        <li>
                            <router-link class="font14" :to="{name: 'designerJoin'}">设计师中心</router-link>
                        </li>
                        <li>
                            <a href="/" class="font14">首页</a>
                        </li>
                    </ul>
                </Col>
            </Row>
        </div>
    </div>
</template>

<script>
// import router from '../../../router/index.js';
import { mapState, mapActions } from 'vuex';

export default {
  data() {
    return {};
  },
  computed: {
    ...mapState({
      info: state => state.User.info
    })
  },
  methods: {
    ...mapActions(['exitUser'])
  },
  mounted() {}
};
</script>


<style lang="scss" scoped>
.nav {
}
.nav li {
  height: 60px;
  line-height: 60px;
  min-width: 100px;
  cursor: pointer;
  float: right;
  padding: 0;
  text-align: right;

  a {
    color: #fff;
  }
}

.layout-ceiling {
  background: #0eb8ff url(../../../assets/images/bj.jpg) no-repeat center;
  background-size: auto 100%;
}
.layout-ceiling-main {
  width: 1200px;
  margin: 0 auto;
  color: #fff;
}
.layout-ceiling-left {
  height: 60px;
  line-height: 60px;

  .name {
    margin-right: 10px;
  }
  .logout {
    position: absolute;
    left: 20px;
    top: 22px;
  }
  .out {
    display: inline-block;
    position: relative;
    color: #fff;
    font-size: 16px;
    padding-left: 40px;
  }
  .out:hover {
    text-decoration: underline;
    color: #3043ff;
  }
}
.layout-ceiling-right {
  height: 60px;
  line-height: 60px;
  text-align: right;
}
</style>
