<template>
    <div v-if="process != 3" class="process box-shadow section">
        <p>{{process | getProcessTxt}}<span v-if="process == 2">￥{{payBail}}</span></p>
        <Button v-on:click="confirmHandle">确定</Button>
    </div>
</template>

<script>
export default {
  props: ['process', 'payBail'],
  data() {
    return {};
  },
  filters: {
    getProcessTxt(i) {
      let txt = [
        '您还未激活该账号，立即入驻激活',
        '认证进度：请填写个人资料、申请等级认证',
        '认证进度：请缴纳平台保证金：',
        ''
      ];
      return txt[i];
    }
  },
  methods: {
    //跳转相应页面
    confirmHandle() {
      this.$emit('parentHandle');
    }
  }
};
</script>


<style lang="scss" scoped>
// 进程
.process {
  text-align: center;
  padding: 42px 0;

  & > p {
    display: inline-block;
    margin-right: 16px;
    font-size: 16px;
    color: #888;

    span {
      color: red;
    }
  }
  button {
    width: 82px;
    height: 27px;
    line-height: 27px;
    color: #fff;
    font-size: 14px;
    background: #00a8ff;
    padding: 0;
  }
}
</style>
