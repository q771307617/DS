<template>
  <div class="personal-center">
    <publicHeader/>
    <div class="main">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
import publicHeader from '@/personalCenter/components/public/header.vue';
import { mapActions } from 'vuex';

export default {
  components: { publicHeader },
  methods: {
    ...mapActions(['designerIsType'])
  },
  mounted() {
    this.designerIsType();
  }
};
</script>
<style>
html,
body {
  background: #f1f1f1;
}
</style>
<style lang="scss" scoped>
.personal-center {
  background: #f1f1f1;
}

.main {
  width: 1200px;
  margin: 0 auto;
  background: #f1f1f1;

  &:after {
    content: '';
    display: table;
    clear: both;
  }
}
</style>

