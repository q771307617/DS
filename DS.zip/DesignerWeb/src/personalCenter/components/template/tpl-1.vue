<template>
  <div class="personal-center">
    <publicHeader/>
    <div class="main">
      <sidebar/>
      <div class="layout-menu-right float-right">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script>
import publicHeader from '@/personalCenter/components/public/header.vue';
import sidebar from '@/personalCenter/components/public/sidebar.vue';
import { mapActions } from 'vuex';

export default {
  components: { publicHeader, sidebar },
  methods: {
    ...mapActions(['designerIsType'])
  },
  mounted() {
    this.designerIsType();
  }
};
</script>

<style lang="scss" scoped>
.personal-center {
  background: rgb(250, 250, 250);
}
.main {
  width: 1200px;
  margin: 0 auto;
  background: rgb(250, 250, 250);

  &:after {
    content: '';
    display: table;
    clear: both;
  }
}
.layout-menu-right {
  width: 902px;
  position: relative;
  margin-top: 15px;
}
</style>

