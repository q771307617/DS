<template>
    <div>
        <Modal v-model="showCash" class="wsl_model" width="940" :styles="{top: '300px'}" @on-cancel="cancel">
            <p slot="header">
                <span>提现到支付宝</span>
            </p>
            <Row>
                <Col span="6" class="pic">
                <img :src="'icon/tx-zfb-big.png' | randomPath" alt="支付宝支付" class="vertical-middle">
                </Col>
                <Col span="17" class="con">
                <Form ref="formInline" :model="formValidate" :rules="ruleValidate" :label-width="110">
                    <!-- <FormItem label="账户名称：" prop="name">
                        {{info.realname}}
                      </FormItem>
                      <FormItem label="支付宝账号：" prop="alipay">
                        {{info.alipay_account}}
                      </FormItem> -->
                    <FormItem label="本次提现金额：" prop="cashNum">
                        <Row>
                            <Col span="11">
                            <InputNumber v-model="formValidate.cashNum" :max="userinfo.balance" style="width:290px" number="true"></InputNumber>
                            </Col>
                            <Col span="10" offset="3">
                            <p style="color:#bcbcbc">可提现金额
                                <span style="color:#f54203">{{userinfo.balance}}</span>元&nbsp&nbsp
                                <span @click="getallmoney" style="color:#f54203">提现全部</span>
                            </p>
                            <!-- <Button type="error" @click="getallmoney" style="text-align: center;">提现全部</Button> -->
                            </Col>
                        </Row>
                    </FormItem>
                    <FormItem label="交易密码：" prop="payPassword">
                       <Input v-model="formValidate.payPassword" placeholder="请输入交易密码" type="password" style="width:290px" :maxlength="6"></Input>
                    </FormItem>
                    <p style="color:#f54203">温馨提示：提现金额将于48小时提现到您指定账户，请注意查收！ </p>
                    <!-- <FormItem label="图片验证码：" prop="imgcode" v-if="needVerifycode">
                        <Row>
                            <Col span="11">
                            <Input v-model="formValidate.imgcode" placeholder="请输入验证码" type="text" style="width:290px" :maxlength="4"></Input>
                            </Col>
                            <Col span="10" offset="3">
                            <img :src="verifycodeUrl" alt="" class="verifycode" @click="fetchCodeImg" style="height:32px">
                            </Col>
                        </Row>
                    </FormItem>
                    <FormItem label="手机号码：" prop="phone">
                        <p>{{formValidate.phone}}
                            <Button type="ghost" @click="sendCode" style="margin-left: 8px" v-if="codeIntervalTime === 60">发送验证码</Button>
                            <Button type="ghost" @click="sendCode" style="margin-left: 8px" disabled v-else>{{codeIntervalTime}}s后再获取</Button>
                        </p>
                    </FormItem>
                    <FormItem label="验证码：" prop="verifycode">
                        <Input v-model="formValidate.verifycode" placeholder="请输入验证码" type="text" style="width:290px" :maxlength="6"></Input>
                    </FormItem> -->
                </Form>
                </Col>
                <Col span="1">
                </Col>
            </Row>
            <!-- <Row>
                <Col class="submit">
                <p style="color:#f54203">温馨提示：提现金额将于48小时提现到您指定账户，请注意查收！ </p>
                </Col>
            </Row> -->
            <div slot="footer" class=" submit cashSubmit">
                <Button type="error" size="large" style="width:125px;height:40px" @click="handleSubmit('formInline')">确认</Button>
            </div>
        </Modal>
    </div>
</template>

<script>
import { mapState } from 'vuex';
export default {
  // components: {  },
  data() {
    const validatecash = (rule, value, callback) => {
      if (value < 0.1) {
        callback(new Error('请输入不小于0.1元的提现金额'));
      } else {
        callback();
      }
    };
    const validatecode = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入短信验证码'));
      } else if (value.length < 6) {
        callback(new Error('请输入六位短信验证码'));
      } else {
        callback();
      }
    };
    const validateimg = (rule, value, callback) => {
      if (!value) {
        callback(new Error('请输入图片验证码'));
      } else if (value.length < 4) {
        callback(new Error('请输入四位图片验证码'));
      } else {
        callback();
      }
    };
    const payPasswordR = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入交易密码'));
      } else if (value.length < 6) {
        callback(new Error('请输入六位交易密码'));
      } else {
        callback();
      }
    };
    return {
      showCash: true,
      needVerifycode: false,
      codeIntervalTime: 60,
      verifycodeUrl: '',
      params: {
        fee: '',
        code: '',
        remittanceChannel: 'ALI'
      },
      formValidate: {
        name: '',
        alipay: '',
        wechat: '',
        cashNum: 0,
        phone: '',
        verifycode: '',
        imgcode: '',
        payPassword: ''
      },
      ruleValidate: {
        cashNum: [
          {
            validator: validatecash,
            required: true,
            trigger: 'blur'
          }
        ],
        verifycode: [
          {
            validator: validatecode,
            required: true,
            trigger: 'blur'
          }
        ],
        imgcode: [
          {
            validator: validateimg,
            trigger: 'blur'
          }
        ],
        payPassword: [
          {
            validator: payPasswordR,
            required: true,
            trigger: 'blur'
          }
        ]
      }
    };
  },
  computed: {
    ...mapState({
      ftpPath: state => state.User.ftpPath,
      userinfo: state => state.User.info
    })
  },
  filters: {},
  methods: {
    /** 提现表单验证 */
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          this.params.fee = this.formValidate.cashNum;
          this.params.code = this.formValidate.verifycode;
          this.params.payPassword = this.formValidate.payPassword;
          this.$ajax.post('withdraw/add', { ...this.params }).then(e => {
            if (e.status === 200) {
              this.$Notice.success({
                title: '提现申请已提交',
                desc: '您的提现申请已提交成功，我们将立即为您处理！',
                duration: 2
              });
              this.$emit('cashmodelshow', 'false');
            } else {
              this.$Notice.error({
                title: e.msg,
                duration: 1
              });
            }
          });
        } else {
        }
      });
    },
    cancel() {
      this.$emit('cashmodelshow', 'false');
    },
    /*** 全部提现 */
    getallmoney() {
      this.formValidate.cashNum = this.userinfo.balance;
    },
    /** 图片验证码 */
    fetchCodeImg() {
      this.verifycodeUrl = this.$ajax.getVerifyCode();
    },
    getphone() {
      this.formValidate.phone = this.userinfo.phone.replace(
        this.userinfo.phone.substr(3, 4),
        '****'
      );
    },
    /** 获取短信验证码 */
    sendCode() {
      this.$ajax
        .post('auth/sendcode', {
          phone: this.userinfo.phone,
          verifycode: this.formValidate.imgcode
        })
        .then(e => {
          if (e.status !== 200) {
            this.needVerifycode = true;
            this.codeIntervalTime = 60;
            clearInterval(this.update);
            this.fetchCodeImg();
            this.$Message.error('请输入正确的验证码');
          } else {
            this.codeIntervalTime--; //60秒倒计时
            this.update = setInterval(() => {
              this.codeIntervalTime--;
            }, 1000);
            this.formValidate.verifycode = e.data;
          }
        });
    }
  },
  mounted() {
    this.getphone();
  },
  watch: {
    codeIntervalTime(val) {
      if (!val) {
        this.codeIntervalTime = 60;
        clearInterval(this.update);
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.submit {
  text-align: center;
  display: flex;
  justify-content: center;
}
.wsl_model .ivu-modal-footer {
  border-top: 0px solid #e9eaec;
  padding: 12px 18px 12px 18px;
  text-align: right;
}
.pic {
  display: flex;
  justify-content: center;
  margin-top: 10px;
}
</style>
