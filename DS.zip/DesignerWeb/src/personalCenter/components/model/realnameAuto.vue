<template>
    <Modal v-model="modal" title="实名认证" class-name="personal-center-modal" width="480" :mask-closable="false">
        <div slot="close" class="" @click="cancel"><i class="ivu-icon ivu-icon-ios-close-empty" style="color: #ccc;"></i></div>
        <div class='form-group'>
            <p>姓名：{{realname}}</p>
            <p>身份证号：{{card}}</p>
        </div>
        <div slot="footer" class="btn-group">
            <Button class="btn-confirm" type="error" @click="ok">确定</Button>
            <Button class="btn-cancle" @click="cancel">取消</Button>
        </div>
    </Modal>
</template>

<script>
export default {
  props: ['modal', 'card', 'realname'],
  data() {
    return {};
  },
  methods: {
    ok() {
      this.$ajax.post('/user/realnameauth').then(e => {
        if (e.status == 200) {
          this.$Notice.success({ title: e.msg });
          this.emitHandle(1);
        } else {
          this.$Notice.error({ title: e.msg });
        }
      });
    },
    cancel() {
      this.emitHandle();
    },
    emitHandle(fresh) {
      let isFresh = fresh || '';
      this.$emit('emitHandle', {
        modal: false,
        isFresh: isFresh
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.form-group {
  padding-left: 80px;
  p {
    font-size: 18px;
    color: #888888;
    margin-bottom: 15px;
    &:last-child {
      margin: 0;
    }
  }
}
.btn-group {
  text-align: center;
  button {
    font-size: 16px;
    width: 100px;
  }
}
.btn-confirm {
  background: #18abff;
  border-color: #18abff;
  margin-right: 25px;
  margin-left: 0;
}
.btn-cancle {
  background: transparent;
  border-color: #4d4d4d;
  color: #4d4d4d;
}
</style>
