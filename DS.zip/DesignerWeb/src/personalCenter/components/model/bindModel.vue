<template>
  <div>
    <Modal v-model="bindmodel" width="900" :styles="{top: '360px'}" class="bindmodel" @on-cancel="cancel">
      <div slot="header" style="font-size:18px;">
        <span v-if="info.pay_password==null" >支付宝提现</span>
        <span v-else>温馨提示</span>
      </div>
      <Row class="font18 content submit">
        <div style="width:100px;height:130px;line-height:170px;text-aligin:right;margin-right:15px;"><img :src="'icon2/payError.png' | randomPath" style="display:inline-block;"></div>
        <Col v-if="info.realNameAuth==0" style="display:inline-block;height:148px;line-height:130px;color:#646464"> 您尚未实名认证，需进行实名认证！</Col>
        <Col v-else-if="info.alipay_account==null" style="display:inline-block;height:148px;line-height:130px;color:#646464">您尚未绑定支付宝，绑定支付宝后方能提现！</Col>
        <Col v-else-if="info.pay_password==null" style="display:inline-block;height:148px;line-height:130px;color:#646464">您尚未设置交易密码，需设置交易密码！</Col>
      </Row>
      <p slot="footer" class="footer">
        <Button type="ghost" size="large" style="width:125px;height:40px;border:1px solid #f54203;color:#f54203;"  @click="cancel">取消</Button>
        <Button v-if="info.realNameAuth==0" type="error"  @click="attest" style="width:125px;height:40px;">立即认证</Button>
        <Button v-else-if="info.alipay_account==null" type="error" @click="bindalipay" style="width:125px;height:40px;">立即绑定</Button>
        <Button v-else-if="info.pay_password==null" type="error"  @click="pay_password" style="width:125px;height:40px;">立即设置</Button>
      </p>
    </Modal>
  </div>
</template>

<script>
import { mapState } from 'vuex';
export default {
  // components: {  },
  data() {
    return {
      bindmodel: true
    };
  },
  computed: {
    ...mapState({
      info: state => state.User.info
    })
  },
  filters: {},
  methods: {
    cancel() {
      this.$emit('bindcancelshow', 'close');
    },
    /**去认证 */
    attest() {
      this.$emit('bindcancelshow', 'open');
    },
    bindalipay() {
      this.$router.push({
        name: 'alipayBind',
        params: {
          id: 1
        }
      });
    },
    pay_password() {
      this.$router.push({
        name: 'personalCenter'
      });
    }
  },
  mounted() {},
  watch: {}
};
</script>

<style lang="scss" scoped>
.bindmodel {
  // .content {
  //   color: #f60;
  //   text-align: center;
  //   min-height: 30px;
  // }
  .submit {
    text-align: center;
    display: flex;
    justify-content: center;
  }
  .footer {
    border-top: 0px solid #e9eaec;
    color: #f60;
    text-align: center;
    .cacel {
      width: 160px;
      height: 28px;
      line-height: 14px;
      text-align: center;
      color: #009fe6;
    }
    .sure {
      width: 160px;
      height: 28px;
      line-height: 14px;
      text-align: center;
      color: #fff;
      background-color: #009fe6;
    }
  }
}
</style>