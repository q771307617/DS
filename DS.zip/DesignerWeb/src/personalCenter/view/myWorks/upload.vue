<template>
  <div class="upload-main">
    <Modal v-model="modal" title=" " class-name="product-upload" width="910" :mask-closable="false" :closable="false">  
        <div class="modal-close" @click="cancel"><i class="ivu-icon ivu-icon-ios-close-empty" style="color: #ccc;"></i></div>
        <div class='form-group'>
            <div class='form-item'>
                <label>作品封面图：</label>
                <div class="form-control">
                    <Upload
                            ref="uploadCover"
                            :show-upload-list="false"
                            :default-file-list="defaultListCover"
                            :on-success="handleSuccessCover"
                            :format="['jpg','jpeg','png']"
                            :max-size="200"
                            :on-format-error="handleFormatError"
                            :on-error="handleErrorCover"
                            :on-exceeded-size="handleMaxSizeCover"
                            :before-upload="handleBeforeUploadCover"
                            multiple
                            action="/api/upload/avatar"
                            style="display: inline-block;width:200px;">
                        <Button ref="proFM" type="ghost" icon="ios-cloud-upload-outline">上传封面图</Button>
                    </Upload>
                    <span v-if="verifyType == 1" class="verify">请上传作品封面图</span>
                    <p class="tip">图片比例1:1,每张最大200KB,支持JPG/GIF/PNG格式</p>
                </div>
                
            </div>
            <div class='form-item'>
                <label>作品图片：</label>
                <div class="form-control">
                    <Upload
                            ref="upload"
                            :show-upload-list="false"
                            :default-file-list="defaultList"
                            :on-success="handleSuccess"
                            :format="['jpg','jpeg','png']"
                            :max-size="5120"
                            :on-format-error="handleFormatError"
                            :on-error="handleError"
                            :on-exceeded-size="handleMaxSize"
                            :before-upload="handleBeforeUpload"
                            multiple
                            action="/api/upload/uploadidimg"
                            style="display: inline-block;width:200px;">
                        <Button ref="proZP" type="ghost" icon="ios-cloud-upload-outline">上传作品</Button>
                    </Upload>
                    <span v-if="verifyType == 2" class="verify">请上传作品图</span>
                    <p class="tip">每张最大5M,尺寸不小于500PXx700PX,支持JPG/GIF/PNG格式</p>
                </div>
            </div>
            <div class='form-item'>
                <label>作品标题：</label>
                <div class="form-control">
                    <Input ref="name" v-model="data.name" placeholder="请输入作品标题" :maxlength="15"></Input>
                    <span style="position: absolute;top: 25px;left: 0;" v-if="verifyType == 3" class="verify">请填写作品标题</span>
                </div>
            </div>
            <div class='form-item'>
                <label>行业类目：</label>
                <div class="form-control">
                    <Select v-model="data.classId">
                        <Option v-for="item in adeptTypeData" :value="item.id" :key="item.id">{{ item.name }}</Option>
                    </Select>
                    <span style="position: absolute;top: 25px;left: 0;" v-if="verifyType == 4" class="verify">请选择行业类目</span>
                </div>
            </div>
            <div class='form-item'>
                <label>设计风格：</label>
                <div class="form-control">
                    <Select v-model="data.styleId">
                        <Option v-for="item in designStyleData" :value="item.id" :key="item.id">{{ item.name }}</Option>
                    </Select>
                    <span style="position: absolute;top: 25px;left: 0;" v-if="verifyType == 5" class="verify">请选择设计风格</span>
                </div>
            </div>
            <div class='form-item'>
                <label>作品标签：</label>
                <div class='form-control' style="width: 746px;">
                    <div class="label-group" v-if="label.length > 0">
                        <div class="label-list" v-for="(v, i) in label" :key='i'>
                        <Button class="label-item">
                            {{v}}
                        </Button>
                        <a v-on:click="handleClose(i)">x</a>
                        </div>
                    </div>
                    <div class="form-label">
                        <Input ref="label" v-model="proLabel" placeholder="请输入作品标签" :maxlength="7" style="width: 170px;">
                            <Button slot="append" type="ghost" v-on:click="addLabel">添加标签</Button>
                        </Input>
                    </div>
                    <span v-if="verifyType == 6" class="verify">请添加作品标签</span>
                    <p class="tip" style="clear: both;">最多添加5个标签，例如：小清新，红色调，小可爱...</p>
                </div>
            </div>
            <div class='form-item' style="margin-bottom: 10px;">
                <label>作品说明：</label>
                <div class="form-control pro-explain">
                    <Input ref="description" v-model="data.tag" type="textarea" :rows="4" placeholder="请输入..." :maxlength="150"></Input>
                    <p class="tip">150</p>
                    <span style="position: absolute;top: 88px;left: 0;" v-if="verifyType == 7" class="verify">请输入作品说明</span>
                </div>
            </div>
        </div>
        <div class="pic">
            <div style="height: 105px">
            <div class="pic-fm" v-for="item in uploadListCover" :key="item.url">
                <template v-if="item.status === 'finished'">
                    <img :src="item.url">
                    <div class="demo-upload-list-cover">
                    <a @click="handleRemoveCover(item)">删除</a>
                    </div>
                </template>
                <template v-else>
                    <Progress v-if="item.showProgress" :percent="item.percentage" hide-info></Progress>
                </template>
            </div>
            </div>
            <div class="pic-zp">
                <div class="img" v-for="item in uploadList" :key="item.url">
                    <template v-if="item.status === 'finished'">
                        <img :src="item.url">
                        <div class="demo-upload-list-cover">
                        <a @click="handleRemove(item)">删除</a>
                        </div>
                    </template>
                    <template v-else>
                        <Progress v-if="item.showProgress" :percent="item.percentage" hide-info></Progress>
                    </template>
                </div>
            </div>
        </div>
        <div slot="footer" class="btn-group">
            <Button class="btn-cancle" @click="cancel">取消</Button>
            <Button class="bnt-confirm" type="error" @click="ok">确定</Button>
        </div>
    </Modal>
    <Modal class="model2" v-model="modal2" title=" " class-name="product-upload" width="910" :closable="false" :styles="{top: '260px'}">  
        <div class="modal-close" @click="cancel2"><i class="ivu-icon ivu-icon-ios-close-empty" style="color: #ccc;"></i></div>
        <div class='form-content'>
                平台将在<span style="color:#f54102"> 3-5 </span>个工作日内审核您上传的作品，请耐心等待
        </div>    
        <div slot="footer" class="btn-group">
            <Button class="bnt-confirm" type="error" @click="cancel2">确定</Button>
        </div>
    </Modal>
  </div>
</template>

<script>
import { mapState } from 'vuex';

const GET_SRC_BY_IMG = imageStr => {
  try {
    // eslint-disable-next-line
    let regImg = /src=['"]([^'"]*)[\'"]/gi;
    let imgArr = [];
    let a = '';
    while ((a = regImg.exec(imageStr)) != null) {
      let str = a[1];
      let star = str.lastIndexOf('!');
      let end = str.length;
      imgArr.push(str.replace(str.slice(star, end), ''));
    }
    return imgArr;
  } catch (e) {
    return [];
  }
};
export default {
  props: ['modal', 'data'],
  data() {
    return {
      modal2: false,
      verifyType: '0', //验证提示

      //作品封面图
      defaultListCover: [], //默认已上传列表
      uploadListCover: [],
      //作品图片
      defaultList: [], //默认已上传列表
      imgName: '', //弹窗大图地址
      visible: false, //弹窗显隐控制
      uploadList: [],
      actionPath: this.$ajax.pathUpload, //上传地址

      label: [], //作品标签
      proLabel: '',
      adeptTypeData: [
        //行业类目
      ],
      designStyleData: [
        //设计风格
      ]
    };
  },
  computed: {
    ...mapState({
      info: state => state.User.info,
      childList4: state => state.Lists.childList4,
      styles: state => state.Lists.styles
    })
  },
  methods: {
    //作品封面图
    handleRemoveCover(file) {
      //移除作品
      const fileList = this.$refs.uploadCover.fileList;
      this.$refs.uploadCover.fileList.splice(fileList.indexOf(file), 1);
    },
    handleSuccessCover(res, file) {
      //文件上传成功
      if (res.status == 200) {
        file.url = res.data;
        file.name = res.data;
      } else {
        this.$Message.error(res.msg);
        this.handleRemoveCover(file);
      }
    },
    handleErrorCover(file) {
      this.$Notice.error({
        title: '上传失败',
        desc: '请上传200KB以内正确格式的图片'
      });
    },
    handleMaxSizeCover(file) {
      //文件超出大小
      this.$Notice.warning({
        title: '超出文件大小限制',
        desc: '文件 ' + file.name + ' 太大，不能超过 200KB。'
      });
    },
    handleBeforeUploadCover() {
      //上传文件之前
      const check = this.uploadListCover.length < 1;
      if (!check) {
        this.$Notice.warning({
          title: '最多只能上传 1 张图片。'
        });
      }
      return check;
    },
    //作品图片
    handleRemove(file) {
      //移除作品
      const fileList = this.$refs.upload.fileList;
      this.$refs.upload.fileList.splice(fileList.indexOf(file), 1);
    },
    handleSuccess(res, file) {
      //文件上传成功
      if (res.status == 200) {
        file.url = res.data;
        file.name = res.data;
      } else {
        this.$Message.error(res.msg);
        this.handleRemove(file);
      }
    },
    handleFormatError(file) {
      //文件格式验证失败
      this.$Notice.warning({
        title: '文件格式不正确',
        desc: '文件 ' + file.name + ' 格式不正确，请上传 jpg 或 png 格式的图片。'
      });
    },
    handleError(file) {
      this.$Notice.error({
        title: '上传失败',
        desc: '请上传5M以内正确格式的图片'
      });
    },
    handleMaxSize(file) {
      //文件超出大小
      this.$Notice.warning({
        title: '超出文件大小限制',
        desc: '文件 ' + file.name + ' 太大，不能超过 5M。'
      });
    },
    handleBeforeUpload() {
      //上传文件之前
      const check = this.uploadList.length < 3;
      if (!check) {
        this.$Notice.warning({
          title: '最多只能上传 3 张图片。'
        });
      }
      return check;
    },

    verify() {
      //验证
      if (this.uploadListCover.length == 0) {
        this.verifyType = 1;
        return;
      }
      if (this.uploadList.length == 0) {
        this.verifyType = 2;
        return;
      }
      if (this.isNull(this.data.name)) {
        this.verifyType = 3;
        this.$refs.name.focus();
        return;
      }
      if (this.isNull(this.data.classId)) {
        this.verifyType = 4;
        return;
      }
      if (this.isNull(this.data.styleId)) {
        this.verifyType = 5;
        return;
      }
      if (this.isNull(this.label)) {
        this.verifyType = 6;
        this.$refs.label.focus();
        return;
      }
      if (this.isNull(this.data.tag)) {
        this.verifyType = 7;
        this.$refs.description.focus();
        return;
      }
      this.verifyType = '';

      this.ajaxSavePro();
    },
    handleClose(i) {
      //删除标签
      this.label.splice(i, 1);
    },
    ajaxSavePro() {
      //保存上传作品信息
      let str = '';
      this.uploadList.map(function(e) {
        if (
          e.url != null &&
          e.url != 'null' &&
          e.url != undefined &&
          e.url != 'undefined' &&
          e.url.length > 0
        ) {
          str += '<p><img src="' + e.url + '!790" name="' + e.name + '"></p>';
        }
      });
      console.log(this.info);
      let params = {
        classId: this.data.classId,
        // description: this.data.description,
        tag: this.data.tag,
        details: str,
        imageUrl: this.uploadListCover[0].url,
        name: this.data.name,
        styleId: this.data.styleId,
        // tag: this.label.join(','),
        label: this.label.join(','),
        userId: this.info.id,
        id: this.data.id
      };
      console.log(params);
      this.$ajax.post('/registerdesigner/insertproduct', params).then(e => {
        if (e.status == 200) {
          this.emitHandle(1);
          this.modal2 = true;
        } else {
          this.$Notice.error({ title: e.msg });
        }
      });
    },
    ok() {
      //验证
      this.verify();
    },
    cancel() {
      this.emitHandle();
    },
    cancel2() {
      this.modal2 = false;
    },
    emitHandle(fresh) {
      //回调
      let isFresh = fresh || '';
      this.$emit('emitHandle', {
        modal: false,
        isFresh: isFresh
      });
    },

    addLabel() {
      //添加标签
      if (this.isNull(this.proLabel)) {
        //错误提示
        return;
      }
      if (this.label.length >= 5) {
        this.$Notice.warning({
          title: '最多只能添加 5 个标签。'
        });
        this.proLabel = '';
        return;
      }
      this.label.push(this.proLabel);
      this.proLabel = '';
    },

    isNull(v) {
      if (v == '' || v == null || v == undefined) {
        return true;
      }
      return false;
    }
  },
  mounted() {
    this.uploadList = this.$refs.upload.fileList;
    this.uploadListCover = this.$refs.uploadCover.fileList;

    this.childList4.forEach(function(item) {
      item.id = item.id.toString();
    });
    this.adeptTypeData = this.childList4;

    this.styles.forEach(function(item) {
      item.id = item.id.toString();
    });
    this.designStyleData = this.styles;
  },
  watch: {
    data() {
      if (this.data.classId) {
        this.data.classId = String(this.data.classId);
      }
      if (this.data.styleId) {
        this.data.styleId = String(this.data.styleId);
      }
      if (this.data.label) {
        this.label = this.data.label.split(',');
      } else {
        this.label = [];
      }

      let list = GET_SRC_BY_IMG(this.data.details);
      this.uploadList = this.$refs.upload.fileList = list.map(item => {
        return {
          url: item,
          name: item,
          status: 'finished'
        };
      });

      let list1;
      if (this.data.imageUrl) {
        list1 = [this.data.imageUrl];
      } else {
        list1 = [];
      }
      console.log(list1);
      this.uploadListCover = this.$refs.uploadCover.fileList = list1.map(
        item => {
          return {
            url: item,
            name: item,
            status: 'finished'
          };
        }
      );
    },
    childList4() {
      this.childList4.forEach(function(item) {
        item.id = item.id.toString();
      });
      this.adeptTypeData = this.childList4;
    },
    styles() {
      this.styles.forEach(function(item) {
        item.id = item.id.toString();
      });
      this.designStyleData = this.styles;
    }
  }
};
</script>

<style lang= "scss">
.product-upload .ivu-modal-close {
  top: 3px;
}
.product-upload .ivu-modal-header {
  background-color: #009fe6;
  border-radius: 6px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
  padding: 8px 16px;
}
.product-upload .ivu-modal-body {
  padding: 20px 25px;
  position: relative;
}
.product-upload .ivu-modal-footer {
  margin-left: 25px;
  margin-right: 25px;
  padding: 30px 18px 20px;
}
.model2 .product-upload .ivu-modal-footer {
  margin-left: 25px;
  margin-right: 25px;
  padding: 0px 18px 30px;
  border: none;
}
</style>
<style lang="scss" scoped>
.form-content {
  font-size: 14px;
  color: #646464;
  text-align: center;
}
.modal-close {
  width: 30px;
  height: 30px;
  position: absolute;
  right: 0;
  top: -30px;
  i {
    width: 30px;
    height: 30px;
    line-height: 30px;
    font-size: 36px;
    text-align: center;
  }
}
.product-upload {
  // 公共
  //验证
  .verify {
    font-size: 12px;
    color: #f54102;
    height: 30px;
    line-height: 30px;
    padding-left: 20px;
    background: url('../../../assets/images/icon_verify.png') no-repeat center
      left;
    background-size: 15px;
  }
  .form-group {
    .form-item {
      margin-top: 25px;

      &:first-child {
        margin-top: 8px;
      }
      &:after {
        content: '';
        display: table;
        clear: both;
      }

      & > label {
        float: left;
        width: 88px;
        height: 32px;
        line-height: 32px;
        margin-right: 25px;
        font-size: 14px;
        color: #888;
      }
      .form-control {
        float: left;
        width: 350px;
        position: relative;

        &.pro-explain {
          width: 746px;
          position: relative;

          .tip {
            position: absolute;
            bottom: 0;
            right: 8px;
            color: #999;
          }
        }
        .tip {
          font-size: 12px;
          color: #bababa;
        }
        .label-group {
          float: left;

          .label-list {
            position: relative;
            margin-right: 10px;
            display: inline-block;
          }
          .label-item {
            background-color: #009fe6;
            color: #fff;
          }
          a {
            font-style: normal;
            position: absolute;
            top: 0;
            right: 3px;
            color: #fff;
          }
        }
        .form-label {
          float: left;
        }
      }
    }
  }

  .pic {
    position: absolute;
    top: 20px;
    right: 20px;
    text-align: center;
    width: 318px;
    height: 225px;

    img {
      display: block;
      max-width: 100%;
      margin: auto;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translateX(-50%) translateY(-50%);
    }
    .pic-fm {
      width: 100px;
      height: 100px;
      overflow: hidden;
      border: 1px solid #ccc;
      display: inline-block;
      position: relative;
      display: block;
      position: relative;

      a {
        position: absolute;
        top: 2px;
        right: 3px;
        font-size: 12px;
        color: #646464;
      }
    }
    .pic-zp {
      &:after {
        content: '';
        display: table;
        clear: both;
      }
      .img {
        width: 100px;
        height: 120px;
        overflow: hidden;
        border: 1px solid #ccc;
        margin-left: 9px;
        float: left;
        position: relative;
        display: block;
        position: relative;

        a {
          position: absolute;
          top: 2px;
          right: 3px;
          font-size: 12px;
          color: #646464;
        }

        &:first-child {
          margin: 0;
        }
      }
    }
  }

  .btn-group {
    text-align: center;

    button {
      width: 140px;
      height: 34px;
      font-size: 14px;
      color: #009fe6;
      border-color: #009fe6;
      background-color: transparent;
    }
    .bnt-confirm {
      margin-left: 32px;
      color: #fff;
      background-color: #009fe6;
    }
  }
}
</style>
