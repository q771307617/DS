<template>
  <Modal v-model="showmodal" title="作品" width="1200" :mask-closable="false">
    <div slot="close" @click="cancel">
      <i class="ivu-icon ivu-icon-ios-close-empty" style="color: #ccc;"></i>
    </div>
    <div class='form-group'>
      <Row class="header">
        <Col span="5" class="leftheader">
        <Row>
          <Col>
          <div class="titleImg"><img :src="data.photoImg" /></div>
          </Col>
        </Row>
        <Row>
          <Col span="24" style="margin-top:18px;">
          <p style="font: 16px 'Microsoft YaHei';">{{data.nickname}}
            <span class="icon">
              <img :src="'icon/security.png' | randomPath" alt="保障">
              <img :src="'icon/certification.png' | randomPath" alt="平台认证">
              <img :src="'icon/' + rankType +'.png' | randomPath" alt="等级">
            </span>
          </p>
          </Col>
        </Row>
        <Row>
          <Col span="24">
          <p>薪资：￥
            <span style="color: #c20c0c;">{{data.salary}}</span>/月 </p>
          </Col>
        </Row>
        </Col>
        <Col span="14" offset="1" style="padding-top: 40px;">
        <Row>
          <Col span="24">
          <p style="font-size: 18px ;color: #000000;">作品名称：{{data.productName}}
            <span></span>
          </p>
          </Col>
        </Row>
        <Row>
          <Col span="24" style="padding-top:31px">
          <p style="margin-bottom: 41px;">
            个人作品展示
            <!-- {{data.label}} -->
          </p>
          </Col>
        </Row>
        <Row>
          <Col span="24" style="padding-top:10px">
          <p class="detail" v-if="data.label">作品标签：{{data.label}}
            <span></span>
          </p>
          </Col>
        </Row>
        <Row>
          <Col span="24" style="border-bottom: 1px solid #e5e5e5;">
          <p>行业类目：{{data.classId | toName(childList4)}}</p>
          </Col>
        </Row>
        <Row>
          <Col span="24" style="padding-top:10px">
          <p class="detail">作品说明：{{data.tag}}
            <span></span>
          </p>
          </Col>
        </Row>
        </Col>
      </Row>
      <br>
      <Row>
        <Col :span="24" class="both"></Col>
      </Row>
      <Row>
        <p class="hint">本案例由
          <span>{{data.nickname}}</span> 原创，未经作者许可，禁止转载或商业使用。上传时间：
          <span>{{createTime}}</span>
        </p>
        <Col span="24" class="content">
        <div v-html="data.details"></div>
        </Col>
      </Row>
    </div>
    <div slot="footer" class="btn-group">
      <Button class="btn-confirm" type="error" @click="cancel">确定</Button>
      <!-- <Button class="btn-cancle" @click="cancel">取消</Button> -->
    </div>
  </Modal>
</template>

<script>
import moment from 'moment';
import { mapState } from 'vuex';
export default {
  props: ['modal', 'productId'],
  data() {
    return {
      type: '',
      showmodal: false,
      data: {},
      rankType: 'ASSISTANT',
      createTime: ''
    }
  },
  computed: {
    ...mapState({
      childList4: state => state.Lists.childList4,
      ranks: state => state.Lists.ranks
    })
  },
  methods: {
    getpro() {
      this.$ajax.get("/product/productdetail", {
        productId: this.productId
      }).then((e) => {
        if (e.status == 200) {
          this.data = e.data;
          this.rankType = e.data.rank;
          this.createTime = moment(e.data.createTime).format('YYYY-MM-DD HH:mm:ss');
          this.showmodal = true;
        } else {
          this.$Notice.error({ title: e.msg });
        }
      })
    },
    cancel() {
      this.emitHandle();
    },
    emitHandle() {
      this.$emit('emitHandle', {
        modal: false
      });
    }
  },
  mounted() {
  },
  watch: {
    'modal'(val) {
      if (val) {
        this.getpro();
      } else {
        this.showmodal = false;
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  background-color: red;
}

.form-group {
  .both {
    background-color: #f8f8f8;
    height: 54px;
    width: 1200px;
    position: absolute;
    right: -16px;
    top: -40px;
  }
  .header {
    display: flex;
    justify-content: center;
    padding-top: 10px;
    margin-bottom: 54px;
    min-height: 300px;
    .leftheader {
      padding-left: 35px;
      border-right: 1px solid #e5e5e5;
    }
    .titleImg {
      width: 176px;
      height: 208px;
      overflow: hidden;
      box-sizing: border-box;
      display: flex;
      align-items: center;
      img {
        width: 100%;
        // height: 100%;
        object-fit: cover;
      }
    }
    .icon img {
      padding-left: 5px;
    }
  }
  .hint {
    text-align: right;
    color: #ccc;
    margin: 30px 230px 0 0;
    font-size: 12px;
  }
  .content {
    display: flex;
    justify-content: center;
    margin-top: 20px;
    overflow: hidden;
    img {
      max-width: 790px;
      min-width: 200px;
    }
  }
  p {
    font-size: 14px;
    color: #808080;
    line-height: 30px;
  }
}

.btn-group {
  text-align: center;
  button {
    font-size: 16px;
    width: 100px;
  }
}

.btn-confirm {
  background: #18abff;
  border-color: #18abff;
  margin-right: 25px;
  margin-left: 0;
}

.btn-cancle {
  background: transparent;
  border-color: #4d4d4d;
  color: #4d4d4d;
}

.detail {
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
}
</style>
