<template>
  <div class="my-works">
    <header class='box-shadow'>
      <div class="left">
        我的作品
        <span>（共{{count}}个作品）</span>
      </div>
      <div class="right">
        <Button v-on:click="updateProduct">作品上传</Button>
      </div>
    </header>
    <div class="section box-shadow">
      <ul class="proStatus">
        <li v-for="(t,i) in productStatus" :key="i" :class="sindex == i?'ac':''">
          <a v-on:click="searchStatus(t.id, i)">{{t.name}}</a>
        </li>
      </ul>
      <ul class="tag">
        <li>
          <a :class="cindex == -1?'ac':''" v-on:click="searchPro('')">全部作品</a>
        </li>
        <li v-for="(t,i) in category" :key="i">
          <a :class="cindex == i?'ac':''" v-on:click="searchPro(t, i)">{{t | formatTag(adeptTypeData)}}</a>
        </li>
      </ul>
      <div class="product-list">
        <!-- 修改 删除 -->
        <div class="product-item" v-for="(p, i) in productList" :key="i" v-on:mouseenter="dataDetails(i)" v-on:mouseleave="hiddenDetail(i)">
          <div class='product-img'>
            <div class="img">
              <img :src="p.imageUrl" alt='作品封面' />
            </div>
            <div class="img-bg" v-show="showDelete==i">
              <a class="delete" v-if="params.auditStatus!='0'" v-on:click="productBG = i">删除</a>
            </div>
          </div>
          <div class="product-inform">
            <h2 class='title'>{{p.name}}</h2>
            <p class='label'>类目：{{p.classId | formatTag(adeptTypeData)}}</p>
            <a class='preview' v-if="params.auditStatus!='-1'" v-on:click="previewProduct(p.id)">预览</a>
            <a class='edit' v-if="params.auditStatus!='0'" v-on:click="updateProduct(p)">编辑</a>
          </div>
          <div class="product-bg" v-show="i == productBG">
            <div class="txt">
              <p>确定删除</p>
              <div class="btn-group">
                <a class="btn-confirm" v-on:click="deleteProduct(p.id);productBG = '-1'">确定</a>
                <a class="btn-cancle" v-on:click="productBG = '-1'">取消</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Page :current="params.pageNum" :total="params.count" :page-size="params.pageSize" show-elevator @on-change="changePage" class="float-right page page-style" style="margin-top: 40px;"></Page>
    </div>
    <productUpload :data="productData" :modal="uploadShow" v-show="uploadShow" v-on:emitHandle="childProductMess" />
    <detailInfo :modal="modal_view_pro" :productId="productId" v-on:emitHandle="authHandle"></detailInfo>
  </div>
</template>

<script>
import productUpload from '@/personalCenter/view/myWorks/upload.vue';
import detailInfo from "@/personalCenter/view/myWorks/detailInfo.vue";
import { mapState } from 'vuex';

export default {
  components: { productUpload, detailInfo },
  data() {
    return {
      productStatus: [{ id: 1, name: '已发布作品' }, { id: 0, name: '审核中作品' }, { id: -1, name: '审核未通过作品' }],
      showDelete: -1,
      modal_view_pro: false,
      productBG: '-1',
      productId: '',
      uploadShow: false, //作品上传
      productData: {
        //单个作品数据
      },
      count: 0, //作品总数
      productList: [], //作品列表
      category: [], //类目
      sindex: 0, //默认全部 tag
      cindex: -1, //默认全部 tag
      adeptTypeData: [],
      params: {
        auditStatus: 1,
        classId: '',
        userId: '',
        pageNum: 1, //当前页码
        count: 0, //总数
        pageSize: 32 //每页条数
      }
    };
  },
  computed: {
    ...mapState({
      info: state => state.User.info,
      childList4: state => state.Lists.childList4
    })
  },
  filters: {
    formatTag(v, arr) {
      let n = '';
      arr.forEach(function(item) {
        if (item.id == v) {
          n = item.name;
        }
      });
      return n;
    }
  },
  methods: {
    //控制鼠标移入移除事件
    dataDetails(val) {
      this.showDelete = val;
    },
    hiddenDetail(val) {
      this.showDelete = -1;
    },
    productShow(v) {
      //显隐作品信息
      this.uploadShow = v;
    },
    childProductMess(o) {
      //接收子数据
      if (o.isFresh) {
        this.searchPro('');
        this.getCategory();
        this.getCount();
      }
      this.productShow(o.modal);
    },
    updateProduct(obj) {
      //更新作品
      if (obj) {
        this.productData = obj;
      } else {
        this.productData = {};
      }
      this.productShow(true);
    },
    authHandle() {
      this.modal_view_pro = false
    },
    previewProduct(id) {
      //预览
      this.productId = id;
      this.modal_view_pro = true;
      // window.open('/proInfo/' + id);
      // window.location.href = '/proInfo/'+id;
    },
    deleteProduct(id) {
      //删除作品
      this.$ajax
        .post('/registerdesigner/deleteproduct', { id: id, status: 1 })
        .then(e => {
          if (e.status == 200) {
            this.searchPro('');
            this.getCategory();
            this.getCount();
          } else {
            this.$Notice.error({ title: e.msg });
          }
        });
    },
    getInfo() {
      //获取作品
      this.params.userId = this.info.user_id;
      this.$ajax
        .get('/registerdesigner/getproductlist', this.params)
        .then(e => {
          if (e.status == 200) {
            console.log(e);
            this.productList = e.data.list;
            this.params.pageNum = e.data.num || 1;
            this.params.count = e.data.count;
            this.params.pageSize = e.data.size;
          } else {
            this.$Notice.error({ title: e.msg });
          }
        });
    },
    getCategory() {
      //获取类目
      this.$ajax
        .get('/registerdesigner/getclassids', { userId: this.info.user_id, auditStatus: this.params.auditStatus })
        .then(e => {
          if (e.status == 200) {
            this.category = e.data;
          } else {
            this.$Notice.error({ title: e.msg });
          }
        });
    },
    getCount() {
      //获取总数
      this.$ajax
        .get('/registerdesigner/getproductcount', { userId: this.info.user_id })
        .then(e => {
          if (e.status == 200) {
            this.count = e.data;
          } else {
            this.$Notice.error({ title: e.msg });
          }
        });
    },
    searchStatus(id, index = -1) {
      //查询审核流程
      this.cindex = -1;
      this.params.classId = null;
      this.params.auditStatus = id;
      this.sindex = index;
      this.getCategory();
      this.getInfo();
    },
    searchPro(id, index = -1) {
      //查询
      if (this.isNull(id)) {
        this.params.classId = null;
      } else {
        this.params.classId = id;
      }
      this.cindex = index;
      this.getInfo();
    },
    changePage(num) {
      //翻页
      this.params.pageNum = num;
      this.getInfo();
    },
    isNull(v) {
      if (v == '' || v == null || v == undefined) {
        return true;
      }
      return false;
    }
  },
  mounted() {
    this.adeptTypeData = this.childList4;
    this.getInfo();
    this.getCategory();
    this.getCount();
  },
  watch: {
    childList4() {
      this.adeptTypeData = this.childList4;
    }
  }
};
</script>

<style lang="scss" scoped>
.boxshadow {
  box-shadow: 3px 3px 5px #ccc;
  background: #fff;
}

.my-works {
  //头部
  header {
    padding: 34px 12px;
    background: #fff;
    overflow: hidden;
    .left {
      padding-left: 6px;
      font-size: 16px;
      color: #646464;
      height: 28px;
      line-height: 28px;
      float: left;
    }
    .right {
      float: right;

      button {
        padding: 0;
        width: 96px;
        height: 28px;
        color: #fff;
        font-size: 14px;
        border: none;
        background: #009fe6;
      }
    }
  }
  .section {
    margin-top: 8px;
    padding: 24px 12px;
    background: #fff;
    .proStatus {
      overflow: hidden;
      li {
        float: left;
        background: #fff;
        text-align: center;
        font-size: 14px;
        border: 1px solid #e0e0e0;
        &:last-child {
          margin: 0;
        }
        a {
          display: inline-block;
          width: 210px;
          height: 46px;
          line-height: 46px;
          color: #808080;
        }
      }
      li.ac {
        background: #5DADFF;
        a {
          display: inline-block;
          width: 210px;
          height: 46px;
          line-height: 46px;
          color: #fff;
        }
      }
      li:nth-of-type(2) {
        border-left: none;
        border-right: none;
      }
    }
    .tag {
      overflow: hidden;
      li {
        float: left;
        width: 70px;
        height: 46px;
        line-height: 46px;
        text-align: center;
        margin-right: 15px;

        &:last-child {
          margin: 0;
        }

        a {
          font-size: 14px;
          color: #646464;
        }
        a.ac {
          color: #f54102;
        }
      }
    }
  }
}

// 上传作品
.product-list {
  padding: 26px -0 28px;

  &:after {
    content: '';
    display: table;
    clear: both;
  }

  .product-item {
    width: 210px;
    height: 255px;
    float: left;
    margin-left: 12.6666px;
    margin-bottom: 12px;
    border: 1px solid #d4d0c8;
    position: relative;

    &:nth-child(4n + 1) {
      margin: 0;
    }

    &.pro-default {
      background: #f2f2f2;
      cursor: pointer;

      .img {
        margin-top: 165px;
        margin-bottom: 15px;

        img {
          display: block;
          max-width: 100%;
          margin: auto;
        }
      }
    }

    .tip {
      font-size: 14px;
      color: #646464;
      width: 151px;
      text-align: center;
      margin: auto;
    }
    .tip-txt {
      font-size: 12px;
      color: #888;
      width: 130px;
      text-align: center;
      margin: auto;
    }
    .product-img {
      position: relative;

      .img {
        width: 100%;
        height: 210px;
        overflow: hidden;
        display: block;
        position: relative;

        img {
          display: block;
          max-width: 100%;
          margin: auto;
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translateX(-50%) translateY(-50%);
        }
      }
      .img-bg {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;

        .delete {
          float: right;
          font-size: 12px;
          color: #646464;
          margin: 5px 7px 0 0;
          padding-left: 20px;
          background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAAQCAYAAAAbBi9cAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAEQSURBVHja7NI9SkNBFIbhJ/EGJSpCQEihgmInRHAJFi5EcgsLsbSwUyxtbAcX4ALERSi4B39QhBgkiDEQtZlivFyNhaVfM+edc+bMN4eptNttI3SPGhbRKyZDCCDDDpbxgCpmY80HltCMfIarGFfQxSDP8yZuM2yiVeLkDS94jLyCNUyW1F5nWMU4+riJ7ipxP8NlLG5hAhfR7TnW0QghdLPkdhhiEONTNDAT+SS6+nImhNAVZ5Iq5anCM+oYS7gGeZ7Xyxql6uO1MLNvVfVH+m80WlmB35N4rpBbKPDwp0apw11MJ7yH+YQr6ZqV3HqMZzyhg8OY6+AOB/FzbqTO0kZb2Mf2L8fSw1EIoQ+fAwDsWDhnxPKjtwAAAABJRU5ErkJggg==') no-repeat center left;
          background-size: 16px;
        }
      }
    }
    .product-inform {
      position: relative;

      .title {
        height: 23px;
        line-height: 23px;
        font-size: 14px;
        color: #666;
        padding-left: 6px;
        padding-right: 60px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      .label {
        height: 18px;
        line-height: 18px;
        font-size: 12px;
        color: #808080;
        padding-left: 6px;
      }
      .edit,
      .preview {
        position: absolute;
        top: 3px;
        right: 5px;
        font-size: 12px;
        color: #009fe6;
      }
      .preview {
        right: 35px;
      }
    }
    .product-bg {
      position: absolute;
      top: 0;
      left: 0;
      background-color: rgba(0, 0, 0, 0.4);
      width: 100%;
      height: 100%;
      z-index: 999;
      .txt {
        margin-top: 85px;
        font-size: 12px;
        text-align: center;
        color: #fff;
        p {
          font-size: 16px;
        }
        .btn-group {
          width: 145px;
          margin: auto;
          margin-top: 20px;
          a {
            display: block;
            width: 66px;
            height: 20px;
            line-height: 20px;
            float: left;
          }
          .btn-confirm {
            background-color: #f54203;
            color: #fff;
            margin-right: 10px;
          }
          .btn-cancle {
            background-color: #fff;
            color: #000;
          }
        }
      }
    }
  }
}
</style>
