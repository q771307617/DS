<template>
    <div class="manage-hall">
        <div class="mess box-shadow section">
            <div class="inform">
                <div class='title'>
                    <p v-if="process != 3" class='name'>我的账户: {{data.userName}}</p>
                    <p v-else class='name'>姓名:{{data.realname}}</p>
                    <router-link v-if="process == 3" :to="{name: 'resume'}" class="edit-btn" >编辑简历</router-link>
                </div>
                <p v-if="process != 0" class='type'>入驻类型：<span >{{data.workPlace}}</span></p>
                <p v-if="process > 1" class='level'>等级认证：<span>{{data.rank | getRank}}</span></p>
            </div>
            <p v-if="info.last_login_time" class='time'>上次登录时间：{{info.last_login_time | getFormatTime}}</p>
        </div>
        <process :process="process" :payBail="data.payBail" v-on:parentHandle="confirmHandle"></process>
        <div v-if="process == 3" class="score box-shadow section">
            <div class='header'>
                <h1 class='title'>我的评分</h1>
                <p class='count'>|&nbsp;评价数: <span>{{data.pjTimes}}</span></p>
            </div>
            <ul class='type'>
                <li>
                    <span class='name'>服务态度:</span>
                    <Rate class='level' disabled v-model="data.attitude"></Rate>
                </li>
                <li>
                    <span class='name'>设计能力:</span>
                    <Rate class='level' disabled v-model="data.ability"></Rate>
                </li>
                <li>
                    <span class='name'>响应速度:</span>
                    <Rate class='level' disabled v-model="data.speed"></Rate>
                </li>
            </ul>
        </div>
        <div class="sign box-shadow section">
            <ul class="toggle">
                <li :class="signToggle ? 'ac' : ''" v-on:click="signToggle = true"><a>公告通知</a></li>
                <li :class="signToggle ? '' : 'ac'" v-on:click="signToggle = false"><a>平台通知</a></li>
            </ul>
            <div class="content">
                <div class='txt' v-if="signToggle">
                    <p>1、11.6日晚6点半，将开始第32期设计师群练作品分享，请不要迟到哦；</p>
                    <p>2、10.25日中午，将于缥缈峰进行设计能力培训，期待您的参加；</p>
                    <p>3、本站将于9.11日凌晨0时进行为期2小时系统维护，页面将关闭请注意合理安排时间；</p>
                </div>
                <div class='txt' v-else>
                    <p>1、11.6日晚6点半，将开始第32期设计师群练作品分享，请不要迟到哦；</p>
                    <p>2、10.25日中午，将于缥缈峰进行设计能力培训，期待您的参加；</p>
                    <p>3、本站将于9.11日凌晨0时进行为期2小时系统维护，页面将关闭请注意合理安排时间；</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { mapState } from 'vuex';
import moment from 'moment';
import process from '@/personalCenter/components/public/process.vue';
export default {
  components: { process },
  data() {
    return {
      signToggle: true,
      process: 0, //入驻进度 0 首页 1 审核 2 缴纳保证金 3 入驻成功
      isPro: false, //作品提交
      data: {}
    };
  },
  computed: {
    ...mapState({
      info: state => state.User.info
    })
  },
  filters: {
    getFormatTime(time) {
      return moment(time).format('YYYY-MM-DD HH:mm:ss');
    }
  },
  methods: {
    //路由跳转
    jumpPage(name) {
      this.$router.push({
        name: name
      });
    },
    // //跳转相应页面
    confirmHandle() {
      let name = [
        'designerJoin',
        'levelApproveCheck',
        'securityDeposit',
        'entryIntoSuccess'
      ];
      if (this.isPro) {
        this.jumpPage('levelApprove');
      }
      this.jumpPage(name[this.process]);
    },
    //获取进程
    getProcess() {
      switch (this.data.status) {
        case 0:
        case 1:
        case 9:
          this.process = 0;
          break;
        case 2:
          this.isPro = true;
          this.process = 1;
          break;
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 10:
        case 11:
        case 12:
          this.process = 1;
          break;
        case 13:
          this.process = 2;
          break;
        case 14:
          this.process = 3;
          break;
        default:
          this.process = 3;
          break;
      }
    },
    //获取信息
    getInfo() {
      this.$ajax.get('/registerdesigner/queryenteruserinfo').then(e => {
        if (e.status == 200) {
          e.data.workPlace = this.$utils.pub.getDesignerWorkPlaceName(
            e.data.workPlace
          );
          this.data = e.data;
          this.getProcess();
        } else {
          this.$Notice.error({ title: e.msg });
        }
      });
    }
  },
  mounted() {
    this.getInfo();
    // this.data.status = 14;this.getProcess();
  },
  watch: {}
};
</script>

<style lang="scss">
.manage-hall .score .level {
  .ivu-rate-star {
    margin-right: 2px;
  }
  .ivu-rate-star-full:before,
  .ivu-rate-star-half .ivu-rate-star-content:before {
    color: #f54102;
    font-size: 18px;
  }
}
</style>
<style lang="scss" scoped>
.manage-hall {
  display: flex;
  flex-direction: column;
  height: 1000px;

  .section {
    margin-top: 8px;
    background: #fff;

    &:first-child {
      margin: 0;
    }
  }

  // 信息
  .mess {
    position: relative;
    padding: 27px 31px;
    min-height: 200px;
    .inform {
      position: relative;
      .title {
        border-bottom: 1px dashed #ededed;
      }
      .name {
        font-size: 18px;
        color: #646464;
        display: inline-block;
        padding-right: 33px;
        padding-bottom: 6px;

        &:after {
          content: '全';
          display: inline-block;
          width: 24px;
          height: 24px;
          line-height: 24px;
          text-align: center;
          color: #fff;
          font-size: 14px;
          background: #f54102;
          border-radius: 50%;
          margin-left: 10px;
        }
      }
      .edit-btn {
        position: absolute;
        top: 0;
        right: 0;
        width: 82px;
        height: 27px;
        line-height: 27px;
        text-align: center;
        background: #00a8ff;
        color: #fff;
        font-size: 14px;
        box-shadow: 1px 2px 3px rgba(0, 0, 0, 0.06);
        border-radius: 4px;
      }
      > p {
        padding: 10px 0 6px;
        border-bottom: 1px dashed #ededed;
        font-size: 14px;
        color: #888888;

        span {
          color: #f54102;
        }
      }
    }
    .time {
      position: absolute;
      bottom: 18px;
      left: 31px;
      font-size: 12px;
      color: #ababab;
    }
  }
  // 评价
  .score {
    padding: 11px 31px 31px;
    font-size: 16px;
    .header {
      padding-bottom: 6px;
      border-bottom: 1px dashed #ededed;
    }
    .title {
      color: #f54102;
      font-size: 16px;
      display: inline-block;
    }
    .count {
      color: #646464;
      display: inline-block;
    }
    .type {
      padding-top: 20px;
      overflow: hidden;

      li {
        float: left;
        margin-right: 110px;

        &:last-child {
          margin: 0;
        }

        .name {
          font-size: 16px;
          color: #888;
          height: 30px;
          line-height: 30px;
          float: left;
          margin-right: 8px;
        }
        .level {
        }
      }
    }
  }
  // 公告
  .sign {
    flex: 1;
    padding: 43px 17px;
    .toggle {
      overflow: hidden;

      li {
        float: left;
        border-right: 1px solid #000;

        a {
          color: #646464;
          font-size: 16px;
          padding: 0 15px;
          user-select: none;
        }
        &:last-child {
          border: none;
        }
      }
      & li.ac a {
        color: #f54102;
      }
    }
    .content {
      margin-top: 18px;
      padding-left: 40px;

      .txt {
        p {
          margin-bottom: 10px;
          font-size: 14px;
          color: #888;
        }
      }
    }
  }
}
</style>
