<template>
    <div class="main-cash">
    <con-header @cashlist="cashlist"/>
        <div style="padding: 14px 20px;background-color: #fff;margin-top: 10px; box-shadow: 4px 4px 5px 3px #efefef;">
            <div>
                <span>订单编号：</span>
                <Input v-model="params.remittanceNo" placeholder="" style="width: 176px;"></Input>
            </div>
            <div style="margin: 14px 0px;">
                <span>提现时间：</span>
                <Date-picker v-model="params.startTime" @on-change="handleBeginPicker" :editable="false" :clearable="false" type="date" placeholder="开始日期" style="width: 200px;display: inline-block;"></Date-picker>
                <span>至</span>
                <Date-picker v-model="params.endTime" :editable="false" :clearable="false" type="date" placeholder="结束日期" style="width: 200px;display: inline-block;"></Date-picker>
                <ul class="time-link-ul">
                    <li>最近</li>
                    <li>
                        <a href="javascript:;" @click="limitDate(1,'weeks')">一周</a>
                    </li>
                    <li>
                        <a href="javascript:;" @click="limitDate(1,'months')">1个月</a>
                    </li>
                    <li>
                        <a href="javascript:;" @click="limitDate(3,'months')">3个月</a>
                    </li>
                    <li>
                        <a href="javascript:;" @click="limitDate(1,'years')">1年</a>
                    </li>
                </ul>
                <Button class="search" @click="search()">查询</Button>
            </div>
        </div>
        <div style="padding: 14px 20px;background-color: #fff;margin-top: 10px;">
            <div style="min-height:400px;">
                <Table border :columns="cash_columns" :data="cash_data"></Table>
            </div>
            <Page :total="params.total" :current="params.pageNum" :page-size="params.pageSize" @on-change="paging" show-total show-elevator class="float-right page page-style" style="margin-top: 20px;"></Page>
        </div>
    </div>
</template>

<script>
/* ============
 * 提现管理
 * ============
 *
 * 提现管理列表页.
 */
import moment from 'moment';
// import Constant from '@/constant/index';
import conHeader from '@/personalCenter/view/financial/header';
export default {
  components: {
    conHeader
  },
  computed: {},
  methods: {
    handleBeginPicker(date) {
      this.endTime = date;
    },
    limitDate(n, u) {
      this.params.startTime = moment().subtract(n, u);
      this.params.endTime = moment();
    },
    paging(pageNum) {
      this.params.pageNum = pageNum;
      this.fetchData();
    },
    search() {
      this.params.pageNum = 1;
      this.fetchData();
    },
    cashlist() {
      this.fetchData();
    },
    /**
                * 获取提现列表.
                */
    fetchData() {
      let params = {
        ...this.params
      };
      params.startTime = this.$utils.time.startTime(
        this.params.startTime,
        'YYYY-MM-DD HH:mm:ss'
      );
      params.endTime = this.$utils.time.endTime(
        this.params.endTime,
        'YYYY-MM-DD HH:mm:ss'
      );
      this.$ajax.get('withdraw/list', params).then(e => {
        if (e.status !== 200) {
          this.cash_data = [];
          this.params.total = 0;
          return;
        }
        this.cash_data = e.data.list;
        this.params.total = e.data.count;
      });
    }
  },
  mounted() {
    this.fetchData();
  },
  data() {
    return {
      params: {
        remittanceNo: '',
        startTime: moment().subtract(1, 'weeks'),
        endTime: moment(),
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      remittance: {
        //提现交易状态
        3: '审核中',
        6: '审核中',
        9: '审核中',
        12: '审核中',
        15: '已完成',
        18: '提现失败'
      },
      id: '',
      cash_data: [],
      cash_columns: [
        {
          width: 130,
          title: '时间',
          align: 'center',
          key: 'gmtCreate',
          render: (h, params) => {
            return h(
              'span',
              `${moment(params.row.gmtCreate).format('YYYY/M/DD HH:mm')}`
            );
          }
        },
        {
          width: 156,
          title: '流水号',
          align: 'center',
          key: 'remittanceNo'
        },
        {
          title: '金额',
          width: 100,
          key: 'fee',
          align: 'center',
          className: 'red',
          render: (h, params) => {
            return h('span', `￥${params.row.fee}`);
          }
        },
        {
          title: '渠道',
          width: 85,
          key: 'remittanceChannel',
          align: 'center',
          render: (h, params) => {
            if (params.row.remittanceChannel == 1) {
              return h('span', '支付宝');
            } else if (params.row.remittanceChannel == 2) {
              return h('span', '微信');
            } else {
              return h('span', '未知');
            }
          }
        },
        {
          title: '状态',
          key: 'remittanceStatus',
          align: 'center',
          render: (h, params) => {
            let num = params.row.remittanceStatus;
            return h('span', this.remittance[num]);
          }
        },
        {
          title: '操作',
          key: 'remittanceMemo',
          align: 'center',
          render: (h, params) => {}
        }
      ]
    };
  }
};
</script>
<style scoped lang="scss">
.main-cash {
  width: 897px;
  min-height: 500px;
}
.search {
  width: 76px;
  height: 28px;
  text-align: center;
  line-height: 14px;
  background-color: #5dadff;
  color: #fff;
  margin-left: 53px;
}
.time-link-ul {
  display: inline-block;
}
.time-link-ul li {
  padding: 0 5px;
  display: inline-block;
}

.time-link-ul li a {
  color: #f54203;
}
.link {
  margin-right: 10px;
}
.link:hover {
  color: #f54203;
}
.color646464 {
  color: #646464;
}
</style>
