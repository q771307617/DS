<template>
    <div>
       <div class="top">
            <ul class="statistics-ul font14 color646464">
                <li>
                    <span>钱包总额</span>
                    <br>
                    <span class="f54203">{{info.balance}}</span>元
                </li>
                <li>
                    <span>保证金</span>
                    <br>
                    <span class="f54203">{{info.deposit}}</span>元
                </li>
                <li>
                    <a v-on:click="modal_pay_auth = true" style="color:#009fe6;margin-top: 10px;" v-if="info.realNameAuth == 0">立即认证</a>
                    <a v-else disabled style="color:#009fe6;margin-top: 10px;">已认证</a> 
                    <br>
                    <a v-if="info.alipay_account==null" style="color:#009fe6;margin-top: 10px;" @click="alipaybind()">支付宝绑定</a>
                    <a v-else style="color:#009fe6;margin-top: 10px;" disabled>支付宝已绑定</a>
                </li>
                <div style="display: inline-block;line-height: 98px;">
                    <div>
                        <Button class="cash search" @click="cash()">提现</Button>
                    </div>
                </div>
            </ul>
        </div>
        <bind-model v-if="bindmodel" @bindcancelshow="bindcancelshow"></bind-model>
        <cash-model v-if="cashmodel" @cashmodelshow="cashmodelshow"></cash-model>
         <realNameAuth :modal="modal_pay_auth" :card="info.id_card" :realname="info.realname" v-on:emitHandle="authHandle" />
    </div>
</template>

<script>
/* ============
 * 绑定实名认证
 * ============
 *
 * 绑定支付宝.
 */
import { mapState, mapActions } from 'vuex';
import cashModel from '@/personalCenter/components/model/cashModel';
import bindModel from '@/personalCenter/components/model/bindModel';
import realNameAuth from '@/personalCenter/components/model/realnameAuto.vue';
export default {
  data() {
    return {
      bindmodel: false, //绑定支付宝弹窗
      cashmodel: false, //提现弹窗
      modal_pay_auth: false //实名认证弹窗
    };
  },
  components: {
    cashModel,
    bindModel,
    realNameAuth
  },
  computed: {
    ...mapState({
      info: state => state.User.info
    })
  },
  mounted() {
    this.fetchUserData();
  },
  methods: {
    ...mapActions(['fetchUserData']),
    authHandle(v) {
      this.modal_pay_auth = v.modal;
      if (v.isFresh) {
        this.fetchUserData();
      }
    },
    /**弹出层模板 */
    bindcancelshow(val) {
      if (val == 'open') {
        this.bindmodel = false;
        this.modal_pay_auth = true;
      } else {
        this.bindmodel = false;
      }
    },
    cashmodelshow() {
      this.cashmodel = false;
      this.fetchUserData();
      this.$emit('cashlist', 'true');
    },
    /**绑定支付宝 */
    alipaybind() {
      if (this.info.realNameAuth == 0) {
        this.bindmodel = true;
      } else {
        this.$router.push({
          name: 'alipayBind',
          params: {
            id: 1
          }
        });
      }
    },
    /**提现 */
    cash() {
      if (
        this.info.realNameAuth != 0 &&
        this.info.alipay_account != null &&
        this.info.pay_password != null
      ) {
        this.cashmodel = true;
      } else if (
        this.info.realNameAuth != 0 &&
        this.info.alipay_account == null
      ) {
        this.bindmodel = true;
      } else if (this.info.pay_password == null) {
        this.bindmodel = true;
      } else {
        this.alipaybind();
      }
    }
  }
};
</script>
<style scoped lang="scss">
.top {
  background-color: #fff;
  height: 98px;
  box-shadow: 4px 4px 5px 3px #efefef;
  .statistics-ul {
    .f54203 {
      color: #f54203;
      font-size: 20px;
    }
    display: inline-block;
    li {
      width: 230px;
      padding: 22px 0px;
      display: inline-block;
      text-align: center;
      line-height: 32px;
      :first-child {
        padding-left: 0;
        border-left: none;
      }
    }
  }
  .cash {
    margin-bottom: 29px;
  }
}
.search {
  width: 76px;
  height: 28px;
  text-align: center;
  line-height: 14px;
  background-color: #5dadff;
  color: #fff;
  margin-left: 53px;
}
.submit {
  text-align: center;
  display: flex;
  justify-content: center;
}
</style>
