<template>
    <Modal v-model="modal" title="修改登录密码" class-name="personal-center-modal" width="480" :mask-closable="false" :closable="false">  
        <div class="modal-close" @click="cancel"><i class="ivu-icon ivu-icon-ios-close-empty" style="color: #ccc;"></i></div>
        <div class='form-group'>
            <!--修改登录密码弹窗-->
            <Form ref="loginPwd" :model="loginPwd" :rules="editpwd" :label-width="120">
                <Form-item label="原登录密码：" prop="pw_old">
                    <Input type="password" v-model="loginPwd.pw_old" placeholder="请输入原登录密码"></Input>
                </Form-item>
                <Form-item label="新登录密码：" prop="pw_new">
                    <Input type="password" v-model="loginPwd.pw_new" placeholder="请输入新登录密码"></Input>
                </Form-item>
                <Form-item label="确认登录密码：" prop="pw_new_r" style="margin: 0;">
                    <Input type="password" v-model="loginPwd.pw_new_r" placeholder="请确认新登录密码"></Input>
                </Form-item>
            </Form>
        </div>
        <div slot="footer" class="btn-group">
            <!-- 修改登录密码 -->
            <Button class="btn-confirm" type="warning" size="large" @click="()=>changePwd('loginPwd')">确定</Button>
            <Button class="btn-cancle" @click="cancel">取消</Button>
        </div>
    </Modal>
</template>

<script>
export default {
  props: ['modal'],
  data() {
    const pwdNew = (rule, value, callback) => {
      if (!/^(\S){6,20}$/.test(value)) {
        callback(new Error('密码只能输入字母、数字，密码长度限制6~20!'));
      } else {
        callback();
      }
    };
    // 验证登录密码是否一致
    const validatePassCheck = (rule, value, callback) => {
      if (!/^(\S){6,20}$/.test(value)) {
        callback(new Error('密码只能输入字母、数字，密码长度限制6~20!'));
      } else if (value !== this.loginPwd.pw_new) {
        callback(new Error('两次输入密码不一致!'));
      } else {
        callback();
      }
    };
    return {
      loginPwd: {
        pw_old: '',
        pw_new: '',
        pw_new_r: ''
      },
      editpwd: {
        pw_old: [
          {
            required: true,
            message: '原密码不能为空',
            trigger: 'blur'
          },
          {
            type: 'string',
            min: 6,
            message: '密码只能输入字母、数字，密码长度限制6~20',
            trigger: 'blur'
          },
          {
            type: 'string',
            max: 20,
            message: '密码只能输入字母、数字，密码长度限制6~20',
            trigger: 'blur'
          }
        ],
        pw_new: [
          {
            required: true,
            message: '新密码不能为空',
            trigger: 'blur'
          },
          {
            type: 'string',
            // min: 6,
            // message: '密码只能输入字母、数字，密码长度限制6~20',
            validator: pwdNew,
            trigger: 'blur'
          }
          // {
          //     type: 'string',
          //     max: 20,
          //     message: '密码只能输入字母、数字，密码长度限制6~20',
          //     trigger: 'blur'
          // }
        ],
        pw_new_r: [
          {
            required: true,
            message: '请确认新密码',
            trigger: 'blur'
          },
          {
            validator: validatePassCheck,
            trigger: 'blur'
          }
        ]
      }
    };
  },
  computed: {},
  methods: {
    cancel() {
      this.emitHandle();
    },
    emitHandle(fresh) {
      let isFresh = fresh || '';
      this.$emit('emitHandle', {
        modal: false,
        isFresh: isFresh
      });
    },
    //修改登录密码
    changePwd(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          this.$ajax
            .post('user/password/reset', {
              old_pwd: this.loginPwd.pw_old,
              new_pwd: this.loginPwd.pw_new
            })
            .then(e => {
              if (e.status == 200) {
                this.emitHandle(1);
                this.$Notice.success({
                  title: '修改密码成功',
                  desc: '下一次请使用新密码登陆'
                });
              } else {
                this.$Notice.error({
                  title: '修改密码失败',
                  desc: e.msg
                });
              }
            });
        }
      });
    }
  },
  watch: {
    modal() {
      this.$refs['loginPwd'].resetFields();
    }
  }
};
</script>


<style lang="scss" scoped>
.send-btn {
  background: #18abff;
  border-color: #18abff;
}
.btn-group {
  text-align: center;
  button {
    font-size: 16px;
    width: 100px;
  }
}
.btn-confirm {
  background: #18abff;
  border-color: #18abff;
  margin-right: 25px;
  margin-left: 0;
}
.btn-cancle {
  background: transparent;
  border-color: #4d4d4d;
  color: #4d4d4d;
}
</style>
