<template>
    <div class="personal-center">
        <div class="my-item account box-shadow">
          <h1 class="title">我的账户:{{data.userName}}</h1>
          <div class="mess">
            <p v-if="process == 3">姓&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;名：<span>{{data.realname}}</span></p>
            <p v-if="process == 3">身份证号：<span>{{data.idCard | getCard}}</span></p>
            <p v-if="process > 0 && process < 3">入驻类型：<span>{{data.workPlace | getJoinType}}</span></p>
            <p v-if="process > 1">等级认证：<span class='red'>{{data.rank | getRank}}</span></p>
          </div>
        </div>
        <div class="my-item box-shadow">
          <div class="left">
            <div class="img">
              <i class="icon icon-phone"></i>
              <span>手机绑定</span>
            </div>
            <p>您绑定的手机号为：{{data.phone | getPhone}}</p>
          </div>
          <div class="right">
            <Button v-on:click="modal_phone = true">更换手机</Button>
          </div>
        </div>
        <div class="my-item box-shadow">
          <div class="left">
            <div class="img">
              <i class="icon icon-mima"></i>
              <span>登录密码</span>
            </div>
            <p>安全性高的密码可以使账号更安全。建议您定期更换密码</p>
          </div>
          <div class="right">
            <Button v-on:click="modal_login_cipher = true">修改密码</Button>
          </div>
        </div>
        <div v-if="data.status == 14" class="my-item box-shadow">
          <div class="left">
            <div class="img">
              <i class="icon icon-name"></i>
              <span>实名认证</span>
            </div>
            <p>验证后，可用于快速找回登录密码，接收账户余额变动提醒和工作安排提醒</p>
          </div>
          <div class="right">
            <Button v-on:click="modal_pay_auth = true" v-if="info.realNameAuth == 0">立即认证</Button>
            <Button v-else disabled>已认证</Button> 
          </div>
        </div>
        <div v-if="data.status == 14" class="my-item box-shadow">
          <div class="left">
            <div class="img">
              <i class="icon icon-pay-mima"></i>
              <span>交易密码</span>
            </div>
            <p>安全性高的密码可以使账号更安全。建议您定期更换密码</p>
          </div>
          <div class="right">
            <Button v-if="data.payPassWord == 0" v-on:click="modal_pay_cipher = true">设置密码</Button>
            <Button v-if="data.payPassWord == 1" v-on:click="modal_pay_cipher = true">修改密码</Button>
          </div>
        </div>
        <div v-if="data.status == 14" class="my-item box-shadow">
          <div class="left">
            <div class="img">
              <i class="icon icon-zfb"></i>
              <span>绑定支付宝</span>
            </div>
            <p>在账户资金变动，修改账户信息时需要输入密码</p>
          </div>
          <div class="right">
            <Button @click="bindPay()" v-if="info.alipay_account">修改绑定</Button>
            <Button @click="bindPay()" v-else>绑定</Button>
          </div>
        </div>

        <phone :modal="modal_phone" :phone="data.phone" v-on:emitHandle="phoneHandle" />
        <loginCipher :modal="modal_login_cipher" v-on:emitHandle="loginCipherHandle" />
        <payCipher :modal="modal_pay_cipher" :phone="data.phone" v-on:emitHandle="payCipherHandle" />
        <realNameAuth :modal="modal_pay_auth" :card="data.idCard" :realname="data.realname" v-on:emitHandle="authHandle" />
    </div>
</template>

<script>
import { mapState, mapActions } from 'vuex';
import phone from '@/personalCenter/view/personalCenter/phone.vue';
import loginCipher from '@/personalCenter/view/personalCenter/loginCipher.vue';
import payCipher from '@/personalCenter/view/personalCenter/payCipher.vue';
import realNameAuth from '@/personalCenter/components/model/realnameAuto.vue';

export default {
  components: { phone, loginCipher, payCipher, realNameAuth },
  data() {
    return {
      modal_phone: false,
      modal_login_cipher: false,
      modal_pay_cipher: false,
      modal_pay_auth: false,
      data: {},
      process: 0 //入驻进度 0 首页 1 审核 2 缴纳保证金 3 入驻成功
    };
  },
  computed: {
    ...mapState({
      info: state => state.User.info
    })
  },
  filters: {
    getJoinType(type) {
      if (type == 0) {
        return '在家办公';
      } else if (type == 1) {
        return '加入众创空间';
      }
    },
    getCard(v) {
      if (v) {
        let s = v.slice(5, 14);
        return v.replace(s, '*********');
      }
    },
    getPhone(v) {
      if (v) {
        let s = v.slice(3, 7);
        return v.replace(s, '****');
      }
    }
  },
  methods: {
    ...mapActions(['fetchUserData']),
    phoneHandle(v) {
      this.modal_phone = v.modal;
      if (v.isFresh) {
        this.getInfo();
      }
    },
    loginCipherHandle(v) {
      this.modal_login_cipher = v.modal;
      if (v.isFresh) {
        this.getInfo();
      }
    },
    payCipherHandle(v) {
      this.modal_pay_cipher = v.modal;
      if (v.isFresh) {
        this.getInfo();
      }
    },
    authHandle(v) {
      this.modal_pay_auth = v.modal;
      if (v.isFresh) {
        this.fetchUserData();
      }
    },
    bindPay() {
      if (this.info.realNameAuth == 0) {
        this.$Notice.error({ title: '为了您的账户安全，请先实名认证!' });
        return;
      }
      this.$router.push({ name: 'bindPay', params: { id: 1 } });
    },
    getInfo() {
      this.$ajax.get('/registerdesigner/queryenteruserinfo').then(e => {
        if (e.status == 200) {
          this.data = e.data;
          this.getProcess();
        } else {
          this.$Notice.error({ title: e.msg });
        }
      });
    },
    //获取进程
    getProcess() {
      switch (this.data.status) {
        case 0:
        case 1:
        case 9:
          this.process = 0;
          break;
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 10:
        case 11:
        case 12:
          this.process = 1;
          break;
        case 13:
          this.process = 2;
          break;
        case 14:
          this.process = 3;
          break;
        default:
          this.process = 3;
          break;
      }
    }
  },
  mounted() {
    this.getInfo();
  },
  watch: {}
};
</script>

<style lang="scss" scoped>
.personal-center {
  // display: flex;
  // flex-direction: column;
  height: 1000px;

  .my-item {
    background: #fff;
    margin-bottom: 19px;
    padding: 27px 49px 24px 35px;

    &:first-child {
      margin-bottom: 21px;
      padding-top: 41px;
      padding: 41px 31px 24px;
    }

    &:after {
      content: '';
      display: table;
      clear: both;
    }
    .left {
      float: left;
      .img {
        width: 76px;
        float: left;
        margin-right: 40px;
        text-align: center;
        .icon {
          display: block;
          width: 44.4px;
          height: 53px;
          margin: auto;
          background: url('../../../assets/images/personal_center_icon_group.png')
            no-repeat;
          background-size: auto 53px;

          &.icon-phone {
            background-position: 0 0;
          }
          &.icon-mima {
            background-position: -44.4px 0;
          }
          &.icon-name {
            background-position: -88.8px 0;
          }
          &.icon-pay-mima {
            background-position: -133.2px 0;
          }
          &.icon-zfb {
            background-position: -177.6px 0;
          }
        }
        span {
          color: #f54102;
          font-size: 15px;
        }
      }
      p {
        float: left;
        font-size: 16px;
        color: #888;
        height: 60px;
        line-height: 60px;
      }
    }
    .right {
      float: right;
      height: 60px;
      line-height: 60px;
      button {
        padding: 0;
        color: #fff;
        background: #00a8ff;
        font-size: 14px;
        width: 82px;
        height: 26px;
        line-height: 26px;
      }
    }

    &.account {
      .title {
        font-size: 18px;
        color: #646464;
        padding: 0 0 12px;
        border-bottom: 1px solid #ededed;
        &:after {
          content: '全';
          display: inline-block;
          width: 24px;
          height: 24px;
          line-height: 24px;
          text-align: center;
          color: #fff;
          font-size: 14px;
          background: #f54102;
          border-radius: 50%;
          margin-left: 10px;
        }
      }
      .mess {
        padding-top: 26px;
        p {
          font-size: 14px;
          color: #bbb;
          margin-bottom: 15px;
          &:last-child {
            margin: 0;
          }
          span {
            color: #646464;
          }
          .red {
            color: #f54102;
          }
        }
      }
    }
  }
}
</style>
