<template>
    <Modal v-model="modal" title="设置交易密码" class-name="personal-center-modal" width="480" :mask-closable="false" :closable="false">  
        <div class="modal-close" @click="cancel"><i class="ivu-icon ivu-icon-ios-close-empty" style="color: #ccc;"></i></div>
        <div class='form-group'>
            <Form ref="imgCodeRef" :model="backPayPwd" :rules="imgCodeValidate" :label-width="120">
                <Form-item label="图片验证码：" :label-width="120" prop="verifycode" v-if="needVerifycode">
                    <Row class="imgcode">
                        <Col span="12">
                        <Input type="text" placeholder="输入图片验证码" v-model="backPayPwd.verifycode" :maxlength="4">
                        </Input>
                        </Col>
                        <Col span="12" class="text-right">
                        <img @click="reImg" :src="imgcodeurl" width="120px;" height="32px" />
                        </Col>
                    </Row>
                </Form-item>
            </Form>
            <Form ref="backPayPwd" :model="backPayPwd" :rules="backPwdValidate" :label-width="120">
                <Form-item label="您的手机号：" :label-width="120">
                    <Row>
                        <Col span="14"> {{phone}}
                        </Col>
                        <Col span="10">
                        <Button type="warning"  @click="sendcode" class="width120 send-btn" v-if="codeIntervalTime == 60" >发送验证码</Button>
                        <Button type="warning" class=" width120" v-else disabled>{{codeIntervalTime}}s重新获取</Button>
                        </Col>
                    </Row>
                </Form-item>
                <Form-item label="手机验证码：" prop="code">
                    <Row>
                        <Col span="24">
                        <Input type="text" placeholder="请输入手机验证码" v-model="backPayPwd.code"></Input>
                        </Col>
                    </Row>
                </Form-item>
                <Form-item label="输入交易密码：" prop="payPwd1">
                    <Row>
                        <Col span="24">
                        <Input type="password" placeholder="输入交易密码" v-model="backPayPwd.payPwd1"></Input>
                        </Col>
                    </Row>
                </Form-item>
                <Form-item label="再次输入：" prop="payPwd2" style="margin: 0">
                    <Row>
                        <Col span="24">
                        <Input type="password" placeholder="再次输入交易密码" v-model="backPayPwd.payPwd2"></Input>
                        </Col>
                    </Row>
                </Form-item>
            </Form>
        </div>
        <div slot="footer" class="btn-group">
            <Button class="btn-confirm" type="warning" size="large" @click="()=>updatePwd('backPayPwd')">确定</Button>
            <Button class="btn-cancle" @click="cancel">取消</Button>
        </div>
    </Modal>
</template>

<script>
export default {
  props: ['modal', 'phone'],
  data() {
    // 验证支付密码是否一致
    const validatePayPassCheck = (rule, value, callback) => {
      if (value !== this.backPayPwd.payPwd1) {
        callback(new Error('两次输入密码不一致!'));
      } else {
        callback();
      }
    };
    return {
      needVerifycode: false, //需要验证码
      codeIntervalTime: 60,

      backPayPwd: {
        code: '',
        verifycode: '',
        payPwd1: '',
        payPwd2: ''
      },
      imgCodeValidate: {
        verifycode: [
          {
            message: '请填写图片验证码',
            trigger: 'blur'
          },
          {
            min: 4,
            message: '请填写4位图片验证码',
            trigger: 'blur'
          },
          {
            max: 4,
            message: '请填写4位图片验证码',
            trigger: 'blur'
          }
        ]
      },
      backPwdValidate: {
        code: [
          {
            required: true,
            message: '请输入手机验证码',
            trigger: 'blur'
          },
          {
            min: 6,
            message: '请填写6位手机验证码',
            trigger: 'blur'
          },
          {
            max: 6,
            message: '请填写6位手机验证码',
            trigger: 'blur'
          }
        ],
        payPwd1: [
          {
            required: true,
            message: '请输入密码',
            trigger: 'blur'
          },
          {
            min: 6,
            message: '请填写6位数密码',
            trigger: 'blur'
          },
          {
            max: 6,
            message: '请填写6位数密码',
            trigger: 'blur'
          }
        ],
        payPwd2: [
          {
            required: true,
            message: '请再次输入密码',
            trigger: 'blur'
          },
          {
            validator: validatePayPassCheck,
            trigger: 'blur'
          }
        ]
      }
    };
  },
  computed: {},
  methods: {
    cancel() {
      this.emitHandle();
    },
    emitHandle(fresh) {
      let isFresh = fresh || '';
      this.$emit('emitHandle', {
        modal: false,
        isFresh: isFresh
      });
    },
    reImg() {
      this.imgcodeurl = this.$ajax.getVerifyCode();
    },
    sendcode() {
      this.reImg();
      this.$ajax
        .post('auth/sendcode', {
          phone: this.phone,
          verifycode: this.backPayPwd.verifycode
        })
        .then(e => {
          if (e.status !== 200) {
            this.needVerifycode = true;
            this.codeIntervalTime = 60;
            clearInterval(this.update);
            this.reImg();
            if (!this.backPayPwd.verifycode) {
              this.$Message.error('需要验证码');
            } else if (this.backPayPwd.verifycode.lenght < 4) {
              this.$Message.error('需要四位验证码');
            } else {
              this.$Message.error(e.msg);
            }
          } else {
            this.$Message.success(e.msg);
            this.codeIntervalTime--; //60秒倒计时
            this.update = setInterval(() => {
              this.codeIntervalTime--;
            }, 1000);
          }
        });
    },
    //更新密码
    updatePwd() {
      this.$refs['backPayPwd'].validate(valid => {
        if (valid) {
          this.$ajax
            .post('user/updatepaypw', {
              payPw: this.backPayPwd.payPwd2,
              phoneCode: this.backPayPwd.code
            })
            .then(e => {
              if (e.status == 200) {
                this.$Notice.success({
                  title: '设置交易密码成功',
                  desc: '请保护好您的交易密码'
                });
                this.codeIntervalTime = 60;
                clearInterval(this.update);
                this.emitHandle(1);
              } else {
                this.$Notice.error({
                  title: '设置交易密码失败',
                  desc: e.msg
                });
              }
            });
        }
      });
    }
  },
  watch: {
    modal() {
      this.$refs['backPayPwd'].resetFields();
      this.$refs['imgCodeRef'].resetFields();
      this.needVerifycode = false;
    },
    codeIntervalTime(val) {
      if (!val) {
        this.codeIntervalTime = 60;
        clearInterval(this.update);
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.send-btn {
  background: #18abff;
  border-color: #18abff;
}
.btn-group {
  text-align: center;
  button {
    font-size: 16px;
    width: 100px;
  }
}
.btn-confirm {
  background: #18abff;
  border-color: #18abff;
  margin-right: 25px;
  margin-left: 0;
}
.btn-cancle {
  background: transparent;
  border-color: #4d4d4d;
  color: #4d4d4d;
}
</style>
