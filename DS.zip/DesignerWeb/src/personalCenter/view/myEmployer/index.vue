<template>
    <div class="main-cash">
        <div style="padding: 14px 20px;background-color: #fff;margin-top: 10px; box-shadow: 4px 4px 5px 3px #efefef;">
            <div style="font-size:18px;margin-bottom:36px;">
              <p style="width:90px;border-bottom:2px solid #cccccc;">我的雇主</p> 
              <hr />
            </div>
            <div style="margin-bottom:16px;">
                <Input v-model="params.username" placeholder="请输入雇主ID/账号/昵称" icon="search" style="width: 276px;"></Input>
            </div>
            姓　　别：
            <Select v-model="params.gender" title="" style="width:80px">
                <Option  value='-1'>不限</Option>
                <Option  value='0'>男</Option>
                <Option  value='1'>女</Option>
            </Select>
            <div style="margin: 14px 0px;">
                <span>注册时间：</span>
                <Date-picker v-model="params.registerStartTime" @on-change="handleBeginPicker" :editable="false" :clearable="false" type="date" placeholder="开始日期" style="width: 200px;display: inline-block;"></Date-picker>
                <span>至</span>
                <Date-picker v-model="params.registerEndTime" :editable="false" :clearable="false" type="date" placeholder="结束日期" style="width: 200px;display: inline-block;"></Date-picker>
                <ul class="time-link-ul">
                    <li>最近</li>
                    <li>
                        <a href="javascript:;" @click="limitDate(1,'weeks')">一周</a>
                    </li>
                    <li>
                        <a href="javascript:;" @click="limitDate(1,'months')">1个月</a>
                    </li>
                    <li>
                        <a href="javascript:;" @click="limitDate(3,'months')">3个月</a>
                    </li>
                    <li>
                        <a href="javascript:;" @click="limitDate(1,'years')">1年</a>
                    </li>
                </ul>
                <Button class="search" @click="paging(1)">查询</Button>
            </div>
            <div>
              <Button class="export" @click="fetchData(true)">导出</Button>
              <Button class="dis" @click="toDis">生成推广链接</Button>
            </div>
        </div>
        <Modal v-model="modal1" :title="disParams.title" class-name="personal-center-modal" width="480" :mask-closable="false">
          <div slot="close" class="" @click="cancel"><i class="ivu-icon ivu-icon-ios-close-empty" style="color: #ccc;"></i></div>
          <div class='form-group'>
              <p style="color:#000;font-size:15px;">推广链接：</p>
              <p v-if="!disParams.step">提示：请把您要推广的页面地址复制下框内，点击生成推广链接</p>
              <p v-if="disParams.step" style="width:400px;height:auto;word-wrap:break-word;word-break:break-all;">{{disParams.redirect}}</p>
              <Input v-model="disParams.redirect" v-if="!disParams.step" placeholder="http://www.dianjiangla.com/" clearable style="width: 400px"></Input>
          </div>
          <div slot="footer" class="btn-group">
            <!-- <Button :class="disParams.step ? 'btn-confirm copyBtn' : 'btn-confirm'" type="error" :data-clipboard-text="disParams.redirect" @click="ok">{{disParams.text}}</Button> -->
              <Button v-if="!disParams.step" class="btn-confirm" type="error" @click="ok">{{disParams.text}}</Button>
              <Button v-else class="btn-confirm" id="copyBtn" type="error" :data-clipboard-text="disParams.redirect" @click="ok">{{disParams.text}}</Button>
          </div>
      </Modal>
        <div style="padding: 14px 20px;background-color: #fff;margin-top: 10px;">
            <div style="min-height:400px;">
                <Table border :columns="cash_columns" :data="cash_data" ref="table"></Table>
            </div>
            <Page :total="params.total" :current="params.pageNum" :page-size="params.pageSize" @on-change="paging" show-total show-elevator class="float-right page page-style" style="margin-top: 20px;"></Page>
        </div>
    </div>
</template>

<script>
/* ============
 * 雇主管理
 * ============
 *
 * 雇主管理列表页.
 */
import moment from 'moment';
// import Constant from '@/constant/index';
export default {
  data() {
    return {
      modal1: false,
      disParams: {
        title: '生成推广链接',
        redirect: '',
        text: '生成推广链接',
        step: false
      },
      params: {
        gender: '-1',
        username: '',
        registerStartTime: moment().subtract(3, 'months'),
        registerEndTime: moment(),
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      remittance: {
        //提现交易状态
        3: '审核中',
        6: '申请成功',
        9: '申请失败',
        12: '处理中',
        15: '提现成功',
        18: '提现失败'
      },
      id: '',
      cash_data: [],
      cash_columns: [
        {
          width: 140,
          title: '注册时间',
          align: 'center',
          key: 'registerTime'
        },
        {
          width: 100,
          title: '雇主ID',
          align: 'center',
          key: 'userId'
        },
        {
          width: 130,
          title: '雇主账号',
          align: 'center',
          key: 'username'
        },
        {
          title: '昵称',
          key: 'nickname',
          align: 'center'
        },
        {
          title: '姓别',
          width: 80,
          key: 'gender',
          align: 'center'
        },
        {
          title: 'QQ',
          key: 'qq',
          align: 'center'
        }
      ]
    };
  },
  computed: {},
  methods: {
    toDis() {
      this.disParams.redirect = '';
      this.disParams.title = '生成推广链接';
      this.disParams.text = '生成推广链接';
      this.modal1 = true;
      this.disParams.step = false;
    },
    cancel() {
      this.modal1 = false;
    },
    ok() {
      console.log(this.disParams.step);
      if (this.disParams.redirect == '') {
        this.$Message.info('地址不能为空');
        return;
      }
      if (this.disParams.step == true) {
        return;
      }
      this.$ajax.post('sale/generate', this.disParams).then(e => {
        if (e.status === 200) {
          this.disParams.redirect = 'http://' + window.location.host + e.data;
          this.disParams.step = true;
          this.disParams.title = '复制推广链接';
          this.disParams.text = '复制链接';
        } else {
          this.$Notice.error({
            title: '生成推广链接',
            desc: e.msg
          });
        }
      });
    },
    handleBeginPicker(date) {
      this.registerEndTime = date;
    },
    limitDate(n, u) {
      this.params.registerStartTime = moment().subtract(n, u);
      this.params.registerEndTime = moment();
    },
    paging(pageNum) {
      this.params.pageNum = pageNum;
      this.fetchData();
    },
    /**
     * 获取雇主列表.
     */
    fetchData(type) {
      let params = {
        ...this.params
      };
      /*********************如果导出*********************/
      if (type) {
        params.pageSize = 9999999;
        params.pageNum = 1;
      }
      params.registerStartTime = this.$utils.time.startTime(
        this.params.registerStartTime,
        'YYYY-MM-DD HH:mm:ss'
      );
      params.registerEndTime = this.$utils.time.endTime(
        this.params.registerEndTime,
        'YYYY-MM-DD HH:mm:ss'
      );
      this.$ajax.get('designer/getemployerlist', params).then(e => {
        if (e.status === 200) {
          let that = this;
          e.data.list.map(function(item) {
            item.gender = item.gender == 0 ? '男' : '女';
            item.registerTime = that.$utils.time.formatTime(item.registerTime, 'YYYY-MM-DD HH:mm') + '\t' || '';
            item.username = item.username + '\t' || '';
            item.qq = item.qq == null ? '' : item.qq + '\t' || '';
            return item;
          });
          if (type) {
            this.$refs.table.exportCsv({
              filename:
                '雇主管理表' +
                this.$utils.time.formatTime(new Date(), 'YYYY-MM-DD HH:mm:ss'),
              columns: this.columns,
              data: e.data.list
            });
          } else {
            this.cash_data = e.data.list;
            this.params.total = e.data.count;
          }
        } else {
          this.$Notice.error({
            title: '雇主列表',
            desc: e.msg
          });
        }
      });
    }
  },
  mounted() {
    this.fetchData();
    // eslint-disable-next-line
    this.clipboard = new Clipboard('#copyBtn');
    this.clipboard.on('success', e => {
      console.log('已复制');
      this.$Message.info('已复制');
      this.modal1 = false;
      e.clearSelection();
    });
    this.clipboard.on('error', e => {
      this.$Message.error('复制失败，请手动复制');
    });
  },
  destroyed() {
    //离开页面时销毁组件
    this.clipboard.destroy();
  }
};
</script>
<style scoped lang="scss">
.main-cash {
  width: 897px;
  min-height: 500px;
}
.search,
.export,
.dis {
  width: 76px;
  height: 28px;
  text-align: center;
  line-height: 14px;
  background-color: #5dadff;
  color: #fff;
  margin-left: 53px;
}
.export {
  margin: 0 20px 0 0;
}
.dis {
  width: 120px;
  margin: 0;
  background-color: #009999;
}
.time-link-ul {
  display: inline-block;
}
.time-link-ul li {
  padding: 0 5px;
  display: inline-block;
}
.time-link-ul li a {
  color: #f54203;
}
.link {
  margin-right: 10px;
}
.link:hover {
  color: #f54203;
}
.color646464 {
  color: #646464;
}
.form-group {
  padding-left: 12px;
  p {
    font-size: 14px;
    color: #888888;
    margin-bottom: 15px;
    &:last-child {
      margin: 0;
    }
  }
}
.btn-group {
  text-align: center;
  button {
    font-size: 16px;
    width: 100px;
  }
}
.btn-confirm {
  width: 160px !important;
  background: #18abff;
  border-color: #18abff;
  margin-right: 25px;
  margin-left: 0;
}
</style>
