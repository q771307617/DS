<template>
  <div class="orders">
    <div v-if="S.pageName=='financialSalary'">
      <div class="breadcrumb">
        <span>当前位置：</span>
        <span><router-link :to="{name:'financialSalary'}">财务中心></router-link></span>
        <span><router-link :to="{name:'financialSalary'}">薪资管理></router-link></span>
        <span style="color: #f54102">详情</span>
      </div>
      <div class="status-info">
        <div class="title" v-if="L.isLastMonth==false">当前状态 : 当月薪资已结算</div>
        <div class="title" v-else>当前状态 : 订单已完成，薪资已结算</div>
      </div>
    </div>
    <div v-else>
      <div class="breadcrumb">
        <span>当前位置：</span>
        <span><router-link :to="{name:'manageHall'}">首页 ></router-link></span>
        <span><router-link :to="{name:'orders',query:{orderType:'DEMAND'}}">订单中心 ></router-link></span>
        <span>
        <router-link :to="{name:'orders',query:{orderType:L.order.orderType}}">
          <span v-html="$utils.orders.getOrderTypeName(L.order.orderType)"></span> >
        </router-link>
      </span>
        <span style="color: #f54102">详情</span>
      </div>
      <div class="nav">
        <ul :class="S.params.isRefundOrder?'HIRE_MONTH': L.order.orderType">
          <li v-for="item in L.navData" :key="item.key" :class="S.ordersNavNum >= item.key ? 'active':'' ">
            <div>{{item.key}}</div>
            <div>{{item.name}}</div>
          </li>
        </ul>
        <div class="hr"></div>
      </div>
      <!--退款单-->
      <div v-if="S.params.isRefundOrder">
        <!--设计师处理退款申请 2-->
        <div v-if="S.ordersNavNum == 2">
          <div class="status-info">
            <div class="title">当前状态 : 雇主发起了申请退款，等待设计师审核</div>
            <div class="info">退款金额：<span>￥{{L.orderRefund.refundFee}}</span></div>
            <div class="info">雇主退款原因：{{L.orderRefund.refundMemo}}</div>
            <div class="info btn-group">
            <span style="overflow: hidden;" v-if="isAudit(L.orderRefund.refundStatus)">
                 <a style="float: left;" @click="setAuditDesigner(L.orderRefund.id,'PASS')" class="error"
                    href="javascript:;">同意退款</a>
                  <a style="float: left;margin-left: 15px;" @click="setAuditDesigner(L.orderRefund.id,'NON_PASS')"
                     href="javascript:;">拒绝退款</a>
              </span>
            </div>
          </div>
          <div>
            <Modal v-model="S.modal2" title="退款审核" width="680">
              <div class="auit">
                <div class="title" v-if="auditParams.result == 'PASS'">您确认同意退款？请填写审核意见：</div>
                <div class="title" v-else>您确认拒绝退款？请填写审核意见：</div>
                <Form ref="auditParams" :model="auditParams" :rules="ruleInline">
                  <div>
                    <FormItem style="width: 100%;" prop="auditMsg">
                      <Input v-model="auditParams.auditMsg" type="textarea" :autosize="{minRows: 2,maxRows: 5}"
                             placeholder="150个字符以内"></Input>
                    </FormItem>
                  </div>
                </Form>
                <div class="float-btn-group">
                  <a class="result" @click="closeModal" href="javascript:;">取消</a>
                  <a class="audit" @click="handleSubmit('auditParams')" href="javascript:;">确认</a>
                </div>
              </div>
              <div slot="footer"></div>
            </Modal>
          </div>
        </div>
        <!--设计师处理退款申请-->

        <!--总监处理退款申请 3-->
        <div v-if="S.ordersNavNum == 3">
          <div class="status-info">
            <div class="title">当前状态 : 雇主发起了申请退款，等待总监审核</div>
            <div class="info">退款金额：<span>￥{{L.orderRefund.refundFee}}</span></div>
            <div class="info">雇主退款原因：{{L.orderRefund.refundMemo}}</div>
            <div class="info">设计师审核备注：{{S.lastAuditVoList.designer}}</div>
          </div>
        </div>
        <!--设计师处理退款申请-->

        <!--退款 4-->
        <div v-if="S.ordersNavNum == 4">
          <div class="status-info">
            <div class="title">当前状态 : 总监审核已通过，退款中</div>
            <div class="info">退款金额：<span>￥{{L.orderRefund.refundFee}}</span></div>
            <div class="info">雇主退款原因：{{L.orderRefund.refundMemo}}</div>
            <div class="info">设计师审核备注：{{S.lastAuditVoList.designer}}</div>
            <div class="info">总监审核备注：{{S.lastAuditVoList.majordomo}}</div>
          </div>
        </div>
        <!--退款-->

        <!--退款完成 5-->
        <div v-if="S.ordersNavNum == 5">
          <!--退款已完成 14-->
          <div v-if="S.ordersNum == 14" class="status-info">
            <div class="title">当前状态 : 已退款</div>
            <div class="info">退款金额：<span>￥{{L.orderRefund.refundFee}}</span></div>
            <div class="info">雇主退款原因：{{L.orderRefund.refundMemo}}</div>
            <div class="info">设计师审核备注：{{S.lastAuditVoList.designer}}</div>
            <div class="info">总监审核备注：{{S.lastAuditVoList.majordomo}}</div>
          </div>

          <!--退款失败 15-->
          <div v-if="S.ordersNum == 15" class="status-info">
            <div class="title">当前状态 : 退款失败</div>
            <div class="info">退款金额：<span>￥{{L.orderRefund.refundFee}}</span></div>
            <div class="info"><span style="font-size: 20px;">该笔退款失败，请联系平台客服处理。</span></div>
          </div>
        </div>
        <!--退款完成-->
      </div>
      <!--正常单-->
      <div v-else>
        <!--需求-->
        <div v-if="L.order.orderType == 'DEMAND'">
          <!--等待雇主支付 3-->
          <div v-if="S.ordersNavNum == 3">
            <!--待支付 1-->
            <div v-if="S.ordersNum == 1" class="status-info">
              <div class="title">当前状态 : 等待雇主支付订单</div>
              <div class="info">该笔订单 <span>{{S.nowTime | getDateDiff(L.order.selfClosingTimeTxt, 'dhm')}}</span>
                超时将自动关闭。
              </div>
              <div class="jingao">您可以主动联系雇主，催促支付该笔订单。</div>
            </div>
            <!--已取消 6-->
            <div v-if="S.ordersNum == 6" class="status-info">
              <div class="title">当前状态 : 已取消</div>
              <div class="info">由于该笔订单超时未支付，系统自动关闭了该笔订单。</div>
            </div>
          </div>
          <!--等待雇主支付-->

          <!--设计师接单工作 4-->
          <div v-if="S.ordersNavNum == 4">
            <!--待交付-->
            <div class="status-info">
              <div class="title">当前状态 : 雇主已付款，设计师工作中，等待作品提交验收</div>
              <div class="info">您 <span>{{S.nowTime | getDateDiff(L.order.deadLineTxt, 'dhm')}}</span>提交作品，请及时提交作品
              </div>
              <div class="info btn-group">
                <a v-if="L.order.orderType == 'DEMAND' && L.demand.budgetStatus == 1 && L.demand.completeStatus == 0"
                   @click="submit(L.demand.id,1)" href="javascript:;">提交验收</a>
              </div>
              <div class="jingao">如果您已经完成该笔订单的设计工作，您可以通知雇主验收作品。<br/>如果您已到工作截止日还未完成工作，可能会遭到雇主投诉，平台将介入处理该笔订单。</div>
            </div>
          </div>
          <!--设计师接单工作-->

          <!--等待雇主验收 5-->
          <div v-if="S.ordersNavNum == 5">
            <!--待验收 4-->
            <div v-if="S.ordersNum == 4" class="status-info">
              <div class="title">当前状态 : 等待雇主验收</div>
              <div class="info">雇主 <span>{{S.nowTime | getDateDiff(L.order.acceptTimeTxt, 'dhm')}} </span>
                来完成订单的验收工作，如果在此期间内雇主未操作验收通过，订单将自动完成验收。
              </div>
              <div class="jingao">您也可以主动联系雇主验收订单。</div>
            </div>

            <!--验收未通过 16-->
            <div v-if="S.ordersNum == 16" class="status-info">
              <div class="title">当前状态 : 雇主验收未通过</div>
              <div class="info">验收结果为未通过，请及时与雇主联系</div>
              <div class="info">验收备注：{{L.demand.acceptView}}</div>
            </div>
          </div>
          <!--等待雇主验收-->


          <!--已完成 6-->
          <div v-if="S.ordersNavNum == 6">
            <!--待评价-->
            <div class="status-info">
              <div class="title">当前状态 : 雇主验收已通过，订单已完成。</div>
              <div class="info">订单已完成，等待雇主评价。</div>
              <div class="info">验收备注：{{L.demand.acceptView}}</div>
            </div>
          </div>
          <!--已完成-->

          <!--评价 7-->
          <div v-if="S.ordersNavNum == 7">
            <!--评价-->
            <div class="status-info">
              <div class="title">当前状态 : 雇主已评价</div>
              <div class="info">验收备注：{{L.demand.acceptView}}</div>
              <div class="info">雇主评价：{{L.evaluate.pjDetails}}</div>
              <div class="jingao">若7天未评价，系统自动默认好评</div>
            </div>
          </div>
          <!--评价-->
        </div>
        <!--需求-->

        <!--雇佣（定制/包月）-->
        <div v-if="L.order.orderType == 'HIRE_CUSTOM' || L.order.orderType == 'HIRE_MONTH'">
          <!--等待雇主支付 2-->
          <div v-if="S.ordersNavNum == 2">
            <!--待支付 1-->
            <div v-if="S.ordersNum == 1" class="status-info">
              <div class="title">当前状态 : 等待雇主支付订单</div>
              <div class="info">该笔订单 <span>{{S.nowTime | getDateDiff(L.order.selfClosingTimeTxt, 'dhm')}}</span>
                超时将自动关闭。
              </div>
              <div class="jingao">您可以主动联系雇主，催促支付该笔订单。</div>
            </div>
            <!--待开始 2-->
            <div v-if="S.ordersNum == 2" class="status-info">
              <div class="title">当前状态 : 雇主已支付，等待设计师进入工作中</div>
              <div class="info">该笔订单 <span>{{S.nowTime | getDateDiff(L.order.workStartTimeTxt, 'dhm')}}</span>
                ，订单进入开始工作中。
              </div>
            </div>
            <!--已取消 6-->
            <div v-if="S.ordersNum == 6" class="status-info">
              <div class="title">当前状态 : 已取消</div>
              <div class="info">由于该笔订单超时未支付，系统自动关闭了该笔订单。</div>
            </div>
          </div>
          <!--等待雇主支付-->

          <!--设计师接单工作 3-->
          <div v-if="S.ordersNavNum == 3">
            <!--待交付-->
            <div class="status-info">
              <div class="title">当前状态 : 雇主已付款，设计师工作中，等待作品提交验收</div>
              <div class="info">您 <span>{{S.nowTime | getDateDiff(L.order.deadLineTxt, 'dhm')}}</span> 提交作品，请及时提交作品
              </div>
              <div class="jingao">如果您已到工作截止日还未完成工作，可能会遭到雇主投诉，平台将介入处理该笔订单。</div>
            </div>
          </div>
          <!--设计师接单工作-->

          <!--已完成 4-->
          <div v-if="S.ordersNavNum == 4">
            <!--待评价-->
            <div class="status-info">
              <div class="title">当前状态 : 订单已完成，等待雇主评价</div>
            </div>
          </div>
          <!--已完成-->

          <!--评价 5-->
          <div v-if="S.ordersNavNum == 5">
            <!--评价-->
            <div class="status-info">
              <div class="title">当前状态 : 雇主已评价</div>
              <div class="info">雇主评价：{{L.evaluate.pjDetails}}</div>
              <div class="jingao">若7天未评价，系统自动默认好评</div>
            </div>
          </div>
          <!--评价-->
        </div>
        <!--雇佣（定制/包月）-->
      </div>
    </div>
    <div class="content">
      <div v-if="!!L.employer" class="row">
        <div class="title">雇主信息</div>
        <div class="info">
          <span>账号 : {{L.employer.username}}</span>
          <span>昵称 : {{L.employer.nickname}}</span>
          <span>联系电话 : {{L.employer.phone}}</span>
          <span>QQ : {{L.employer.wechat}}</span>
        </div>
      </div>
      <div v-if="!!L.designer" class="row">
        <div class="title">设计师信息</div>
        <div class="info">
          <span>账号 : {{L.designer.username}}</span>
          <span>花名 : {{ L.designer.nickname || L.designer.realname || L.designer.username}}</span>
          <span>联系电话 : {{L.designer.phone}}</span>
          <span>QQ : {{L.designer.qq}}</span>
          <span>等级 : {{L.designer.rankTxt}}设计师</span>
          <span>入驻类型 : {{L.designer.workPlaceTxt}}</span>
        </div>
      </div>
      <div v-if="!!L.order" class="row">
        <div class="title">订单信息</div>
        <div class="info orders-info">
          <span>订单编号 : {{L.order.orderId}}</span>
          <span>创建时间 : {{L.order.createTimeTxt}}</span>
          <span>订单类型 : {{ L.order.orderTypeTxt}}</span>
        </div>
        <ul>
          <li class="tab-title">
            <div class="first">
              <span v-if="S.params.orderType == 'DEMAND'">订单名称</span>
              <span v-else-if="S.params.orderType == 'HIRE_MONTH'">入职邀请</span>
              <span v-else>制作内容</span>
            </div>
            <div class="other">开始时间</div>
            <div v-if="L.order.orderType == 'DEMAND'" class="other">预计完成时间</div>
            <div v-else-if="L.order.orderType != 'DEMAND'" class="other">结束时间</div>
            <div class="other">订单金额</div>
          </li>
          <li class="tab-info">
            <div class="first">{{L.order.content}}</div>
            <div class="other">{{L.order.startTimeTxt}}</div>
            <div class="other" v-if="L.order.orderType == 'DEMAND'">{{L.deadLineTxt}}</div>
            <div class="other" v-else>{{L.order.endTimeTxt}}</div>
            <div class="other money">￥{{L.order.amount}}</div>
          </li>
        </ul>
      </div>
      <div v-if="!!L.demand" class="row">
        <div class="title">设计需求</div>
        <div class="info">
          <span>平台：{{ L.demand.classStr1}}</span>
          <span>选择类目：{{ L.demand.classStr2}}</span>
          <span>设计类型：{{ L.demand.typeId | toName(typeList)}}</span>
          <span>设计风格：{{ L.demand.styleId | toName(styles)}}</span>
          <span>设计说明：{{ L.demand.details}}</span>
          <span>参考店铺：{{ L.demand.referenceStore}}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import moment from 'moment'
  import {mapState} from 'vuex'
  export default {
    components: {},
    data(){
      return {
        // 退款审核 提交参数
        auditParams: {
          auditMsg: '',// 审核信息
          id: '',// 审核单号编号
          result: '',//审核结果 PASS：通过；NON_PASS：未通过
          targetType: 'REFUND',// 审核类型 	REFUND：退款，WITHDRAW_DEPOSIT:提现
        },
        ruleInline: {
          auditMsg: [
            {required: true, message: '请输入审核意见', trigger: 'blur'},
            {type: 'string', max: 150, message: '审核意见不能多于150个字符', trigger: 'blur'}
          ]
        },
        S: {
          pageName: '',// Mad Dragon 【 395548460@qq.com 】 2017/11/20 18:19  页面路由名称
          lastAuditVoList: {
            designer: '',
            majordomo: '',
          },// Mad Dragon 【 395548460@qq.com 】 2017/11/20 15:42 退款审核备注信息
          nowTime: '',
          modal2: false,// Mad Dragon 【 395548460@qq.com 】 2017/11/20 11:08 退款审核 审核浮动
          ordersNavNum: 0,// 订单导航状态
          /**
           * @Title: 当前订单状态
           * @Author: Mad Dragon 【 395548460@qq.com 】
           * @Date: 2017/11/18 20:23
           * @Version V2.0.2
           * @Description: 储存 当前订单的 订单状态，用于页面进度导航 和 订单状态详情模块 判断
           *  订单状态列表
           * 0: 全部
           *
           * 正常订单
           *     1: 待支付 2: 待开始 3: 待交付 4: 待验收 16:验收不通过(需求订单) 5: 已完成 6: 已取消 7: 待评价 8: 已评价
           *
           * 退款订单
           *     9: 退款审核中 10: 等待设计师审核 11: 等待总监审核 12: 等待财务审核 13: 退款中 14: 已退款 15: 退款失败
           */
          ordersNum: 0,
          params: {
            orderId: '',
            orderType: '',
            isRefundOrder: false
          },
        },
        L: {
          employer: {},// 雇主信息
          designer: {},// 设计师信息
          order: {},// 订单信息
          demand: {},// 需求详情
          navData: [],// 导航数据
          orderRefund: {},// 订单退款状态
          hire: {},// 雇佣单状态
          evaluate: {},// 评价
          isLastMonth:false, //是否是最后一个月
          deadLineTxt:null
        }
      }
    },
    mounted(){
      this.S.params.orderId = this.$route.query.orderId || '';// 订单编号
      this.S.params.orderType = this.$route.query.orderType || '';// 订单类型
      this.S.pageName = this.$route.query.pageName || '';// 页面路由名称
      this.S.nowTime = this.$moment().format('YYYY-MM-DD HH:mm:ss') || '';
      this.getOrderInfo();// 获取订单详情
    },
    watch: {},
    computed: {
      ...mapState({
        ranks: state => state.Lists.ranks,
        typeList: state => state.Lists.typeList,
        styles: state => state.Lists.styles,
      }),
    },
    methods: {
      // Mad Dragon 【 395548460@qq.com 】 2017/11/18 19:47 设计师退款审核
      auditDesigner(){
        this.$ajax.post('/orders/refund/designer', {...this.auditParams}).then((e) => {
          if (e.status != 200) {
            this.$Notice.error({
              title: '退款审核',
              desc: e.msg
            });
            return;
          }
          this.S.modal2 = false;
          this.auditParamsResult();// 重置 审核参数
          this.getOrderInfo();// 获取订单详情
        })
      },
      /**
       * @Title: 审核数据验证
       * @Author: Mad Dragon 【 395548460@qq.com 】
       * @Date: 2017/11/18 19:40
       * @Version V2.0.2
       * @Description:
       */
      handleSubmit(name) {
        this.$refs[name].validate((valid) => {
          if (valid) {
            this.auditDesigner();
          } else {

          }
        })
      },
      // 审核界面  取消审核
      closeModal(){
        this.S.modal2 = false;
        this.auditParamsResult();// 重置 审核参数
      },
      // 重置 审核参数
      auditParamsResult(){
        this.auditParams = {
          auditMsg: '',// 审核信息
          id: '',// 审核单号编号
          result: '',//审核结果 PASS：通过；NON_PASS：未通过
          targetType: 'REFUND',// 审核类型 	REFUND：退款，WITHDRAW_DEPOSIT:提现
        }
      },
      /**
       * @Title: 需求订单 提交验收
       * @Author: Mad Dragon 【 395548460@qq.com 】
       * @Date: 2017/11/18 19:47
       * @Version V2.0.2
       * @Description:
       * id 需求ID demand_id
       * completeStatus 完成状态 始终传值1(接口这么定义的)
       */
      submit(id, completeStatus){
        this.$Modal.confirm({
          title: '提交验收',
          content: '<p>您是否确认提交验收</p>',
          onOk: () => {
            this.updatestatus(id, completeStatus);
          },
          onCancel: () => {
          }
        });
      },
      /**
       * @Title: 需求订单 提交验收数据
       * @Author: Mad Dragon 【 395548460@qq.com 】
       * @Date: 2017/11/22 20:31
       * @Version V2.0.2
       *
       * @param id 需求ID demand_id
       * @param completeStatus 完成状态 始终传值1(接口这么定义的)
       *
       * @Description:
       */
      updatestatus(id, completeStatus){
        this.$ajax.post('/demand/updatestatus', {
          complete_status: completeStatus,
          id: id
        }).then((e) => {
          if (e.status != 200) {
            this.$Notice.success({
              title: '提交审核',
              desc: e.msg
            })
            return;
          }
          this.$Notice.success({
            title: '提交审核',
            desc: '提交成功'
          })
          this.getOrderInfo();
        })
      },
      // 判断
      isAudit(refund_status){
        return this.S.params.isRefundOrder && refund_status == 'PENDING_DESIGNER_AUDIT';
      },
      // 退款界面
      setAuditDesigner(refund_id, result){
        this.auditParams.id = refund_id;// 退款编号
        this.auditParams.result = result;// 审核结果
        this.S.modal2 = true;
      },
      // 获取订单列表 每条订单数据 状态名称（需求如此） 0 => object Mad Dragon 2017年11月14日17:06:55
      getItemOrderStatusName(){
        if (this.L.order == undefined || this.L.order == null) {
          return;
        }
        // 是否是 退款单
        if (this.S.params.isRefundOrder) {
          return this.$utils.orders.getRefundOrderStatuNum(this.L.orderRefund.refundStatus); // 获取退款订单状态
        }
        // 是否是 需求订单。 DEMAND : 需求订单
        if (this.$utils.orders.isDemandOrderType(this.L.order.orderType)) {
          return this.$utils.orders.getDemandOrderStatusNum(this.L.demand);// 获取需求订单状态
        }
        // 是否是 雇佣订单 。HIRE_MONTH : 包月订单 ， HIRE_CUSTOM : 定制订单
        if (this.$utils.orders.isHireOrderType(this.L.order.orderType)) {
          return this.$utils.orders.getHireOrderStatusNum({...this.L.hire, ...this.L.order}); // // 获取雇佣订单状态
        }
        return '';
      },
      /**
       * @Title: 设置订单导航选中进度
       * @Author: Mad Dragon 【 395548460@qq.com 】
       * @Date: 2017/11/18 20:04
       * @Version V2.0.2
       * @Description: 订单状态集合
       *  0: 全部 , 1: 待支付 , 2: 待开始 , 3: 待交付 , 4: 待验收 , 5: 已完成 , 6: 已取消 , 7: 待评价 , 8: 已评价 ,
       *  9: 退款审核中 , 10: 等待设计师审核 , 11: 等待总监审核 , 12: 等待财务审核 , 13: 退款中 , 14: 已退款 , 15: 退款失败 ,16: 验收未通过
       */
      setOrdersNavNum(){
        let ordersNavNum = 0;
        // 退款单 导航
        // 导航数据集合 1 : 退款申请, 2 : 设计师处理退款申请, 3 : 总监处理退款申请, 4 : 退款, 5 : 退款完成,
        if (this.S.params.isRefundOrder) {
          switch (this.S.ordersNum) {
            case 9:
            case 10:
              ordersNavNum = 2;// 设计师处理退款申请
              break;
            case 11:
              ordersNavNum = 3;// 总监处理退款申请
              break;
            case 12:
            case 13:
              ordersNavNum = 4;// 退款
              break;
            case 14:
            case 15:
              ordersNavNum = 5;// 退款完成
              break;
          }
          this.S.ordersNavNum = ordersNavNum;// 订单导航状态
          return;
        }
        // 需求单 导航
        // 导航数据集合 1 : 雇主下单, 2 : 平台分配订单, 3 : 等待雇主支付, 4 : 设计师接单工作, 5 : 等待雇主验收, 6 : 已完成, 7 : 评价,
        if (this.$utils.orders.isDemandOrderType(this.L.order.orderType)) {
          switch (this.S.ordersNum) {
            case 0:
              ordersNavNum = 0;// 未知类型 异常处理
              break;
            case 1:
            case 2:
            case 6:
              ordersNavNum = 3;// 等待雇主支付
              break;
            case 3:
              ordersNavNum = 4;// 设计师接单工作
              break;
            case 4:
            case 16:
              ordersNavNum = 5;// 等待雇主验收
              break;
            case 5:
              ordersNavNum = 6;// 已完成
              break;
          }
          this.S.ordersNavNum = ordersNavNum;// 订单导航状态
          return;
        }
        // 雇佣单 导航
        // 导航数据集合(定制 / 包月) 1 : 雇主下单, 2 : 等待雇主支付, 3 : 设计师接单工作, 4 : 已完成, 5 : 评价,
        if (this.$utils.orders.isHireOrderType(this.L.order.orderType)) {
          let ordersNavNum = 0;
          switch (this.S.ordersNum) {
            case 0:
              ordersNavNum = 0;// 未知类型 异常处理
              break;
            case 1:
            case 2:
            case 6:
              ordersNavNum = 2;// 等待雇主支付
              break;
            case 3:
              ordersNavNum = 3;// 设计师接单工作
              break;
            case 5:
            case 7:
              ordersNavNum = 4;// 等待雇主验收
              break;
            case 8:
              ordersNavNum = 5;// 已完成
              break;
          }
          this.S.ordersNavNum = ordersNavNum;// 订单导航状态
          return;
        }
      },
      // 设置导航数据
      setNavData(){
        if (this.S.params.isRefundOrder) { // 退款单
          this.L.navData = [
            {key: 1, name: '退款申请'},
            {key: 2, name: '设计师处理退款申请'},
            {key: 3, name: '总监处理退款申请'},
            {key: 4, name: '退款'},
            {key: 5, name: '退款完成'},
          ];
          return;
        }

        if (this.$utils.orders.isDemandOrderType(this.L.order.orderType)) { // 需求
          this.L.navData = [
            {key: 1, name: '雇主下单'},
            {key: 2, name: '平台分配订单'},
            {key: 3, name: '等待雇主支付'},
            {key: 4, name: '设计师接单工作'},
            {key: 5, name: '等待雇主验收'},
            {key: 6, name: '已完成'},
            {key: 7, name: '评价'},
          ];
          return;
        }

        if (this.$utils.orders.isHireOrderType(this.L.order.orderType)) { // 定制 / 包月 雇佣单
          this.L.navData = [
            {key: 1, name: '雇主下单'},
            {key: 2, name: '等待雇主支付'},
            {key: 3, name: '设计师接单工作'},
            {key: 4, name: '已完成'},
            {key: 5, name: '评价'},
          ];
          return;
        }
      },
      // 获取订单详情
      getOrderInfo(){
        this.$ajax.get("/order/detail", {orderId: this.S.params.orderId}).then((e) => {
          if (e.status != 200) {
            this.$Notice.error({title: '订单详情', desc: e.msg});
            return;
          }

          this.L.employer = e.data.employer; // 雇主信息
          this.L.orderRefund = e.data.orderRefund; // 订单退款 信息
          this.L.evaluate = e.data.evaluate; // 评价信息
          this.L.designer = e.data.designer; // 设计师信息
          this.L.order = e.data.order; // 订单信息
          this.L.demand = e.data.demand;// 需求设计
          this.L.hire = e.data.hire;// 雇佣信息
          this.L.isLastMonth = e.data.isLastMonth;// 是否是最后一个月
          if (e.data.demand) {
            this.L.demand.classStr1 = e.data.demand.classStr.split(',')[0] || '';
            this.L.demand.classStr2 = e.data.demand.classStr.split(',')[1] || '';
          }
          this.L.order.deadLine =
              (e.data.order.deadLine &&moment(e.data.order.deadLine).format("YYYY-MM-DD HH:mm:ss")) ||
              "";
          this.L.deadLineTxt =
          (e.data.order.deadLine &&moment(e.data.order.deadLine).format("YYYY-MM-DD")) ||
          "";
          if (e.data.hire) {
            this.L.hire.hireId = e.data.hire.id;
            this.L.hire.hireStatus = e.data.hire.status;
          }
          if (e.data.lastAuditVoList) {
            e.data.lastAuditVoList.map((d) => {
              if (d.auditRole == '设计师') {
                this.S.lastAuditVoList.designer = d.auditMsg;
              }
              if (d.auditRole == '总监') {
                this.S.lastAuditVoList.majordomo = d.auditMsg;
              }
            })
          }

          if (e.data.designer) {
            this.L.designer.rankTxt = this.$utils.pub.getDesignerRankName(e.data.designer.rank);// 等级
            this.L.designer.workPlaceTxt = this.$utils.pub.getDesignerWorkPlaceName(e.data.designer.workPlace);// 入驻类型
          }
          if (e.data.order) {
            this.L.order.endTimeTxt = this.$utils.time.formatTime(e.data.order.endTime);
            this.L.order.startTimeTxt = this.$utils.time.formatTime(e.data.order.startTime);
            this.L.order.createTimeTxt = this.$utils.time.formatTime(e.data.order.createTime, 'YYYY-MM-DD HH:mm');
            this.L.order.workStartTimeTxt = this.$utils.time.formatTime(e.data.order.startTime, 'YYYY-MM-DD HH:mm:ss'); // 工作开始时间
            this.L.order.selfClosingTimeTxt = this.setSelfClosingTimeTxt(e.data.order.createTime, e.data.order.orderType);// 订单自动关闭时间
            this.L.order.deadLineTxt = this.$utils.time.formatTime(e.data.order.deadLine, 'YYYY-MM-DD HH:mm:ss');// 工作结束时间
            this.L.order.acceptTimeTxt = this.$utils.time.formatTime(e.data.order.acceptTime, "YYYY-MM-DD HH:mm:ss");// 雇主验收时间
            this.L.order.orderTypeTxt = this.$utils.orders.getOrderTypeName(e.data.order.orderType); // 订单类型
            this.S.params.isRefundOrder = this.$utils.orders.isRefundOrder(e.data.order.status);// 是否是退款单
            this.S.ordersNum = this.getItemOrderStatusName();
          }


          this.setNavData();// 设置导航数据
          this.setOrdersNavNum();// 设置订单导航选中进度 active Mad Dragon 2017年11月17日16:00:36
        })
      },
      // Mad Dragon 【 395548460@qq.com 】 2017/11/23 14:56 订单自动关闭时间
      setSelfClosingTimeTxt(createTime, orderType){
        let days = 1;
        if (this.$utils.orders.isDemandOrderType(orderType)) {
          days = 8;// 自动关闭时间 需求订单 8天自动关闭
        }
        if (this.$utils.orders.isHireOrderType(orderType)) {
          days = 1;// 自动关闭时间 雇佣订单 1天自动关闭
        }
        return this.$utils.time.formatAddTime(createTime, 'YYYY-MM-DD HH:mm:ss', days);// 自动关闭时间
      }
    },


  }
</script>

<style lang="scss" scoped>
  .orders {
    font-size: 14px;
    color: #888;
    .breadcrumb {
      height: 53px;
      line-height: 53px;
      a {
        color: #888;
      }
    }
    .nav {
      padding: 40px 24px 0 24px;
      background-color: #fff;
      position: relative;
      ul {
        overflow: hidden;
        li {
          float: left;
          width: 162px;
          text-align: center;
          div:first-child {
            background-color: #bababa;
            width: 33px;
            height: 33px;
            line-height: 33px;
            border-radius: 15px;
            color: #fff;
            margin: auto;
            position: relative;
            z-index: 99;
          }
          div:last-child {
            height: 50px;
            line-height: 50px;
            font-size: 18px;
            color: #646464;
          }
        }
        .active {
          div:first-child {
            background-color: #f54102;
          }
          div:last-child {
            color: #f54102;
          }
        }

      }
      ul.DEMAND li {
        width: 14.28%;
      }
      ul.HIRE_CUSTOM li {
        width: 20%;
      }
      ul.HIRE_MONTH li {
        width: 20%;
      }
      .hr {
        border-bottom: 1px solid #ebebeb;
        height: 58px;
        width: 1152px;
        position: absolute;
        top: 0;
        z-index: 1;
      }

    }
    .content {
      background-color: #fff;
      margin-top: 16px;
      padding: 25px 53px;
      .row {
        margin-bottom: 20px;
        .title {
          color: #454545;
          height: 40px;
          line-height: 40px;
          border-bottom: 1px solid #ebebeb;
        }
        .info {
          padding: 10px 0;
          span {
            margin-right: 25px;
          }
        }
        .orders-info {
          span {
            display: inline-block;
            width: 33%;
            margin-right: 0;
          }
        }
      }
      ul {
        border: 1px solid #6cc6ef;

        .tab-title {
          overflow: hidden;
          div {
            background-color: #6cc6ef;
            color: #fff;
            height: 28px;
            line-height: 28px;
          }
        }
        .tab-info {
          padding: 15px;
          overflow: hidden;
          display: flex;
          align-items: center;
        }
        div {
          text-align: center;
          float: left;
        }
        .first {
          width: 40%;
        }
        .other {
          width: 20%;
        }
        .money {
          font-size: 16px;
          color: #f54102;
        }
      }

    }
    .status-info {
      background-color: #fff;
      margin-top: 16px;
      padding: 25px 53px;
      min-height: 217px;
      .title {
        height: 40px;
        line-height: 40px;
        border-bottom: 1px solid #ebebeb;
        font-size: 16px;
        color: #646464;
      }
      .info {
        height: 40px;
        line-height: 40px;
        color: #888;
        span {
          color: #f54102;
        }
      }
      .jingao {
        color: #bababa;
        margin-top: 70px;
        min-height: 30px;
        line-height: 30px;
        font-size: 12px;
      }
    }
    .btn-group {
      a {
        display: block;
        width: 64px;
        height: 20px;
        line-height: 20px;
        text-align: center;
        /*margin: auto;*/
        background-color: #5dadff;
        border: 1px solid #5dadff;
        color: #fff;
        border-radius: 4px;
        font-size: 12px;
        margin-bottom: 10px;
      }
      a.error {
        background-color: #fff;
        border: 1px solid #5dadff;
        color: #5dadff;
      }
    }
  }

  .float-btn-group {
    width: 220px;
    overflow: hidden;
    margin: auto;
    a {
      display: block;
      width: 96px;
      height: 28px;
      line-height: 28px;
      text-align: center;
      border-radius: 4px;
    }
    .result {
      float: left;
      border: 1px solid #bababa;
      color: #009fe6;
    }
    .audit {
      float: right;
      background-color: #009fe6;
      border: 1px solid #009fe6;
      color: #fff;
    }
    .auit {
      font-size: 16px;
      color: #666;
    }

  }
</style>
