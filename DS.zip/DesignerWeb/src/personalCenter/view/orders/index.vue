<template>
  <div class="orders">
    <div class="top">
      <div class="nav">
        <a @click="setSearchStatus(item.key)" v-for="item in L.statusList" :key="item.key"
           :class="S.params.searchStatus == item.key ?'active':''" href="javascript:;">{{item.name}}</a>
      </div>
      <div class="form">
        <div class="row">
          <div class="block">
            <div class="title">订单编号 :</div>
            <div class="input">
              <Input v-model="S.params.orderId" placeholder="输入订单编号进行搜索" style="width: 275px;"></Input>
            </div>
          </div>
          <div class="block">
            <div class="title">雇主账号 :</div>
            <div class="input">
              <Input v-model="S.params.employer" placeholder="输入雇主账号进行搜索" style="width: 275px;"></Input>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="block">
            <div class="title">下单时间 :</div>
            <div class="input">
              <div>
                <Date-picker v-model="S.params.startTime" type="date" placeholder="开始日期"
                             style="width: 145px;"></Date-picker>
              </div>
              <div style="margin: 0 10px;">至</div>
              <div>
                <Date-picker v-model="S.params.endTime" type="date" placeholder="结束日期"
                             style="width: 145px;"></Date-picker>
              </div>
            </div>
          </div>
          <div class="block"><a @click="getOrderList" href="javascript:;">搜索</a></div>
        </div>
      </div>
    </div>
    <div class="content" :class="S.orderType == 'DEMAND'?'':'content2'">
      <ul>
        <li>
          <div class="item" style="border-bottom:1px solid #ebebeb; margin-bottom: 10px;">
            <div class="bt tab-title">标题</div>
            <div class="name tab-title">雇主</div>
            <div class="moeny tab-title">金额</div>
            <div class="orderstatu tab-title">订单状态</div>
            <div class="action tab-title">操作</div>
          </div>
        </li>
        <li v-for="item in L.orderList" :key="item.id">
          <div class="title">
            <span>{{item.create_time}}</span>
            <span>订单编号 : {{item.order_id}}</span>
          </div>
          <div class="item">
            <div class="bt">{{item.content}}</div>
            <div class="name">{{item.employer_nickname || item.employer_username}}</div>
            <div class="moeny">￥ {{item.amount}}</div>
            <div class="orderstatu">
              <p>{{item.statusText}}</p>
              <a @click="toOrderInfoPage(item.order_id)" href="javascript:;">详情</a>
            </div>
            <div class="action">
              <span v-if="isAudit(item.status,item.refund_status)">
                 <a @click="setAuditDesigner(item.refund_id,'PASS')" class="error" href="javascript:;">同意退款</a>
                  <a @click="setAuditDesigner(item.refund_id,'NON_PASS')" href="javascript:;">拒绝退款</a>
              </span>
              <a v-if="item.order_type == 'DEMAND' && item.budget_status == 1 && item.complete_status == 0"
                 @click="submit(item.demand_id,1)" href="javascript:;">提交验收</a>
            </div>
          </div>
        </li>
      </ul>
      <div class="orderpage">
        <div class="pagecontent">
          <Page :total="S.params.count" :current="S.params.pageNum" :page-size="S.params.pageSize" @on-change="paging"
                show-total show-elevator class="float-right page page-style" style="margin-top: 20px;"></Page>
        </div>
      </div>
    </div>
    <Modal v-model="S.modal2" title="退款审核" width="680">
      <div class="auit">
        <div class="title" v-if="auditParams.result == 'PASS'">您确认同意退款？请填写审核意见：</div>
        <div class="title" v-else>您确认拒绝退款？请填写审核意见：</div>
        <Form ref="auditParams" :model="auditParams" :rules="ruleInline">
          <div>
            <FormItem style="width: 100%;" prop="auditMsg">
              <Input v-model="auditParams.auditMsg" type="textarea" :autosize="{minRows: 2,maxRows: 5}"
                     placeholder="150个字符以内"></Input>
            </FormItem>
          </div>
        </Form>
        <div class="btn-group">
          <a class="result" @click="closeModal" href="javascript:;">取消</a>
          <a class="audit" @click="handleSubmit('auditParams')" href="javascript:;">确认</a>
        </div>
      </div>
      <div slot="footer"></div>
    </Modal>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // 退款审核 提交参数
      auditParams: {
        auditMsg: '', // 审核信息
        id: '', // 审核单号编号
        result: '', //审核结果 PASS：通过；NON_PASS：未通过
        targetType: 'REFUND' // 审核类型 REFUND：退款，WITHDRAW_DEPOSIT:提现
      },
      ruleInline: {
        auditMsg: [
          { required: true, message: '请输入审核意见', trigger: 'blur' },
          {
            type: 'string',
            max: 150,
            message: '审核意见不能多于150个字符',
            trigger: 'blur'
          }
        ]
      },
      // status 缩写 S 状态集合数据
      S: {
        modal2: false, // 退款审核 审核浮动
        orderType: '-1',
        // 列表 搜索参数
        params: {
          count: 0,
          pageSize: 10,
          pageNum: 1,
          startTime: '',
          endTime: '',
          orderId: '', // 订单编号
          employer: '', // 雇主账号
          searchStatus: '-1',
          type: ''
        }
      },
      // list 缩写 L 列表集合数据
      L: {
        orderList: [],
        statusList: [] // 订单状态
      }
    };
  },
  mounted() {
    this.getInitData(); // 初始化 界面参数
  },
  watch: {
    $route: function() {
      this.getInitData(); // 初始化 界面参数
    }
  },
  computed: {},
  filters: {},
  methods: {
    // 判断
    // eslint-disable-next-line
    isAudit(status, refund_status) {
      return (
        // eslint-disable-next-line
        this.$utils.orders.isRefundOrder(status) && refund_status == 'PENDING_DESIGNER_AUDIT'
      );
    },
    // 审核界面  取消审核
    closeModal() {
      this.S.modal2 = false;
      this.auditParamsResult(); // 重置 审核参数
    },
    // 重置 审核参数
    auditParamsResult() {
      this.auditParams = {
        auditMsg: '', // 审核信息
        id: '', // 审核单号编号
        result: '', //审核结果 PASS：通过；NON_PASS：未通过
        targetType: 'REFUND' // 审核类型 REFUND：退款，WITHDRAW_DEPOSIT:提现
      };
    },
    /**
       * @Title: 审核数据验证
       * @Author: Mad Dragon 【 395548460@qq.com 】
       * @Date: 2017/11/18 19:40
       * @Version V2.0.2
       * @Description:
       */
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          this.auditDesigner();
        } else {
        }
      });
    },
    // eslint-disable-next-line
    setAuditDesigner(refund_id, result) {
      // eslint-disable-next-line
      this.auditParams.id = refund_id; // 退款编号
      this.auditParams.result = result; // 审核结果
      this.S.modal2 = true;
    },
    // Mad Dragon 【 395548460@qq.com 】 2017/11/18 19:47 设计师退款审核
    auditDesigner() {
      this.$ajax
        .post('/orders/refund/designer', { ...this.auditParams })
        .then(e => {
          if (e.status != 200) {
            this.$Notice.error({
              title: '退款审核',
              desc: e.msg
            });
            return;
          }
          this.S.modal2 = false;
          this.auditParamsResult(); // 重置 审核参数
          this.getOrderList();
        });
    },
    /**
       * @Title: 需求订单 提交验收
       * @Author: Mad Dragon 【 395548460@qq.com 】
       * @Date: 2017/11/18 19:47
       * @Version V2.0.2
       *
       * @param id 需求ID demand_id
       * @param completeStatus 完成状态 始终传值1(接口这么定义的)
       *
       * @Description:
       *
       */
    submit(id, completeStatus) {
      this.$Modal.confirm({
        title: '提交验收',
        content: '<p>您是否确认提交验收</p>',
        onOk: () => {
          this.updatestatus(id, completeStatus);
        },
        onCancel: () => {}
      });
    },
    /**
       * @Title: 需求订单 提交验收数据
       * @Author: Mad Dragon 【 395548460@qq.com 】
       * @Date: 2017/11/22 20:31
       * @Version V2.0.2
       *
       * @param id 需求ID demand_id
       * @param completeStatus 完成状态 始终传值1(接口这么定义的)
       *
       * @Description:
       */
    updatestatus(id, completeStatus) {
      this.$ajax
        .post('/demand/updatestatus', {
          complete_status: completeStatus,
          id: id
        })
        .then(e => {
          if (e.status != 200) {
            this.$Notice.success({
              title: '提交审核',
              desc: e.msg
            });
            return;
          }
          this.$Notice.success({
            title: '提交审核',
            desc: '提交成功'
          });
          this.getOrderList();
        });
    },
    // Mad Dragon 【 395548460@qq.com 】 2017/11/18 19:49 跳转到 订单详情页面
    toOrderInfoPage(orderId) {
      this.$router.push({
        name: 'ordersinfo',
        query: {
          orderId: orderId,
          orderType: this.S.orderType
        }
      });
    },
    /**
       * @Title: 设置 订单状态 列表
       * @Author: Mad Dragon 【 395548460@qq.com 】
       * @Date: 2017/11/22 20:10
       * @Version V2.0.2
       * @Description: 所有订单状态列表
       * 0: 未知类型 -1: 全部订单
       *
       * 正常订单
       *     1: 待支付 2: 待开始 3: 待交付 4: 待验收 16:验收不通过(需求订单) 5: 已完成 6: 已取消 7: 待评价 8: 已评价
       *
       * 退款订单
       *     9: 退款审核中 10: 等待设计师审核 11: 等待总监审核 12: 等待财务审核 13: 退款中 14: 已退款 15: 退款失败
       */
    setStatusList() {
      // Mad Dragon 【 395548460@qq.com 】 2017/11/22 20:18  需求订单状态列表
      if (this.$utils.orders.isDemandOrderType(this.S.orderType)) {
        this.L.statusList = this.$utils.orders.filterOrderStatusList(
          '-1,1,3,4,5,6,9,13,14'
        );
        return;
      }
      // Mad Dragon 【 395548460@qq.com 】 2017/11/22 20:18  雇佣订单状态列表
      if (this.$utils.orders.isHireOrderType(this.S.orderType)) {
        this.L.statusList = this.$utils.orders.filterOrderStatusList(
          '-1,1,2,3,7,8,6,9,13,14'
        );
        return;
      }
      // Mad Dragon 【 395548460@qq.com 】 2017/11/22 20:18  默认订单状态列表
      this.L.statusList = this.$utils.orders.filterOrderStatusList(
        '-1,1,3,7,8,6,9,13,14'
      );
    },
    // 初始化 界面参数 Mad Dragon 2017年11月14日17:06:22
    getInitData() {
      this.S.orderType = this.$route.query.orderType || ''; // 订单类型 Mad Dragon 2017年11月14日15:53:44
      this.S.params.searchStatus = '-1'; // Mad Dragon 【 395548460@qq.com 】 2017/11/20 15:32 切换订单类型时 默认显示全部订单
      this.setStatusList(); // 设置 订单状态 列表 Mad Dragon 2017年11月14日15:53:22
      this.getOrderList(); // 获取订单列表 Mad Dragon 2017年11月14日11:17:06
    },
    // 分页 页码修改 Mad Dragon  2017年11月14日17:06:31
    paging(pageNum) {
      this.S.params.pageNum = pageNum;
      this.getOrderList();
    },
    // 设置 当前 订单状态 更新数据 Mad Dragon 2017年11月14日17:06:40
    setSearchStatus(key) {
      this.S.params.searchStatus = key;
      this.getOrderList();
    },
    // 获取订单列表 Mad Dragon 2017年11月14日11:07:04
    getOrderList() {
      let _this = this;
      let params = { ...this.S.params };
      params.startTime = this.$utils.time.startTime(
        this.S.params.startTime,
        'YYYY-MM-DD HH:mm:ss'
      );
      params.endTime = this.$utils.time.endTime(
        this.S.params.endTime,
        'YYYY-MM-DD HH:mm:ss'
      );

      params.type = this.S.orderType != -1 ? this.S.orderType : '';
      params.searchStatus =
        this.S.params.searchStatus != -1 ? this.S.params.searchStatus : '';

      this.$ajax.get('/order/list', params).then(e => {
        if (e.status != 200) {
          this.$Notice.error({ title: '订单中心', desc: e.msg });
          return;
        }
        this.L.orderList = e.data.list || [];
        this.L.orderList.map(function(item) {
          item.statusText = _this.getItemOrderStatusName(item); // 获取订单列表 每条订单数据 状态名称
          item.create_time = _this.$utils.time.formatTime(
            item.create_time,
            'YYYY-MM-DD HH:mm'
          ); // 订单创建时间
        });
        this.S.params.count = Math.ceil(e.data.count) || 0;
      });
    },
    // 获取订单列表 每条订单数据 状态名称（需求如此） 0 => object Mad Dragon 2017年11月14日17:06:55
    getItemOrderStatusName(orderInfo) {
      if (orderInfo == undefined || orderInfo == null) {
        return;
      }
      // 是否是 退款单
      if (this.$utils.orders.isRefundOrder(orderInfo.status)) {
        return this.$utils.orders.getRefundOrderStatuName(
          orderInfo.refund_status
        ); // 获取退款订单状态名称
      }
      // 是否是 需求订单。 DEMAND : 需求订单
      if (this.$utils.orders.isDemandOrderType(orderInfo.order_type)) {
        return this.$utils.orders.getDemandOrderStatusName(orderInfo); // 获取需求订单状态名称
      }
      // 是否是 雇佣订单 。HIRE_MONTH : 包月订单 ， HIRE_CUSTOM : 定制订单
      if (this.$utils.orders.isHireOrderType(orderInfo.order_type)) {
        return this.$utils.orders.getHireOrderStatusName(orderInfo); // 获取雇佣订单状态名称
      }
      return '未知状态';
    }
  }
};
</script>

<style lang="scss" scoped>
.orders {
  .top {
    padding: 32px 22px;
    background-color: #fff;
    box-shadow: 4px 4px 5px 3px #efefef;
    overflow: hidden;
    min-width: 902px;

    .nav {
      border-bottom: 1px solid #ebebeb;
      overflow: hidden;
      a {
        display: block;
        padding: 10px;
        color: #646464;
        font-size: 14px;
        text-align: center;
        float: left;
      }
      a.active {
        border-bottom: 2px solid #f54203;
        padding: 10px 10px 8px 10px;
      }
    }
    .form {
      margin-top: 15px;
      .row {
        padding: 10px 0;
        overflow: hidden;
        .block {
          float: left;
          width: 420px;
          height: 34px;
          line-height: 34px;
          overflow: hidden;
          font-size: 14px;
          color: #646464;
          .title {
            float: left;
            width: 75px;
          }
          .input {
            overflow: hidden;
            div {
              float: left;
            }
            input {
              width: 150px;
              height: 27px;
              border: 1px solid #ebebeb;
              text-indent: 10px;
              color: #646464;
              font-size: 12px;
            }
          }
          a {
            display: block;
            width: 76px;
            height: 28px;
            line-height: 28px;
            text-align: center;
            background-color: #5dadff;
            color: #fff;
            border-radius: 4px;
          }
        }
      }
    }
  }
  .content {
    margin-top: 30px;
    background-color: #fff;
    box-shadow: 4px 4px 5px 3px #efefef;
    overflow: hidden;
    min-width: 902px;
    ul {
      padding: 0px 22px;
      overflow: hidden;
      li {
        font-size: 14px;
        .title {
          overflow: hidden;
          height: 28px;
          line-height: 28px;
          font-size: 12px;
          color: #646464;
          background-color: #f1f1f1;
          span {
            display: inline-block;
            min-width: 100px;
            margin-right: 20px;
            text-indent: 15px;
          }
        }
        .item {
          padding: 20px 0;
          overflow: hidden;
          display: flex;
          align-items: center;
          div {
            float: left;
            text-align: center;
          }
          .bt {
            width: 285px;
            color: #888;
            text-align: left;
          }
          .name {
            width: 150px;
            color: #888;
          }
          .moeny {
            width: 140px;
            color: #454545;
            font-weight: bold;
          }
          .orderstatu {
            width: 140px;
            p {
              color: #f54203;
            }
            a {
              display: block;
              color: #646464;
            }
          }
          .action {
            width: 140px;
            a {
              display: block;
              width: 64px;
              height: 20px;
              line-height: 20px;
              text-align: center;
              margin: auto;
              background-color: #5dadff;
              border: 1px solid #5dadff;
              color: #fff;
              border-radius: 4px;
              font-size: 12px;
              margin-bottom: 10px;
            }
            a.error {
              background-color: #fff;
              border: 1px solid #5dadff;
              color: #5dadff;
            }
          }
          .tab-title {
            font-size: 16px;
            color: #5dadff;
            font-weight: 400;
            text-align: center;
          }
        }
      }
    }
  }
  .content2 {
    ul {
      li {
        .item {
          .bt {
            display: none;
          }
          .name {
            width: 320px;
          }
          .moeny {
            width: 170px;
          }
          .orderstatu {
            width: 170px;
          }
          .action {
            width: 170px;
          }
        }
      }
    }
  }
  .orderpage {
    padding: 0px 22px;
    .pagecontent {
      height: 90px;
      border-top: 1px solid #ebebeb;
    }
  }
}

.auit {
  font-size: 16px;
  color: #666;
}

.btn-group {
  width: 220px;
  overflow: hidden;
  margin: auto;
  a {
    display: block;
    width: 96px;
    height: 28px;
    line-height: 28px;
    text-align: center;
    border-radius: 4px;
  }
  .result {
    float: left;
    border: 1px solid #bababa;
    color: #009fe6;
  }
  .audit {
    float: right;
    background-color: #009fe6;
    border: 1px solid #009fe6;
    color: #fff;
  }
}
</style>
