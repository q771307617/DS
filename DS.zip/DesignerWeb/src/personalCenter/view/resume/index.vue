<template>
  <div class="orderShouru ">
    <div  v-if="show" >
      <div class="mine boxshadow">
          <p><span>基本信息</span></p>
          <ul >
            <li>真实姓名 ：<span class="sRight">{{infoParams.realname?infoParams.realname:""}}</span> <span class="saveBtn" @click="write()"> <a>编辑</a> </span></li>
            <li>姓　　别 ：<span class="sRight">{{infoParams.gender==0?"男":"女"}}</span>  </li>
            <li>花　　名 ：<span class="sRight">{{infoParams.nickname}}</span> </li>
            <li>出生日期 ：<span class="sRight">{{infoParams.birthday}}</span></li>
            <!-- <li>薪　　资 ： <span class="sRight">￥ {{salayParams[infoParams.salary]}} 元</span></li> -->
            <li>薪　　资 ：<span class="sRight">￥{{infoParams.salary}}</span></li>
            <li>工作年限 ：<span class="sRight">{{infoParams.exp}} 年</span></li>
            <li>所在城市 ：<span class="sRight">{{infoParams.city| getcity(provs)}}</span> </li>
            <li>学　　历 ：<span class="sRight">{{schoolheight[infoParams.education?infoParams.education-1:5].label}}</span>  </li>
            <li>个性签名 ：<span class="sRight">{{infoParams.description}}</span></li>
            <li>设计宣言 ：<span class="sRight">{{infoParams.designDeclaration}}</span></li>
        </ul>
        </div>
        <div class="phone boxshadow">
          <p><span>联系方式</span></p>
          <ul >
            <li>Q　　 Q ：<span class="sRight">{{infoParams.qq}}</span></li>
            <li>手机号码 ：<span class="sRight">{{infoParams.phone}}</span></li>
          </ul>
        </div>
        <div class="exp boxshadow">
          <p><span>工作经验</span></p>
          <ul >
            <li>从业时间 ：<span class="sRight">{{employTimeData[infoParams.workYear]}}</span></li>
            <li>擅长类目 ：<span class="sRight">{{infoParams.skilful | getStylel(childList4)}}</span></li>
            <li>设计风格 ：<span class="sRight">{{infoParams.style | getStylel(styles)}}</span></li>
          </ul>
        </div>
    </div>
    <div v-else class="orderShouru ">
      <div class="mine boxshadow">
        <p><span>基本信息</span></p>
        <ul >
            <li>真实姓名 : <span class="sRight">{{infoParams.realname}}</span> <span class="saveBtn" @click="saveBtn()"> <a>保存</a> </span></li>
            <li>姓　　别 : <span class="sRight">{{infoParams.gender==0?"男":"女"}}</span> </li>
            <li>花　　名 : <span class="sRight">{{infoParams.nickname}}</span> </li>
            <li>出生日期 : <span class="sRight">{{infoParams.birthday}}</span></li>
            <li>薪　　资 : <input class="work_year sRight f2" type="text" v-model="infoParams.salary" @change="salary(infoParams.salary)" > 元 <span class="error" v-show="HintError"><img  :src="'join/err.png' | randomPath" > {{HintError}}</span></li>
            <li>工作年限 : <input class="work_year sRight f2" type="text" placeholder="工作年限保留一位小数" v-model="infoParams.exp" @change="exp(this,1)" > 年  <span class="error" v-show="expShow"><img  :src="'join/err.png' | randomPath" > 不符合选定的工作年限</span></li>
            <li>所在城市 : <Cascader class="sRight" placeholder="请选择您的城市" style="width:200px;display:inline-block;" :data="provs"  v-model="infoParams.city"></Cascader></li>
            <li>学　　历 :
                          <Select class="sRight" :value = "infoParams.education" v-model="infoParams.education" placeholder="请选择您的学历" style="width:200px">
                              <Option v-for="item in schoolheight" :value="item.value"  :key="item.value">{{ item.label }}</Option>
                          </Select>
            </li>
            <li> <span class="h6">个性签名 :</span>  <textarea class="sRight f2" v-model= "infoParams.description" rows="1" cols="120" placeholder="最多50个字符"  maxlength="50"/></li>
            <li> <span class="h6">设计宣言 :</span> <textarea class="sRight f2" v-model= "infoParams.designDeclaration" rows="1" cols="120" placeholder="最多50个字符" maxlength="50"/></li>
        </ul>
      </div>
      <div class="phone boxshadow">
        <p><span>联系方式</span></p>
        <ul >
          <li>QQ 　　　：<span class="sRight">{{infoParams.qq}}</span></li>
          <li>手机号码 ：<span class="sRight">{{infoParams.phone}}</span></li>
        </ul>
      </div>
      <div class="exp boxshadow">
        <p><span>工作经验</span></p>
        <ul >
          <li>从业时间 ： <span class="sRight">{{employTimeData[infoParams.workYear]}}</span></li>
          <li>擅长类目 ：<span class="sRight">{{infoParams.skilful | getStylel(childList4)}}</span></li>
          <li>设计风格 ：<span class="sRight">{{infoParams.style | getStylel(styles)}}</span></li>
        </ul>
      </div>
    </div>
    <div class="resume boxshadow">
        <p><span>个性简历</span></p>
        <div class="to_resume" v-if="personResumeShow">
            <span class="" >
                <Upload
                                  ref="uploadCover"
                                  :show-upload-list="false"
                                  :on-success="handleSuccessCover"
                                  :format="['jpg','jpeg','png']"
                                  :max-size="5120"
                                  :on-format-error="handleFormatError"
                                  :on-exceeded-size="handleMaxSizeCover"
                                  multiple
                                  :action="actionPath"
                                  style="display: inline-block;width:116px;">
                              <Button ref="proFM" type="ghost" icon="ios-cloud-upload-outline">上传个性简历</Button>
                </Upload>
            </span>
        </div>
        <div class="to_resume" v-else>
          <div class="bjBtn clearboth" @click="bjBtn()">
            <Upload
                                  ref="uploadCover"
                                  :show-upload-list="false"
                                  :on-success="handleSuccessCover"
                                  :format="['jpg','jpeg','png']"
                                  :max-size="5120"
                                  :on-format-error="handleFormatError"
                                  :on-exceeded-size="handleMaxSizeCover"
                                  multiple
                                  :action="actionPath"
                                  style="display: inline-block;width:186px;margin:18px 20px;">
                              <Button style="width:116px;height:28px;line-height:28px;padding:0;font-size:14px;background:#009fe6;border-radius:5px;" ref="proFM" type="ghost" icon="ios-cloud-upload-outline">编辑</Button>
                </Upload>
          </div>
          <div class="resumeimg" v-html="infoParams.details">
            <!-- <img :src="infoParams.personResume"/> -->
            </div>
        </div>
      </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex';
import moment from 'moment';
export default {
  watch: {
    // infoParams: function(val, oldVal) {
    //
    // }
  },
  data() {
    return {
      HintError: '',
      infoParams: {},
      postParams: {
        city: ['', ''],
        designDeclaration: '',
        education: '',
        description: '',
        personResume: '',
        exp: ''
      },
      show: true,
      showS: true,
      expShow: false,
      personResumeShow: true,
      actionPath: this.$ajax.pathUpload
    };
  },
  computed: {
    ...mapState({
      info: state => state.User.info,
      childList4: state => state.Lists.childList4,
      styles: state => state.Lists.styles,
      provs: state => state.pub.provs,
      employTimeData: state => state.pub.employTimeData,
      salayParams: state => state.pub.salayParams,
      schoolheight: state => state.pub.schoolheight,
      salaryScope: state => state.pub.salaryBudget
    })
  },
  mounted() {
    this.getInfo();
    // 获取薪资范围
    this.getSalary();
  },
  filters: {
    getStylel(i, data) {
      let style = '';
      if (i) {
        if (typeof i == 'string') {
          i = i.split(',');
        }
        for (let item in i) {
          style += data[item].name + ' / ';
        }
        style = style.substr(0, style.length - 1);
      } else {
        return '';
      }
      return style.substr(0, style.length - 1);
    },
    getcity(i, data) {
      if (i instanceof String) {
        i = i.split(',');
      }
      if (i instanceof Array && i[0] && i != []) {
        let city = '';
        city +=
          data[Number(i[0]) - 1].label +
          ' / ' +
          data[Number(i[0] - 1)].children[Number(i[1]) - 1].label;
        return city;
      } else {
        return '';
      }
    }
  },
  methods: {
    ...mapActions(['getSalary']),
    /*获取设计师信息*/
    getInfo() {
      this.$ajax.get('registerdesigner/queryenteruserinfo').then(e => {
        if (e.status == 200) {
          if (e.data.city != null) {
            e.data.city = e.data.city.split(',');
          } else {
            e.data.city = [];
          }
          e.data.birthday = moment(e.data.birthday).format('YYYY年MM月DD日');
          this.infoParams = e.data;
          if (this.infoParams.education != null) {
            this.infoParams.education = this.infoParams.education.toString();
          }
          e.data.personResume == '' && e.data.details == ''
            ? (this.personResumeShow = true)
            : (this.personResumeShow = false);
          // console.log(e.data.city,e.data.designDeclaration,e.data.education,e.data.description,e.data.exp,
          //   e.data.city==null||e.data.city[0]=="",e.data.designDeclaration=='',
          //   e.data.education==null,e.data.description==null||e.data.description=="",e.data.exp==null||e.data.description=="",
          //   e.data.city==null||e.data.city[0]==""&&e.data.designDeclaration==''&&e.data.education==null&&e.data.description==""&&e.data.exp=="")
          if (
            e.data.city == null ||
            (e.data.city[0] == '' &&
              e.data.designDeclaration == '' &&
              e.data.education == null &&
              e.data.description == '' &&
              e.data.exp == null &&
              this.showS == true)
          ) {
            this.show = false;
          } else {
            this.show = true;
          }
        } else {
          this.$Notice.error({ title: e.msg });
        }
      });
    },
    postInfo() {
      let list = { ...this.infoParams };
      // list.education==5?list.education="":list.education=list.education;
      if (list.city instanceof Array) {
        list.city = list.city.join(',');
      }
      this.$ajax.post('registerdesigner/updatedesignerinfo', list).then(e => {
        if (e.status == 200) {
          this.getInfo();
        } else {
          this.$Notice.error({ title: e.msg });
        }
      });
    },
    // 设置薪资
    salary(value) {
      let rank = this.infoParams.rank;
      let startSalary = Number(this.salaryScope[rank].start);
      let endSalary = Number(this.salaryScope[rank].end);
      if (!value) {
        this.HintError = '请输入薪资';
      } else if (value < startSalary || value > endSalary) {
        this.HintError = '您可设置的薪资范围为' + startSalary + '--' + endSalary;
      } else {
        this.HintError = '';
      }
    },
    exp(e, num) {
      var start = 0;
      var end = 100;
      switch (this.infoParams.workYear) {
        case 1:
          start = 0;
          end = 1;
          break;
        case 2:
          start = 1;
          end = 2;
          break;
        case 3:
          start = 2;
          end = 3;
          break;
        case 4:
          start = 3;
          end = 5;
          break;
        case 5:
          start = 5;
          end = 100;
          break;
        default:
          break;
      }
      if (this.infoParams.exp <= end && this.infoParams.exp >= start) {
        // this.infoParams.exp;
        this.expShow = false;
        var regu = /^[0-9]+\.?[0-9]*$/;
        if (!regu.test(this.infoParams.exp)) {
          // this.$Message.error("请输入正确的工作年限")
          this.infoParams.exp = this.infoParams.exp.substring(
            0,
            this.infoParams.exp.length - 1
          );
          this.infoParams.exp = '';
          e.focus();
        }
        if (this.infoParams.exp.indexOf('.') > -1) {
          if (this.infoParams.exp.split('.')[1].length > num) {
            this.infoParams.exp = this.infoParams.exp.substring(
              0,
              this.infoParams.exp.length - 1
            );
            e.focus();
          }
        }
      } else {
        this.infoParams.exp = '';
        this.expShow = true;
        // this.$Message.error("请输入正确的工作年限")
      }
    },
    /*保存资料*/
    saveBtn() {
      // 信息填写正确再提交
      if (!this.HintError && !this.expShow) {
        this.postInfo();
        this.showS = false;
        this.show = true;
      }
    },
    write() {
      this.show = false;
    },
    bjBtn() {
      // this.personResumeShow=true;
    },
    handleSuccessCover(res, file) {
      //文件上传成功
      if (res.status == 200) {
        file.url = res.data + '!790';
        file.name = res.data;
        this.infoParams.personResume = file.url;
        this.infoParams.details =
          '<p><img src="' + file.url + '" name="' + file.name + '"></p>';
        this.postInfo();
        this.personResumeShow = false;
        this.$Message.success('文件上传成功');
      } else {
        this.personResumeShow = true;
        this.$Message.error(res.msg);
        this.handleRemoveCover(file);
      }
    },
    handleMaxSizeCover(file) {
      //文件超出大小
      this.$Notice.warning({
        title: '超出文件大小限制',
        desc: '文件 ' + file.name + ' 太大，不能超过 5M。'
      });
    },
    handleFormatError(file) {
      //文件格式验证失败
      this.$Notice.warning({
        title: '文件格式不正确',
        desc: '文件 ' + file.name + ' 格式不正确，请上传 jpg 或 png 格式的图片。'
      });
    }
  }
};
</script>
<style lang="scss" scoped>
$color: #009fe6;
$font4: 14px;
$font8: 18px;
.error {
  color: #f54102;
  img {
    margin-bottom: -4px;
  }
}
.boxshadow {
  box-shadow: 3px 3px 5px #ccc;
  background: #fff;
}
.orderShouru {
  border: 1px solid #ffffff;
  background: #fff;
}
.mine,
.phone,
.resume,
.exp {
  margin: 5px auto;
  p {
    margin: 20px 20px 0 27px;
    border-bottom: 1px solid #ebebeb;
    font-size: 18px;
    color: $color;
    span {
      border-bottom: 2px solid #ebebeb;
      display: inline-block;
      hieght: 32px;
      line-height: 32px;
    }
  }
  ul {
    padding: 11px 27px;
    margin: 0 auto;
    li {
      padding-bottom: 6px;
      min-height: 26px;
      line-height: 26px;
      font-size: $font4;
      .sRight {
        margin-left: 7px;
      }
      .f2 {
        font-size: 12px;
      }
      .work_year,
      .school {
        width: 200px;
        text-indent: 5px;
        padding: 3px;
        border-radius: 5px;
        border: 1px solid #ccc;
      }
      textarea {
        display: inline-block;
        line-height: 26px;
        text-indent: 3px;
        border-radius: 5px;
        padding: 5px;
        border: 1px solid #ccc;
      }
      .error {
        margin-left: 36px;
      }
      .saveBtn a {
        float: right;
        display: inline-block;
        height: 28px;
        line-height: 28px;
        width: 116px;
        text-align: center;
        background: $color;
        color: #ffffff;
        border-radius: 5px;
      }
    }
  }

  .to_resume {
    height: auto !important;
    min-height: 110px;
    position: relative;
    margin: 10px;
    padding-bottom: 80px;
    button {
      background: $color;
      color: #fff;
    }
    span {
      width: 120px;
      height: 30px;
      display: block;
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      margin: auto;
    }
    .resumeimg {
      display: block;
      width: 897px;
      display: table-cell;
      text-align: center;
      vertical-align: middle;
      margin: 80px;
    }
    .resumeimg img {
      max-width: 820px;
      display: inline-block;
    }
    .bjBtn {
      text-align: right;
      a {
        margin: 18px 20px;
        display: inline-block;
        height: 28px;
        line-height: 28px;
        width: 116px;
        text-align: center;
        background: $color;
        color: #ffffff;
        border-radius: 5px;
      }
    }
  }
}
.mine {
  margin: 0;
}
</style>
