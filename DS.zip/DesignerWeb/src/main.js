/* eslint-disable */
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue';
import App from './App';
import router from './router';
import iView from 'iview';
import VueResource from 'vue-resource';
import store from './store';
import 'iview/dist/styles/iview.css';
import api from './api';
import Filter from '@/filter';
import VueLazyload from 'vue-lazyload';
import { user } from '@/sessionstorage/index.js';
import moment from 'moment';
import utils from '@/utils';

Vue.use(iView); // iView
Vue.use(VueResource); // VueResource
Vue.prototype.$ajax = api;
Vue.prototype.$moment = moment;
Vue.prototype.$utils = utils;

// VueViewload
Vue.use(VueLazyload, {
  preLoad: 1.3,
  // error: 'dist/error.png',
  loading: 'http://5.img.dianjiangla.com/assets/icon/loading.png',
  attempt: 1
});
// Vue.http.options.emulateJSON = true;
// // http拦截器 处理发送请求前的事情和发送请求后的事情
// let backHome = function(){
//     store.commit('set_user_data',{});
//     router.push({
//         name:"indexPage"
//     });
// }
// Vue.http.interceptors.push((request, next) => {
//     console.info("发送请求......",request);
// next((response) => {
//         // console.info("请求结束.....",response);
//         //如果未登录 跳转到登录页面
//         if(response.data && response.data.status == "401"){
//             // console.error("你没有登录");
//             backHome();
//         }
//         if(response && response.data && response.data.status != "200"){
//           response.data.data = {
//
//           };
//         }
//         return response;
//
//   });
// });

Vue.config.productionTip = false;
// eslint-disable-next-line
new Vue({
  el: '#app',
  store,
  api,
  router,
  template: '<App/>',
  components: { App }
});
