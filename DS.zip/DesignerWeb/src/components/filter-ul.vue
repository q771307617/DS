<template>
    <ul>
        label,
    </ul>
</template>
<script>
export default {
  props: [''],
  data() {
    return {};
  },
  mounted() {},
  methods: {},
  computed: {}
};
</script>

