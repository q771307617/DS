<template>
    <div class="header-warp">
    <header class="header">
        <ul class="user clearfix">
            <li class="float-left font12">你好，</li>
            <!--<li v-if="info.id" class="user-name float-left">-->
                <!--<Dropdown>-->
                    <!--<a href="javascript:void(0)" class="font12">-->
                        <!--{{info|getName}}-->
                        <!--<Icon type="arrow-down-b"></Icon>-->
                    <!--</a>-->
                    <!--<Dropdown-menu slot="list">-->
                        <!--<Dropdown-item>-->
                            <!--<div  @click="loginout" class="font12">-->
                                <!--退出-->
                            <!--</div>-->
                        <!--</Dropdown-item>-->
                    <!--</Dropdown-menu>-->
                <!--</Dropdown>-->
            <!--</li>-->
            <li class="float-left font12">欢迎来到点将啦！</li>
        </ul>
    </header>
    <!--<div class="ivu-modal-mask" v-if="registerModal || loginModal"></div>-->
    <!--<div class="ivu-modal-wrap" v-if="loginModal">-->
        <!--<Login :cancle="cancle"></Login>-->
    <!--</div>-->
    <!--<div class="ivu-modal-wrap" v-if="registerModal">-->
        <!--<Register :cancle="cancle"></Register>-->
    <!--</div>-->
    </div>
</template>

<script>
import Register from '@/components/register.vue';
import Login from '@/components/login.vue';
import { mapState } from 'vuex';
export default {
  data() {
    return {
      loginModal: false,
      registerModal: false
    };
  },
  components: {
    Login,
    Register
  },
  computed: {
    ...mapState({
      info: state => state.User.info
    })
  },
  mounted() {},
  methods: {
    cancle() {
      this.loginModal = false;
      this.registerModal = false;
    },
    loginout() {
      this.$store.commit('set_user_data', {});
      //  this.$root.$emit("LOGIN_OUT");
      this.$ajax.post('auth/logout').then(e => {});
    }
  }
};
</script>
<style>
.header .ivu-input-group-append,
.header .ivu-input-group-prepend {
  border: 1px solid #e63f04;
}
</style>
<style scoped>
.header-warp {
  background-color: #c20c0c;
  width: 100%;
}
.header {
  width: 1200px;
  height: 24px;
  line-height: 24px;
  margin: 0 auto;
  color: #fff;
}
.user {
  display: block;
}
/*.user>li {*/
/*padding: 0 5px;*/
/*margin: 0 5px;*/
/*}*/
.user > li:first-child {
  margin-left: 0;
  padding-left: 0;
}
.user-name a {
  color: #fc7b09;
}
</style>

