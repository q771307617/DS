<style scoped>
.login-main {
  width: 315px;
  margin: 0 auto;
}

.btn-login {
  height: 48px;
  width: 100%;
}

img {
  height: 100%;
  width: 100%;
}
</style>
<template>
    <Modal v-model="resetModal" width="376" :styles="{left: '50%','margin-left': '180px',top: '250px'}" @on-cancel="cancel">
        <div class="login">
            <div class="login-main">
                <div style="display: flex;justify-content: space-between;align-items: baseline;margin-top: 20px;margin-bottom: 20px;">
                    <span style="font-size: 22px;color: #888888;">新密码</span>
                </div>
                <Form ref="formInline" :model="formInline" :rules="ruleInline" inline style="min-height: 185px;">
                    <Form-item prop="password" style="width: 100%;">
                        <Input type="password" v-model="formInline.password" size="large" placeholder="新密码"> </Input>
                    </Form-item>
                    <Form-item prop="verifyPassword" style="width: 100%;">
                        <Input type="password" v-model="formInline.verifyPassword" size="large" placeholder="确认密码" @on-enter="handleSubmit('formInline')"></Input>
                    </Form-item>
                    </Form-item>
                    <Form-item style="width: 100%;margin-bottom: -10px;" v-if="!!error_msg">
                        <Alert type="error">{{error_msg}}</Alert>
                    </Form-item>
                </Form>
            </div>
        </div>
        <div slot="footer">
            <Button type="error" @click="handleSubmit('formInline')" class="btn-login">重置密码</Button>
        </div>
    </Modal>
</template>

<script>
import { mapState } from 'vuex';

export default {
  computed: {
    ...mapState({
      resetModal: state => state.Modal.resetModal,
      code: state => state.User.code,
      phone: state => state.User.phone
    })
  },
  data() {
    return {
      error_msg: '',
      formInline: {
        password: '',
        verifyPassword: ''
      },
      ruleInline: {
        password: [
          {
            required: true,
            message: '请填写密码',
            trigger: 'blur'
          },
          {
            pattern: /^[a-zA-Z0-9]{6,20}$/,
            message: '密码只能输入字母、数字，密码长度限制6~20',
            trigger: 'blur'
          }
        ],
        verifyPassword: [
          {
            required: true,
            message: '请填写确认密码',
            trigger: 'blur'
          }
        ]
      }
    };
  },
  methods: {
    cancel() {
      this.$refs.formInline.resetFields();
      this.$store.commit('SETTING_RESET_MODAL', false);
    },
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (!valid) return;

        let password = this.formInline.password;
        let verifyPassword = this.formInline.verifyPassword;
        if (password !== verifyPassword) {
          this.error_msg = '两次密码不匹配';
          return;
        }

        this.error_msg = '';
        this.$ajax
          .post('auth/password/forget', {
            password,
            phone: this.phone,
            code: this.code
          })
          .then(e => {
            if (e.status !== 200) {
              this.error_msg = e.msg;
              setTimeout(() => {
                this.$refs.formInline.resetFields();
                this.error_msg = '';
                this.$store.commit('SETTING_VERIFY_USER_MODAL', true);
              }, 2000);
              return;
            }
            this.cancel();
            this.$Message.success('密码已重置，请重新登录');
          });
      });
    }
  }
};
</script>

