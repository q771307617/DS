<template>
    <div>
        <p class="font18 clearfix marginbtom10 title-resume">
            <span class="float-left borderstyle">服务记录
                <b v-if="workCount > 0 " style="color: #f54203;font-size: 18px;font-weight:inherit;">（{{workCount}}）</b>
            </span>
            <span v-if="workCount > 0 " :class="classesList.length > 13?'wsl-tag-14':''" class="wsl-tag-proInfo-style">
                <a @click="setClassId" :class="classId ==''? 'active':''" href="javascript:;" >全部</a>
                <a @click="setClassId(e.id)" :class="classId == e.id ? 'active':''" href="javascript:;" v-for="e in classesList" :key="e.id" :value="e.id">{{e.name}}</a>
            </span>
            <span v-if="isShow.length > 4" style="line-height: 52px;">
                <span class="float-right pointer" @click="toggleShow" v-if="!showAll">展开 ↓</span>
                <span class="float-right pointer" @click="toggleShow" v-else>收起 ↑</span>
            </span>
            <!--<span style="float: right;margin: 0 10px;">
                <span style="font-size: 14px;color: #646464;">类目筛选：</span>
                <select v-model="classId" style="font-size: 12px;color: #000;border-radius: 5px;">
                    <option value="">全部</option>
                    <option v-for="e in classesList" :key="e.id" :value="e.id">{{e.name}}</option>
                </select>
            </span>-->
        </p>
        <Row :gutter="16" v-if="showList.length">
            <Col span="12" v-for="(item,index) in showList" :key="index">
                <div class="border-area">
                    <div class="divider title">
                        <Strong>{{item.storeName}}</Strong>
                        <div style="float:right;overflow: hidden;">
                            <div style="float: left;">{{item.className}}</div>
                            <a @click="jumpPage(item.id)" class="wsl-btn" href="javascript:;">查看作品</a>
                        </div>
                    </div>
                    <div style="font-size:14px;line-height:30px;height: 90px;overflow-y: auto;">{{item.details}}</div>
                </div>
            </Col>
        </Row>
        <h3 v-else class="text-center message">该作者很懒，还没有上传服务记录！</h3>
    </div>
</template>

<script>
export default {
  data() {
    return {
      items: [],
      showAll: false,
      hyclassList: [],
      classesList: [],
      id: '',
      classId: '',
      workCount: 0,
      isShow: []
    };
  },
  mounted() {
    this.id = this.$route.params.id;
    if (!this.id) return;
    this.getHyclassList();
    this.getClassesList();
  },
  computed: {
    showList() {
      var showList = [];
      if (!this.showAll) {
        if (this.items.length > 4) {
          for (let i = 0; i < 4; i++) {
            showList.push(this.items[i]);
          }
        } else {
          showList = this.items;
        }
      } else {
        showList = this.items;
      }
      return showList;
    }
  },
  methods: {
    work() {
      this.$ajax
        .get('designer/work2product', {
          id: this.id,
          classId: this.classId
        })
        .then(e => {
          if (e.status === 200) {
            this.isShow = e.data.workList;
            this.workCount = e.data.workCount;
            this.$store.commit('set_productList', e.data.productList);
            this.items = e.data.workList.map(t => {
              for (let d in this.hyclassList) {
                if (this.hyclassList[d].id == t.classId) {
                  t['className'] = this.hyclassList[d].name;
                }
              }
              return t;
            });
          }
        });
    },
    getHyclassList() {
      this.$ajax.get('class/child?pid=4').then(e => {
        if (e.status === 200) {
          this.hyclassList = e.data;
          this.work();
        }
      });
    },
    toggleShow() {
      if (this.showAll == false) {
        this.showAll = true;
      } else {
        this.showAll = false;
      }
    },
    jumpPage(designerWorkId) {
      this.$router.push({
        name: 'proInfoList',
        params: {
          designerWorkId: designerWorkId
        }
      });
    },
    getClassesList() {
      this.$ajax
        .get('designer/classes', {
          id: this.id
        })
        .then(e => {
          if (e.status === 200) {
            this.classesList = e.data;
          }
        });
    },
    setClassId(classId) {
      this.classId = classId;
    }
  },
  watch: {
    classId: 'work'
  }
};
</script>

<style scoped>
.wsl-tag-proInfo-style {
  overflow: hidden;
  display: block;
  width: 1050px;
  float: left;
  max-height: 50px;
}
.wsl-tag-proInfo-style.wsl-tag-14 a {
  padding: 2px 10px;
  line-height: 22px;
  height: 22px;
}
.wsl-tag-proInfo-style a {
  display: block;
  float: left;
  padding: 5px 10px;
  color: #646464;
  font-size: 14px;
}
.wsl-tag-proInfo-style a:hover,
.wsl-tag-proInfo-style a.active {
  color: #f54203;
}

.wsl-btn {
  display: block;
  float: left;
  width: 78px;
  height: 21px;
  line-height: 21px;
  text-align: center;
  color: #fff;
  background-color: #f54203;
  font-size: 12px;
  border-radius: 5px;
  margin: 10px 0 0 10px;
}

.border-area {
  border: 1px solid #dddee1;
  padding: 10px 20px;
  margin-bottom: 20px;
}

.border-area:nth-child(even) {
  border-left: none;
}

.divider {
  border-bottom: 1px solid #dddee1;
  padding-bottom: 5px;
  margin-bottom: 10px;
}

.title {
  display: flex;
  justify-content: space-between;
  height: 43px;
  line-height: 43px;
  font-size: 18px;
}

.title-resume {
  height: 40px;
  line-height: 40px;
}

.borderstyle {
  font-size: 18px;
  color: #646464;
  border-bottom: 3px solid #f54203;
}

.pointer {
  cursor: pointer;
}
</style>
