<template>
    <div>
        <div class="affix-main">
            <Affix :offset-top="50" @on-change="change" v-if="show">
                <div class="demo-affix">
                    <div>
                        <a href="/rules?index=1">
                            <img :src="'icon/rules-icon-1.jpg!181' | randomPath">
                        </a>
                    </div>
                    <div>
                        <a href="/rules?index=1">
                            <img :src="'icon/rules-icon-2.png!181' | randomPath">
                        </a>
                    </div>
                    <div>
                        <a href="/rules?index=2">
                            <img :src="'icon/rules-icon-3.png!181' | randomPath">
                        </a>
                    </div>
                    <div>
                        <a href="/rules?index=3">
                            <img :src="'icon/rules-icon-4.png!181' | randomPath">
                        </a>
                    </div>
                    <div>
                        <a href="/rules?index=4">
                            <img :src="'icon/rules-icon-5.png!181' | randomPath">
                        </a>
                    </div>
                </div>
            </Affix>
        </div>
    </div>
</template>
<script>
import { mapState } from 'vuex';
export default {
  data() {
    return {
      show: document.body.clientWidth >= 1735
    };
  },
  mounted() {
    window.onscroll = () => {
      if (
        document.body.clientHeight - document.body.scrollTop < 1200 ||
        document.body.clientWidth < 1735
      ) {
        this.show = false;
      } else {
        this.show = true;
      }
    };
  },
  computed: {
    ...mapState({
      ftpPath: state => state.User.ftpPath
    })
  },
  //方法
  methods: {
    change(e) {
      // console.log(e);
    }
  }
};
</script>
<style scoped>
.demo-affix {
  position: absolute;
  right: 50px;
  border: 1px solid #e6e6e6;
}
</style>
