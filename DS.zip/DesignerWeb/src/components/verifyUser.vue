<style scoped>
.login-main {
  width: 315px;
  margin: 0 auto;
}

.btn-login {
  height: 48px;
  width: 100%;
}

img {
  height: 100%;
  width: 100%;
}
</style>
<template>
    <Modal v-model="verifyModal" width="376" :styles="{left: '50%','margin-left': '180px',top: '250px'}" @on-cancel="cancel">
        <div class="login">
            <div class="login-main">
                <div style="display: flex;justify-content: space-between;align-items: baseline;margin-top: 20px;margin-bottom: 20px;">
                    <span style="font-size: 22px;color: #888888;">找回密码</span>
                </div>
                <Form ref="formInline" :model="formInline" :rules="ruleInline" inline style="min-height: 185px;">
                    <Form-item prop="phone" style="width: 100%;">
                        <Input type="text" v-model="formInline.phone" size="large" placeholder="手机号" :maxlength="11"></Input>
                    </Form-item>
                    <Form-item prop="verifycode" style="width: 100%;">
                        <Row :gutter="16">
                            <Col span="16">
                            <Input type="text" v-model="formInline.verifycode" size="large" placeholder="验证码"></Input>
                            </Col>
                            <Col span="8" style="height: 36px;">
                            <img :src="codesrc" @click="changeCodeSrc">
                            </Col>
                        </Row>
                    </Form-item>
                    <Form-item prop="code" style="width: 100%;">
                        <Row :gutter="16">
                            <Col span="16">
                            <Input type="text" v-model="formInline.code" size="large" placeholder="短信验证码" @on-enter="handleSubmit('formInline')"></Input>
                            </Col>
                            <Col span="8">
                            <Button type="error" @click="fetchCode" v-if="codeIntervalTime === 60">获取验证码</Button>
                            <Button type="error" disabled v-else>{{codeIntervalTime}}后重新获取</Button>
                            </Col>
                        </Row>
                    </Form-item>
                    <Form-item style="width: 100%;margin-bottom: -10px;" v-if="!!error_msg">
                        <Alert type="error">{{error_msg}}</Alert>
                    </Form-item>
                </Form>
            </div>
        </div>
        <div slot="footer">
            <Button type="error" @click="handleSubmit('formInline')" class="btn-login">下一步</Button>
        </div>
    </Modal>
</template>

<script>
import { mapState } from 'vuex';

export default {
  computed: {
    ...mapState({
      verifyModal: state => state.Modal.verifyModal
    })
  },
  mounted() {
    this.changeCodeSrc();
  },
  watch: {
    codeIntervalTime(val) {
      if (!val) {
        this.codeIntervalTime = 60;
        clearInterval(this.update);
      }
    },
    'formInline.phone'(val, oldVal) {
      if (!val && oldVal.length === 1) return;
      if (/^[1-9]*[1-9][0-9]*$/.test(val)) return;
      this.$nextTick(() => {
        this.formInline.phone = oldVal;
      });
    }
  },
  destroyed() {
    clearInterval(this.update);
  },
  data() {
    return {
      codeIntervalTime: 60,
      update: '',
      error_msg: '',
      codesrc: '',
      formInline: {
        phone: '',
        verifycode: '',
        code: ''
      },
      ruleInline: {
        phone: [
          {
            required: true,
            message: '请填写手机号',
            trigger: 'blur'
          },
          {
            required: true,
            pattern: /^1(3|4|5|7|8)\d{9}$/,
            message: '请填写正确的手机号',
            trigger: 'blur'
          }
        ],
        verifycode: [
          {
            required: true,
            message: '请填写验证码',
            trigger: 'blur'
          }
        ],
        code: [
          {
            type: 'string',
            required: true,
            message: '请填写短信验证码',
            trigger: 'submit'
          }
        ]
      }
    };
  },
  methods: {
    cancel() {
      this.$refs.formInline.resetFields();
      this.$store.commit('SETTING_VERIFY_USER_MODAL', false);
    },
    changeCodeSrc() {
      this.codesrc = this.$ajax.getVerifyCode();
    },
    fetchCode() {
      // 获取短信验证码
      let phone = this.formInline.phone;
      if (!phone || !/^1(3|4|5|7|8)\d{9}$/.test(phone)) {
        this.error_msg = '请填写11位数字手机号';
        return;
      }

      let verifycode = this.formInline.verifycode;
      if (!verifycode) {
        this.error_msg = '请填写验证码';
        return;
      }

      this.error_msg = '';

      this.$ajax.get('auth/isexist', { username: phone }).then(e => {
        if (e.status === 200) {
          this.error_msg = '用户不存在';
          return;
        }

        this.codeIntervalTime--;
        this.update = setInterval(() => {
          this.codeIntervalTime--;
        }, 1000);

        this.$ajax.post('auth/sendcode', { phone, verifycode }).then(e => {
          if (e.status !== 200) {
            this.error_msg = e.msg;
            this.codeIntervalTime = 60;
            clearInterval(this.update);
            return;
          }

          this.formInline.code = e.data || '';
        });
      });
    },
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (!valid) return;

        this.error_msg = '';
        this.codeIntervalTime = 60;
        clearInterval(this.update);
        this.$store.commit('SETTING_RESET_MODAL', true);
        this.$store.commit('verifyinfo', {
          code: this.formInline.code,
          phone: this.formInline.phone
        });
        this.$refs.formInline.resetFields();
      });
    }
  }
};
</script>

