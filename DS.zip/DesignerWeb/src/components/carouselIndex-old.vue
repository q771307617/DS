<template>  
    <div tag="div" class="articleList articleListMod-3 er-carouseindex" name="slide-fade" id="articleList" :style="{height:imgHeight+'px'}" >  
        <span id="btn1" class="er-carouseindex-left" @mousedown="imgMove('mouseLeft')" @mouseup="cancelMove('left')" v-show="isOrNotButton"></span>  
        <span id="btn2" class="er-carouseindex-right"  @mousedown="imgMove('mouseRight')" @mouseup="cancelMove('right')" v-show="isOrNotButton"></span>  
        <div id="packageAll" class="er-carouseindex-con" @mouseover="clearAuto" @mouseout="slideAuto">  
            <div class="er-carouseindex-bar" v-show="isOrNotCircle">  
                <div v-for="(item,dex) in imgList" :key="item" @mouseup="clearAuto" class="er-carouseindex-circle" @click="circleClick(dex)" :class="{circleSelected:dex===indexCircle}">  
                </div>  
            </div>  
            <div id="imageAll" class="er-carouseindex-item" :style="{transform:translateX,transition:transFlag?transitionTime:''}">  
                <div class="articleList-box er-carouseindex-box" v-for="(list,index) in imgLisShow" :key="list" :style="{width:imgWidth+'%'}" style="max-height:50%;">  
                    <slot :item="list"></slot>  
                </div>  
            </div>  
        </div>  
    </div>  
</template>  
<script>
export default {
  name: 'ErCarouselIndex',
  data() {
    return {
      imgList: [], //请求接口数据
      imgLisShow: [], //图片滚动数据，包括左中右三种
      timer: null, //自动循环滚动时的间隔时间
      timeout: null, //长按时的图片滚动间隔时间
      index: 0, //图片索引
      translateXnum: 0, //图片滚动时的偏移量
      translateX: '', //生成图片偏移时的表达式
      imgWidth: '', //图片所占宽度
      timeDown: '', //鼠标刚按下时的时间
      timeup: '', //鼠标松开时的时间
      clickSpace: '', //鼠标按下松开的时间间隙
      transFlag: true, //是否匀速滚动,
      transitionTime: '',
      indexCircle: 0 //小圆圈滚动索引
    };
  },
  props: {
    duration: 0, //图片延时滚动
    typeNumber: 0, //每次滚动几张
    timeSpace: 0, //图片滚动时间间隔
    url: String, //请求接口地址
    pageNumber: 0, //当前页面显示几张图片
    isOrNotButton: true, //是否显示左右按钮
    isOrNotCircle: true, //是否显示小圆圈
    imgHeight: '' //图片滚动显示高度
  },
  watch: {
    index: {
      handler() {
        var _this = this;
        if (Math.abs(this.index) == this.imgList.length) {
          this.indexCircle = 0;
          setTimeout(function() {
            _this.reset();
          }, _this.duration * 1000 * 0.98);
        } else {
          this.indexCircle = this.index;
        }
        this.calcXnum();
      }
    },
    translateXnum: {
      handler() {
        this.translateX = 'translateX(' + this.translateXnum + '%)';
      }
    }
  },
  methods: {
    //页面初始化复赋值
    imgView: function() {
      var _this = this;
      // _this.$http.get(_this.url).then(function (res) {
      _this.imgList = [
        'http://192.168.2.200:8888/assets/banner/0.jpg',
        'http://192.168.2.200:8888/assets/banner/1.jpg',
        'http://192.168.2.200:8888/assets/banner/2.jpg'
      ];
      for (var i = 0; i < 3; i++) {
        _this.imgList.forEach(function(item, index) {
          _this.imgLisShow.push(item);
        });
      }
      _this.reset();
      _this.slideAuto();
      _this.imgWidth = 100 / _this.pageNumber - 1;
      _this.transitionTime = 'all ' + _this.duration * 0.98 + 's linear';
      // });
    },
    //图片滚动方法(长按)
    imgMove: function(direct) {
      var _this = this;
      _this.timeDown = new Date(); //记录按下的时间
      _this.timeout = setInterval(function() {
        if (direct == 'mouseLeft') {
          _this.leftMove();
        } else {
          _this.rightMove();
        }
      }, 300);
    },
    //鼠标送开时执行的方法
    cancelMove: function(direct) {
      var _this = this;
      _this.clearAuto();
      this.timeup = new Date(); //记录松开的时间
      this.clickSpace = this.timeup.getTime() - this.timeDown.getTime();
      //时间间隔小于500毫秒为点击，反之为长按
      if (this.clickSpace < 500) {
        for (var i = 0; i < _this.typeNumber; i++) {
          if (direct == 'left') {
            _this.leftMove();
          } else {
            _this.rightMove();
          }
        }
      }
      if (this.timeout) {
        clearInterval(this.timeout);
        this.timeout = null;
      }
    },
    //向左移动
    leftMove: function() {
      this.index--;
      this.transFlag = true;
    },
    //向右移动
    rightMove: function() {
      this.transFlag = true;
      this.index++;
    },
    slideAuto: function() {
      var _this = this;
      _this.timer = setTimeout(function() {
        if (Math.abs(_this.index) !== _this.imgList.length) {
          _this.rightMove();
          _this.slideAuto();
        }
      }, _this.timeSpace * 1000);
    },
    clearAuto: function() {
      if (this.timer) {
        clearInterval(this.timer);
        this.timer = null;
      }
    },
    //重置
    reset: function() {
      this.index = 0;
      this.transFlag = false;
      this.calcXnum();
    },
    calcXnum: function() {
      var _this = this;
      this.translateXnum =
        -(this.index + this.imgList.length) * (100 / this.pageNumber);
    },
    //点击圆圈跳转图片
    circleClick: function(dex) {
      this.index = dex;
      this.clearAuto();
    }
  },
  mounted() {
    this.$nextTick(function() {
      this.imgView();
    });
  }
};
</script>
<style>
.hljs {
  display: block;
  padding: 0.5em;
  background: #fff;
  color: #000;
}
.hljs-comment,
.hljs-template_comment,
.hljs-javadoc,
.hljs-comment * {
  color: #800;
}
.hljs-keyword,
.method,
.hljs-list .hljs-title,
.clojure .hljs-built_in,
.nginx .hljs-title,
.hljs-tag .hljs-title,
.setting .hljs-value,
.hljs-winutils,
.tex .hljs-command,
.http .hljs-title,
.hljs-request,
.hljs-status {
  color: #008;
}
.hljs-envvar,
.tex .hljs-special {
  color: #660;
}
.hljs-string,
.hljs-tag .hljs-value,
.hljs-cdata,
.hljs-filter .hljs-argument,
.hljs-attr_selector,
.apache .hljs-cbracket,
.hljs-date,
.hljs-regexp,
.coffeescript .hljs-attribute {
  color: #080;
}
.hljs-sub .hljs-identifier,
.hljs-pi,
.hljs-tag,
.hljs-tag .hljs-keyword,
.hljs-decorator,
.ini .hljs-title,
.hljs-shebang,
.hljs-prompt,
.hljs-hexcolor,
.hljs-rules .hljs-value,
.css .hljs-value .hljs-number,
.hljs-literal,
.hljs-symbol,
.ruby .hljs-symbol .hljs-string,
.hljs-number,
.css .hljs-function,
.clojure .hljs-attribute {
  color: #066;
}
.hljs-class .hljs-title,
.haskell .hljs-type,
.smalltalk .hljs-class,
.hljs-javadoctag,
.hljs-yardoctag,
.hljs-phpdoc,
.hljs-typename,
.hljs-tag .hljs-attribute,
.hljs-doctype,
.hljs-class .hljs-id,
.hljs-built_in,
.setting,
.hljs-params,
.hljs-variable,
.clojure .hljs-title {
  color: #606;
}
.css .hljs-tag,
.hljs-rules .hljs-property,
.hljs-pseudo,
.hljs-subst {
  color: #000;
}
.css .hljs-class,
.css .hljs-id {
  color: #9b703f;
}
.hljs-value .hljs-important {
  color: #f70;
  font-weight: bold;
}
.hljs-rules .hljs-keyword {
  color: #c5af75;
}
.hljs-annotation,
.apache .hljs-sqbracket,
.nginx .hljs-built_in {
  color: #9b859d;
}
.hljs-preprocessor,
.hljs-preprocessor *,
.hljs-pragma {
  color: #444;
}
.tex .hljs-formula {
  background-color: #eee;
  font-style: italic;
}
.diff .hljs-header,
.hljs-chunk {
  color: #808080;
  font-weight: bold;
}
.diff .hljs-change {
  background-color: #bccff9;
}
.hljs-addition {
  background-color: #baeeba;
}
.hljs-deletion {
  background-color: #ffc8bd;
}
.hljs-comment .hljs-yardoctag {
  font-weight: bold;
}
.markdown_views {
  font-family: 'microsoft yahei';
  font-size: 15px;
  color: #3f3f3f;
}
.markdown_views * {
  box-sizing: border-box;
}
.markdown_views h1,
.markdown_views h2,
.markdown_views h3,
.markdown_views h4,
.markdown_views h5,
.markdown_views h6 {
  font-weight: 100;
  margin: 0.8em 0;
}
/* add by zhangw */
.markdown_views h1 {
  font-size: 2.6em;
}
.markdown_views h2 {
  font-size: 2.13em;
}
.markdown_views h3 {
  font-size: 1.73em;
}
.markdown_views a {
  color: #4fa1db;
}

.markdown_views p,
.markdown_views pre,
.markdown_views pre.prettyprint,
.markdown_views blockquote {
  margin: 0 0 1.1em;
}
.markdown_views hr {
  margin: 2em 0;
  border: 0;
  border-top: 1px solid rgba(128, 128, 128, 0.1);
}
.markdown_views dt {
  font-weight: bold;
}
.markdown_views abbr[title],
.markdown_views abbr[data-original-title] {
  cursor: help;
  border-bottom: 1px dotted #999;
}
.markdown_views .initialism {
  font-size: 90%;
  text-transform: uppercase;
}
.markdown_views blockquote {
  padding: 15px 20px;
  border-left: 10px solid rgba(128, 128, 128, 0.075);
  background-color: rgba(128, 128, 128, 0.05);
  border-radius: 0 5px 5px 0;
}
.markdown_views blockquote p {
  line-height: 1.25;
}
.markdown_views blockquote p:last-child {
  margin-bottom: 0;
}
.markdown_views blockquote small,
.markdown_views blockquote .small {
  display: block;
  line-height: 1.45;
  color: #999;
}
.markdown_views blockquote small:before,
.markdown_views blockquote .small:before {
  content: '鈥斅�';
}
.markdown_views blockquote.pull-right {
  padding-right: 15px;
  padding-left: 0;
  border-right: 5px solid rgba(128, 128, 128, 0.075);
  border-left: 0;
}
.markdown_views blockquote.pull-right p,
.markdown_views blockquote.pull-right small,
.markdown_views blockquote.pull-right .small {
  text-align: right;
}
.markdown_views blockquote.pull-right small:before,
.markdown_views blockquote.pull-right .small:before {
  content: '';
}
.markdown_views blockquote.pull-right small:after,
.markdown_views blockquote.pull-right .small:after {
  content: '聽鈥�';
}
.markdown_views blockquote:before,
.markdown_views blockquote:after {
  content: '';
}
.markdown_views address {
  margin-bottom: 21px;
  font-style: normal;
  line-height: 1.45;
}
.markdown_views code,
.markdown_views kbd,
.markdown_views pre,
.markdown_views samp {
  font-family: 'Source Code Pro', monospace;
}
.markdown_views code {
  padding: 2px 4px;
  font-size: 90%;
  color: #3f3f3f;
  background-color: rgba(128, 128, 128, 0.075);
  white-space: nowrap;
  border-radius: 0;
}
.markdown_views pre {
  display: block;
  padding: 10px;
  margin: 0 0 10.5px;
  font-size: 14px;
  line-height: 1.45;
  word-break: break-all;
  word-wrap: break-word;
  color: #333;
  background-color: rgba(128, 128, 128, 0.05);
  border: 1px solid rgba(128, 128, 128, 0.075);
  border-radius: 0;
}
.markdown_views pre code {
  padding: 0;
  font-size: inherit;
  color: inherit;
  white-space: pre;
  word-wrap: normal;
  background-color: transparent;
  border-radius: 0;
}
.markdown_views .pre-scrollable {
  max-height: 340px;
  overflow-y: scroll;
}
.markdown_views .sequence-diagram,
.markdown_views .flow-chart {
  text-align: center;
  margin-bottom: 1.1em;
}
.markdown_views table {
  width: 100%;
  background-color: transparent;
  border-collapse: collapse;
  border-spacing: 0;
  border: 1px solid #eee;
}
.markdown_views table th,
.markdown_views table td {
  padding: 8px;
  line-height: 20px;
  vertical-align: top;
  border: 1px solid #eee;
}
.markdown_views .prettyprint {
  padding: 5px;
  position: relative;
  overflow-y: hidden;
  overflow-x: auto;
  white-space: nowrap;
  padding-left: 60px;
}
.markdown_views .prettyprint .pre-numbering {
  position: absolute;
  width: 50px;
  background-color: #eee;
  top: 0;
  left: 0;
  margin: 0;
  padding: 6px 0 40px 0;
  border-right: 1px solid #ddd;
  list-style: none;
  text-align: right;
}
.markdown_views .prettyprint .pre-numbering li {
  padding: 0 5px;
}
</style>
