<template>
    <div class="bannerzmd" v-on:mouseenter="()=>{enterCarousel()}" v-on:mouseleave="()=>{leaveCarousel()}">
        <SXCarousel 
            v-model="CarouselIndex" 
            :autoplay="setting.autoplay"
            :autoplay-speed="setting.autoplaySpeed"
            :dots="setting.dots"
            :arrow="setting.arrow">
             <!-- <SXCarousel-item>
                <div class="demo-carousel">
                    <img :src="`banner/3.jpg!1920` | randomPath" alt="" width="100%;">
                </div>
            </SXCarousel-item> -->
            
            <SXCarousel-item v-for="item in imglist" :key="item">
                <div class="demo-carousel">
                    <img :src="item" alt="" width="100%;">
                </div>
            </SXCarousel-item>
        </SXCarousel>
    </div>
</template>

<script>
import SXCarousel from '../iview/carousel/carousel.vue';
import SXCarouselItem from '../iview/carousel/carousel-item.vue';
export default {
  data() {
    return {
      CarouselIndex: 0,
      imglist: '',
      setting: {
        autoplay: true,
        autoplaySpeed: 10000,
        dots: 'inside',
        arrow: 'hover'
      }
    };
  },
  computed: {
    // ...mapState({
    //         ftpPath: state => state.User.ftpPath
    //     })
  },
  components: {
    SXCarousel,
    SXCarouselItem
  },
  methods: {
    enterCarousel() {
      this.setting.autoplay = false;
    },
    leaveCarousel() {
      this.setting.autoplay = true;
    }
  },
  mounted() {
    this.$ajax.get('common/config/gets', { keys: 'bannerkey' }).then(e => {
      if (e.status == 200) {
        let data = JSON.parse(e.data[0].value);
        let imglist = [];
        for (let i in data) {
          imglist.push(data[i].img);
          this.imglist = imglist;
        }
      }
    });
  }
};
</script>
<style>
.bannerzmd .ivu-carousel-arrow {
  width: 40px;
  font-size: 0;
  height: 78px;
}
.bannerzmd .ivu-carousel .left {
  background: url('../../assets/images/index_jt1.png') no-repeat;
}
.bannerzmd .ivu-carousel .right {
  background: url('../../assets/images/index_jt2.png') no-repeat;
}
</style>