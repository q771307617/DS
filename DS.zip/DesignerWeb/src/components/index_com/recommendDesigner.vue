<template>
 <div class="designerlist">
        <div class="list">
            <p class="list-head">
                <span class="list-title">{{title}}</span>
                <span class="list-btn">
                    <!--Button icon="ios-search" class="btn">随缘</Button-->
                    <Button class="btn" @click="search">
                        更多设计师
                        <Icon type="chevron-right"></Icon>
                    </Button>
                </span>
            </p>
            <div v-if="lists.length" class="zmd">
                <SXCarousel 
                    v-model="tjdesigner"
                    :autoplay="setting.autoplay"
                    :autoplay-speed="setting.autoplaySpeed"
                    :dots="setting.dots"
                    :arrow="setting.arrow">
                    <SXCarouselItem v-for="i in getPageNum()" :key="i">
                        <div class="pro-list-wrapper">
                            <ul class="list-body">
                                <li v-for="item in getPage(i)" :key="item.id" v-on:mouseenter="()=>{enter(item)}" v-on:mouseleave="()=>{leave(item)}">
                                    <div v-show="!item.active">
                                        <router-link :to="{ name: 'detailForDesigner', params: { id: item.user_id }}">
                                            <div class="tj-head" style="height:339px;">
                                                <img v-lazy="item.image_url+'!288x339'" class="ryimg" width="288px">
                                            </div>
                                        </router-link>
                                        <div class="tj-font">
                                            <p style="overflow:hidden;line-height:17px">
                                                <router-link :to="{ name: 'detailForDesigner', params: { id: item.user_id }}">
                                                    <span class="tj-nickname float-left">{{item.nickname}}</span>
                                                </router-link>
                                                <!--<img :src="jb2Icon" alt="中级">-->
                                                <img :src="`icon/security.png` | randomPath" alt="保障">
                                                <img :src="`icon/certification.png` | randomPath" alt="平台认证">

                                                <span class="float-right font14">
                                                    <Icon type="social-yen"></Icon>&nbsp;
                                                    <span class="salary-color">{{item.salary || 0}}</span>
                                                    <span style="color:#6e6e6e">/月</span>
                                                </span>
                                            </p>
                                            <p class="good">
                                                <span style="letter-spacing:2px">{{item.skilful | SKILLFULL_LIST_TEXT(childList4,'|')}}</span>
                                            </p>
                                        </div>
                                    </div>

                                    <div v-show="item.active" style="text-align:center;">
                                        <div class="tj-head" style="padding-top:20px;">
                                            <router-link :to="{ name: 'detailForDesigner', params: { id: item.user_id }}">
                                                <div class="img-border"><img class="ryimg" v-lazy="item.image_url+'!160x160'" width="160px" ></div>
                                                <!--<p class="userjb"><img src="../../assets/images/index_gs.png"></p>-->
                                            </router-link>
                                        </div>
                        
                                        <div class="tj-salary font20">
                                            <span>月薪：</span><span class="color-red">{{item.salary || 0}}元</span>
                                        </div>
                                        <Row class="font14 margintop10 text-center">
                                            <Col span="4">&nbsp;</Col>
                                            <Col span="8">
                                                <span class="font30 color-red">{{item.worktimes || 0}}</span>次<br>工作次数
                                            </Col>
                                            <Col span="8">
                                                <span class="font30 color-red">{{item.exp || 0}}</span>年<br>工作年限
                                            </Col>
                                            <Col span="4">&nbsp;</Col>
                                        </Row>
                                        <router-link :to="{ name: 'detailForDesigner', params: { id: item.user_id }}">
                                            <Button type="warning" style="margin-top:30px;background:#f54203;width:177px;">查看联系方式</Button>
                                        </router-link>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </SXCarouselItem>
                </SXCarousel>
            </div>
            <h3 v-else class="text-center message">暂时没有{{title}}</h3>
        </div>
    </div>      
</template>

<script>
import SXCarousel from '../iview/carousel/carousel.vue';
import SXCarouselItem from '../iview/carousel/carousel-item.vue';
import { mapState } from 'vuex';
export default {
  props: {
    title: {
      type: String,
      default: ''
    },
    id: {
      type: Number,
      default: 0
    },
    pageSize: {
      type: Number,
      default: 0
    },
    changeShow: {
      type: Function,
      default: function() {}
    }
  },
  components: {
    SXCarousel,
    SXCarouselItem
  },
  data() {
    return {
      lists: [],
      tjdesigner: 0,
      setting: {
        dots: 'none',
        arrow: 'always'
      }
    };
  },
  mounted() {
    if (this.id == 1) {
      this.recommend();
    } else {
      this.newest();
    }
  },
  computed: {
    ...mapState({
      defaultSrc: state => state.User.defaultSrc,
      childList4: state => state.Lists.childList4, //子分类
      ftpPath: state => state.User.ftpPath
    })
  },
  methods: {
    // 改变滚动条位置触发图片懒加载
    // scrollChange(){
    //     let y = window.pageYOffset;
    //     window.scrollTo(0,y+(y%2 ==0?1:-1));
    // },
    //获取推荐的设计师
    recommend() {
      this.$ajax.get('designer/recommend', {}).then(e => {
        if (e.status == 200) {
          for (let i = 0; i < e.data.length; i++) {
            e.data[i].index = i;
            e.data[i].active = false;
          }
          this.lists = e.data;
          this.changeShow();
        } else {
          this.$Message.error('发生错误!');
        }
      });
    },
    //获取新晋设计师
    newest() {
      this.$ajax.get('designer/newest', {}).then(e => {
        if (e.status == 200) {
          for (let i = 0; i < e.data.length; i++) {
            e.data[i].index = i;
            e.data[i].active = false;
          }
          this.lists = e.data.list;
        } else {
          this.$Message.error('发生错误!');
        }
      });
    },
    // 计算总页数
    getPageNum() {
      var pageNum = 0;
      var count = this.lists.length;
      var p = this.pageSize;
      if (count % p == 0) {
        pageNum = parseInt(count / p);
      } else {
        pageNum = parseInt(count / p) + 1;
      }
      return pageNum;
    },
    //返回每页数据
    getPage(index) {
      var dataList = [];
      var p = this.pageSize;
      let k = 0;
      if (index > 1) {
        k = (index - 1) * p;
      }
      // let count = index * p;
      for (let i = k; i < index * p; i++) {
        if (!this.lists[i]) {
          break;
        }
        dataList.push(this.lists[i]);
      }
      return dataList;
    },
    search() {
      this.$router.push({
        name: 'designer'
      });
    },
    enter(item) {
      if (this.id == 2) {
        return;
      }
      this.lists[item.index].active = true;
    },
    leave(item) {
      if (this.id == 2) {
        return;
      }
      this.lists[item.index].active = false;
    }
  }
};
</script>

<style>
.zmd .ivu-carousel .left {
  left: -80px;
  background: url('../../assets/images/index_jt1.png') no-repeat;
  font-size: 0;
}
.zmd .ivu-carousel .right {
  right: -80px;
  background: url('../../assets/images/index_jt2.png') no-repeat;
  font-size: 0;
}
.zmd .ivu-carousel .left:hover {
  background: url('../../assets/images/index_jt4.png') no-repeat;
}
.zmd .ivu-carousel .right:hover {
  background: url('../../assets/images/index_jt3.png') no-repeat;
}
.zmd .ivu-carousel .ivu-carousel-arrow .ivu-icon {
  display: hidden;
  height: 84px;
  width: 42px;
  color: rgba(0, 0, 0, 0);
}
.zmd .ivu-carousel-arrow {
  height: 125px;
  width: 50px;
  background: #fff;
  color: #cacaca;
  font-size: 40px;
  border-radius: 0;
}
.zmd .ivu-carousel-list {
  width: 1280px;
}
</style>

<style scoped>
.designerlist {
  padding-top: 10px;
  width: 1280px;
  margin: 0 auto;
  padding-bottom: 50px;
  clear: both;
}
.tj-head {
  position: relative;
  width: 288px;
  margin: 0 auto;
  overflow: hidden;
}
.tj-head .img-border {
  height: 160px;
  width: 160px;
  border-radius: 100px;
  overflow: hidden;
  margin: 0 auto;
}
.tj-head .userjb {
  text-align: center;
  margin-top: -10px;
}

/*.tj-head-box{
        width:100%;
        height:100%;
        background-color:#000;
        position:absolute;
        top:0;
        left:0;
        z-index:2;
        opacity:0.3;
        /*兼容IE8及以下版本浏览器
        /*filter: alpha(opacity=30)
    }*/
.list-head {
  height: 70px;
  line-height: 70px;
}
.list-head .list-title {
  color: #646464;
  font-size: 20px;
}
.list-head .list-btn {
  float: right;
}
.list-head .list-btn .btn {
  font-size: 12px;
  padding: 2px 5px;
  border-radius: 5px;
  background: #fff;
}
.list-head .list-btn .btn:hover {
  border-color: #f54203;
  color: #f54203;
}
.list-body {
  overflow: hidden;
}
.list-body li {
  -moz-box-shadow: 5px 4px 20px #f2f2f2; /* 老的 Firefox */
  margin-bottom: 17px;
  border: 1px solid #efefef;
  float: left;
  margin-right: 40px;
  position: relative;
  height: 412px;
  overflow: hidden;
}
.list-body li:nth-child(4) {
  margin-right: 0;
}
.list-body li:nth-child(8) {
  margin-right: 0;
}
.list-body .ryimg {
  /*width: 288px;
        height: 339px;*/
}
.list-body .tj-nickname {
  font-size: 14px;
  color: #646464;
  margin-right: 14px;
  max-width: 56px;
  overflow: hidden;
  height: 20px;
  line-height: 18px;
}
.list-body li .tj-font {
  height: 72px;
  overflow: hidden;
  padding: 15px 15px;
  line-height: 24px;
}
.tj-salary {
  height: 60px;
  line-height: 50px;
  border-bottom: 1px solid #eee;
  width: 160px;
  margin: 0 auto;
}
.tj-work {
}
.salary-color {
  color: #f54203;
}
.good {
  font-size: 14px;
  color: #888;
  bottom: 0;
  width: 258px;
  overflow: hidden;
}
.color-red {
  color: #f54203;
}
</style>