<template>
    <div class="matching-box" v-lazy:background-image="`${ftpPath}images/index_bg1.png`">
        <div class="matching">
            <p class="title text-center">先工作后付款 平台有保障</p>
            <div class="sskuang">
                <div class="sel-box flex-box">
                    <ul class="sel-ul">
                        <li class="sel-li">
                            <Dropdown @on-click="hyclassChange" :class="getClass(childList4)" style="position:relative">
                                <a href="javascript:void(0)">
                                    {{typedata.hyclass}}
                                    <Icon type="arrow-down-b"></Icon>
                                </a>
                                <span class="su">|</span>
                                <Dropdown-menu slot="list" :class="getClass2(childList4)" style="width:320px;">
                                    <Dropdown-item v-for="item in childList4" :value="item.id" :key="item.id" :name="item.name">{{ item.name }}</Dropdown-item>
                                </Dropdown-menu>
                            </Dropdown>
    
                        </li>
                        <li class="sel-li">
                            <Dropdown @on-click="experienceChange" :class="getClass(experienceList)" style="position:relative">
                                <a href="javascript:void(0)">
                                    {{typedata.experience}}
                                    <Icon type="arrow-down-b"></Icon>
                                </a>
                                <span class="su">|</span>
                                <Dropdown-menu slot="list" :class="getClass2(experienceList)">
                                    <Dropdown-item v-for="item in experienceList" :value="item.value" :key="item.value" :name="item.label">{{ item.label }}</Dropdown-item>
                                </Dropdown-menu>
                            </Dropdown>
    
                        </li>
                        <li class="sel-li">
                            <Dropdown @on-click="sexChange" :class="getClass(sexList)" style="position:relative">
                                <a href="javascript:void(0)">
                                    {{typedata.sex}}
                                    <Icon type="arrow-down-b"></Icon>
                                </a>
                                <span class="su">|</span>
                                <Dropdown-menu slot="list" :class="getClass2(sexList)">
                                    <Dropdown-item v-for="item in sexList" :value="item.value" :key="item.value" :name="item.label">{{ item.label }}</Dropdown-item>
                                </Dropdown-menu>
                            </Dropdown>
                        </li>
                        <li class="sel-li">
                            <Dropdown @on-click="salaryChange" :class="getClass(salaryList)" style="position:relative">
                                <a href="javascript:void(0)">
                                    {{typedata.salary}}
                                    <Icon type="arrow-down-b"></Icon>
                                </a>
                                <Dropdown-menu slot="list" :class="getClass2(salaryList)">
                                    <Dropdown-item v-for="item in salaryList" :value="item.value" :key="item.value" :name="item.label">{{ item.label }}</Dropdown-item>
                                </Dropdown-menu>
                            </Dropdown>
                        </li>
                    </ul>
    
                </div>
                <Button type="warning" class="piepibtn" @click="quickSearch">快速匹配</Button>
            </div>
            <img :src="'icon/index-sb.png' | randomPath">
        </div>
    </div>
</template>

<script>
import * as types from '@/constant/index';
import { mapState } from 'vuex';

export default {
  data() {
    return {
      experienceList: types.workyears,
      sexList: types.gender,
      salaryList: types.salaryBudget,
      typedata: {
        hyclass: '行业类目',
        experience: '工作经验',
        sex: '性别',
        salary: '薪资预算'
      },
      typeidData: {
        hyclassid: '',
        experienceid: '',
        sexid: '',
        salaryid: ''
      }
    };
  },
  mounted() {},
  computed: {
    ...mapState({
      childList4: state => state.Lists.childList4, //子分类
      ftpPath: state => state.User.ftpPath
    })
  },
  methods: {
    getClass(data) {
      if (!data) {
        return 'text-center col-box';
      }
      var leg = data.length;
      if (leg / 5 > 2) {
        return 'text-center col-box col-three';
      } else if (leg / 5 > 1) {
        return 'text-center col-box col-tow';
      }
      return 'text-center col-box';
    },
    getClass2(data) {
      if (!data) {
        return 'col';
      }
      var leg = data.length;
      if (leg / 5 > 1) {
        return 'col';
      }
      return '';
    },
    hyclassChange(name) {
      this.typedata.hyclass = name;
      for (let item of this.childList4) {
        if (item.name == name) {
          this.typeidData.hyclassid = item.id;
          break;
        }
      }
    },
    experienceChange(name) {
      this.typedata.experience = name;
      for (let item of this.experienceList) {
        if (item.label == name) {
          this.typeidData.experienceid = item.value;
          break;
        }
      }
    },
    sexChange(name) {
      this.typedata.sex = name;
      for (let item of this.sexList) {
        if (item.label == name) {
          this.typeidData.sexid = item.value;
          break;
        }
      }
    },
    salaryChange(name) {
      this.typedata.salary = name;
      for (let item of this.salaryList) {
        if (item.label == name) {
          this.typeidData.salaryid = item.value;
          break;
        }
      }
    },
    quickSearch() {
      this.$router.push({
        name: 'designer',
        query: {
          gender: this.typeidData.sexid,
          hy: this.typeidData.hyclassid,
          jb: this.typeidData.experienceid,
          salary: this.typeidData.salaryid
        }
      });
    }
  }
};
</script>

<style>
.sskuang .ivu-dropdown-rel {
  height: 67px;
  line-height: 67px;
  width: 199.5px;
}

.sskuang .ivu-dropdown-menu {
  max-width: 100px;
}

.col-tow .ivu-dropdown-menu {
  max-width: 200px;
}

.col-three .ivu-dropdown-menu {
  max-width: 300px;
}

.col .ivu-dropdown-item {
  float: left;
  clear: none;
  width: 100px;
}

.sel-box .ivu-dropdown-item:hover {
  color: #f54203;
}
</style>

<style scoped>
.col-box .ivu-dropdown-rel {
  width: 25%;
}

.matching-box {
  text-align: center;
  height: 300px;
  width: 100%;
}

.matching {
  width: 1280px;
  margin: 0 auto;
  margin-bottom: 30px;
  padding-top: 30px;
}

.matching .title {
  color: #fff;
  font-size: 40px;
  height: 85px;
  line-height: 85px;
}

.matching .sskuang {
  background: rgba(255, 255, 255, 0.2);
  margin: 0 auto;
  height: 67px;
  width: 963px;
  margin-bottom: 20px;
}

.sskuang .sel-box {
  border: 1px solid rgba(255, 255, 255, 0.2);
  float: left;
  height: 67px;
  width: 800px;
  font-size: 16px;
  line-height: 50px;
}

.sskuang .sel-box .sel-ul {
  width: 100%;
}

.sskuang .sel-box .sel-li {
  width: 25%;
  float: left;
}

.sskuang .sel-box a {
  color: #fff;
}

.sskuang .sel-box a:hover {
  color: #f54203;
}

.sskuang .sel-box select {
  border: 0;
}

.sskuang .sel-box .su {
  color: rgba(255, 255, 255, 0.2);
  line-height: 67px;
  float: right;
}

.sskuang .piepibtn {
  background-color: #f54203;
  border-color: #f36735;
  float: right;
  height: 67px;
  width: 163px;
  font-size: 16px;
  border-radius: 0;
}
</style>
