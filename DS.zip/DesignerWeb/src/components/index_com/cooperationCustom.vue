<template>
<div class="hzal">
    <div class="hzmain">
        <p class="hz-title">合作客户</p>
        <div class="hz-box">
            <ul>
                <li v-for="(item,index) in lists" :key="item.id" v-on:mouseenter="()=>{enter(item.id)}" v-on:mouseleave="()=>{leave(item.id)}">
                    <img v-lazy="imgPath(index,'images/hzkh_' + item.id +'.png')" v-show="!item.active">
                    <img v-lazy="imgPath(index,'images/hzkh' + item.id +'.png')" v-show="item.active">
                </li>
            </ul>
        </div>
    </div>
    <div class="hz-footer text-center" v-lazy:background-image="`${ftpPath}images/index_bg3.png`">
        <img :src="'icon/index-hg.png' | randomPath">
        <p class="hz-gg">降低用人成本58.9%</p>
        <div class="hz-btnitem">
            <span class="btn btn1" @click="demandAdd" v-if="info.id">发布需求</span>
            <span class="btn btn1" @click="login" v-else>发布需求</span>
            <span class="btn btn2" @click="designer">找设计师</span>
        </div>
        <img :src="'icon/index-sb.png' | randomPath">
    </div>

    <div class="ivu-modal-mask" v-if="registerModal"></div>
    <div class="ivu-modal-wrap" v-if="registerModal">
        <Register :cancle="cancle"></Register>
    </div>
 </div>
</template>

<script>
import { mapState } from 'vuex';
import Register from '@/components/register.vue';

export default {
  data() {
    return {
      registerModal: false,
      active: false,
      lists: [
        {
          id: 1,
          active: false
        },
        {
          id: 2,
          active: false
        },
        {
          id: 3,
          active: false
        },
        {
          id: 4,
          active: false
        },
        {
          id: 5,
          active: false
        },
        {
          id: 6,
          active: false
        },
        {
          id: 7,
          active: false
        },
        {
          id: 8,
          active: false
        },
        {
          id: 9,
          active: false
        },
        {
          id: 10,
          active: false
        },
        {
          id: 11,
          active: false
        },
        {
          id: 12,
          active: false
        },
        {
          id: 13,
          active: false
        },
        {
          id: 14,
          active: false
        },
        {
          id: 15,
          active: false
        },
        {
          id: 16,
          active: false
        },
        {
          id: 17,
          active: false
        },
        {
          id: 18,
          active: false
        },
        {
          id: 19,
          active: false
        },
        {
          id: 20,
          active: false
        },
        {
          id: 21,
          active: false
        }
      ]
    };
  },
  computed: {
    ...mapState({
      defaultSrc: state => state.User.defaultSrc,
      info: state => state.User.info,
      ftpPath: state => state.User.ftpPath
    })
  },
  components: {
    Register
  },
  methods: {
    imgPath(index, name) {
      const n = index % 5 + 1;
      return `http://${n}.img.dianjiangla.com/assets/${name}`;
    },
    login() {
      window.location.href = `/user/login?redirect=${encodeURIComponent(
        location.pathname
      )}`;
      // this.$store.commit('SETTING_LOGIN_MODAL', true);
    },
    enter(index) {
      this.lists[index - 1].active = true;
    },
    leave(index) {
      this.lists[index - 1].active = false;
    },
    cancle() {
      this.registerModal = false;
    },
    demandAdd() {
      this.$router.push({
        name: 'demandManagentChoose'
      });
    },
    designer() {
      this.$router.push({
        path: '/search/designer'
      });
    }
  }
};
</script>

<style>
.hz-btnitem {
  margin: 0 auto;
  overflow: hidden;
  width: 366px;
  margin-top: 10px;
  margin-bottom: 12px;
  font-size: 18px;
}
.hz-btnitem .btn {
  cursor: pointer;
  display: block;
  float: left;
  color: #fff;
  border: 0;
  width: 183px;
  height: 50px;
  line-height: 50px;
  margin: 0;
}
.hz-btnitem .btn1 {
  background-color: #f14104;
}
.hz-btnitem .btn2 {
  background-color: #16151b;
  border: 1px solid #454449;
}
</style>

<style scoped>
.hzmain {
  width: 1280px;
  margin: 0 auto;
}
.hz-title {
  height: 37px;
  line-height: 37px;
  color: #646464;
  font-size: 20px;
  margin-bottom: 30px;
}
.hz-box {
  /*background: url('../../assets/images/hzkh.png');*/
  height: 405px;
  margin-bottom: 100px;
}
.hz-box ul li {
  float: left;
  width: 182px;
  height: 135px;
  line-height: 135px;
  text-align: center;
  cursor: pointer;
}
.hz-footer {
  height: 300px;
  width: 100%;
  padding-top: 68px;
}
.hz-gg {
  height: 70px;
  line-height: 70px;
  font-size: 40px;
  color: #fff;
}
</style>
`
