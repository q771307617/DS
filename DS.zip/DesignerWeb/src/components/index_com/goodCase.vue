<template>
  <div class="goodcase">
        <p class="title-box ">
            <span class="title float-left">优秀案例</span>
            <span class="list-btn float-right">
                <!--Button icon="ios-search" class="btn">随缘</Button-->
                <Button class="btn" @click="search">
                    更多作品
                    <Icon type="chevron-right"></Icon>
                </Button>
            </span>
        </p>
        <div style="width:1280px;margin:0px auto;" v-if="getPageNum()">
            <SXCarousel
                v-model="goodcase"
                :autoplay="setting.autoplay"
                :autoplay-speed="setting.autoplaySpeed"
                :dots="setting.dots"
                :arrow="setting.arrow">
                <SXCarousel-item v-for="i in getPageNum()" :key="i">
                    <div class="pro-list-wrapper">
                        <ul>
                            <li v-for="item in getPage(i)" :key="item.id" class="list-item">
                                <div class="works">
                                    <div class="pro-img">
                                        <router-link :to="{ name: 'proInfo', params: { id: item.id }}" style="color:#646464;">
                                            <img v-lazy="item.image_url+'!288x312'" :alt="item.name" width="100%">
                                        </router-link>
                                    </div>
                                    <div class="show">
                                        <div class="desc-box font14">
                                            <router-link :to="{ name: 'proInfo', params: { id: item.id }}" style="color:#646464">{{item.name}}</router-link>
                                            <p class="work-tag" style="text-overflow:ellipsis;white-space:nowrap;">{{item.tag}}</p>
                                            <!--<span class="iconitem"><Icon type="ios-eye-outline" class="font24"></Icon>&nbsp;{{item.viewtimes}}</span>
                                            <span class="iconitem"><Icon type="heart" class="heart font18"></Icon>&nbsp;{{item.loves}}</span>-->
                                        </div>
                                        <div class="user-desc">
                                            <div class="user row-inline">
                                                <router-link :to="{ name: 'detailForDesigner', params: { id: item.user_id }}">
                                                    <img v-lazy="item.designer_image_url+'!37x45'" :alt="item.designer_name">
                                                </router-link>
                                            </div>
                                            <div class="row-inline">
                                                <div>
                                                    <ul class="icons">
                                                        <li class="li_name font14">
                                                            <router-link :to="{ name: 'detailForDesigner', params: { id: item.user_id }}">
                                                                {{item.designer_name}}
                                                            </router-link>
                                                        </li>
                                                        <!--<li>
                                                            <img :src="jb2Icon" alt="中级">
                                                        </li>-->
                                                        <li>
                                                            <img :src="'icon/security.png' | randomPath" alt="保障">
                                                        </li>
                                                        <li>
                                                            <img :src="`icon/certification.png` | randomPath" alt="平台认证">
                                                        </li>
                                                    </ul>
                                                    <p class="sc">{{item.skilful | SKILLFULL_LIST_TEXT(childList4,'|')}}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </SXCarousel-item>
            </SXCarousel>
        </div>
        <h3 v-else class="text-center message">没有找到符合条件的作品</h3>
        <div class="bg2" v-lazy:background-image="`${ftpPath}images/index_bg2.png`">
            <p class="bg2-title text-center">只需4步 轻松找美工</p>
            <p class="bg2-desc text-center">选择设计师雇佣&nbsp;&nbsp;工资托管点将担保&nbsp;&nbsp;设计师在线全职工作&nbsp;&nbsp;雇主满意后发薪</p>
            <img :src="'icon/index-sb.png' | randomPath">
        </div>
    </div>
</template>

<script>
import SXCarousel from '../iview/carousel/carousel.vue';
import SXCarouselItem from '../iview/carousel/carousel-item.vue';
import { mapState } from 'vuex';

export default {
  data() {
    return {
      goodcase: 0,
      isshow: false,
      goodCaseList: [],
      setting: {
        autoplay: false,
        autoplaySpeed: 2000,
        dots: 'none',
        arrow: 'always'
      }
    };
  },
  components: {
    SXCarouselItem, SXCarousel
  },
  computed: {
    ...mapState({
      defaultSrc: state => state.User.defaultSrc,
      childList4: state => state.Lists.childList4, //子分类
      ftpPath: state => state.User.ftpPath
    })
  },
  mounted() {
    //获取优秀案例
    this.$ajax.get('product/fine', {}).then(e => {
      if (e.status == 200) {
        this.goodCaseList = e.data.list;
        this.isshow = true;
      } else {
        this.$Message.error('发生错误!');
      }
    });
  },
  methods: {
    // 改变滚动条位置触发图片懒加载
    // scrollChange(){
    //     let y = window.pageYOffset;
    //     window.scrollTo(0,y + (y%2 == 0 ?1:-1));
    // },
    // 计算总页数
    getPageNum() {
      var pageNum = 0;
      var count = this.goodCaseList.length;
      if (count % 4 == 0) {
        pageNum = parseInt(count / 4);
      } else {
        pageNum = parseInt(count / 4) + 1;
      }
      return pageNum;
    },
    getPage(index) {
      var dataList = [];
      let k = 0;
      if (index > 1) {
        k = (index - 1) * 4;
      }
      // let count = index * 4;
      for (let i = k; i < index * 4; i++) {
        if (!this.goodCaseList[i]) {
          break;
        }
        dataList.push(this.goodCaseList[i]);
      }
      return dataList;
    },
    search() {
      this.$router.push({
        name: 'proList'
      });
    }
  }
};
</script>

<style>
.desc-box .ivu-icon {
  line-height: inherit;
}
.heart {
  color: #fd7f7f;
}
.goodcase .ivu-carousel-arrow {
  height: 125px;
  width: 50px;
  background: #fff;
  color: #cacaca;
  font-size: 40px;
  border-radius: 0;
}
.goodcase .ivu-carousel .left {
  left: -80px;
  background: url('../../assets/images/index_jt1.png') no-repeat;
  font-size: 0;
}
.goodcase .ivu-carousel .right {
  right: -80px;
  background: url('../../assets/images/index_jt2.png') no-repeat;
  font-size: 0;
}
.goodcase .ivu-carousel .left:hover {
  background: url('../../assets/images/index_jt4.png') no-repeat;
}
.goodcase .ivu-carousel .right:hover {
  background: url('../../assets/images/index_jt3.png') no-repeat;
}
.goodcase .ivu-carousel .ivu-carousel-arrow .ivu-icon {
  display: hidden;
  height: 84px;
  width: 42px;
  color: rgba(0, 0, 0, 0);
}
</style>

<style scoped>
.goodcase .title-box {
  width: 1280px;
  margin: 0 auto;
  height: 70px;
  line-height: 68px;
  margin-top: 35px;
}
.goodcase .title-box .title {
  color: #646464;
  font-size: 20px;
}

.goodcase .list-btn {
  float: right;
}
.goodcase .list-btn .btn {
  font-size: 12px;
  padding: 2px 5px;
}
.goodcase .list-btn .btn:hover {
  border-color: #f54203;
  color: #f54203;
}
.goodcase .bg2 {
  width: 100%;
  height: 221px;
  padding-top: 30px;
  text-align: center;
}
.goodcase .bg2 .bg2-title {
  font-size: 40px;
  color: #fff;
  height: 85px;
  line-height: 85px;
}
.goodcase .bg2 .bg2-desc {
  font-size: 16px;
  margin-bottom: 10px;
  color: #ffffff;
}
.text-center {
  text-align: center;
}
.show {
  width: 288px;
  border: 1px solid #efefef;
  height: 140px;
  /*padding: 0 20px;*/
}

.info {
  padding-top: 10px;
  border-top: 1px solid #e9eaec;
}
.pro-img {
  width: 288px;
  height: 312px;
  overflow: hidden;
  border: 1px solid #dddee1;
  border-bottom: 0;
}
.user {
  width: 39px;
  height: 47px;
  border: 1px solid #efefef;
}
.user img {
  display: block;
  width: 100%;
  height: 100%;
}
.row-inline {
  display: inline-block;
  vertical-align: middle;
  margin-right: 4px;
}
.works {
  background-color: #fff;
}

.icons {
  overflow: hidden;
  margin-top: 5px;
}
.icons li {
  float: left;
  margin-right: 7px;
}
.icons li > img {
  width: 17px;
  height: 17px;
}
.icons li.li_name {
  margin-right: 10px;
  max-width: 60px;
  overflow: hidden;
  height: 17px;
  line-height: 20px;
}
.li_name a {
  color: #646464;
}
.pro-list-wrapper {
  overflow: hidden;
  padding-bottom: 112px;
}
.pro-list-wrapper ul li:nth-child(4) {
  margin-right: 0;
}
.pro-list-wrapper ul li:nth-child(8) {
  margin-right: 0;
}
.list-item {
  margin-right: 42px;
  float: left;
  /*border:1px solid #ccc;*/
}
.desc-box {
  height: 66px;
  color: #646464;
  padding: 10px 15px 0 15px;
  border-bottom: 1px solid #efefef;
}
.desc-box .iconitem {
  display: flex;
  float: left;
  margin-right: 46px;
  height: 30px;
  line-height: 30px;
  margin-top: 6px;
}
.work-tag {
  color: #bbb;
  font-size: 12px;
  overflow: hidden;
  height: 24px;
  line-height: 24px;
}

.user-desc {
  height: 65px;
  padding-top: 15px;
  padding-left: 15px;
}
.sc {
  letter-spacing: 2px;
  color: #888;
  font-size: 14px;
  height: 22px;
  line-height: 22px;
}
</style>
