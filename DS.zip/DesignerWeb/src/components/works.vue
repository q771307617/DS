<template>
    <div>
        <p class="font18 clearfix marginbtom10 title-resume"><span class="float-left borderstyle title-style">相关作品(共{{items.length}}条)</span>
        <!--<span class="float-right" @click="more">点击查看全部</span> -->
        <router-link :to="{ name: 'oneDesigner', params: { id: $route.params.id } }" class="float-right title-style">
            点击查看全部
        </router-link>
        </p>
        <Row :gutter="16" v-if="items.length">
            <Col span="6" v-for="(item,index) in showList" :key="index">
                <div class="item" style="width:268px;margin:auto;">
                    <div class="text-center works"  style="width:268px;height:288px;overflow:hidden;position: relative;">
                        <router-link :to="{ name: 'proInfo', params: { id: item.id }}">
                            <img width="268" :src="item.image_url+'!268x288'" :alt="item.name">
                            <div class="imgshow" style="width:100%;height:100%;background-color:rgba(0,0,0,0.4)">
                                <p style="width:102px;height:30px;background-color:#fe980f;color:#fff;text-align:center;margin:auto;margin-top:130px;font-size:16px;line-height:30px;">点击查看</p>
                            </div>
                        </router-link>
                    </div>
                    <div class="divider text-center">{{item.name}}</div>
                </div>
            </Col>
        </Row>
        <h3 v-else class="text-center message">该作者很懒，还没有上传作品！</h3>
    </div>
</template>
<script>
import { mapState } from 'vuex';

export default {
  data() {
    return {
      // items: []
    };
  },
  computed: {
    ...mapState({
      defaultSrc: state => state.User.defaultSrc,
      items: state => state.pub.productList
    }),
    showList() {
      var showList = [];
      if (this.items.length > 4) {
        for (let i = 0; i < 4; i++) {
          showList.push(this.items[i]);
        }
      } else {
        showList = this.items;
      }
      return showList;
    }
  }
};
</script>
<style scoped>
.divider {
  /*border-bottom: 1px solid #dddee1;*/
  font-size: 14px;
  color: #646464;
  padding-bottom: 10px;
  padding-top: 10px;
}

.text-center {
  text-align: center;
}

.works {
  width: 100%;
  height: 100%;
  overflow: hidden;
}

.works:hover .imgshow {
  position: absolute;
  top: 0;
}

.works img {
  width: 100%;
  overflow: hidden;
  border-bottom: 1px solid #dddee1;
}
.title-style {
  color: #646464;
  font-size: 18px;
}

.item {
  margin-bottom: 16px;
}
.borderstyle {
  font-size: 18px;
  color: #646464;
  border-bottom: 3px solid #f54203;
}
.title-resume {
  /*border-bottom:2px solid #fc7c09;*/
  height: 40px;
  line-height: 40px;
}
</style>
