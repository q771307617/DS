<template>
    <div class="fotter">
        <div class="fotter-box">
            <ul>
                <li class="float-left text-center">
                    <!--<router-link :to="{path:'/rules?index=1'}">-->
                        <img :src="'icon/footerhomt.png' | randomPath" alt="">
                        <p class="margintop5 font16">专业店铺设计</p>
                        <p class="fotter-txt font14">定制您的专属旺铺</p>
                    <!--</router-link>-->
                </li>
                <li class="float-left text-center">
                    <!--<router-link :to="{path:'/rules?index=2'}">-->
                        <img :src="'icon/footersjs.png' | randomPath" alt="">
                        <p class="margintop5 font16">极速匹配设计师</p>
                        <p class="fotter-txt font14">当天匹配专业设计师</p>
                    <!--</router-link>-->
                </li>
                <li class="float-left text-center">
                    <!--<router-link :to="{path:'/rules?index=3'}">-->
                        <img :src="'icon/footer3.png' | randomPath" alt="">
                        <p class="margintop5 font16">三天试用</p>
                        <p class="fotter-txt font14">降低风险满意再付款</p>
                    <!--</router-link>-->
                </li>
                <li class="float-left text-center">
                    <!--<router-link :to="{path:'/rules?index=4'}">-->
                        <img :src="'icon/footerdb.png' | randomPath" alt="">
                        <p class="margintop5 font16">平台担保</p>
                        <p class="fotter-txt font14">保障您的资金安全</p>
                    <!--</router-link>-->
                </li>
            </ul>
        </div>
        <div class="fotter-desc">
          <ul class="friend-links">
            <li v-for="i in links" :key="i.name">
              <a v-bind:href="i.link" target="_blank">{{i.name}}</a>
            </li>
          </ul>
          <ul class="paddingtop28">
            <li class="text-center">
              <a href="http://www.miibeian.gov.cn" target="_blank">备案号：浙ICP备12026518号-58</a> Copyright2008-2017 All rights reserved </li>
            <li class="text-center">杭州四喜信息技术有限公司版权所有 地址：杭州市西湖区西湖科技园西园八路11号B座5楼</li>
            <li class="text-center" style="margin-top:5px;">
              <a key="5971671c2548be7a81d18856" logo_size="124x47" logo_type="realname" href="https://v.pinpaibao.com.cn/authenticate/cert/?site=www.dianjiangla.com/&amp;at=realname" target="_blank">
                <img width="90" src='http://static.anquan.org/static/outer/image/sm_124x47.png' />
              </a>
            </li>
          </ul>
        </div>
    </div>
</template>
<script>
// eslint-disable-next-line
var _hmt = _hmt || [];
if (location.host.indexOf('dianjiangla') > -1) {
  (function() {
    var hm = document.createElement('script');
    hm.src = 'https://hm.baidu.com/hm.js?27a52ece913b7a181e7e8267a6de1d61';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(hm, s);
  })();

  (function() {
    var hm2 = document.createElement('script');
    hm2.src = 'http://tajs.qq.com/stats?sId=63353741';
    hm2.charset = 'UTF-8';
    var s2 = document.getElementsByTagName('script')[0];
    s2.parentNode.insertBefore(hm2, s2);
  })();
}

export default {
  data: function() {
    return {
      links: []
    };
  },
  mounted: function() {
    const that = this;
    this.$ajax.get('/common/config/get', { key: 'Links' }).then(e => {
      if (e.status !== 200) {
        return;
      }
      this.$nextTick(function() {
        that.links = JSON.parse(e.data);
      });
    });
  }
};
</script>

<style>
.paddingtop37 {
  padding-top: 37px;
}

.paddingtop28 {
  padding-top: 28px;
}

.fotter {
  background: #fafafa;
}

.fotter-box {
  padding-top: 46px;
  width: 1280px;
  margin: 0 auto;
  height: 175px;
  color: #646464;
}

.fotter-box a {
  color: #646464;
}

.fotter-box ul {
  overflow: hidden;
}

.fotter-box ul li {
  float: left;
  width: 25%;
}

.fotter-desc {
  height: 183px;
  border-top: 1px solid #ccc;
  color: #bbb;
}

.fotter-desc li a {
  color: #bbb;
}

.fotter-txt {
  color: #a1a1a1;
}

.flex-item a {
  color: #646464;
}

/*友情链接  */
.friend-links {
  width: 1280px;
  margin: 0 auto;
  padding-top: 29px;
  text-align: center;
}

.friend-links li {
  display: inline-block;
  margin: 0 19px;
}

.friend-links li a {
  font-size: 12px;
  color: #646464;
}
</style>


