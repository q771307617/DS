<template>
    <div v-if="htmlStr">
        <div v-html="htmlStr"></div>
    </div>
    <h3 v-else class="text-center message">该作者很懒，还没有上传简历！</h3>
</template>
<script>
export default {
  props: ['htmlStr'],
  data() {
    return {};
  },
  mounted() {}
};
</script>
<style>

</style>
