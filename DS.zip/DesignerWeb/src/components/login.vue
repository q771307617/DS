<style scoped>
.login-main {
  width: 315px;
  margin: 0 auto;
}

.btn-login {
  height: 48px;
  width: 100%;
}
</style>
<template>
    <div>
        <div v-if="registerModal">
            <!--注册-->
            <div class="ivu-modal-mask"></div>
            <div class="ivu-modal-wrap">
                <Register :cancle="cancleRegister"></Register>
            </div>
        </div>
        <div>
            <Modal v-model="loginModal" width="376" :styles="{left: '50%','margin-left': '180px',top: '250px'}" @on-cancel="cancel">
                <div class="login">
                    <div class="login-main">
                        <div style="display: flex;justify-content: space-between;align-items: baseline;margin-top: 20px;margin-bottom: 20px;">
                            <span style="font-size: 22px;color: #888888;">用户登录</span>
                            <span style="font-size: 14px;color: #888888;">没有账户？
                                <a href="javascript:;" style="color: #ff9900;" @click="register">立即注册</a>
                            </span>
                        </div>
                        <Form ref="formInline" :model="formInline" :rules="ruleInline" inline class="c-form">
                            <Form-item prop="user" style="width: 100%;">
                                <Input type="text" v-model="formInline.user" placeholder="用户名/手机号">
                                <Icon type="ios-person-outline" slot="prepend"></Icon>
                                </Input>
                            </Form-item>
                            <Form-item prop="password" style="width: 100%;">
                                <Input type="password" v-model="formInline.password" placeholder="请输入密码" @on-enter="handleSubmit('formInline')">
                                <Icon type="ios-locked-outline" slot="prepend"></Icon>
                                </Input>
                            </Form-item>
                            <Form-item style="width: 100%;margin-bottom: -10px;" v-if="!!error_msg">
                                <Alert type="error">{{error_msg}}</Alert>
                            </Form-item>
                        </Form>
                        <div style="display: flex;margin: 10px 0;justify-content: space-between;align-items: center;">
                            <Checkbox v-model="formInline.autologin" class="chk-warning">下次自动登录</Checkbox>
                            <a href="javascript:;" style="color: #ff9900;" @click="reset">密码找回</a>
                        </div>
                    </div>
                </div>
                <div slot="footer">
                    <Button type="error" @click="handleSubmit('formInline')" class="btn-login">登录</Button>
                </div>
            </Modal>
        </div>
    </div>
</template>


<script>
// import Cookie from '@/utils/cookie.js';
import Register from './register';

import { mapState, mapActions } from 'vuex';

export default {
  components: { Register },
  computed: {
    ...mapState({
      loginModal: state => state.Modal.loginModal
    })
  },
  data() {
    return {
      registerModal: false,
      error_msg: '',
      formInline: {
        user: '',
        password: '',
        autologin: false,
        userType: 0,
        date: '',
        time: ''
      },
      ruleInline: {
        user: [
          {
            required: true,
            message: '请填写用户名或者手机号',
            trigger: 'blur'
          }
        ],
        password: [
          {
            required: true,
            message: '请填写密码',
            trigger: 'blur'
          },
          {
            type: 'string',
            min: 6,
            message: '密码只能输入字母、数字，密码长度限制6~20',
            trigger: 'blur'
          },
          {
            type: 'string',
            max: 20,
            message: '密码只能输入字母、数字，密码长度限制6~20',
            trigger: 'blur'
          }
        ]
      }
    };
  },
  methods: {
    ...mapActions(['fetchUserData']),
    cancleRegister() {
      this.registerModal = false;
    },
    register() {
      this.registerModal = true;
      this.cancel();
    },
    reset() {
      this.$store.commit('SETTING_VERIFY_USER_MODAL', true);
    },
    cancel() {
      this.$refs.formInline.resetFields();
      this.$store.commit('SETTING_LOGIN_MODAL', false);
    },
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (!valid) {
          return;
        }

        this.error_msg = '';
        this.$ajax
          .post('auth/login', {
            password: this.formInline.password,
            username: this.formInline.user,
            type: 2
          })
          .then(e => {
            if (e.status !== 200) {
              this.error_msg = e.msg;
              return;
            }
            this.$Message.success('登录成功！');
            this.cancel();
            this.fetchUserData();
          });
      });
    }
  }
};
</script>

