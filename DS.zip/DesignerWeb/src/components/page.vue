<template>
    <nav class="pagination" style="margin: 10px 0;text-align: right;">
        <ul class="pagination-list">
            <li @click="prePage">
                <a :disabled="currentPage===1">
                    <下一页</a>
            </li>
            <li @click="jump(1)" v-if="pages!==1" :class="{'is-current': currentPage === 1}">
                <a>1</a>
            </li>
            <li v-if="preClipped" class="page-hellip">
                <a class="pagination-link pagination-ellipsis">&hellip;</a>
            </li>
            <li v-for="n in showPages" :key="n" @click="jump(n)" :class="{'is-current': n===currentPage}">
                <a>{{n}}</a>
            </li>
            <li v-if="backClipped" class="page-hellip">
                <a class="pagination-link pagination-ellipsis">&hellip;</a>
            </li>
            <li @click="jump(pages)" :class="{'is-current': currentPage === pages}" v-show="showLastPage && pages">
                <a>{{pages}}</a>
            </li>
            <li @click="nextPage">
                <a :disabled="currentPage===pages">下一页></a>
            </li>
        </ul>
        <div class="page-jump">
            到第
            <input v-model="pageNum" type="text" @keyup.enter="handleEnter">页
            <Button style="margin-left: 8px;" @click="handleEnter">确定</Button>
        </div>
    </nav>
</template>

<script>
export default {
  props: {
    pageSize: {
      type: Number,
      default: 10
    },
    total: {
      type: Number,
      default: 10
    },
    current: {
      type: Number,
      default: 1
    }
  },
  data() {
    return {
      currentPage: this.current,
      preClipped: false,
      backClipped: false,
      pageNum: ''
    };
  },
  watch: {
    current(val) {
      this.currentPage = val;
    }
  },
  computed: {
    pages() {
      return Math.ceil(this.total / this.pageSize);
    },
    showLastPage() {
      return this.pages - this.currentPage <= 2;
    },
    showPages() {
      let ret = [];
      if (this.currentPage > 3) {
        // 当前页码大于三时，显示当前页码的前2个
        ret.push(this.currentPage - 2);
        ret.push(this.currentPage - 1);
        if (this.currentPage > 4) {
          // 当前页与第一页差距4以上时显示省略号
          this.preClipped = true;
        }
      } else {
        this.preClipped = false;
        for (let i = 2; i < this.currentPage; i++) {
          ret.push(i);
        }
      }
      if (this.currentPage !== this.pages && this.currentPage !== 1) {
        ret.push(this.currentPage);
      }
      if (this.currentPage < this.pages - 2) {
        // 显示当前页码的后2个
        ret.push(this.currentPage + 1);
        ret.push(this.currentPage + 2);
        if (this.currentPage <= this.pages - 3) {
          // 当前页与最后一页差距3以上时显示省略号
          this.backClipped = true;
        }
      } else {
        this.backClipped = false;
        for (let i = this.currentPage + 1; i < this.pages; i++) {
          ret.push(i);
        }
      }
      // 返回整个页码组
      return ret;
    }
  },
  methods: {
    prePage() {
      if (this.currentPage > 1) {
        this.currentPage--;
        this.changePage();
      }
    },
    nextPage() {
      if (this.currentPage < this.pages) {
        this.currentPage++;
        this.changePage();
      }
    },
    jump(n) {
      this.currentPage = n;
      this.changePage();
    },
    handleEnter() {
      if (!this.pageNum) return;
      this.currentPage =
        (/^[1-9][0-9]*$/.test(this.pageNum) && Number(this.pageNum)) || 1;
      this.currentPage =
        this.currentPage <= this.pages ? this.currentPage : this.pages;
      this.changePage();
    },
    changePage() {
      this.$emit('on-change', this.currentPage);
    }
  }
};
</script>

<style scoped>
.is-current {
  background-color: #f54203;
  border-color: #f54203;
}

.pagination-list {
  display: inline-block;
  margin-right: 20px;
}

.pagination-list .is-current a {
  color: #fff;
}

.pagination-list li {
  display: inline-block;
  vertical-align: middle;
  min-width: 37px;
  height: 37px;
  line-height: 37px;
  margin-right: 4px;
  text-align: center;
  border: 1px solid #dddee1;
  border-radius: 4px;
}

.pagination-list li:hover {
  border-color: #f54203;
}

.pagination-list li.page-hellip {
  border: none;
}

.pagination-list li.page-hellip a {
  cursor: default;
}

.pagination-list li:first-child,
.pagination-list li:last-child {
  padding: 0 5px;
}

.pagination-list li > a {
  color: #3c3c3c;
}

.page-jump {
  display: inline-block;
}

.page-jump input {
  display: inline-block;
  width: 50px;
  height: 23px;
  line-height: 1.5;
  padding: 4px 7px;
  font-size: 12px;
  border: 1px solid #dddee1;
  color: #495060;
  background-color: #fff;
  background-image: none;
  border-radius: 4px;
  margin: 0 8px;
}
</style>


