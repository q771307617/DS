<template>
<div class="login">
    <div class="login-main">
        <Row class="login-head">
            <Col span="12">
                <span class="title">欢迎登录</span>
            </Col>
            <div style="width:150px;height:150px;border-radius:50%;margin:60px auto 0;overflow:hidden;">
                <img :src="imageUrl+'!150x150'" alt="用户头像" width="100%" />
            </div>
        </Row>
        <div style="text-align:center;padding:0 30px;color:#f90;font-size:20px;">
            {{name}}
        </div>
        <Form ref="formInline"  inline class="c-form">
            <Button type="warning"  class="btn" @click="gotoEmloyer">进入雇主后台</Button>
            <div class="clearfix">
                <a href="javascript:void(0)" class="float-right" @click="logoutBtn">登出</a>
            </div>
        </Form>
    </div>
</div>
</template>

<script>
// import Cookie from '../utils/cookie.js';
export default {
  props: {
    imageUrl: {
      type: String,
      default: ''
    },
    name: {
      type: String,
      default: ''
    },
    logoutAction: {
      type: Function,
      default: function() {}
    }
  },
  data() {
    return {};
  },
  mounted() {},
  methods: {
    gotoEmloyer() {
      this.$router.push({
        name: 'EmloyerHome'
      });
    },
    logoutBtn() {
      this.$Modal.confirm({
        title: '登出',
        content: '确认要登出吗？',
        onOk: () => {
          this.$root.$emit('LOGIN_OUT');
          this.logoutAction();
        }
      });
    }
  }
};
</script>

<style>
.c-form .ivu-form-inline,
.c-form .ivu-form-item {
  margin-right: 0;
}
.c-form .ivu-input-group-append,
.c-form .ivu-input-group-prepend {
  border-radius: 0;
  font-size: 18px;
  width: 36px;
}
.c-form .ivu-input {
  border-radius: 0;
  height: 40px;
}
.c-form .ivu-btn {
  border-radius: 0;
}
</style>
<style scoped>
.login {
  width: 1280px;
  margin: 0 auto;
}
.login-main {
  width: 375px;
  min-height: 400px;
  padding: 30px;
  background: #fff;
  float: right;
  margin-top: 100px;
  margin-bottom: 100px;
}
.login .login-head {
  margin-bottom: 10px;
}
.login .title {
  font-weight: 400px;
  font-size: 20px;
}
.title span {
  font-style: normal;
  color: #f90;
}
.c-form .tab {
  height: 40px;
  line-height: 35px;
  font-size: 14px;
  text-align: center;
  background-color: rgb(239, 243, 246);
}
.c-form .action {
  background-color: #f29100;
  color: #fff;
}
.btn {
  margin-top: 10px;
  margin-bottom: 15px;
  height: 45px;
  width: 100%;
}
</style>