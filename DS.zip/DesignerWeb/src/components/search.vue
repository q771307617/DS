<template>
  <div class="main main-top clearfix" style="overflow:visible;">
   <div class="logo">
      <a href="/" class="over-hid">
         <img src="http://5.img.dianjiangla.com/assets/icon/logo-2.png" height="73">
      </a>
   </div>
   <div class="nav">
      <ul class="over-hid" id="top-nav">
         <li v="home"><a href="/">首页</a></li>
         <li v="designer" ><a href="/search/designer">设计师</a></li>
         <li v="pro" ><a href="/prolist" >作品</a></li>
         <li v="ptgz"><router-link :to="{name:'rules',query:{index:1}}">关于我们</router-link></li>
      </ul>
   </div>
   <div class="search">
      <form id="ser-form2" action="">
         <div class="border">
            <div style="width: 327px;">
               <div class="select" t2="dropdown">
                  <a id="ser-name" class="ser-name">{{fromParams.searchName}}　▼</a>
                  <div id="ser-select" class="ser-select" t="dropdown-nav">
                     <div v-if="fromParams.search">
                        <a @click="setAction(1)">设计师</a>
                        <a @click="setAction(2)">作品</a>
                     </div>
                  </div>
               </div>
               <div class="input" style="float: right;">
                  <input v-model="fromParams.value" type="text" name="name" :placeholder="fromParams.searchPlacehoder" style="height:28px;">
               </div>
            </div>
            <a class="btn" style="width:30px;height:32px;" @click="submit()"><img style="width:14px;height:14px;margin:8px 8px;" src="http://4.img.dianjiangla.com/assets/icon2/search.png" alt="搜"></a>
         </div>
      </form>
   </div>
   <div class="dl_zc_xq">
        <span v-if="info.type != 2">或者</span>
        <a v-if="info.id > 0 && info.type == 1" href="/emloyerBackstage/demandManagent/create/1">发布需求</a>
        <a v-else-if="info.id > 0 && info.type == 2" style="display: none;"></a>
        <a v-else href="/user/login">发布需求</a>
    </div>
    <div class="personal"  v-if="info.id > 0" >
        <a class="personal_a" id="userinfo_img"><img :src="info.image_url"> </a>
        <ul class="personal_ul">
            <li><img src="http://1.img.dianjiangla.com/assets/icon2/personal.png" alt="1"><a @click="inletJumpUrl"> 个人中心 </a></li>
            <li><img src="http://2.img.dianjiangla.com/assets/icon2/setUp.png" alt="2"><a @click="setJumpUrl"> 设置 </a></li>
            <li><img src="http://5.img.dianjiangla.com/assets/icon2/retreat.png" alt="3"><a href="" @click="exitUser"> 退出 </a></li>
        </ul>
    </div>
    <div class="dl_zc"   v-else>
        <p class="dl_zc_a">
            <a  href="/user/login"  > 登录 </a> | <a href="/user/register" > 注册 </a>
        </p>
    </div>
</div>
</template>
<script>
// import router from '../router/index.js';
import Register from '@/components/register.vue';
import Login from '@/components/login.vue';
import { mapState, mapActions } from 'vuex';

export default {
  data() {
    return {
      registerModal: false,
      loginModal: false,
      keyword: '',
      activeMenu: 1,
      fromParams: {
        value: '',
        search: true,
        searchName: '设计师',
        searchPlacehoder: '设计师名称',
        action: '/search/designer'
      }
    };
  },
  components: { Register, Login },
  computed: {
    ...mapState({
      info: state => state.User.info,
      ftpPath: state => state.User.ftpPath
    })
    // 菜单item
    //      menuItems(){
    //            return this.info.id ? login_item : not_login_item;
    //        return not_login_item;
    //      }
  },
  mounted() {
    //   this.bindActiveMenu();
  },
  watch: {
    //      '$route': 'bindActiveMenu'
  },
  methods: {
    ...mapActions(['exitUser']),
    inletJumpUrl() {
      var type = this.info.type;
      if (type == 1) {
        window.location.href = '/emloyerBackstage/home';
      } else if (type == 2) {
        window.location.href = '/personalCenter/manageHall';
      }
    },
    setJumpUrl() {
      //设置
      var type = this.info.type;
      if (type == 1) {
        window.location.href = '/emloyerBackstage/settings/userinfo/editinfo';
      } else if (type == 2) {
        window.location.href = '/personalCenter/personalCenter';
      }
    },
    setAction(type) {
      var setval = type;
      if (setval == 1) {
        this.fromParams.searchName = '设计师';
        this.fromParams.searchPlacehoder = '设计师名称';
        this.fromParams.action = '/search/designer';
      } else if (setval == 2) {
        this.fromParams.searchName = '作品';
        this.fromParams.searchPlacehoder = '作品名称';
        this.fromParams.action = '/prolist';
      }
      // router.name({path:action});
    },
    submit() {
      var searchList = this.fromParams;
      console.log(searchList);
      location.href = '' + searchList.action + '?name=' + searchList.value + '';
      // windows.open()
    }
  }
};
</script>
<style scope>
.main-top a {
  text-decoration: none;
  color: #646464;
}
.main-top a:hover {
  color: #f54203;
}
.main-top {
  margin: 0 auto;
  width: 1200px;
  height: 80px;
}
.main-top div,
.main-top li {
  float: left;
}
.main-top .logo {
  width: 190px;
  margin-top: 3px;
}
.main-top .logo a {
  display: block;
  width: 213px;
  height: 73px;
}
.main-top .nav {
  width: 20pc;
  height: 40px;
  line-height: 40px;
  margin-top: 20px;
  margin-left: -12px;
}
.main-top .nav li {
  text-align: center;
}
.main-top .nav li a {
  display: block;
  padding: 0 12px;
  font-size: 14px;
}
.main-top .nav li.active a,
.main-top .nav li:hover a {
  color: #f54203;
}
.main-top .search .tab-search {
  float: none;
  height: 58px;
}
.main-top .search .tab-search .tab-nav {
  float: none;
}
.main-top .search .tab-search .tab-nav div {
  margin-right: 0;
  width: 78px;
  text-align: center;
}
.main-top .search .tab-search .tab-nav div a {
  display: block;
  padding: 2px 1pc 4px;
  border-radius: 4px 4px 0 0;
  transition: all 0.3s ease-in-out;
}
.main-top .search .tab-search .tab-nav div:hover a {
  color: #f54203;
}
.main-top .search .tab-search .tab-nav div a.active {
  background-color: #f54203;
  color: #fff;
}
.main-top .search .tab-search .search-btn {
  position: relative;
  top: -1px;
  float: none;
  display: table;
  margin-top: -1px;
  width: 100%;
  border-collapse: separate;
  vertical-align: middle;
  font-size: 9pt;
  opacity: 1;
  transition: opacity 0.3s;
  -ms-flex-negative: 0;
  flex-shrink: 0;
}
.main-top .search .tab-search .search-btn div.input {
  height: 25px;
  border: 1px solid #f54203;
  border-bottom-left-radius: 4px;
  border-top-left-radius: 4px;
  box-shadow: inherit;
}
.main-top .search .tab-search .search-btn div input {
  width: 379px;
  height: 24px;
  border: none;
  border-bottom-left-radius: 4px;
  border-top-left-radius: 4px;
  text-indent: 10px;
}
.main-top .search .tab-search .search-btn div a {
  display: block;
  width: 75px;
  height: 25px;
  border: 1px solid #e83f03;
  border-top-right-radius: 6px;
  border-bottom-right-radius: 6px;
  background-color: #f54203;
  color: #fff;
  text-align: center;
  font-weight: 400;
  line-height: 25px;
}
.main-top .search .keyword-search ul li {
  font-size: 14px;
}
.main-top .search .keyword-search ul li a {
  display: block;
  padding: 0 5px;
  color: #bbb;
}

/** 头部搜索 */
.main-top .search .border {
  border: 1px solid #b3b3b3;
  height: 32px;
  line-height: 32px;
  border-radius: 4px;
  margin-top: 20px;
  position: relative;
}
.main-top .search .border .select {
  float: left;
  z-index: 999999;
  position: absolute;
}
.main-top .search .border .select .ser-name {
  height: 20px;
  line-height: 20px;
  margin-top: 5px;
  width: 92px;
  text-indent: 17px;
  border: none;
  display: block;
  border-right: 1px solid rgba(0, 0, 0, 0.2);
}
.main-top .search .border .select .ser-select {
  width: 92px;
  height: inherit;
  display: none;
}
.main-top .search .border .select:hover div {
  display: block;
}
.main-top .search .border .select .ser-select div {
  padding: 4px 17px;
  width: 95px;
  background-color: #fff;
  border-bottom-right-radius: 2px;
  border-bottom-left-radius: 2px;
  z-index: 900;
  border-top: none;
}
.main-top .search .border .select .ser-select div a {
  display: block;
}
.main-top .search .border .input {
  float: left;
}
.main-top .search .border .input input {
  width: 234px;
  height: 30px;
  border: none;
  text-indent: 17px;
}
.main-top .search .border .btn {
  float: left;
  width: 77px;
  text-align: center;
}
.main-top .search .border .btn a {
  display: block;
  background-color: #c20c0c;
  color: #fff;
  font-size: 9pt;
}
.main-top .search .border .btn a img {
  height: 14px;
  width: 14px;
  margin-top: 10px;
}

.main-top .dl_zc_xq {
  width: 150px;
  height: 32px;
  line-height: 32px;
  margin: 20px 0 19px;
}
.main-top .dl_zc_xq span {
  padding: 12px 20px;
  font-size: 14px;
}
.main-top .dl_zc_xq a {
  display: inline-block;
  width: 70px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  background-color: #c20;
  margin: 3px;
  border-radius: 5px;
  text-align: center;
  color: #ffffff;
  border: none;
}
.main-top .notes {
  display: inline-block;
  width: 50px;
  height: 32px;
  line-height: 32px;
  margin: 20px 0px;
}
.main-top .notes img {
  width: 30px;
  max-width: 30px;
  height: 30px;
  margin: auto 10px;
}
.main-top .personal {
  float: right;
  min-width: 100px;
  width: 100px;
  width: auto;
  height: 32px;
  line-height: 32px;
  margin: 20px 0;
  position: relative;
}
.main-top .dl_zc {
  width: 90px;
  height: 32px;
  line-height: 32px;
  text-align: center;
  margin: 20px 0;
  float: right;
}
.main-top .dl_zc_a {
  margin-left: 16px;
}
.main-top .personal:hover .personal_ul {
  display: block;
}
.main-top .personal .dl_zc {
  width: 80px;
  margin: 0 8px;
  display: none;
}
.main-top .personal .personal_a img {
  width: 30px;
  max-width: 40px;
  height: 30px;
  margin: auto 36px;
}
.main-top .personal_ul {
  position: absolute;
  top: 32px;
  right: 0;
  width: 100px;
  height: auto;
  background-color: #ffffff;
  z-index: 99;
  border: 1px solid #ccc;
  display: none;
}
.main-top .personal_ul li {
  display: block;
  width: 100px;
  height: 36px;
  line-height: 36px;
  text-align: center;
  overflow: hidden;
  color: red;
}
.main-top .personal_ul li img {
  float: left;
  width: 15px;
  height: 15px;
  margin: 10px 5px;
}
.main-top .personal_ul li a {
  float: left;
  display: block;
  width: 70px;
}
.main-top a.router-link-active {
  color: #c20c0c;
}
</style>

