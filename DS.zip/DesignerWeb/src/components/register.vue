<template>
    <div class="reg">
        <div class="reg-main">
            <div class="reg-top">
                <p class="reg-title marginbottom20">
                    用户注册
                </p>
                <div @click="cancle" class="close">
                    <Icon type="ios-close" size="30" color="#495060" />
                </div>
            </div>
    
            <Form ref="formInline" :model="formInline" :rules="ruleInline" inline class="c-form">
                <Form ref="formInlinePhone" :model="formInline" :rules="rulePhone" inline>
                    <Form-item prop="phone">
                        <Input type="text" v-model="formInline.phone" placeholder="请输入常用的手机号" class="width320" :maxlength="11">
                        <Icon type="ios-person-outline" slot="prepend"></Icon>
                        </Input>
                    </Form-item>
                </Form>
                <Form-item prop="password">
                    <Input type="password" v-model="formInline.password" placeholder="密码（6-20位字母、数字、无空格）" class="width320">
                    <Icon type="ios-locked-outline" slot="prepend"></Icon>
                    <Icon type="eye"></Icon>
                    </Input>
                </Form-item>
                <Form-item prop="verifycode" class="width320" v-if="isShowCode">
                    <Row>
                        <Col span="12">
                        <Input type="text" placeholder="输入验证码" v-model="formInline.verifycode">
                        <Icon type="ios-locked-outline" slot="prepend"></Icon>
                        </Input>
                        </Col>
                        <Col span="12" class="text-right paddingleft20">
                        <img v-bind:src="codesrc" @click="changeCodeSrc" width="100%" height="40px" style="display:block;" />
                        </Col>
                    </Row>
                </Form-item>
                <Form-item prop="code" class="width320">
                    <Row>
                        <Col span="12">
                        <Input type="text" v-model="formInline.code" placeholder="输入6位动态码">
                        <Icon type="ios-locked-outline" slot="prepend"></Icon>
                        </Input>
                        </Col>
                        <Col span="12" class="text-right paddingleft20">
                        <Button type="error" class="codebtn" v-if="codeIntervalTime != 60" loading style="padding:0">{{codeIntervalTime}}后重新获取</Button>
                        <Button type="error" @click="sendcode" class="codebtn" v-if="codeIntervalTime == 60">获取动态码</Button>
                        </Col>
                    </Row>
                </Form-item>
                <Button type="error" :disabled="!formInline.checkboxType" @click="handleSubmit('formInline')" class="btn-reg">注册</Button>
                <Row class="margintop10">
                    <Col span="12" style="overflow:hidden;">
                    <div style="float:left;">
                        <input v-model="formInline.checkboxType" style="margin-top:4px;" type="checkbox">
                    </div>
                    <a target="_black" title="点击查看" href="/rules?index=4" style="color:#888;">《点将啦服务协议》</a>
                    </Col>
                </Row>
            </Form>
        </div>
    </div>
</template>

<script>
export default {
  props: {
    cancle: {
      type: Function,
      default: function() {
        console.warn('未填写');
      }
    },
    gotoLogin: {
      type: Function,
      default: function() {
        console.warn('未填写');
      }
    }
  },
  watch: {
    'formInline.phone'(val, oldVal) {
      if (!val && oldVal.length === 1) return;
      if (/^[1-9]*[1-9][0-9]*$/.test(val)) return;
      this.$nextTick(() => {
        this.formInline.phone = oldVal;
      });
    }
  },
  mounted() {
    this.$refs['formInline'].resetFields();
  },
  data() {
    return {
      isShowCode: false,
      //验证码的超时时间
      codeIntervalTime: 60,
      imgcode: true,
      codesrc: this.$ajax.getVerifyCode(),
      formInline: {
        username: '',
        password: '',
        phone: '',
        code: '',
        checkboxType: true
      },
      rulePhone: {
        phone: [
          {
            required: true,
            message: '请填写手机号',
            trigger: 'blur'
          },
          {
            required: true,
            pattern: /^1(3|4|5|7|8)\d{9}$/,
            message: '请填写正确的手机号',
            trigger: 'blur'
          }
        ]
      },
      ruleInline: {
        phone: [
          {
            required: true,
            message: '请填写手机号',
            trigger: 'blur'
          },
          {
            required: true,
            pattern: /^1(3|4|5|7|8)\d{9}$/,
            message: '请填写正确的手机号',
            trigger: 'blur'
          }
        ],
        password: [
          {
            required: true,
            message: '请填写密码',
            trigger: 'blur'
          },
          {
            pattern: /^[a-zA-Z0-9]{6,20}$/,
            message: '密码只能输入字母、数字，密码长度限制6~20',
            trigger: 'blur'
          }
        ],
        verifycode: [
          {
            required: true,
            message: '请输入验证码',
            trigger: 'blur'
          },
          {
            len: 4,
            message: '4位验证码',
            trigger: 'blur'
          }
        ],
        code: [
          {
            required: true,
            message: '请输入验证码',
            trigger: 'blur'
          },
          {
            len: 6,
            message: '验证码错误',
            trigger: 'blur'
          }
        ]
      }
    };
  },
  methods: {
    sendcode() {
      this.$refs.formInlinePhone.validate(valid => {
        if (!valid) {
          this.$Notice.error({ title: '请填写正确的手机号' });
          return;
        }

        this.$ajax
          .get('auth/isexist', { username: this.formInline.phone })
          .then(e => {
            if (e.status !== 200) {
              this.$Notice.error({ title: '手机已经注册!' });
              return;
            }

            this.$ajax
              .post('auth/sendcode', {
                phone: this.formInline.phone,
                verifycode: this.formInline.verifycode
              })
              .then(e => {
                if (e.status == 200) {
                  this.formInline.code = e.data;
                  this.intervalTimeid = setInterval(() => {
                    this.codeIntervalTime--;
                    if (this.codeIntervalTime == 0) {
                      this.codeIntervalTime = 60;
                      clearInterval(this.intervalTimeid);
                    }
                  }, 1000);
                  this.$Notice.success({ title: '验证码已发送！' });
                } else if (e.status == 403) {
                  this.$Notice.error({ title: e.msg });
                  this.isShowCode = true;
                }
              });
          });
      });
    },
    changeCodeSrc() {
      this.codesrc = this.$ajax.getVerifyCode();
    },
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          this.$ajax
            .get('auth/register', {
              username: this.formInline.phone,
              password: this.formInline.password,
              phone: this.formInline.phone,
              code: this.formInline.code,
              type: 2
            })
            .then(e => {
              if (e.status == 200) {
                this.$Notice.success({ title: '注册成功，请登录' });
                this.$root.$emit('REGISTER_OK');
                this.cancle();
              }
            });
        } else {
          this.$Notice.error({ title: '表单验证失败!' });
        }
      });
    }
  }
};
</script>
<style scoped>
.close {
  position: absolute;
  right: 0;
  top: 0;
}

.reg {
  position: absolute;
  left: 50%;
  margin-left: 205px;
  z-index: 1000;
}

.reg-main {
  width: 375px;
  min-height: 400px;
  margin-top: 250px;
  margin-bottom: 100px;
  float: right;
  padding: 27px;
  padding-top: 15px;
  background: #fff;
}

.reg-top {
  position: relative;
}

.reg-title {
  text-align: center;
  font-size: 20px;
  height: 40px;
  line-height: 40px;
  margin-bottom: 20px;
  width: 100%;
  border-bottom: 2px solid #f29100;
}

.codebtn {
  width: 100%;
  height: 40px;
  font-size: 16px;
}

.textcenter {
  text-align: center;
}

.marginleft10 {
  margin-left: 10px;
}

.marginbottom10 {
  margin-bottom: 10px;
}

.margintop10 {
  margin-top: 10px;
}

.paddingleft20 {
  padding-left: 20px;
}

.padding8-40 {
  padding: 8px 40px;
}

.padding8-20 {
  padding: 8px 20px;
}

.imgcode {
  margin-bottom: 10px;
}

.width320 {
  width: 320px;
}

.btn-reg {
  height: 43px;
  width: 100%;
  font-size: 18px;
}
</style>