<template>
    <ul class="row box-shadow">
        <li class="col">
            <div class="col-con">
                <router-link :to="{name:'demandManagentTable',query:{status:1}}">{{data.submit}}</router-link>
                <p>已提交需求</p>
            </div>
        </li>
        <li class="col">
            <div class="col-con">
                <span>
                    <router-link :to="{name:'demandManagentTable',query:{status:2}}" v-if="!gethashTamp">0</router-link>
                    <router-link v-else :to="{ name : 'demandManagentWrite', query: { temp: 1, platform: 4, category: temp.class_id, designType: temp.type_id} }">1</router-link>
                </span>
                <p>草稿箱</p>
            </div>
        </li>
        <li class="col">
            <div class="col-con">
                <router-link :to="{name:'demandManagentTable',query:{status:3}}">{{data.not_complete}}</router-link>
                <p>未完成的需求</p>
            </div>
        </li>
        <li class="col">
            <div class="col-con">
                <router-link :to="{name:'demandManagentTable',query:{status:4}}">{{data.complete}}</router-link>
                <p>已完成的需求</p>
            </div>
        </li>
        <li class="col">
            <div class="col-con" style="border-right: none;">
                <router-link :to="{name:'demandManagentTable',query:{status:6}}">{{data.cancel}}</router-link>
                <p>已取消的需求</p>
            </div>
        </li>
    </ul>
</template>
<script>
import { mapState } from 'vuex';

export default {
  data() {
    return {
      data: {
        complete: 0,
        not_complete: 0,
        cancel: 0,
        submit: 0,
        temp: 0
      },
      hasTemp: false,
      temp: {}
    };
  },
  computed: {
    gethashTamp: function() {
      return this.hasTemp;
    },
    ...mapState({ reflash: state => state.pub.reflash })
  },
  watch: {
    reflash(val) {
      if (val) {
        this.fetchData();
      }
    }
  },
  mounted() {
    this.fetchData();
  },
  methods: {
    fetchData() {
      this.$ajax.get('index/status').then(e => {
        if (e.status !== 200) return;
        this.data = e.data;
      });
      this.$ajax.get('demand/temp').then(e => {
        if (e.status !== 200) return;
        if (e.data) {
          this.temp = e.data;
          this.hasTemp = true;
          sessionStorage.setItem('TEMP_DEMAND', JSON.stringify(this.temp));
        }
      });
    }
  }
};
</script>
<style scoped>
.row {
  display: inline-block;
  width: 100%;
  margin: 10px 0;
  background: #fff;
  padding: 35px 0;
}

.col {
  font-size: 14px;
  height: 60px;
  width: 150px;
  display: inline-block;
}

.col a {
  font-size: 28px;
  color: #f54203;
  font-weight: bold;
}

.col-con {
  width: 100%;
  text-align: center;
  border-right: 1px solid #e5e5e5;
  height: 60px;
}
</style>
