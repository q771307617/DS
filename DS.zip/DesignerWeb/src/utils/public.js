import state from '@/store/public/state'
/**
 * @Title: 公共-工具类提供一些便捷地工具服务
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/21 14:59
 * @Version V2.0.2
 *
 * =====================================================================
 * @Description: 工具索引
 *     1、getArrName 在 key name 数组中 获取 name
 *     2、getArrTitle 在 key title 集合中 获取 title
 *     3、getDesignerRankName 获取 设计师 等级 名称
 *     4、getDesignerWorkPlaceName 获取 设计师 入驻类型 名称
 * =====================================================================
 */
let util = {};
/**
 * @Title: 1、在 key name 集合中 获取 name
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/21 15:12
 * @Version V2.0.2
 *
 * @param arr [{key: "1", name: "待支付"}, {key: "2", name: "待开始"}, {key: "3", name: "待交付"}]
 * @param key 1
 * @return string name
 *
 * @Description:
 * // Mad Dragon 【 395548460@qq.com 】 2017/11/24 11:01  find IE不兼容，用下面方式替换
 */
util.getArrName = function (arr = [], key = "") {
  let name = '';
  if (key == undefined || key == null) {
    return '';
  }
  arr.map(function (e) {
    if (e.key == key) {
      name = e.name;
    }
  });
  return name;
};
/**
 * @Title: 2、在 key title 集合中 获取 title
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/22 15:54
 * @Version V2.0.2
 *
 * @param arr [{key: "1", title: "待支付"}, {key: "2", title: "待开始"}, {key: "3", title: "待交付"}]
 * @param key 1
 * @return string title
 *
 * @Description:
 * // Mad Dragon 【 395548460@qq.com 】 2017/11/24 11:01  find IE不兼容，用下面方式替换
 */
util.getArrTitle = function (arr = [], key = "") {
  let title = '';
  if (key == undefined || key == null) {
    return '';
  }
  arr.map(function (e) {
    if (e.key == key) {
      title = e.title;
    }
  });
  return title;
};

/**
 * @Title: 3、获取 设计师 等级 名称
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/23 11:29
 * @Version V2.0.2
 * @Description:
 */
util.getDesignerRankName = function (rankKey) {
  return util.getArrName(state.ranksList, rankKey);
}

/**
 * @Title: 4、获取 设计师 入驻类型 名称
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/23 13:51
 * @Version V2.0.2
 * @Description:
 */
util.getDesignerWorkPlaceName = function (workPlace) {
  return util.getArrName(state.workPlaceList, workPlace);
}


export default util;
