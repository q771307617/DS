// import Constant from "../constant/index.js"
export default {
    // toString:(obj)=>{

    //     if(obj.createTime){
    //         obj.createTimeValue = new Date(obj.createTime*1).Format("yyyy-MM-dd hh:mm:ss");
    //     }
    //     return obj;
    // }
}