import moment from 'moment'
import pub from './public'
import state from '@/store/public/state'
/**
 * @Title: 订单-工具类提供一些便捷地工具服务
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/21 15:00
 * @Version V2.0.2
 *
 * =====================================================================
 * @Description: 工具索引
 *     1、isRefundOrder 根据订单状态 判断 是否是退款单
 *     2、getOrderStatusName 获取订单状态名称
 *     3、getHireOrderStatusNum  获取雇佣订单状态
 *     4、getHireOrderStatusName 获取雇佣订单状态名称
 *     5、getDemandOrderStatusNum 获取需求订单状态
 *     6、getDemandOrderStatusName 获取需求订单状态名称
 *     7、getRefundOrderStatuNum 获取退款订单状态
 *     8、getRefundOrderStatuName 获取退款订单状态名称
 *     9、isDemandOrderType 是否是 需求订单
 *     10、isHireOrderType 是否是 雇佣订单
 *     11、filterOrderStatusList 过滤 订单状态 列表
 *     12、getOrderTypeName 获取 订单类型 名称
 * ============================================================================
 */

let util = {};

/**
 * @Title: 1、根据订单状态 判断 是否是退款单
 *
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/21 14:26
 * @Version V2.0.2
 *
 * @param status 订单状态
 * @return boolean true/false
 *
 * @Description: 退款订单状态列表
 *     REFUND_AUDIT : 退款审核中 , REFUND_WAIT : 等待退款 , REFUND_SUCCESS : 退款成功
 */
util.isRefundOrder = function (status) {
  return status == 'REFUND_AUDIT' || status == 'REFUND_WAIT' || status == 'REFUND_SUCCESS';
};

/**
 * @Title: 2、获取订单状态名称
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/22 16:32
 * @Version V2.0.2
 * @Description: 所有订单状态集合
 *
 * {key: "0", name: "未知类型", title: "未知类型"},
 * {key: "1", name: "待支付", title: "等待雇主付款"},
 * {key: "2", name: "待开始", title: "等待开始工作"},
 * {key: "3", name: "待交付", title: "等待设计师提交验收"},
 * {key: "4", name: "待验收", title: "等待雇主验收"},
 * {key: "5", name: "已完成", title: "订单已完成"},
 * {key: "6", name: "已取消", title: "订单已取消"},
 * {key: "7", name: "待评价", title: "等待雇主评价"},
 * {key: "8", name: "已评价", title: "订单已评价"},
 * {key: "9", name: "退款审核中", title: "退款审核中"},
 * {key: "10", name: "等待设计师审核", title: "等待设计师审核"},
 * {key: "11", name: "等待总监审核", title: "等待总监审核"},
 * {key: "12", name: "等待财务审核", title: "等待财务审核"},
 * {key: "13", name: "退款中", title: "退款中"},
 * {key: "14", name: "已退款", title: "已退款"},
 * {key: "15", name: "退款失败", title: "退款失败"},
 * {key: "16", name: "验收未通过", title: "验收未通过"},
 */
util.getOrderStatusName = function (statusNum) {
  return pub.getArrTitle(state.allStatusList, statusNum);
};

/**
 * @Title: 3、获取雇佣订单状态
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/21 17:18
 * @Version V2.0.2
 *
 * @param orderInfo 订单详情
 * @return number [0-16]
 *
 * @Description: 所有订单状态列表
 *  * 0: 全部
 *
 * 正常订单
 *     1: 待支付 2: 待开始 3: 待交付 4: 待验收 16:验收不通过(需求订单) 5: 已完成 6: 已取消 7: 待评价 8: 已评价
 *
 * 退款订单
 *     9: 退款审核中 10: 等待设计师审核 11: 等待总监审核 12: 等待财务审核 13: 退款中 14: 已退款 15: 退款失败
 */
util.getHireOrderStatusNum = function (orderInfo) {
  let nowTime = moment().format('x');
  let hireStatus = orderInfo.hire_status || orderInfo.hireStatus || 0;
  let startTime = orderInfo.start_time || orderInfo.startTime;
  let endTime = orderInfo.end_time || orderInfo.endTime;

  if (hireStatus == 0) {
    return 1; // 1 等待雇主付款
  }
  if ((hireStatus == 1 || hireStatus == 2) && (startTime > nowTime)) {
    return 2;// 2 等待开始工作
  }
  if ((hireStatus == 1 || hireStatus == 2) && (startTime < nowTime) && (endTime > nowTime)) {
    return 3;// 3 等待设计师提交验收
  }
  if ((hireStatus == 1 || hireStatus == 2) && (endTime < nowTime)) {
    return 4;// 4 等待雇主验收
  }
  /**
   * 相当于待评价 暂时不用
   if (hireStatus == 3) {
         return ; // 5 订单已完成
       }
   */
  if (hireStatus == -1) {
    return 6; // 6 订单已取消
  }
  if (hireStatus == 3) {
    return 7; // 7 等待雇主评价
  }
  if (hireStatus == 4) {
    return 8; // 8 订单已评价
  }
  return 0; // 未知类型
};
/**
 * @Title: 4、获取雇佣订单状态名称
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/21 17:18
 * @Version V2.0.2
 *
 * @param orderInfo 订单详情
 * @return string '等待雇主评价'/ '订单已评价' ...
 */
util.getHireOrderStatusName = function (orderInfo) {
  return util.getOrderStatusName(util.getHireOrderStatusNum(orderInfo));
};

/**
 * @Title: 5、获取需求订单状态
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/22 10:58
 * @Version V2.0.2
 *
 * @param orderInfo 订单详情
 * @return number [0-16]
 *
 * @Description: 所有订单状态列表
 * 0: 全部
 *
 * 正常订单
 *     1: 待支付 2: 待开始 3: 待交付 4: 待验收 16:验收不通过(需求订单) 5: 已完成 6: 已取消 7: 待评价 8: 已评价
 *
 * 退款订单
 *     9: 退款审核中 10: 等待设计师审核 11: 等待总监审核 12: 等待财务审核 13: 退款中 14: 已退款 15: 退款失败
 */
util.getDemandOrderStatusNum = function (orderInfo) {
  let completeStatus = orderInfo.complete_status || orderInfo.completeStatus || 0;
  let auditStatus = orderInfo.audit_status || orderInfo.auditStatus || 0;
  let budgetStatus = orderInfo.budget_status || orderInfo.budgetStatus || 0;
  let acceptStatus = orderInfo.accept_status || orderInfo.acceptStatus || 0;

  if (completeStatus == -1) {
    return 6;// 6 订单已取消
  }
  if (auditStatus == 1 && budgetStatus == 0) {
    return 1;// 1 等待雇主付款
  }
  if (budgetStatus == 1 && completeStatus == 0) {
    return 3;// 3 等待设计师提交验收
  }
  if (completeStatus == 1) {
    if (acceptStatus == 0) {
      return 4;// 4 等待雇主验收
    }
    if (acceptStatus == -1) {
      return 16;// 16 雇主验收不通过
    }
  }
  if (completeStatus == 1 && acceptStatus == 1) {
    return 5;// 5 订单已完成
  }
  return 0; // 未知类型
};
/**
 * @Title: 6、获取需求订单状态名称
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/22 10:58
 * @Version V2.0.2
 *
 * @param orderInfo 订单详情
 * @return string '等待雇主评价'/ '订单已评价' ...
 */
util.getDemandOrderStatusName = function (orderInfo) {
  return util.getOrderStatusName(util.getDemandOrderStatusNum(orderInfo));
};

/**
 * @Title: 7、获取退款订单状态
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/22 15:11
 * @Version V2.0.2
 *
 * @param refundStatus 退款订单状态
 * @return number [0-16]
 *
 * @Description: 所有订单状态列表
 * 0: 全部
 *
 * 正常订单
 *     1: 待支付 2: 待开始 3: 待交付 4: 待验收 16:验收不通过(需求订单) 5: 已完成 6: 已取消 7: 待评价 8: 已评价
 *
 * 退款订单
 *     9: 退款审核中 10: 等待设计师审核 11: 等待总监审核 12: 等待财务审核 13: 退款中 14: 已退款 15: 退款失败
 */
util.getRefundOrderStatuNum = function (refundStatus) {
  return pub.getArrTitle(state.refundStatusTypeList, refundStatus);
};
/**
 * @Title: 8、获取退款订单状态名称
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/22 15:11
 * @Version V2.0.2
 *
 * @param refundStatus 退款订单状态
 * @return string '等待设计师审核'/'等待总监审核' ...
 */
util.getRefundOrderStatuName = function (refundStatus) {
  return util.getOrderStatusName(util.getRefundOrderStatuNum(refundStatus));
};

/**
 * @Title: 9、是否是 需求订单
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/22 17:46
 * @Version V2.0.2
 *
 * @param orderType 订单类型
 * @return true / false
 *
 * @Description: 订单类型列表
 * DEMAND : 需求订单 ， HIRE_MONTH : 包月订单 ， HIRE_CUSTOM : 定制订单
 */
util.isDemandOrderType = function (orderType) {
  return orderType == 'DEMAND';
};
/**
 * @Title: 10、是否是 雇佣订单
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/22 17:46
 * @Version V2.0.2
 *
 * @param orderType 订单类型
 * @return true / false
 *
 * @Description: 订单类型列表
 * DEMAND : 需求订单 ， HIRE_MONTH : 包月订单 ， HIRE_CUSTOM : 定制订单
 */
util.isHireOrderType = function (orderType) {
  return orderType == 'HIRE_MONTH' || orderType == 'HIRE_CUSTOM'
};

/**
 * @Title: 11、过滤 订单状态 列表
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/22 20:10
 * @Version V2.0.2
 *
 * @param indexs "0,-1,1,2"
 * @return
 * [
 *     {key: "0", name: "未知类型", title: "未知类型"},
 *     {key: "-1", name: "全部订单", title: "全部订单"},
 *     {key: "1", name: "待支付", title: "等待雇主付款"},
 *     {key: "2", name: "待开始", title: "等待开始工作"}
 * ]
 * @Description:
 *    需求订单状态列表 "-1,1,3,4,5,6,9,13,14"
 *    雇佣订单状态列表 "-1,1,2,3,7,8,6,9,13,14"
 *
 * 所有订单状态列表
 *     0: 未知类型 -1: 全部订单
 *
 * 正常订单
 *     1: 待支付 2: 待开始 3: 待交付 4: 待验收 16:验收不通过(需求订单) 5: 已完成 6: 已取消 7: 待评价 8: 已评价
 *
 * 退款订单
 *     9: 退款审核中 10: 等待设计师审核 11: 等待总监审核 12: 等待财务审核 13: 退款中 14: 已退款 15: 退款失败
 */
util.filterOrderStatusList = function (indexs) {
  var arr = []
  let newStatusList = [];
  if (indexs == [] || indexs == undefined || indexs == null || indexs == '' || indexs.length <= 0) {
    return state.allStatusList;
  }
  arr = indexs.split(",");
  if (arr.length <= 0) {
    return state.allStatusList;
  }
  arr.map(function (e) {
    for (let i = 0; state.allStatusList.length > i; i++) {
      if (state.allStatusList[i].key == e) {
        newStatusList.push(state.allStatusList[i]);
      }
    }
  });
  return newStatusList;
};

/**
 * @Title: 12、获取 订单类型 名称
 * @Author: Mad Dragon 【 395548460@qq.com 】
 * @Date: 2017/11/23 11:26
 * @Version V2.0.2
 * @Description:
 */
util.getOrderTypeName = function (orderType) {
  if (orderType == null || orderType == undefined || orderType == '') return;
  return pub.getArrName(state.orderTypeList, orderType);
}

export default util;
