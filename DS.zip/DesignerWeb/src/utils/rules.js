//抽象出所有的校验规则放于此处
export const NOT_NULL = [
     { required: true, message: '不能为空', trigger: 'blur' }
];
export const PASS_WORD = [
     { required: true, message: '不能为空', trigger: 'blur' },
];
export const USER_NAME = [
     { required: true, message: '不能为空', trigger: 'blur' }
];
export const PHONE = [
     { required: true, message: '不能为空', trigger: 'blur' }
];
