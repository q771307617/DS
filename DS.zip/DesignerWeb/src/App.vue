<template>
  <div id="app">
    <login-modal></login-modal>
    <verify-modal></verify-modal>
    <reset-modal></reset-modal>
    <router-view></router-view>
  </div>
</template>
<script>
import loginModal from '@/components/login';
import verifyModal from '@/components/verifyUser';
import resetModal from '@/components/resetPassword';
import { mapActions } from 'vuex';
export default {
  name: 'app',
  components: { loginModal, verifyModal, resetModal },
  data() {
    return {};
  },
  mounted() {
    this.islogin();
    this.LIST_GET();
  },
  methods: {
    ...mapActions(['islogin', 'LIST_GET'])
  }
};
</script>

<style>
* {
  margin: 0;
  padding: 0;
}

body {
  font-size: 14px;
  font-weight: 500;
}

.ivu-input {
  font-size: 14px;
}

.main {
  background: #fff;
}

.primary-bg {
  /**background:#2d8cf0!important;*/
  background: RGB(246, 116, 4) !important;
}

.primary-color {
  /**color:#2d8cf0!important;*/
  color: RGB(246, 116, 4) !important;
}

.font12 {
  font-size: 12px;
}

.font14 {
  font-size: 14px;
}

.font16 {
  font-size: 16px;
}

.font18 {
  font-size: 18px;
}

.font20 {
  font-size: 20px;
}

.font22 {
  font-size: 22px;
}

.font24 {
  font-size: 24px;
}

.font28 {
  font-size: 28px;
}

.font30 {
  font-size: 30px;
}

.font38 {
  font-size: 38px;
}

.float-right {
  float: right;
}

.float-left {
  float: left;
}

.paddingtop35 {
  padding-top: 35px;
}

.margintop5 {
  margin-top: 5px;
}

.margintop10 {
  margin-top: 10px;
}

.margintop20 {
  margin-top: 20px;
}

.margintop30 {
  margin-top: 30px;
}

.marginbtom10 {
  margin-bottom: 10px;
}

.marginleft10 {
  margin-left: 10px;
}

.marginright5 {
  margin-right: 5px;
}

.marginright7 {
  margin-right: 7px;
}

.marginright10 {
  margin-right: 10px;
}

.marginright20 {
  margin-right: 20px;
}

.marginright25 {
  margin-right: 25px;
}

.text-center {
  text-align: center;
}

.text-right {
  text-align: right;
}

.clearboth {
  clear: both;
}

.clearfix:after {
  content: '.';
  display: block;
  height: 0;
  clear: both;
  visibility: hidden;
}

.clearfix {
  *+height: 1%;
}

.flex-box {
  display: -webkit-box;
  /* OLD - iOS 6-, Safari 3.1-6 */
  display: -moz-box;
  /* OLD - Firefox 19- (buggy but mostly works) */
  display: -ms-flexbox;
  /* TWEENER - IE 10 */
  display: -webkit-flex;
  /* NEW - Chrome */
  display: flex;
}

.flex-item2 {
  -webkit-box-flex: 2;
  /* OLD - iOS 6-, Safari 3.1-6 */
  -moz-box-flex: 2;
  /* OLD - Firefox 19- */
  /* For old syntax, otherwise collapses. */
  -webkit-flex: 2;
  /* Chrome */
  -ms-flex: 2;
  /* IE 10 */
  flex: 2;
}

.flex-item {
  -webkit-box-flex: 1;
  /* OLD - iOS 6-, Safari 3.1-6 */
  -moz-box-flex: 1;
  /* OLD - Firefox 19- */
  /* For old syntax, otherwise collapses. */
  -webkit-flex: 1;
  /* Chrome */
  -ms-flex: 1;
  /* IE 10 */
  flex: 1;
}

.circle-img {
  overflow: hidden;
  border-radius: 50%;
}

.inline-flex {
  display: inline-flex;
}

.message {
  background-color: #fff;
  padding-top: 10px;
  padding-bottom: 10px;
  min-height: 300px;
  line-height: 300px;
}

.box-shadow {
  box-shadow: 0 0 10px #eee;
}

.sx-tabs {
  margin-top: 17px;
  background-color: #fff;
}

.sx-tabs .ivu-tabs-nav {
  padding-left: 20px;
}

.sx-tabs > .ivu-tabs-card > .ivu-tabs-content > .ivu-tabs-tabpane {
  padding: 5px;
}

.sx-tabs > .ivu-tabs.ivu-tabs-card > .ivu-tabs-bar .ivu-tabs-nav-container {
  height: 49px;
}

.sx-tabs > .ivu-tabs.ivu-tabs-card > .ivu-tabs-bar .ivu-tabs-tab {
  width: 160px;
  height: 48px;
  font-size: 24px;
  color: #666666;
  margin-right: 15px;
  text-align: center;
}

.sx-tabs > .ivu-tabs-card > .ivu-tabs-bar .ivu-tabs-tab-active {
  /**color: #2d8cf0!important;*/
  color: RGB(246, 116, 4) !important;
}

.sx-tabs > .ivu-tabs.ivu-tabs-card > .ivu-tabs-bar .ivu-tabs-tab-active {
  height: 50px;
}
/*加盟主色*/
.blue {
  color: #5dadff;
}
.red {
  color: #f54203;
}

/*分页样式*/

.page-style .ivu-page-item-active {
  background-color: #f54203;
  border-color: #f54203;
}

.page-style .ivu-page-item:hover {
  border-color: #f54203;
}

.page-style .ivu-page-item:hover a {
  color: #f54203;
}

.page-style .ivu-page-next:hover,
.page-style .ivu-page-prev:hover {
  border-color: #f54203;
}

.page-style .ivu-page-next:hover a,
.page-style .ivu-page-prev:hover a {
  color: #f54203;
}

.page-style .ivu-page-item-active a,
.page-style .ivu-page-item-active:hover a {
  color: #fff;
}

/** 事件插件 样式修改 */

.time-style .ivu-date-picker-cells-cell-selected em,
.time-style .ivu-date-picker-cells-cell-selected:hover em {
  background: #f54203;
  color: #fff;
}

/** 单选框 样式修改 */

.radio-style .ivu-radio-checked .ivu-radio-inner {
  border-color: #f54203;
}

.radio-style .ivu-radio-inner:after {
  background-color: #f54203;
}

/*二维码  */

.qrcode img {
  margin: 0 auto;
}

/*h5  */

.h5-container {
  max-width: 12.037rem;
  margin: 0 auto;
}

.h5-container a {
  color: #f54203;
}

.h5-header {
  font-size: 28px;
  text-align: center;
  border-bottom: 1px solid #dddee1;
  padding: 0.481rem 0.703rem;
  color: #282828;
}

.h5-header .btn {
  float: left;
  min-width: 1rem;
  color: #282828;
}

.h5-logo {
  text-align: center;
  margin: 2.111rem auto 3.777rem;
  max-width: 7.444rem;
  width: 100%;
}

.h5-logo img {
  width: 100%;
}

.h5-input {
  height: 1.37rem;
  display: flex;
  margin: 0.666rem 0;
  border: 1px solid #dddee1;
  border-radius: 6px;
}

.h5-input .icon {
  min-width: 1.388rem;
  width: 1.388rem;
  background-color: #dddee1;
  text-align: center;
  float: left;
  padding: 0.4rem 0;
  border-top-left-radius: 6px;
  border-bottom-left-radius: 6px;
  background-position: center center;
  background-repeat: no-repeat;
}

.h5-input .input {
  height: 1.3rem;
  font-size: 16px;
  text-indent: 0.444rem;
  color: #888888;
  width: 100%;
  border: none;
  border-top-right-radius: 6px;
  border-bottom-right-radius: 6px;
}

.h5-form {
  padding: 0 1.055rem;
}

.h5-form .btn {
  width: 100%;
  color: #fff;
  border: none;
  border-radius: 5px;
  font-size: 28px;
  padding: 0.26rem 0;
  margin-top: 1rem;
}

.h5-form .btn.err-msg,
.h5-form .btn.success {
  margin-top: 0.2rem;
}

.h5-form .btn.primary {
  background-color: #f54203;
}

.h5-footer {
  margin-top: 2.841rem;
  text-align: center;
  font-size: 24px;
  margin-bottom: 1rem;
  color: #282828;
}

.h5-form p.err-msg {
  font-size: 16px;
  color: #ff3030;
  margin: 0.2rem 0;
}

.h5-form p.success {
  font-size: 16px;
  color: #19be6b;
  margin: 0.2rem 0;
}

.h5-input img.verifycode {
  width: 2.4rem;
}

.h5-input a.disabled {
  cursor: not-allowed;
  color: #888888;
}

/** input placeholder 颜色修改*/
input {
  outline: none;
}
input::-webkit-input-placeholder,
textarea::-webkit-input-placeholder {
  color: #bababa;
}
input:-moz-placeholder,
textarea:-moz-placeholder {
  color: #bababa;
}
input::-moz-placeholder,
textarea::-moz-placeholder {
  color: #bababa;
}
input:-ms-input-placeholder,
textarea:-ms-input-placeholder {
  color: #bababa;
}
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none !important;
  margin: 0;
}
</style>
