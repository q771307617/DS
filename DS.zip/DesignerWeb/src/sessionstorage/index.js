/* eslint-disable */
const setItem = (key, data) => {
  if (!data || !key) return;
  sessionStorage.setItem(key, JSON.stringify(data));
};

const getItem = key => {
  if (!key) return;
  let data = sessionStorage.getItem(key);
  if (!data) return;
  return JSON.parse(data);
};

const removeItem = key => {
  if (!key) return;
  sessionStorage.removeItem(key);
};

// 用户信息
const USER = 'USER';
export const user = {
  set: data => {
    setItem(USER, data);
  },
  get: () => {
    return getItem(USER);
  }
};

// 区域（例如:首页、详情页模板...）
const TYPES = 'TYPES';
export const types = {
  set: data => {
    setItem(TYPES, data);
  },
  get: () => {
    return getItem(TYPES);
  }
};

// 分类（例如:服装内衣、母婴玩具...）
const CATES = 'CATES';
export const cates = {
  set: data => {
    setItem(CATES, data);
  },
  get: () => {
    return getItem(CATES);
  }
};
