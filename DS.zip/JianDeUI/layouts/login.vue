<template>
    <div class="login">
      <!-- <p class="three">@2017 jiandezhengfuxinxi  Reserved.   浙ICP备案15043816号-1  浙公网安备 33010902000325</p> -->
      <nuxt/>
  </div>
</template>
<script>
export default {
  data() {
    return {
    };
  }
};
</script>
<style lang="scss" scoped>
.login{
  position: relative;
  min-width: 1200px;
  .three{
    position: absolute;
    z-index: 10;
    left: 695px;
    top: 920px;
    font-size:12px;
    color:#ffffff;
  }
}
</style>



