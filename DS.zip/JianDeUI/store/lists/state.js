export default {
  AllTownShip: [], // 所有乡镇
  AllIndustry: [], // 所有行业
  scale: [
    // 规模
    { key: '1', name: '规上' },
    { key: '2', name: '规下' }
  ]
};
