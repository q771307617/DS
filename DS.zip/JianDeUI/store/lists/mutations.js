export default {
  ALL_TOWN_SHIP(state, data) {
    state.AllTownShip = data;
  },
  ALL_INDUSTRY(state, data) {
    state.AllIndustry = data;
  }
};
