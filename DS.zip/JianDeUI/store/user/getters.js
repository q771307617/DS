export default {
  // permissions: state => {
  //   return state.info.permissions || [];
  // },
  // hasPermissions: (state, getters) => permission => {
  //   return getters.permissions.includes(permission);
  // }
};
