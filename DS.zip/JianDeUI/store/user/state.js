export default {
  info: {}
};
