export default {
  SET_USER_DATA(state, data) {
    state.info = data;
  }
};
