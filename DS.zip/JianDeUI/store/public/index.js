import state from './state.js';

export default {
  state
};
