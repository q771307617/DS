import Vue from 'vue';
import Element from 'element-ui';

Vue.use(Element);
