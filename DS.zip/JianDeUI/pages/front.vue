<template>
  <div class='hello'>
    <nuxt-child/>
  </div>
</template>
<script src=" http://api.tianditu.com/api?v=4.0" type="text/javascript"></script>
<script type="text/javascript" src="http://lbs.tianditu.com/api/js4.0/opensource/openlibrary/ImageOverlay.js"></script>
<script>
export default {
  layout: 'index',
  data() {
    return {
    };
  }
};
</script>
