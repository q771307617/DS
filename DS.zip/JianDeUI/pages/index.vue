<template>
  <div class='hello'>
    <nuxt-child/>
  </div>
</template>

<script>
export default {
  layout: 'login',
  data() {
    return {
    };
  }
};
</script>
