<template>
  <div class='hello'>
    <nuxt-child/>
  </div>
</template>

<script>
export default {
  layout: 'admin',
  data() {
    return {
    };
  }
};
</script>


<style scoped>

</style>
